from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec


class ECAdapter:

    def generate_private_key(self):
        return ec.generate_private_key(ec.SECP521R1())

    def get_public_key(self, private_key):
        return private_key.public_key()

    def serialize_public_key(self, public_key):
        return public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )

    def serialize_private_key(self, private_key, password=None):
        return private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.BestAvailableEncryption(password) if password is not None else serialization.NoEncryption(),
        )

    def load_private_key_pem(self, data, password=None):
        return serialization.load_pem_private_key(data, password=password)

    def load_public_key_pem(self, data):
        return serialization.load_pem_public_key(data)

    def sign(self, private_key, data):
        return private_key.sign(data, ec.ECDSA(hashes.SHA256()))

    def verify(self, public_key, signature, data):
        return public_key.verify(signature, data, ec.ECDSA(hashes.SHA256()))
