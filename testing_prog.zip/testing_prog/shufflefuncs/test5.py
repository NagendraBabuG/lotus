class Greeter:
    def greet(self):
        self.say_hi()

    def say_hi(self):
        print("Hi!")
