import builtins
import sys
from pathlib import Path

import libcst as cst


_EMPTY_MODULE = cst.Module([])

BUILTIN_NAMES = set(dir(builtins))
LITERAL_NAMES = {"None", "True", "False", "Ellipsis", "NotImplemented"}

CLASSICAL_ALGORITHMS = {
    "X25519PrivateKey",
    "X25519PublicKey",
    "X448PrivateKey",
    "X448PublicKey",
    "EllipticCurvePrivateKey",
    "EllipticCurvePublicKey",
    "DHPrivateKey",
    "DHPublicKey",
    "DHParameters",
}

CLASSICAL_ALGORITHM_SET = {"X25519", "X448", "EC", "DH"}

CLASSICAL_PRIVATE_TYPE_MAP = {
    "X25519": "X25519PrivateKey",
    "X448": "X448PrivateKey",
    "EC": "EllipticCurvePrivateKey",
    "DH": "DHPrivateKey",
}

CLASSICAL_MODULES = {"x25519", "x448", "ec", "dh"}

PQC_ALGORITHMS = (
    "MLKEM1024",
    "MLKEM768",
    "MLKEM512",
)

PQC_ALGORITHM_SET = set(PQC_ALGORITHMS)

PQC_CLASSES = {
    f"{algorithm}{suffix}"
    for algorithm in PQC_ALGORITHMS
    for suffix in ("PrivateKey", "PublicKey")
}

MODULE_CLASS_MAP = {
    "x25519": {"X25519PrivateKey", "X25519PublicKey"},
    "x448": {"X448PrivateKey", "X448PublicKey"},
    "ec": {"EllipticCurvePrivateKey", "EllipticCurvePublicKey"},
    "dh": {"DHPrivateKey", "DHPublicKey", "DHParameters"},
    "mlkem": PQC_CLASSES,
}

MODULE_PATHS = {
    "x25519": "cryptography.hazmat.primitives.asymmetric.x25519",
    "x448": "cryptography.hazmat.primitives.asymmetric.x448",
    "dh": "cryptography.hazmat.primitives.asymmetric.dh",
    "mlkem": "cryptography.hazmat.primitives.asymmetric.mlkem",
}

STDLIB_IMPORTS = {
    "base64": "import base64",
    "hashlib": "import hashlib",
}

KEY_BYTE_LENGTHS = {
    ("X25519PrivateKey", "from_private_bytes"): 32,
    ("X25519PublicKey", "from_public_bytes"): 32,
    ("X448PrivateKey", "from_private_bytes"): 56,
    ("X448PublicKey", "from_public_bytes"): 56,
    ("MLKEM512PrivateKey", "from_seed_bytes"): 64,
    ("MLKEM768PrivateKey", "from_seed_bytes"): 64,
    ("MLKEM1024PrivateKey", "from_seed_bytes"): 64,
    ("MLKEM512PublicKey", "from_public_bytes"): 800,
    ("MLKEM768PublicKey", "from_public_bytes"): 1184,
    ("MLKEM1024PublicKey", "from_public_bytes"): 1568,
}

DIRECT_FUNCTION_GENERATORS = {
    ("cryptography.hazmat.primitives.asymmetric.ec", "generate_private_key"): (
        "ec",
        "generate_private_key",
        "EllipticCurvePrivateKey",
        "EC",
    ),
    ("cryptography.hazmat.primitives.asymmetric.dh", "generate_parameters"): (
        "dh",
        "generate_parameters",
        "DHParameters",
        "DH",
    ),
}

INSTANCE_RESULT_TYPES = {
    ("DHParameters", "generate_private_key"): ("DHPrivateKey", False, "DH"),
    ("DHPrivateKey", "public_key"): ("DHPublicKey", False, "DH"),
    ("DHPrivateKey", "parameters"): ("DHParameters", False, "DH"),
    ("DHPublicKey", "parameters"): ("DHParameters", False, "DH"),
    ("X25519PrivateKey", "public_key"): ("X25519PublicKey", False, "X25519"),
    ("X448PrivateKey", "public_key"): ("X448PublicKey", False, "X448"),
    ("EllipticCurvePrivateKey", "public_key"): (
        "EllipticCurvePublicKey",
        False,
        "EC",
    ),
    **{
        (f"{alg}PrivateKey", "public_key"): (f"{alg}PublicKey", True, alg)
        for alg in PQC_ALGORITHMS
    },
}

METHOD_NAME_MAP = {
    "generate": "generate_private_key",
    "generate_private_key": "generate_private_key",
    "generate_parameters": "generate_parameters",
    "from_private_bytes": "load_private_key",
    "from_public_bytes": "load_public_key",
    "from_seed_bytes": "load_private_key",
    "private_bytes": "serialize_private_key",
    "public_bytes": "serialize_public_key",
    "private_bytes_raw": "serialize_private_key_raw",
    "public_bytes_raw": "serialize_public_key_raw",
    "public_key": "get_public_key",
    "exchange": "exchange",
    "encapsulate": "encapsulate",
    "decapsulate": "decapsulate",
    "sign": "sign",
    "verify": "verify",
}

SERIALIZATION_PARAM_ORDER = {
    "private_bytes": ("encoding", "format", "encryption_algorithm"),
    "public_bytes": ("encoding", "format"),
}

PRIVATE_KEY_TRIGGER_METHODS = {
    "generate",
    "generate_private_key",
    "from_seed_bytes",
    "from_private_bytes",
    "private_bytes",
    "private_bytes_raw",
    "exchange",
    "decapsulate",
    "sign",
}

CURVE_PREFIXES = ("SECP", "SECT", "Brainpool")
HASH_PREFIXES = ("SHA", "BLAKE2", "MD5")


def _code(node):
    return _EMPTY_MODULE.code_for_node(node)


def _full_name(node):
    try:
        return cst.helpers.get_full_name_for_node(node)
    except Exception:
        return None


def _uses_base64_decode(call):
    all_args = list(call.arguments) + list(call.keywords.values())
    return any("b64decode" in arg for arg in all_args)


def _collect_free_names(expr_str):
    try:
        tree = cst.parse_expression(expr_str)
    except Exception:
        return None

    names = set()

    class FreeNameCollector(cst.CSTVisitor):
        def visit_Arg(self, node):
            node.value.visit(self)
            return False

        def visit_Attribute(self, node):
            node.value.visit(self)
            return False

        def visit_Name(self, node):
            names.add(node.value)

    tree.visit(FreeNameCollector())
    return names


def _is_int_literal(expr_str):
    try:
        node = cst.parse_expression(expr_str)
        return isinstance(node, cst.Integer)
    except Exception:
        return False


def _collect_referenced_names(class_code):
    """Collect free top-level names referenced anywhere in the generated class."""
    referenced = set()

    class ReferenceCollector(cst.CSTVisitor):
        def __init__(self):
            self.scope_stack = []

        def visit_FunctionDef(self, node):
            for param in (
                list(node.params.posonly_params)
                + list(node.params.params)
                + list(node.params.kwonly_params)
            ):
                if param.default is not None:
                    param.default.visit(self)

            params = {
                p.name.value
                for p in (
                    list(node.params.posonly_params)
                    + list(node.params.params)
                    + list(node.params.kwonly_params)
                )
            }
            if isinstance(node.params.star_arg, cst.Param):
                params.add(node.params.star_arg.name.value)
            if node.params.star_kwarg:
                params.add(node.params.star_kwarg.name.value)

            self.scope_stack.append(params)
            node.body.visit(self)
            self.scope_stack.pop()
            return False

        def visit_Assign(self, node):
            node.value.visit(self)
            if self.scope_stack:
                for target in node.targets:
                    if isinstance(target.target, cst.Name):
                        self.scope_stack[-1].add(target.target.value)
            return False

        def visit_Arg(self, node):
            node.value.visit(self)
            return False

        def visit_Attribute(self, node):
            node.value.visit(self)
            return False

        def visit_Name(self, node):
            name = node.value
            if name in BUILTIN_NAMES or name in LITERAL_NAMES:
                return
            for scope in self.scope_stack:
                if name in scope:
                    return
            referenced.add(name)

    try:
        tree = cst.parse_module(class_code)
        tree.visit(ReferenceCollector())
    except Exception:
        pass

    return referenced


class CryptoCall:

    def __init__(
        self,
        name,
        receiver,
        arguments,
        keywords,
        receiver_type=None,
        is_class_method=False,
        is_pqc=False,
        algorithm=None,
        resolved_curve=None,
        resolved_signature_algorithm=None,
    ):
        self.name = name
        self.receiver = receiver
        self.arguments = arguments
        self.keywords = keywords
        self.receiver_type = receiver_type
        self.is_class_method = is_class_method
        self.is_pqc = is_pqc
        self.algorithm = algorithm
        self.resolved_curve = resolved_curve
        self.resolved_signature_algorithm = resolved_signature_algorithm


class HybridCallExtractor(cst.CSTVisitor):

    def __init__(self):
        self.crypto_calls = []
        self.variables = {}
        self.import_aliases = {}
        self.module_aliases = {}
        self.hash_module_aliases = {"hashes"}
        self.direct_func_aliases = {}
        self.direct_curve_aliases = {}
        self.direct_hash_aliases = set()
        self.direct_ecdh_aliases = set()
        self.ec_config_values = {}

        # (import_code, bound_names_set)
        self.imports = []
        self._seen_import_codes = set()
        self.imported_names = set()

        self.classical_algorithms_order = []
        self.last_classical_algorithm = None
        self.unresolved_classical_calls = []

        self.pqc_algorithms_order = []
        self.last_pqc_algorithm = None
        self.unresolved_pqc_calls = []

        self._scope_snapshots = []

    def _record_import(self, import_code, bound_names):
        if import_code not in self._seen_import_codes:
            self._seen_import_codes.add(import_code)
            self.imports.append((import_code, set(bound_names)))

    def _register_algorithm(self, algorithm, is_pqc):
        if is_pqc:
            if algorithm not in PQC_ALGORITHM_SET:
                return
            if algorithm not in self.pqc_algorithms_order:
                self.pqc_algorithms_order.append(algorithm)
            self.last_pqc_algorithm = algorithm
        else:
            if algorithm not in CLASSICAL_ALGORITHM_SET:
                return
            if algorithm not in self.classical_algorithms_order:
                self.classical_algorithms_order.append(algorithm)
            self.last_classical_algorithm = algorithm

    def _resolve_name(self, name):
        return self.import_aliases.get(name, name)

    def _get_algorithm(self, class_name, is_pqc=False):
        if not class_name:
            return None

        if is_pqc:
            for algorithm in PQC_ALGORITHMS:
                if algorithm in class_name:
                    return algorithm

        if "X25519" in class_name:
            return "X25519"

        if "X448" in class_name:
            return "X448"

        if "EllipticCurve" in class_name or class_name == "ec":
            return "EC"

        if "DH" in class_name or class_name == "dh":
            return "DH"

        return class_name

    def _resolve_module_name(self, owner_node):
        if isinstance(owner_node, cst.Name):
            name = owner_node.value
            canonical = self.module_aliases.get(name, name)
            if canonical in MODULE_CLASS_MAP:
                return canonical
            return None

        full = _full_name(owner_node)
        if full:
            leaf = full.split(".")[-1]
            if full.startswith("cryptography.") and leaf in MODULE_CLASS_MAP:
                return leaf
            canonical = self.module_aliases.get(full)
            if canonical in MODULE_CLASS_MAP:
                return canonical

        return None

    def _is_ecdh_expression(self, expr_str):
        compact = expr_str.replace(" ", "")
        if compact == "ec.ECDH()":
            return True
        for alias, canonical in self.module_aliases.items():
            if canonical == "ec" and compact == f"{alias}.ECDH()":
                return True
        for alias in self.direct_ecdh_aliases:
            if compact == f"{alias}()":
                return True
        return False

    def _get_ec_config_kind(self, expression):
        if not isinstance(expression, cst.Call):
            return None

        func = expression.func
        if isinstance(func, cst.Attribute):
            attr = func.attr.value
            mod = self._resolve_module_name(func.value)
            if mod == "ec" and attr.startswith(CURVE_PREFIXES):
                return "curve"
            if (
                isinstance(func.value, cst.Name)
                and func.value.value in self.hash_module_aliases
                and attr.startswith(HASH_PREFIXES)
            ):
                return "hash"

        if isinstance(func, cst.Name):
            if func.value in self.direct_curve_aliases:
                return "curve"
            if func.value in self.direct_hash_aliases:
                return "hash"

        return None

    def _normalize_curve_expression(self, expr_str):
        try:
            expression = cst.parse_expression(expr_str)
        except Exception:
            return None

        class CurveVarResolver(cst.CSTTransformer):
            def __init__(self, values):
                self.values = values

            def leave_Name(self, original_node, updated_node):
                item = self.values.get(original_node.value)
                if item is None or item[0] != "curve":
                    return updated_node
                try:
                    return cst.parse_expression(item[1])
                except Exception:
                    return updated_node

        for _ in range(5):
            updated = expression.visit(CurveVarResolver(self.ec_config_values))
            if updated.deep_equals(expression):
                break
            expression = updated

        if not isinstance(expression, cst.Call):
            return None

        func = expression.func
        curve_name = None

        if isinstance(func, cst.Attribute):
            mod = self._resolve_module_name(func.value)
            if mod == "ec" and func.attr.value.startswith(CURVE_PREFIXES):
                curve_name = func.attr.value
        elif isinstance(func, cst.Name):
            if func.value in self.direct_curve_aliases:
                curve_name = self.direct_curve_aliases[func.value]
            elif func.value.startswith(CURVE_PREFIXES):
                curve_name = func.value

        if not curve_name:
            return None

        normalized = expression.with_changes(
            func=cst.Attribute(
                value=cst.Name("ec"),
                attr=cst.Name(curve_name),
            )
        )
        return _code(normalized)

    def _resolve_hash_vars(self, expr_str):
        try:
            expression = cst.parse_expression(expr_str)
        except Exception:
            return expr_str

        class HashVarResolver(cst.CSTTransformer):
            def __init__(self, values):
                self.values = values

            def leave_Name(self, original_node, updated_node):
                item = self.values.get(original_node.value)
                if item is None or item[0] != "hash":
                    return updated_node
                try:
                    return cst.parse_expression(item[1])
                except Exception:
                    return updated_node

        for _ in range(5):
            updated = expression.visit(HashVarResolver(self.ec_config_values))
            if updated.deep_equals(expression):
                break
            expression = updated

        return _code(expression)

    def _get_class_info(self, func):
        if not isinstance(func, cst.Attribute):
            return None

        owner = func.value

        if isinstance(owner, cst.Name):
            class_name = self._resolve_name(owner.value)

            if class_name in CLASSICAL_ALGORITHMS:
                return (
                    class_name,
                    False,
                    self._get_algorithm(class_name, False),
                )

            if class_name in PQC_CLASSES:
                return (
                    class_name,
                    True,
                    self._get_algorithm(class_name, True),
                )

        if isinstance(owner, cst.Attribute):
            module_name = self._resolve_module_name(owner.value)
            class_name = owner.attr.value

            if module_name and class_name in MODULE_CLASS_MAP.get(module_name, set()):
                is_pqc = module_name == "mlkem"
                return (
                    class_name,
                    is_pqc,
                    self._get_algorithm(class_name, is_pqc),
                )

        return None

    def _get_module_func_call(self, func):
        if isinstance(func, cst.Name):
            if func.value in self.direct_func_aliases:
                return self.direct_func_aliases[func.value]
            return None

        if isinstance(func, cst.Attribute):
            method_name = func.attr.value
            module_name = self._resolve_module_name(func.value)

            if module_name == "ec" and method_name == "generate_private_key":
                return ("ec", "generate_private_key", "EllipticCurvePrivateKey", "EC")

            if module_name == "dh" and method_name == "generate_parameters":
                return ("dh", "generate_parameters", "DHParameters", "DH")

        return None

    def _infer_call_result_info(self, call_node):
        mod_call = self._get_module_func_call(call_node.func)
        if mod_call:
            _, _, result_type, algorithm = mod_call
            return (result_type, False, algorithm)

        class_info = self._get_class_info(call_node.func)
        if class_info:
            return class_info

        if isinstance(call_node.func, cst.Attribute):
            receiver_info = self._get_receiver_info(call_node.func.value)
            if receiver_info:
                receiver_type, _, _ = receiver_info
                return INSTANCE_RESULT_TYPES.get(
                    (receiver_type, call_node.func.attr.value)
                )

        return None

    def _get_receiver_info(self, receiver):
        if isinstance(receiver, cst.Call):
            return self._infer_call_result_info(receiver)

        receiver_name = _full_name(receiver) or _code(receiver)
        if receiver_name in self.variables:
            return self.variables[receiver_name]

        if isinstance(receiver, cst.Name):
            return self.variables.get(receiver.value)

        return None

    def _extract_args(self, args):
        positional = []
        keywords = {}

        for arg in args:
            value = _code(arg.value)
            if arg.keyword:
                keywords[arg.keyword.value] = value
            else:
                positional.append(value)

        return positional, keywords

    def _get_target_names(self, target):
        if isinstance(target, cst.Name):
            return [target.value]
        if isinstance(target, cst.Attribute):
            return [_full_name(target) or _code(target)]
        return []

    def _clear_target_bindings(self, target):
        if isinstance(target, (cst.Name, cst.Attribute)):
            for name in self._get_target_names(target):
                self.variables.pop(name, None)
        elif isinstance(target, (cst.Tuple, cst.List)):
            for element in target.elements:
                self._clear_target_bindings(element.value)

    def _resolve_annotation_info(self, annotation_node):
        if annotation_node is None:
            return None

        ann_expr = annotation_node.annotation
        ann_name = None
        if isinstance(ann_expr, cst.Name):
            ann_name = self._resolve_name(ann_expr.value)
        elif isinstance(ann_expr, cst.Attribute):
            ann_name = ann_expr.attr.value

        if ann_name in CLASSICAL_ALGORITHMS:
            return (ann_name, False, self._get_algorithm(ann_name, False))
        if ann_name in PQC_CLASSES:
            return (ann_name, True, self._get_algorithm(ann_name, True))
        return None

    def _track_assignment(self, target, value, annotation_node=None):
        if isinstance(target, (cst.Tuple, cst.List)):
            self._clear_target_bindings(target)
            return

        target_names = self._get_target_names(target)
        if not target_names:
            return

        if isinstance(value, cst.Call):
            config_kind = self._get_ec_config_kind(value)
            if config_kind:
                config_code = _code(value)
                for name in target_names:
                    self.ec_config_values[name] = (config_kind, config_code)
                    self.variables.pop(name, None)
                return

        if isinstance(value, (cst.Name, cst.Attribute)):
            src_name = _full_name(value) or _code(value)
            if src_name in self.ec_config_values:
                for name in target_names:
                    self.ec_config_values[name] = self.ec_config_values[src_name]
            if src_name in self.variables:
                info = self.variables[src_name]
                for name in target_names:
                    self.variables[name] = info
                return

        info = None
        if isinstance(value, cst.Call):
            info = self._infer_call_result_info(value)

        if info is None and annotation_node is not None:
            info = self._resolve_annotation_info(annotation_node)

        if info:
            _, is_pqc, algorithm = info
            self._register_algorithm(algorithm, is_pqc)
            for name in target_names:
                self.variables[name] = info
        else:
            for name in target_names:
                self.variables.pop(name, None)

    def visit_ImportFrom(self, node):
        if not node.module:
            return

        module_name = _code(node.module)
        import_code = _code(node)
        is_crypto = module_name.startswith("cryptography")

        if isinstance(node.names, cst.ImportStar):
            self._record_import(import_code, set())
            return

        bound_names = set()

        for item in node.names:
            imported_name = item.name.value
            alias = item.asname.name.value if item.asname else imported_name

            bound_names.add(alias)
            self.imported_names.add(alias)

            if not is_crypto:
                continue

            if imported_name in CLASSICAL_ALGORITHMS or imported_name in PQC_CLASSES:
                self.import_aliases[alias] = imported_name

            if imported_name in MODULE_CLASS_MAP:
                self.module_aliases[alias] = imported_name

            if imported_name == "hashes":
                self.hash_module_aliases.add(alias)

            func_key = (module_name, imported_name)
            if func_key in DIRECT_FUNCTION_GENERATORS:
                self.direct_func_aliases[alias] = DIRECT_FUNCTION_GENERATORS[func_key]

            if module_name.endswith(".ec"):
                if imported_name.startswith(CURVE_PREFIXES):
                    self.direct_curve_aliases[alias] = imported_name
                elif imported_name == "ECDH":
                    self.direct_ecdh_aliases.add(alias)

            if module_name.endswith(".hashes") and imported_name.startswith(HASH_PREFIXES):
                self.direct_hash_aliases.add(alias)

        self._record_import(import_code, bound_names)

    def visit_Import(self, node):
        import_code = _code(node)
        bound_names = set()

        for item in node.names:
            module_name = _code(item.name)
            short_name = module_name.split(".")[-1]
            alias = (
                item.asname.name.value
                if item.asname
                else module_name.split(".")[0]
            )
            bound_names.add(alias)
            self.imported_names.add(alias)

            if not module_name.startswith("cryptography"):
                continue

            if item.asname:
                if short_name in MODULE_CLASS_MAP:
                    self.module_aliases[alias] = short_name
                elif short_name == "hashes":
                    self.hash_module_aliases.add(alias)
            elif short_name in MODULE_CLASS_MAP:
                self.module_aliases[module_name] = short_name

        self._record_import(import_code, bound_names)

    def visit_FunctionDef(self, node):
        self._scope_snapshots.append(
            (dict(self.variables), dict(self.ec_config_values))
        )

        all_params = (
            list(node.params.posonly_params)
            + list(node.params.params)
            + list(node.params.kwonly_params)
        )
        for param in all_params:
            info = self._resolve_annotation_info(param.annotation)
            if info:
                self.variables[param.name.value] = info
                self._register_algorithm(info[2], info[1])

    def leave_FunctionDef(self, original_node):
        if not self._scope_snapshots:
            return

        prev_vars, prev_ec = self._scope_snapshots.pop()
        attr_vars = {k: v for k, v in self.variables.items() if "." in k}
        self.variables = {**prev_vars, **attr_vars}
        self.ec_config_values = prev_ec

    def leave_Assign(self, original_node):
        for assignment_target in original_node.targets:
            self._track_assignment(
                assignment_target.target,
                original_node.value,
            )

    def leave_AnnAssign(self, original_node):
        self._track_assignment(
            original_node.target,
            original_node.value,
            annotation_node=original_node.annotation,
        )

    def visit_Call(self, node):
        mod_call = self._get_module_func_call(node.func)
        if mod_call:
            module_name, method_name, _, algorithm = mod_call
            self._register_algorithm(algorithm, False)
            positional, keywords = self._extract_args(node.args)

            resolved_curve = None
            if module_name == "ec" and method_name == "generate_private_key":
                raw_curve = (
                    positional[0]
                    if positional
                    else keywords.get("curve")
                )
                if raw_curve:
                    resolved_curve = self._normalize_curve_expression(raw_curve)

            self.crypto_calls.append(
                CryptoCall(
                    name=method_name,
                    receiver=module_name,
                    arguments=positional,
                    keywords=keywords,
                    receiver_type=module_name,
                    is_class_method=True,
                    is_pqc=False,
                    algorithm=algorithm,
                    resolved_curve=resolved_curve,
                )
            )
            return

        if not isinstance(node.func, cst.Attribute):
            return

        method_name = node.func.attr.value
        receiver = node.func.value

        class_info = self._get_class_info(node.func)
        if class_info:
            class_name, is_pqc, algorithm = class_info
            self._register_algorithm(algorithm, is_pqc)

            positional, keywords = self._extract_args(node.args)

            self.crypto_calls.append(
                CryptoCall(
                    name=method_name,
                    receiver=class_name,
                    arguments=positional,
                    keywords=keywords,
                    receiver_type=class_name,
                    is_class_method=True,
                    is_pqc=is_pqc,
                    algorithm=algorithm,
                )
            )
            return

        receiver_info = self._get_receiver_info(receiver)
        if receiver_info:
            class_name, is_pqc, algorithm = receiver_info
            self._register_algorithm(algorithm, is_pqc)

            positional, keywords = self._extract_args(node.args)

            resolved_sig_alg = None
            if class_name in {"EllipticCurvePrivateKey", "EllipticCurvePublicKey"}:
                if method_name == "sign":
                    raw_alg = (
                        positional[1]
                        if len(positional) >= 2
                        else keywords.get("signature_algorithm")
                    )
                    if raw_alg:
                        resolved_sig_alg = self._resolve_hash_vars(raw_alg)
                elif method_name == "verify":
                    raw_alg = (
                        positional[2]
                        if len(positional) >= 3
                        else keywords.get("signature_algorithm")
                    )
                    if raw_alg:
                        resolved_sig_alg = self._resolve_hash_vars(raw_alg)

            self.crypto_calls.append(
                CryptoCall(
                    name=method_name,
                    receiver=_code(receiver),
                    arguments=positional,
                    keywords=keywords,
                    receiver_type=class_name,
                    is_class_method=False,
                    is_pqc=is_pqc,
                    algorithm=algorithm,
                    resolved_signature_algorithm=resolved_sig_alg,
                )
            )
            return

        # Untracked fallback for uniquely PQC KEM operations (e.g., untyped helper params)
        if method_name in {"encapsulate", "decapsulate"}:
            positional, keywords = self._extract_args(node.args)
            total_args = len(positional) + len(keywords)
            expected_args = 0 if method_name == "encapsulate" else 1
            if total_args != expected_args:
                return

            if self.last_pqc_algorithm:
                alg = self.last_pqc_algorithm
                suffix = "PublicKey" if method_name == "encapsulate" else "PrivateKey"
                self.crypto_calls.append(
                    CryptoCall(
                        name=method_name,
                        receiver=_code(receiver),
                        arguments=positional,
                        keywords=keywords,
                        receiver_type=f"{alg}{suffix}",
                        is_class_method=False,
                        is_pqc=True,
                        algorithm=alg,
                    )
                )
            else:
                self.unresolved_pqc_calls.append(
                    (method_name, _code(receiver), positional, keywords)
                )
            return

        # Untracked fallback for classical KEX exchange() in untyped helper functions
        if method_name == "exchange":
            positional, keywords = self._extract_args(node.args)
            total_args = len(positional) + len(keywords)
            if total_args not in (1, 2):
                return

            is_ecdh = (
                (positional and self._is_ecdh_expression(positional[0]))
                or (
                    "algorithm" in keywords
                    and self._is_ecdh_expression(keywords["algorithm"])
                )
            )

            if is_ecdh:
                self._register_algorithm("EC", False)
                self.crypto_calls.append(
                    CryptoCall(
                        name=method_name,
                        receiver=_code(receiver),
                        arguments=positional,
                        keywords=keywords,
                        receiver_type="EllipticCurvePrivateKey",
                        is_class_method=False,
                        is_pqc=False,
                        algorithm="EC",
                    )
                )
            elif total_args == 1 and self.last_classical_algorithm:
                alg = self.last_classical_algorithm
                self.crypto_calls.append(
                    CryptoCall(
                        name=method_name,
                        receiver=_code(receiver),
                        arguments=positional,
                        keywords=keywords,
                        receiver_type=CLASSICAL_PRIVATE_TYPE_MAP[alg],
                        is_class_method=False,
                        is_pqc=False,
                        algorithm=alg,
                    )
                )
            elif total_args == 1:
                self.unresolved_classical_calls.append(
                    (method_name, _code(receiver), positional, keywords)
                )

    def leave_Module(self, original_node):
        if self.unresolved_pqc_calls and self.pqc_algorithms_order:
            fallback_pqc = self.pqc_algorithms_order[0]
            for method_name, receiver_str, positional, keywords in self.unresolved_pqc_calls:
                suffix = "PublicKey" if method_name == "encapsulate" else "PrivateKey"
                self.crypto_calls.append(
                    CryptoCall(
                        name=method_name,
                        receiver=receiver_str,
                        arguments=positional,
                        keywords=keywords,
                        receiver_type=f"{fallback_pqc}{suffix}",
                        is_class_method=False,
                        is_pqc=True,
                        algorithm=fallback_pqc,
                    )
                )

        if self.unresolved_classical_calls and self.classical_algorithms_order:
            fallback_classical = self.classical_algorithms_order[0]
            priv_type = CLASSICAL_PRIVATE_TYPE_MAP[fallback_classical]
            for method_name, receiver_str, positional, keywords in self.unresolved_classical_calls:
                self.crypto_calls.append(
                    CryptoCall(
                        name=method_name,
                        receiver=receiver_str,
                        arguments=positional,
                        keywords=keywords,
                        receiver_type=priv_type,
                        is_class_method=False,
                        is_pqc=False,
                        algorithm=fallback_classical,
                    )
                )


def get_algorithm(crypto_calls, is_pqc):
    for call in crypto_calls:
        if call.is_pqc == is_pqc and call.algorithm:
            return call.algorithm
    return None


def get_adapter_name(crypto_calls):
    classical_algorithm = get_algorithm(crypto_calls, False)
    pqc_algorithm = get_algorithm(crypto_calls, True)

    if classical_algorithm and pqc_algorithm:
        return f"{classical_algorithm}{pqc_algorithm}Adapter"

    if pqc_algorithm:
        return f"{pqc_algorithm}Adapter"

    if classical_algorithm:
        return f"{classical_algorithm}Adapter"

    return "CryptoAdapter"


def get_adapter_method_name(call):
    method = METHOD_NAME_MAP.get(call.name)
    if not method:
        return None
    prefix = "pqc" if call.is_pqc else "classical"
    return f"{prefix}_{method}"


def _build_serialization_params(call, imported_names):
    canonical_order = SERIALIZATION_PARAM_ORDER[call.name]
    bound = {}

    for idx, val in enumerate(call.arguments):
        if idx < len(canonical_order):
            bound[canonical_order[idx]] = val

    for key, val in call.keywords.items():
        if key in canonical_order:
            bound[key] = val

    allowed_names = set(imported_names) | BUILTIN_NAMES | LITERAL_NAMES

    all_have_safe_defaults = len(bound) == len(canonical_order)
    if all_have_safe_defaults:
        for param_name in canonical_order:
            free = _collect_free_names(bound[param_name])
            if free is None or not free.issubset(allowed_names):
                all_have_safe_defaults = False
                break

    if all_have_safe_defaults:
        param_decls = [f"{name}={bound[name]}" for name in canonical_order]
    else:
        param_decls = list(canonical_order)

    call_args = [f"{name}={name}" for name in canonical_order]
    return param_decls, call_args


def _build_normalizer_helper():
    return (
        "    @staticmethod\n"
        "    def _normalize_key_bytes(\n"
        "        data,\n"
        "        expected_len=None,\n"
        "        take_tail=False,\n"
        "        allow_expand=False,\n"
        "        try_b64=False,\n"
        "    ):\n"
        "        if isinstance(data, str):\n"
        "            text = data.strip()\n"
        "            try:\n"
        "                raw = bytes.fromhex(text)\n"
        "            except ValueError:\n"
        "                if try_b64:\n"
        "                    decoder = (\n"
        "                        base64.urlsafe_b64decode\n"
        "                        if ('-' in text or '_' in text)\n"
        "                        else base64.b64decode\n"
        "                    )\n"
        "                    raw = decoder(text)\n"
        "                else:\n"
        "                    raw = text.encode('utf-8')\n"
        "        else:\n"
        "            raw = bytes(data)\n"
        "\n"
        "        if expected_len is None or len(raw) == expected_len:\n"
        "            return raw\n"
        "\n"
        "        if len(raw) == expected_len * 2:\n"
        "            try:\n"
        "                decoded = bytes.fromhex(raw.decode('ascii'))\n"
        "                if len(decoded) == expected_len:\n"
        "                    return decoded\n"
        "            except (UnicodeDecodeError, ValueError):\n"
        "                pass\n"
        "\n"
        "        if try_b64:\n"
        "            try:\n"
        "                decoder = (\n"
        "                    base64.urlsafe_b64decode\n"
        "                    if (b'-' in raw or b'_' in raw)\n"
        "                    else base64.b64decode\n"
        "                )\n"
        "                decoded = decoder(raw)\n"
        "                if len(decoded) == expected_len:\n"
        "                    return decoded\n"
        "            except Exception:\n"
        "                pass\n"
        "\n"
        "        if len(raw) > expected_len:\n"
        "            return raw[-expected_len:] if take_tail else raw[:expected_len]\n"
        "\n"
        "        if allow_expand and len(raw) > 0:\n"
        "            return hashlib.shake_256(raw).digest(expected_len)\n"
        "\n"
        "        return raw\n"
    )


def _format_loader_call(call, param_name):
    expected_len = KEY_BYTE_LENGTHS.get((call.receiver, call.name))
    take_tail = call.is_pqc
    allow_expand = call.name == "from_seed_bytes"
    try_b64 = _uses_base64_decode(call)

    args = [param_name, f"expected_len={expected_len}"]
    if take_tail:
        args.append("take_tail=True")
    if allow_expand:
        args.append("allow_expand=True")
    if try_b64:
        args.append("try_b64=True")

    normalized = f"self._normalize_key_bytes({', '.join(args)})"
    return f"{call.receiver}.{call.name}({normalized})"


def get_method_definition(call, imported_names):
    method_name = get_adapter_method_name(call)
    if not method_name:
        return None

    # EC key generation
    if call.receiver_type == "ec" and call.name == "generate_private_key":
        if call.resolved_curve:
            return (
                f"    def {method_name}(self, curve={call.resolved_curve}):\n"
                "        return ec.generate_private_key(curve)\n"
            )
        return (
            f"    def {method_name}(self, curve):\n"
            "        return ec.generate_private_key(curve)\n"
        )

    # DH parameter generation
    if call.receiver_type == "dh" and call.name == "generate_parameters":
        gen_val = (
            call.arguments[0]
            if len(call.arguments) >= 1
            else call.keywords.get("generator")
        )
        size_val = (
            call.arguments[1]
            if len(call.arguments) >= 2
            else call.keywords.get("key_size")
        )

        if gen_val and size_val and _is_int_literal(gen_val) and _is_int_literal(size_val):
            sig = f"self, generator={gen_val}, key_size={size_val}"
        elif size_val and _is_int_literal(size_val):
            sig = f"self, generator, key_size={size_val}"
        else:
            sig = "self, generator, key_size"

        return (
            f"    def {method_name}({sig}):\n"
            "        return dh.generate_parameters("
            "generator=generator, key_size=key_size)\n"
        )

    # DH private key generation from parameters
    if call.receiver_type == "DHParameters" and call.name == "generate_private_key":
        return (
            f"    def {method_name}(self, parameters):\n"
            "        return parameters.generate_private_key()\n"
        )

    # EC exchange requires ec.ECDH()
    if call.name == "exchange" and call.receiver_type == "EllipticCurvePrivateKey":
        return (
            f"    def {method_name}(self, private_key, peer_public_key):\n"
            "        return private_key.exchange(ec.ECDH(), peer_public_key)\n"
        )

    # Classical and PQC key generation
    if call.name == "generate":
        return (
            f"    def {method_name}(self):\n"
            f"        return {call.receiver}.generate()\n"
        )

    # Classical and PQC key loading (with hex/base64/hybrid length normalization)
    if call.name == "from_seed_bytes":
        loader_expr = _format_loader_call(call, "seed")
        return (
            f"    def {method_name}(self, seed):\n"
            f"        return {loader_expr}\n"
        )

    if call.name == "from_private_bytes":
        loader_expr = _format_loader_call(call, "private_bytes")
        return (
            f"    def {method_name}(self, private_bytes):\n"
            f"        return {loader_expr}\n"
        )

    if call.name == "from_public_bytes":
        loader_expr = _format_loader_call(call, "public_bytes")
        return (
            f"    def {method_name}(self, public_bytes):\n"
            f"        return {loader_expr}\n"
        )

    # Public key extraction
    if call.name == "public_key":
        return (
            f"    def {method_name}(self, private_key):\n"
            "        return private_key.public_key()\n"
        )

    # Key exchange
    if call.name == "exchange":
        return (
            f"    def {method_name}(self, private_key, peer_public_key):\n"
            "        return private_key.exchange(peer_public_key)\n"
        )

    # ML-KEM encapsulation
    if call.name == "encapsulate":
        return (
            f"    def {method_name}(self, public_key):\n"
            "        return public_key.encapsulate()\n"
        )

    # ML-KEM decapsulation
    if call.name == "decapsulate":
        return (
            f"    def {method_name}(self, private_key, ciphertext):\n"
            "        return private_key.decapsulate(ciphertext)\n"
        )

    # Serialization
    if call.name == "private_bytes":
        param_decls, call_args = _build_serialization_params(call, imported_names)
        return (
            f"    def {method_name}(self, private_key, {', '.join(param_decls)}):\n"
            f"        return private_key.private_bytes({', '.join(call_args)})\n"
        )

    if call.name == "public_bytes":
        param_decls, call_args = _build_serialization_params(call, imported_names)
        return (
            f"    def {method_name}(self, public_key, {', '.join(param_decls)}):\n"
            f"        return public_key.public_bytes({', '.join(call_args)})\n"
        )

    if call.name == "private_bytes_raw":
        return (
            f"    def {method_name}(self, private_key):\n"
            "        return private_key.private_bytes_raw()\n"
        )

    if call.name == "public_bytes_raw":
        return (
            f"    def {method_name}(self, public_key):\n"
            "        return public_key.public_bytes_raw()\n"
        )

    # Signature operations
    if call.name == "sign":
        if call.receiver_type == "EllipticCurvePrivateKey":
            allowed = set(imported_names) | BUILTIN_NAMES | LITERAL_NAMES
            alg_expr = call.resolved_signature_algorithm
            free = _collect_free_names(alg_expr) if alg_expr else None
            if alg_expr and free is not None and free.issubset(allowed):
                sig = f"self, private_key, data, signature_algorithm={alg_expr}"
            else:
                sig = "self, private_key, data, signature_algorithm"
            return (
                f"    def {method_name}({sig}):\n"
                "        return private_key.sign(data, signature_algorithm)\n"
            )
        return (
            f"    def {method_name}(self, private_key, data):\n"
            "        return private_key.sign(data)\n"
        )

    if call.name == "verify":
        if call.receiver_type == "EllipticCurvePublicKey":
            allowed = set(imported_names) | BUILTIN_NAMES | LITERAL_NAMES
            alg_expr = call.resolved_signature_algorithm
            free = _collect_free_names(alg_expr) if alg_expr else None
            if alg_expr and free is not None and free.issubset(allowed):
                sig = (
                    f"self, public_key, signature, data, "
                    f"signature_algorithm={alg_expr}"
                )
            else:
                sig = "self, public_key, signature, data, signature_algorithm"
            return (
                f"    def {method_name}({sig}):\n"
                "        return public_key.verify("
                "signature, data, signature_algorithm)\n"
            )
        return (
            f"    def {method_name}(self, public_key, signature, data):\n"
            "        return public_key.verify(signature, data)\n"
        )

    return None


def _private_type_for_call(call):
    if call.receiver_type and "PrivateKey" in call.receiver_type:
        return call.receiver_type

    if call.receiver_type == "ec" and call.name == "generate_private_key":
        return "EllipticCurvePrivateKey"

    if call.receiver_type == "DHParameters" and call.name == "generate_private_key":
        return "DHPrivateKey"

    if call.name in PRIVATE_KEY_TRIGGER_METHODS and call.algorithm:
        if call.algorithm == "EC":
            return "EllipticCurvePrivateKey"
        return f"{call.algorithm}PrivateKey"

    return None


def add_missing_public_key_methods(crypto_calls):
    existing_methods = {
        get_adapter_method_name(call)
        for call in crypto_calls
    }

    private_algorithms = {}

    for call in crypto_calls:
        private_type = _private_type_for_call(call)
        if not private_type:
            continue

        key = (call.is_pqc, call.algorithm)
        private_algorithms.setdefault(key, private_type)

    for (is_pqc, algorithm), private_type in private_algorithms.items():
        method_name = (
            "pqc_get_public_key"
            if is_pqc
            else "classical_get_public_key"
        )

        if method_name in existing_methods:
            continue

        crypto_calls.append(
            CryptoCall(
                name="public_key",
                receiver="private_key",
                arguments=[],
                keywords={},
                receiver_type=private_type,
                is_class_method=False,
                is_pqc=is_pqc,
                algorithm=algorithm,
            )
        )
        existing_methods.add(method_name)


def get_required_imports(referenced_names, source_imports):
    canonical_modules = {}
    import_lines = []
    bound_names = set()

    for name in sorted(referenced_names):
        if name in STDLIB_IMPORTS:
            import_lines.append(STDLIB_IMPORTS[name])
            bound_names.add(name)
            continue

        if name == "ec":
            canonical_modules.setdefault("ec", set())
            bound_names.add("ec")
            continue

        if name == "dh":
            canonical_modules.setdefault("dh", set())
            bound_names.add("dh")
            continue

        for module_name, classes in MODULE_CLASS_MAP.items():
            if name in classes and module_name in MODULE_PATHS:
                canonical_modules.setdefault(module_name, set()).add(name)
                bound_names.add(name)
                break

    for module_name in sorted(canonical_modules):
        if module_name == "ec":
            import_lines.append(
                "from cryptography.hazmat.primitives.asymmetric import ec"
            )
        elif module_name == "dh":
            import_lines.append(
                "from cryptography.hazmat.primitives.asymmetric import dh"
            )
        else:
            class_names = sorted(canonical_modules[module_name])
            import_path = MODULE_PATHS[module_name]
            import_lines.append(
                f"from {import_path} import {', '.join(class_names)}"
            )

    remaining = referenced_names - bound_names
    if remaining:
        for import_code, import_bound in source_imports:
            if import_bound & remaining:
                if import_code not in import_lines:
                    import_lines.append(import_code)
                bound_names.update(import_bound)

    return import_lines


def generate_hybrid_target_adapter(extractor, output_file):
    crypto_calls = list(extractor.crypto_calls)
    add_missing_public_key_methods(crypto_calls)

    adapter_name = get_adapter_name(crypto_calls)

    methods = {}

    for call in crypto_calls:
        method_name = get_adapter_method_name(call)
        if not method_name or method_name in methods:
            continue

        method_code = get_method_definition(call, extractor.imported_names)
        if method_code:
            methods[method_name] = method_code

    uses_normalizer = any(
        "_normalize_key_bytes(" in body for body in methods.values()
    )

    class_code = f"class {adapter_name}:\n\n"
    if not methods:
        class_code += "    pass\n"
    else:
        blocks = []
        if uses_normalizer:
            blocks.append(_build_normalizer_helper())
        blocks.extend(methods.values())
        class_code += "\n".join(blocks)

    referenced_names = _collect_referenced_names(class_code)
    imports = get_required_imports(referenced_names, extractor.imports)

    code = ""
    if imports:
        code += "\n".join(imports) + "\n\n\n"

    code += class_code

    compile(code, str(output_file), "exec")

    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(code, encoding="utf-8")

    return adapter_name


def process_file(source_file, target_file):
    source_code = source_file.read_text(encoding="utf-8")
    module = cst.parse_module(source_code)

    extractor = HybridCallExtractor()
    module.visit(extractor)

    if not extractor.crypto_calls:
        return None

    return generate_hybrid_target_adapter(extractor, target_file)


def process_files(source_dir, target_dir):
    source_dir = Path(source_dir)
    target_dir = Path(target_dir)

    target_dir.mkdir(parents=True, exist_ok=True)

    for source_file in sorted(source_dir.rglob("*.py")):
        relative_path = source_file.relative_to(source_dir)
        target_file = target_dir / relative_path

        try:
            adapter_name = process_file(source_file, target_file)

            if adapter_name:
                print(f"Generated {adapter_name}: {target_file}")
            else:
                print(f"No crypto operations found: {source_file}")

        except Exception as error:
            print(f"ERROR processing {source_file.name}: {error}")


if __name__ == "__main__":
    in_dir = sys.argv[1] if len(sys.argv) > 1 else "../kem_files/hybrid_server"
    out_dir = sys.argv[2] if len(sys.argv) > 2 else "./adapter/target"
    process_files(in_dir, out_dir)
