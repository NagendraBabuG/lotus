from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.backends import default_backend

class ECAdapter:

    def generate_private_key(self):
        return ec.generate_private_key(ec.SECP256R1(), default_backend())

    def get_public_key(self, private_key):
        return private_key.public_key()

    def get_private_numbers(self, private_key):
        return private_key.private_numbers()

    def get_public_numbers(self, public_key):
        return public_key.public_numbers()

