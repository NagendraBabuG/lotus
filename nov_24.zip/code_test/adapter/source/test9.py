from cryptography.hazmat.primitives.asymmetric import ed25519


class Ed25519Adapter:

    def load_public_key(self, data):
        return ed25519.Ed25519PublicKey.from_public_bytes(data)

    def generate_private_key(self):
        return ed25519.Ed25519PrivateKey.generate()
