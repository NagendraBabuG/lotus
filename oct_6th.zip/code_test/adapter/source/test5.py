from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec

class EllipticCurveAdapter:

    def generate_private_key(self):
        return ec.generate_private_key(ec.SECP384R1())

    def sign(self, private_key, data):
        return private_key.sign(data, ec.ECDSA(hashes.SHA256()))

