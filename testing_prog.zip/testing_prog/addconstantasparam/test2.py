def calculate():
    x = 5
    y = 10
    result = 2 * x + y
    print(result)

v = calculate()