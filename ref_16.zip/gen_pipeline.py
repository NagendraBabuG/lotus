import os
import shutil
from pathlib import Path
from collections import defaultdict
import numpy as np


from defaut_arg_deep import AddDefaultArgValue
from except_code import ExceptionRefactor
from hardcode_deep import HardcodedValues
from forwhilev2 import ForWhile
from lambda_refactor import LambdaRefactor
from asserts import AddAssertions
from partials_ls import PartialsRefactor
from ternary_ref import TernaryRefactor
from try_crypto import CryptoTryExceptInjector
from conv_assign import AugAssignRefactor
from conv_except_assertion import RaiseRefactor
from line_stmts import AssignGroupers
from elif_ren import ElIfConverter
from elseIf import ElseIfConverter
from param_refact_v2 import ParameterRefactor
from var_extract import CryptoVarExtractor
import rem_comments
import bert_code  # Assumed to have analyze_code_pair returning dict with 'codebleu' or similar

refactor_classes = {
    "raise_refact": RaiseRefactor(),
    "line_stmts": AssignGroupers(),
    "elif_ref": ElIfConverter(),
    "elseif": ElseIfConverter(),
    "add_default_arg": AddDefaultArgValue(),
    "hardcoded_values": HardcodedValues(),
    "exception_code": ExceptionRefactor(),
    "var_extract": CryptoVarExtractor(),
    "loops": ForWhile(),
    "lambda_refactor": LambdaRefactor(),
    "assertions": AddAssertions(),
    "partials": PartialsRefactor(),
    "param_refactor": ParameterRefactor(),
    "ternary": TernaryRefactor(),
    "crypto_try": CryptoTryExceptInjector(),
    "conv_assign": AugAssignRefactor(),
}

refactor_classes = {k: v for k, v in refactor_classes.items() if v is not None}

def read_code(file_path: Path) -> str:
    return file_path.read_text(encoding="utf-8", errors="ignore")

def apply_technique(code: str, tech_name: str) -> str:
    refactor = refactor_classes[tech_name]
    return refactor.get_refactored_code(code)

def apply_pipeline(code: str, pipeline: list) -> str:
    current = code
    current = rem_comments.get_refactored_code(current)
    for tech in pipeline:
        try:
            current = apply_technique(current, tech)
        except Exception as e:
            print(f"  [Warning] {tech} failed: {e}")
            continue
    return current

def measure_codebleu_divergence(original_code: str, refactored_code: str) -> float:
    try:
        result = bert_code.analyze_code_pair(original_code, refactored_code)
        codebleu_score = result["semantic_difference_percent"]
        return max(0.0, codebleu_score) 
    except Exception as e:
        print(f"  [CodeBLEU Error] {e}")
        return 0.0

def evaluate_techniques_codebleu(source_dir: str = "source"):
    programs = list(Path(source_dir).glob("*.py"))
    if not programs:
        print(f"No .py files found in '{source_dir}'")
        return {}

    print(f"Evaluating {len(refactor_classes)} techniques on {len(programs)} programs using CodeBLEU...\n")

    technique_divergence = defaultdict(list)

    for prog_path in programs:
        code = read_code(prog_path)
        print(f"Processing: {prog_path.name}")

        for tech_name in refactor_classes:
            try:
                print(tech_name, "\n")
                cur_pip = tech_name
                variant = apply_technique(code,cur_pip)
                div = measure_codebleu_divergence(code, variant)
                technique_divergence[tech_name].append(div)
            except Exception as e:
                print(f"  [Failed] {tech_name}: {e}")
                technique_divergence[tech_name].append(0.0)
    print(technique_divergence, "\n")
    mean_divergence = {
        tech: np.mean(scores) if scores else 0.0
        for tech, scores in technique_divergence.items()
    }
    print(mean_divergence, "\n")

    return mean_divergence

def create_divergent_pipelines(mean_divergence: dict, num_pipelines: int = 4, tech_per_pipeline: int = 4):
    if not mean_divergence:
        print("No divergence data available.")
        return []

    sorted_techniques = sorted(mean_divergence.items(), key=lambda x: x[1], reverse=True)
    tech_names = [tech for tech, score in sorted_techniques]
    scores = [score for tech, score in sorted_techniques]

    print("\nRanked Techniques by Divergence (Higher = Better for Diversity):")
    for i, (tech, score) in enumerate(sorted_techniques[:15], 1):
        print(f"  {i:2}. {tech:20} → {score:6.2f}% divergence")

    if len(tech_names) < num_pipelines * tech_per_pipeline:
        print(f"Not enough techniques ({len(tech_names)}) for {num_pipelines}×{tech_per_pipeline} pipelines.")
        tech_names = tech_names[:len(tech_names)]

    pipelines = [[] for _ in range(num_pipelines)]

    for i, tech in enumerate(tech_names):
        pipeline_idx = i % num_pipelines
        pipelines[pipeline_idx].append(tech)

    final_pipelines = []
    for p in pipelines:
        if len(p) > tech_per_pipeline:
            p = p[:tech_per_pipeline]
        elif len(p) < tech_per_pipeline and tech_names:
            pass
        if p:
            final_pipelines.append(p)

    while len(final_pipelines) < num_pipelines and tech_names:
        extra = [t for t in tech_names if not any(t in p for p in final_pipelines)]
        if not extra:
            break
        for i, tech in enumerate(extra):
            if len(final_pipelines) <= i:
                final_pipelines.append([])
            if len(final_pipelines[i]) < tech_per_pipeline:
                final_pipelines[i].append(tech)

    final_pipelines = final_pipelines[:num_pipelines]

    print(f"\nGenerated {len(final_pipelines)} divergent pipelines:")
    for i, pipe in enumerate(final_pipelines, 1):
        print(f"  Pipeline {i}: {pipe}  →  Avg div: {np.mean([mean_divergence.get(t, 0) for t in pipe]):.2f}%")

    return final_pipelines

def main():
    print("="*70)
    print("MAXIMALLY DIVERGENT REFACTORING PIPELINE GENERATOR (CodeBLEU-Based)")
    print("="*70)

    print("\nStep 1: Evaluating individual techniques using CodeBLEU...")
    divergence_scores = evaluate_techniques_codebleu("source")

    if not divergence_scores:
        print("No scores computed. Exiting.")
        return

    print("\nStep 2: Creating non-overlapping, high-diversity pipelines...")
    pipelines = create_divergent_pipelines(
        mean_divergence=divergence_scores,
        num_pipelines=4,
        tech_per_pipeline=4
    )

    if not pipelines:
        print("Failed to generate pipelines. Using safe fallback...")
        safe = ["ternary", "loops", "lambda_refactor", "assertions", "hardcoded_values", "crypto_try"]
        available = [t for t in safe if t in refactor_classes]
        pipelines = [available[i:i+4] for i in range(0, len(available), 4)][:4]

    for i, p in enumerate(pipelines, 1):
        avg_div = np.mean([divergence_scores.get(t, 0) for t in p])
        print(f"Final Pipeline {i}: {p}  (avg divergence: {avg_div:.2f}%)")


    print("\nSUCCESS! Created maximally divergent, non-overlapping refactoring pipelines.")
    print("Output: target_divergent/pipeline_X_divergent/")

if __name__ == "__main__":
    main()