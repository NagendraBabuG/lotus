from cryptography.hazmat.primitives.asymmetric import mldsa

private_key = mldsa.MLDSA87PrivateKey.generate()
signature = private_key.sign(b"my authenticated message")
public_key = private_key.public_key()
# Raises InvalidSignature if verification fails
public_key.verify(signature, b"my authenticated message")