def test2(x):
    if x % 2 == 0:
        result = even_handler(x)
    else:
        result = odd_handler(x)
    return result

def even_handler(n): return f"{n} is even"
def odd_handler(n): return f"{n} is odd"
