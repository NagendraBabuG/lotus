import ast


class RelationRefactors(ast.NodeTransformer):

    def change_exp(self, node: ast.Compare):
        left = node.left
        op = node.ops[0]
        right = node.comparators[0]

        def swapped(new_op):
            new_node = ast.Compare(
                left=right,
                ops=[new_op],
                comparators=[left]
            )
            return ast.copy_location(new_node, node)

        if isinstance(op, ast.Gt):
            return swapped(ast.Lt())

        elif isinstance(op, ast.GtE):
            return swapped(ast.LtE())

        elif isinstance(op, ast.Lt):
            return swapped(ast.Gt())

        elif isinstance(op, ast.LtE):
            return swapped(ast.GtE())

        elif isinstance(op, ast.Eq):
            new_node = ast.UnaryOp(
                op=ast.Not(),
                operand=ast.Compare(
                    left=left,
                    ops=[ast.NotEq()],
                    comparators=[right]
                )
            )
            return ast.copy_location(new_node, node)

        elif isinstance(op, ast.NotEq):
            new_node = ast.UnaryOp(
                op=ast.Not(),
                operand=ast.Compare(
                    left=left,
                    ops=[ast.Eq()],
                    comparators=[right]
                )
            )
            return ast.copy_location(new_node, node)

        return node  

    def conditional_check(self, node):

        if isinstance(node, ast.Compare):
            return self.change_exp(node)

        elif isinstance(node, ast.BoolOp):
            return ast.BoolOp(
                op=node.op,
                values=[self.conditional_check(v) for v in node.values]
            )

        return node

    def visit_If(self, node):
        self.generic_visit(node)
        node.test = self.conditional_check(node.test)
        return node

    def visit_While(self, node):
        self.generic_visit(node)
        node.test = self.conditional_check(node.test)
        return node

    def get_refactored_code(self, code):
        try:
            tree = ast.parse(code)
            tree = self.visit(tree)
            ast.fix_missing_locations(tree)
            return ast.unparse(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")

