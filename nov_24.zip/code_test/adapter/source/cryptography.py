from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric import dsa
from cryptography.hazmat.primitives.asymmetric import padding


class DSAAdapter:

    def generate_private_key(self):
        return dsa.generate_private_key(key_size=2048)

    def get_public_key(self, private_key):
        return private_key.public_key()

    def sign(self, private_key, data):
        return private_key.sign(data, hashes.SHA256())

    def verify(self, public_key, signature, data):
        return public_key.verify(signature, data, hashes.SHA256())

    def serialize_private_key(self, private_key, format=serialization.PrivateFormat.PKCS8):
        return private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=format,
            encryption_algorithm=serialization.NoEncryption(),
        )

    def serialize_public_key(self, public_key):
        return public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )


class ECAdapter:

    def generate_private_key(self):
        return ec.generate_private_key(ec.SECP256R1())

    def get_public_key(self, private_key):
        return private_key.public_key()

    def sign(self, private_key, data):
        return private_key.sign(data, ec.ECDSA(hashes.SHA256()))

    def verify(self, public_key, signature, data):
        return public_key.verify(signature, data, ec.ECDSA(hashes.SHA256()))

    def serialize_private_key(self, private_key, format=serialization.PrivateFormat.PKCS8):
        return private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=format,
            encryption_algorithm=serialization.NoEncryption(),
        )

    def serialize_public_key(self, public_key):
        return public_key.public_bytes(
            encoding=serialization.Encoding.OpenSSH,
            format=serialization.PublicFormat.OpenSSH,
        )

    def serialize_public_key_pem(self, public_key):
        return public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )


class Ed25519Adapter:

    def generate_private_key(self):
        return ed25519.Ed25519PrivateKey.generate()

    def get_public_key(self, private_key):
        return private_key.public_key()

    def sign(self, private_key, data):
        return private_key.sign(data)

    def verify(self, public_key, signature, data):
        return public_key.verify(signature, data)

    def serialize_private_key(self, private_key, format=serialization.PrivateFormat.PKCS8):
        return private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=format,
            encryption_algorithm=serialization.NoEncryption(),
        )

    def serialize_public_key(self, public_key):
        return public_key.public_bytes(
            encoding=serialization.Encoding.OpenSSH,
            format=serialization.PublicFormat.OpenSSH,
        )

    def serialize_public_key_raw(self, public_key):
        return public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )


class RSAAdapter:

    def generate_private_key(self):
        return rsa.generate_private_key(public_exponent=65537, key_size=2048)

    def get_public_key(self, private_key):
        return private_key.public_key()

    def sign(self, private_key, data):
        return private_key.sign(data, padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH), hashes.SHA256())

    def verify(self, public_key, signature, data):
        return public_key.verify(signature, data, padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH), hashes.SHA256())

    def serialize_private_key(self, private_key, format=serialization.PrivateFormat.PKCS8):
        return private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=format,
            encryption_algorithm=serialization.NoEncryption(),
        )

    def serialize_public_key(self, public_key):
        return public_key.public_bytes(
            encoding=serialization.Encoding.OpenSSH,
            format=serialization.PublicFormat.OpenSSH,
        )

    def serialize_public_key_pem(self, public_key):
        return public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
