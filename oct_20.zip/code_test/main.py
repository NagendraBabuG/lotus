import ast
import csv
import importlib.util
import sys
from pathlib import Path
from matchingadapter import get_expected_target


ROOT = Path(__file__).resolve().parent / "adapter"
SOURCE_DIR = ROOT / "source"
TARGET_DIR = ROOT / "target"
RESULT_FILE = ROOT / "test_results.csv"


def get_class_names(file_path):
    tree = ast.parse(file_path.read_text(encoding="utf-8"))
    return [
        node.name
        for node in tree.body
        if isinstance(node, ast.ClassDef)
    ]


def load_classes(file_path):
    module_name = f"adapter_test_{file_path.stem}_{abs(hash(str(file_path)))}"
    spec = importlib.util.spec_from_file_location(module_name, file_path)

    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {file_path}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)

    return {
        name: getattr(module, name)
        for name in get_class_names(file_path)
        if hasattr(module, name)
    }

#1
def test_generate_private_key(adapter):
    key = adapter.generate_private_key()
    print(key is not None)
    assert key is not None 
#2
def test_serialize_load(adapter):
    key = adapter.generate_private_key()
    private_bytes = adapter.serialize_private_key(key)
    loaded_key = adapter.load_private_key(private_bytes)
    assert loaded_key is not None

#3
def test_protected_load(adapter):
    key = adapter.generate_private_key()
    private_bytes = adapter.encode_private_key(key, b"password")
    loaded_key = adapter.load_pem_key(private_bytes, b"password")
    assert loaded_key is not None

#4
def test_wrong_password(adapter):
    key = adapter.generate_private_key()
    private_bytes = adapter.encode_private_key(key, b"password")
    adapter.load_pem_key(private_bytes, b"wrong-password")

#4
def test_loaded_key_type(adapter):
    key = adapter.generate_private_key()
    private_bytes = adapter.serialize_private_key(key)
    loaded_key = adapter.load_private_key(private_bytes)
    assert type(key) is type(loaded_key)

#5
def test_empty_key(adapter):
    adapter.load_private_key(b"")
#6
def test_short_key(adapter):
    adapter.load_private_key(b"\x00" * 16)

#7
def test_long_key(adapter):
    adapter.load_private_key(b"\x00" * 10000)

#8
def test_string_input(adapter):
    adapter.load_private_key("not bytes")

#9
def test_integer_input(adapter):
    adapter.load_private_key(1)

#10
def test_none_input(adapter):
    adapter.load_private_key(None)

#11
def test_bytearray_input(adapter):
    key = adapter.generate_private_key()
    private_bytes = adapter.serialize_private_key(key)
    loaded_key = adapter.load_private_key_bytearray(private_bytes)
    assert loaded_key is not None




#12
def test_generate_unique_keys(adapter):
    key1 = adapter.generate_private_key()
    key2 = adapter.generate_private_key()

    bytes1 = adapter.serialize_private_key(key1)
    bytes2 = adapter.serialize_private_key(key2)

    assert bytes1 != bytes2

#13
def test_serialize_private_key_type(adapter):
    key = adapter.generate_private_key()
    private_bytes = adapter.serialize_private_key(key)

    assert isinstance(private_bytes, bytes)
#14

def test_serialize_private_key_not_empty(adapter):
    key = adapter.generate_private_key()
    private_bytes = adapter.serialize_private_key(key)

    assert len(private_bytes) > 0
#15

def test_load_same_key_bytes(adapter):
    key = adapter.generate_private_key()
    private_bytes = adapter.serialize_private_key(key)

    loaded_key = adapter.load_private_key(private_bytes)
    loaded_bytes = adapter.serialize_private_key(loaded_key)

    assert private_bytes == loaded_bytes

#16
def test_public_key_generation(adapter):
    private_key = adapter.generate_private_key()
    public_key = adapter.get_public_key(private_key)

    assert public_key is not None

#17
def test_serialize_public_key(adapter):
    private_key = adapter.generate_private_key()
    public_key = adapter.get_public_key(private_key)
    public_bytes = adapter.serialize_public_key(public_key)

    assert isinstance(public_bytes, bytes)
    assert len(public_bytes) > 0

#18
def test_load_public_key(adapter):
    private_key = adapter.generate_private_key()
    public_key = adapter.get_public_key(private_key)
    public_bytes = adapter.serialize_public_key(public_key)

    loaded_public_key = adapter.load_public_key(public_bytes)

    assert loaded_public_key is not None

#19

def test_loaded_public_key_type(adapter):
    private_key = adapter.generate_private_key()
    public_key = adapter.get_public_key(private_key)
    public_bytes = adapter.serialize_public_key(public_key)

    loaded_public_key = adapter.load_public_key(public_bytes)

    assert type(public_key) is type(loaded_public_key)

#20
def test_sign_and_verify(adapter):
    private_key = adapter.generate_private_key()
    public_key = adapter.get_public_key(private_key)
    message = b"Post-quantum cryptography test message"

    signature = adapter.sign(private_key, message)
    result = adapter.verify(public_key, signature, message)

    assert signature is not None
#21

def test_verify_modified_message(adapter):
    private_key = adapter.generate_private_key()
    public_key = adapter.get_public_key(private_key)
    message = b"Original message"
    signature = adapter.sign(private_key, message)

    adapter.verify(public_key, signature, b"Modified message")

#22
def test_verify_modified_signature(adapter):
    private_key = adapter.generate_private_key()
    public_key = adapter.get_public_key(private_key)
    message = b"Signature verification test"
    signature = adapter.sign(private_key, message)

    modified_signature = bytes([signature[0] ^ 1]) + signature[1:]

    adapter.verify(public_key, modified_signature, message)

#23
def test_sign_empty_message(adapter):
    private_key = adapter.generate_private_key()
    public_key = adapter.get_public_key(private_key)

    signature = adapter.sign(private_key, b"")

    assert signature is not None
    adapter.verify(public_key, signature, b"")

#24
def test_sign_string_input(adapter):
    private_key = adapter.generate_private_key()
    adapter.sign(private_key, "not bytes")

#25
def test_sign_none_input(adapter):
    private_key = adapter.generate_private_key()
    adapter.sign(private_key, None)

#26
def test_load_public_key_empty(adapter):
    adapter.load_public_key(b"")

#27
def test_load_public_key_invalid_type(adapter):
    adapter.load_public_key("not bytes")

#28
def test_load_private_key_repeatedly(adapter):
    key = adapter.generate_private_key()
    private_bytes = adapter.serialize_private_key(key)

    loaded1 = adapter.load_private_key(private_bytes)
    loaded2 = adapter.load_private_key(private_bytes)

    assert type(loaded1) is type(loaded2)
    assert adapter.serialize_private_key(loaded1) == adapter.serialize_private_key(loaded2)

#29
def test_public_key_matches_private_key(adapter):
    private_key = adapter.generate_private_key()
    public_key = adapter.get_public_key(private_key)

    private_bytes = adapter.serialize_private_key(private_key)
    loaded_private_key = adapter.load_private_key(private_bytes)

    loaded_public_key = adapter.get_public_key(loaded_private_key)

    public_bytes1 = adapter.serialize_public_key(public_key)
    public_bytes2 = adapter.serialize_public_key(loaded_public_key)

    assert public_bytes1 == public_bytes2
#30
def test_get_public_key(adapter):
    private_key = adapter.generate_private_key()
    public_key = adapter.get_public_key(private_key)

    assert public_key is not None


TESTS = [
    ("Generate Private Key", True, ("generate_private_key",), test_generate_private_key),

    (
        "Generate, serialize and load",
        True,
        ("generate_private_key", "serialize_private_key", "load_private_key"),
        test_serialize_load,
    ),
    (
        "Protected private-key serialization",
        True,
        ("generate_private_key", "encode_private_key", "load_pem_key"),
        test_protected_load,
    ),
    (
        "Load with incorrect password",
        False,
        ("generate_private_key", "encode_private_key", "load_pem_key"),
        test_wrong_password,
    ),
    (
        "Loaded key has the expected type",
        True,
        ("generate_private_key", "serialize_private_key", "load_private_key"),
        test_loaded_key_type,
    ),
    (
        "Zero-length private-key input",
        False,
        ("load_private_key",),
        test_empty_key,
    ),
    (
        "Short private-key input",
        False,
        ("load_private_key",),
        test_short_key,
    ),
    (
        "Oversized private-key input",
        False,
        ("load_private_key",),
        test_long_key,
    ),
    (
        "String input",
        False,
        ("load_private_key",),
        test_string_input,
    ),
    (
        "Integer input",
        False,
        ("load_private_key",),
        test_integer_input,
    ),
    (
        "None input",
        False,
        ("load_private_key",),
        test_none_input,
    ),
    (
        "Bytearray private-key input",
        True,
        (
            "generate_private_key",
            "serialize_private_key",
            "load_private_key_bytearray",
        ),
        test_bytearray_input,
    ),
    (
    "Generate unique keys",
    True,
    ("generate_private_key", "serialize_private_key"),
    test_generate_unique_keys,
    ),
    (
        "Serialized private key is bytes",
        True,
        ("generate_private_key", "serialize_private_key"),
        test_serialize_private_key_type,
    ),
    (
        "Serialized private key is not empty",
        True,
        ("generate_private_key", "serialize_private_key"),
        test_serialize_private_key_not_empty,
    ),
    (
        "Serialized key round-trip preserves bytes",
        True,
        ("generate_private_key", "serialize_private_key", "load_private_key"),
        test_load_same_key_bytes,
    ),
    (
        "Generate public key",
        True,
        ("generate_private_key", "get_public_key"),
        test_public_key_generation,
    ),
    (
        "Serialize public key",
        True,
        ("generate_private_key", "get_public_key", "serialize_public_key"),
        test_serialize_public_key,
    ),
    (
        "Load serialized public key",
        True,
        ("generate_private_key", "get_public_key", "serialize_public_key", "load_public_key"),
        test_load_public_key,
    ),
    (
        "Loaded public key has expected type",
        True,
        ("generate_private_key", "get_public_key", "serialize_public_key", "load_public_key"),
        test_loaded_public_key_type,
    ),
    (
        "Sign and verify message",
        True,
        ("generate_private_key", "get_public_key", "sign", "verify"),
        test_sign_and_verify,
    ),
    (
        "Reject modified message",
        False,
        ("generate_private_key", "get_public_key", "sign", "verify"),
        test_verify_modified_message,
    ),
    (
        "Reject modified signature",
        False,
        ("generate_private_key", "get_public_key", "sign", "verify"),
        test_verify_modified_signature,
    ),
    (
        "Sign empty message",
        True,
        ("generate_private_key", "get_public_key", "sign", "verify"),
        test_sign_empty_message,
    ),
    (
        "Reject string message",
        False,
        ("generate_private_key", "sign"),
        test_sign_string_input,
    ),
    (
        "Reject None message",
        False,
        ("generate_private_key", "sign"),
        test_sign_none_input,
    ),
    (
        "Reject empty public key",
        False,
        ("load_public_key",),
        test_load_public_key_empty,
    ),
    (
        "Reject invalid public key type",
        False,
        ("load_public_key",),
        test_load_public_key_invalid_type,
    ),
    (
        "Repeated private-key loading",
        True,
        ("generate_private_key", "serialize_private_key", "load_private_key"),
        test_load_private_key_repeatedly,
    ),
    (
        "Public key matches reloaded private key",
        True,
        ("generate_private_key", "get_public_key", "serialize_private_key", "load_private_key", "serialize_public_key"),
        test_public_key_matches_private_key,
    ),
    ("get public key", True, ("generate_private_key", "get_public_key"), test_get_public_key)
]
print(" no test funcs : ", len(TESTS), "\n")

def execute_test(adapter_class, expected_success, required_methods, test_func):
    missing = [
        name for name in required_methods
        if not callable(getattr(adapter_class, name, None))
    ]

    if missing:
        return {
            "result": "SKIP",
            "behavior": ("SKIP", tuple(missing)),
            "details": f"Missing methods: {', '.join(missing)}",
        }

    try:
        test_func(adapter_class())
        passed = expected_success

        return {
            "result": "PASS" if passed else "FAIL",
            "behavior": ("RETURNED",),
            "details": (
                "Completed successfully"
                if expected_success
                else "Expected an exception, but none was raised"
            ),
        }

    except Exception as exc:
        passed = not expected_success

        return {
            "result": "PASS" if passed else "FAIL",
            "behavior": ("EXCEPTION", type(exc).__name__),
            "details": f"{type(exc).__name__}: {exc}",
        }


def compare_test(source_class, target_class, test_name,
                 expected_success, required_methods, test_func,
                 source_name, target_name, file_name):

    source_result = execute_test(
        source_class, expected_success, required_methods, test_func
    )
    target_result = execute_test(
        target_class, expected_success, required_methods, test_func
    )

    if source_result["result"] == "SKIP" and target_result["result"] == "SKIP":
        comparison = "BOTH SKIPPED"
    elif source_result["behavior"] == target_result["behavior"]:
        comparison = "EQUIVALENT BEHAVIOUR"
    else:
        comparison = "DIVERGENT BEHAVIOUR"

    print(f"{file_name}: {source_name} -> {target_name}")
    print(f"Test: {test_name}")
    print(f"Source: {source_result['result']} - {source_result['details']}")
    print(f"Target: {target_result['result']} - {target_result['details']}")
    print(f"Comparison: {comparison}\n")

    return {
        "file": file_name,
        "source_class": source_name,
        "target_class": target_name,
        "test": test_name,
        "source_result": source_result["result"],
        "source_details": source_result["details"],
        "target_result": target_result["result"],
        "target_details": target_result["details"],
        "comparison": comparison,
    }


def main():
    all_results = []

    for source_file in sorted(SOURCE_DIR.rglob("*.py")):
        relative_path = source_file.relative_to(SOURCE_DIR)
        target_file = TARGET_DIR / relative_path

        if not target_file.exists():
            print(f"Missing target file: {relative_path}\n")
            continue

        try:
            source_classes = load_classes(source_file)
            target_classes = load_classes(target_file)
        except Exception as exc:
            print(f"Could not load {relative_path}: {type(exc).__name__}: {exc}\n")
            continue

        source_names = list(source_classes)
        target_names = list(target_classes)

        if not source_names or not target_names:
            print(f"No adapter classes found in {relative_path}\n")
            continue

        if len(source_names) != len(target_names):
            print(
                f"WARNING: Different class counts in {relative_path}: "
                f"source={len(source_names)}, target={len(target_names)}\n"
            )
        """
        for source_name, target_name in zip(source_names, target_names):
            source_class = source_classes[source_name]
            target_class = target_classes[target_name]

            for test_name, expected, methods, test_func in TESTS:
                result = compare_test(
                    source_class,
                    target_class,
                    test_name,
                    expected,
                    methods,
                    test_func,
                    source_name,
                    target_name,
                    str(relative_path),
                )
                all_results.append(result)
        """

        for source_name, source_class in source_classes.items():
            expected_target = get_expected_target(
                source_name, source_file
            )

            if expected_target is None:
                print(
                    f"MAPPING NOT DEFINED: {relative_path}: "
                    f"{source_name}\n"
                )
                continue

            if expected_target not in target_classes:
                print(
                    f"MATCH NOT PRESENT: {relative_path}: "
                    f"{source_name} -> {expected_target}\n"
                )
                continue

            target_class = target_classes[expected_target]

            for test_name, expected, methods, test_func in TESTS:
                result = compare_test(
                    source_class,
                    target_class,
                    test_name,
                    expected,
                    methods,
                    test_func,
                    source_name,
                    expected_target,
                    str(relative_path),
                )
                if result['source_result'] == result['target_result'] and result['source_result'] == "SKIP":
                    continue
                all_results.append(result)

    RESULT_FILE.parent.mkdir(parents=True, exist_ok=True)

    fieldnames = [
        "file",
        "source_class",
        "target_class",
        "test",
        "source_result",
        "source_details",
        "target_result",
        "target_details",
        "comparison",
    ]

    with RESULT_FILE.open("w", newline="", encoding="utf-8") as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(all_results)

    print(f"Test execution completed. Results saved to: {RESULT_FILE}")
    print(f"Total test cases executed or skipped: {len(all_results)}")


if __name__ == "__main__":
    main()