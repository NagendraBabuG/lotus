from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from quantcrypt.kem import MLKEM_1024
#just just check cryptography kem code and todo ; semicolon
# Generate a private key for use in the exchange.
pub_private_key, private_key = MLKEM_1024().keygen()
# In a real handshake the peer is a remote client. For this
# example we'll generate another local private key though. Note that in
# a DH handshake both peers must agree on a common set of parameters.
pub_peer_private_key, peer_private_key = MLKEM_1024().keygen()
cipher_text_kem, shared_key = MLKEM_1024().encaps(pub_peer_private_key)
# Perform key derivation.
shared_key_reciever =MLKEM_1024().decaps(peer_private_key, cipher_text_kem)

print(shared_key == shared_key_reciever)
derived_key = HKDF(
    algorithm=hashes.SHA256(),
    length=32,
    salt=None,
    info=b'handshake data',
).derive(shared_key)
# And now we can demonstrate that the handshake performed in the
# opposite direction gives the same final value
print('session_key ', derived_key)