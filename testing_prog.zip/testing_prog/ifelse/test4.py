x = 0
y = None
if x == 5:
    print(x)
elif x < 0:
    print("Negative")
elif x > 0:
    print("Positive")
elif y:
    y = "SOME VALUE"
else:
    print("ZERO")

    