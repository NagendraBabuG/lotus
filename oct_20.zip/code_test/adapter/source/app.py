from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

class Ed25519Adapter:

    def generate_private_key(self):
        return Ed25519PrivateKey.generate()

