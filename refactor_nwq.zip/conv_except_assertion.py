import ast
import random
import re

HEX_PATTERN = re.compile(r"0x[0-9A-Fa-f]+")

class RaiseRefactor(ast.NodeTransformer):
    
    def visit_Raise(self, node):
        if isinstance(node.exc, ast.Call):
            raise_arg = node.exc.args
            rand = random.randint(1,2)
            if rand == 1:
                new_print = ast.Expr(
                    value=ast.Call(func=ast.Name(id='print', ctx=ast.Load()), args=raise_arg, keywords=[])
                )
                ast.fix_missing_locations(new_print)
                return new_print
            elif rand == 2:
                if not len(raise_arg):
                        temp_msg = []
                else:
                    temp_msg = raise_arg[0]
                new_assert = ast.Assert(
                    test=ast.Constant(value=False),
                    msg=temp_msg
                )
                ast.fix_missing_locations(new_assert)
                return new_assert
        return node
        
    
    def get_refactored_code(self, source_code):
        hex_literals = HEX_PATTERN.findall(source_code)
        print(hex_literals, '\n')
        try:
            tree = ast.parse(source_code)
            tree = self.visit(tree)
            result = ast.unparse(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")

        for hx in hex_literals:
            dec = str(int(hx, 16))
            result = result.replace(dec, hx)

        return result
    
wrapper = RaiseRefactor() 

source = """  
class f1:
    x = 2
    def f2(self, pas):
        self.x = self.x + 2
        return 2
    def f3(self, p2):
        return p2
    def f4(self, a, b, c):
        a = a + 1
        b = b.upper()
        return a, b, c

def func2(x):
    x = x.upper()
    return x

def many(p1, p2, p3, p4):
    p1 += 1
    p2 = p2.strip()
    return p1, p2
def verify_sign(msg, sing, pub_key):
    key = RSA.import_key(pub_key)
def create_siv_cipher(factory, **kwargs):
    key_copy = kwargs.pop()
def creat_cipher(v):
    v_int = bytes_to_long(v)
    q = v_int & 0xFFFFFFFFFFFFFFFF7FFFFFFF7FFFFFFF
"""

target = wrapper.get_refactored_code(source)
print(target)