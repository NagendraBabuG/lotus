def func1(key, msg):
    signer = pkcs1_15.new(key)
    signature = signer.sign(msg)
    return signature

def func2(key):
    msg = b'hello'
    sign = pcks1_15.new(key).sign(msg)
    return sign


def func3(key, msg):
    sign = pcks1_15.new(key).sign(msg)
    return sign


msg = b'hello'
sign = pcks1_15.new(key).sign(msg)


def risky():
    try:
        result = 1 / 0
        print('Done')
    except Exception as error:
        print(f'ERROR: {error}')


def risky():
    result = 1 / 0
    print('Done')