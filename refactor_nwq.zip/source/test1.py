from cryptography.fernet import Fernet

key = Fernet.generate_key()
cipher = Fernet(key)

# Encrypt data
message1 = b"Secret message 1"
encrypted1 = cipher.encrypt(message1)
print("Encrypted1:", encrypted1)

# Decrypt data
decrypted1 = cipher.decrypt(encrypted1)
print("Decrypted1:", decrypted1)

# Encrypt another message
message2 = b"Secret message 2"
encrypted2 = cipher.encrypt(message2)
print("Encrypted2:", encrypted2)

# Decrypt again
decrypted2 = cipher.decrypt(encrypted2)
print("Decrypted2:", decrypted2)

def func1(parm):
	l = len(param)
	return parm
	
