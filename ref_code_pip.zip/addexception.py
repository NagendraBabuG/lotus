import ast
import os
import random

# it will add exception block to function , added a condition so that it doesn't add, if try catch block already exists

class AddTryExceptRefactor(ast.NodeTransformer):
    ERROR_MESSAGES = ['ERROR: ', "Exception encountered: ", "Operation Failed: "]
    EXCEPTION_POOL = ['e', 'exception', 'exc', 'err', 'error']

    def get_handler_block(self, exc_id):
        return [
            ast.ExceptHandler(
                type=ast.Name(id='Exception', ctx=ast.Load()),
                name=exc_id,
                body=[
                    ast.Expr(
                        value=ast.Call(
                            func=ast.Name(id='print', ctx=ast.Load()),
                            args=[
                                ast.JoinedStr(
                                    values=[
                                        ast.Constant(value=random.choice(self.ERROR_MESSAGES)),
                                        ast.FormattedValue(
                                            value=ast.Name(id=exc_id, ctx=ast.Load()),
                                            conversion=-1
                                        )
                                    ]
                                )
                            ],
                            keywords=[]
                        )
                    )
                ]
            )
        ]

    def visit_FunctionDef(self, node):
        if not node.body:  # Skip empty functions
            return node

        if any(isinstance(stmt, ast.Try) for stmt in node.body):
            return node
        init_body = [elem for elem in node.body]
        
        exc_id = random.choice(self.EXCEPTION_POOL)
        new_body = [
            ast.Try(
                body=init_body,
                handlers=self.get_handler_block(exc_id),
                orelse=[],
                finalbody=[]
            )
        ]
        node.body = new_body
        ast.fix_missing_locations(node)
        self.generic_visit(node)
        return node
           
    def refactor_try_except(self, tree):           
        self.visit(tree)
        ast.fix_missing_locations(tree)
        return ast.unparse(tree)

    def get_refactored_code(self, source_code):                                                       
        try:
            tree = ast.parse(source_code)
            return self.refactor_try_except(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")
