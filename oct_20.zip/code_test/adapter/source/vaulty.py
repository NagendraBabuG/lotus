from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

class Ed25519Adapter:

    def generate_private_key(self):
        return Ed25519PrivateKey.generate()

    def get_public_key(self, private_ed25519):
        return private_ed25519.public_key()

    def serialize_private_key(self, private_ed25519):
        return private_ed25519.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption())

    def load_private_key(self, private_key):
        return Ed25519PrivateKey.from_private_bytes(private_key)

    def sign(self, key, data):
        return key.sign(data)

    def load_public_key(self, public_key):
        return Ed25519PublicKey.from_public_bytes(public_key)

    def verify(self, key, signature, data):
        return key.verify(signature, data)

