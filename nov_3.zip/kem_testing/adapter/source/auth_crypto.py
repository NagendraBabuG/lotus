from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey,
    X25519PublicKey,
)

class X25519Adapter:

    def load_private_key(self, seed):
        return X25519PrivateKey.from_private_bytes(seed)

    def get_public_key(self, verify_private):
        return verify_private.public_key()

    def load_public_key(self, client_pub_key):
        return X25519PublicKey.from_public_bytes(client_pub_key)

