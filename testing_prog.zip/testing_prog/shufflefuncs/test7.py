def my_decorator(f):
    def wrapper():
        print("Before call")
        f()
        print("After call")
    return wrapper

@my_decorator
def greet():
    print("Hello!")

greet()
