from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric import utils

class ECAdapter:

    def generate_private_key(self):
        return ec.generate_private_key(ec.SECP384R1())

    def sign(self, private_key, digest, chosen_hash):
        return private_key.sign(digest, ec.ECDSA(utils.Prehashed(chosen_hash)))

    def get_public_key(self, private_key):
        return private_key.public_key()

    def verify(self, public_key, sig, digest, chosen_hash):
        return public_key.verify(sig, digest, ec.ECDSA(utils.Prehashed(chosen_hash)))

