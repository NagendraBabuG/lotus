from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric.x448 import X448PrivateKey
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from quantcrypt.kem import MLKEM_768

private_key_pub, private_key = MLKEM_768().keygen()peer_public_key, peer_public_key_priv = MLKEM_768().keygen()mlkem = MLKEM_768()

mlkem_public_key, mlkem_secret_key = mlkem.keygen()

# The ML-KEM public key should be sent to the server.
#
# The ciphertext is assumed to be received
# from the server.

shared_key = mlkem.decaps(
    mlkem_secret_key,
    ciphertext
)
# Perform key derivation.
derived_key = HKDF(
    algorithm=hashes.SHA256(),
    length=32,
    salt=None,
    info=b'handshake data',
).derive(shared_key)
private_key_2_pub, private_key_2 = MLKEM_768().keygen()peer_public_key_2, peer_public_key_2_priv = MLKEM_768().keygen()mlkem = MLKEM_768()

mlkem_public_key, mlkem_secret_key = mlkem.keygen()

# The ML-KEM public key should be sent to the server.
#
# The ciphertext is assumed to be received
# from the server.

shared_key_2 = mlkem.decaps(
    mlkem_secret_key,
    ciphertext
)
derived_key_2 = HKDF(
    algorithm=hashes.SHA256(),
    length=32,
    salt=None,
    info=b'handshake data',
).derive(shared_key_2)