from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

class X25519Adapter:

    def load_private_key(self, private_key_text):
        return X25519PrivateKey.from_private_bytes((private_key_text if isinstance(private_key_text, bytes) else bytes.fromhex(private_key_text)))

    def generate_private_key(self):
        return X25519PrivateKey.generate()

    def serialize_public_key(self, public_key):
        return public_key.public_bytes(encoding=Encoding.Raw, format=PublicFormat.Raw)

    def get_public_key(self, private_key):
        return private_key.public_key()

