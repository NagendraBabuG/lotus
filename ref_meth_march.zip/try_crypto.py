import ast
class CryptoTryExceptInjector(ast.NodeTransformer):

    CRYPTO_FUNCTIONS = {"encrypt", "decrypt", "sign", "verify"}
    EXCEPTION_TYPE = "Exception"
    ERROR_MESSAGE = "error"

    def __init__(self):
        self.temp_counter = 0
        self.inside_try = 0 


    def fresh_temp(self):
        name = f"_crypto_tmp_{self.temp_counter}"
        self.temp_counter += 1
        return name


    def is_crypto_call(self, node):
        if not isinstance(node, ast.Call):
            return False

        if isinstance(node.func, ast.Attribute):
            return node.func.attr in self.CRYPTO_FUNCTIONS

        if isinstance(node.func, ast.Name):
            return node.func.id in self.CRYPTO_FUNCTIONS

        return False


    def build_try_except(self, assign):

        handler = ast.ExceptHandler(
            type=ast.Name(id=self.EXCEPTION_TYPE, ctx=ast.Load()),
            name="e",
            body=[
                ast.Expr(
                    value=ast.Call(
                        func=ast.Name(id="print", ctx=ast.Load()),
                        args=[
                            ast.Constant(self.ERROR_MESSAGE),
                            ast.Name(id="e", ctx=ast.Load()),
                        ],
                        keywords=[],
                    )
                )
            ],
        )

        return ast.Try(
            body=[assign],
            handlers=[handler],
            orelse=[],
            finalbody=[],
        )


    def wrap_call(self, call_node):
        temp = self.fresh_temp()

        assign = ast.Assign(
            targets=[ast.Name(id=temp, ctx=ast.Store())],
            value=call_node,
        )

        try_block = self.build_try_except(assign)

        return ast.Name(id=temp, ctx=ast.Load()), [try_block]


    def visit_Try(self, node):
        self.inside_try += 1
        node = self.generic_visit(node)
        self.inside_try -= 1
        return node


    def visit_Assign(self, node):
        node = self.generic_visit(node)

        if self.inside_try:
            return node

        if self.is_crypto_call(node.value):
            result, extra = self.wrap_call(node.value)
            node.value = result
            return extra + [node]

        return node


    def visit_Return(self, node):
        node = self.generic_visit(node)

        if self.inside_try:
            return node

        if node.value and self.is_crypto_call(node.value):
            result, extra = self.wrap_call(node.value)
            node.value = result
            return extra + [node]

        return node


    def visit_Expr(self, node):
        node = self.generic_visit(node)

        if self.inside_try:
            return node

        if self.is_crypto_call(node.value):
            result, extra = self.wrap_call(node.value)
            node.value = result
            return extra + [node]

        return node

    def visit_If(self, node):
        node = self.generic_visit(node)

        if self.inside_try:
            return node

        if self.is_crypto_call(node.test):
            result, extra = self.wrap_call(node.test)
            node.test = result
            return extra + [node]

        return node


    def visit_FunctionDef(self, node):
        self.temp_counter = 0
        return self.generic_visit(node)


    def get_refactored_code(self, source_code):
        tree = ast.parse(source_code)
        tree = self.visit(tree)
        ast.fix_missing_locations(tree)
        return ast.unparse(tree)
    



