from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.asymmetric import mlkem

# Generate a private key for use in the exchange.
server_private_key = ec.generate_private_key(
    ec.SECP384R1()
)
server_private_key_pqc = mlkem.MLKEM768PrivateKey.generate()
# In a real handshake the peer is a remote client. For this
# example we'll generate another local private key though.
peer_private_key = ec.generate_private_key(
    ec.SECP384R1()
)
peer_private_key_pqc = mlkem.MLKEM768PrivateKey.generate()
shared_key = server_private_key.exchange(
    ec.ECDH(), peer_private_key.public_key())
ciphertext_var = "ciphertext"

pqc_shared_secret = server_private_key_pqc.decapsulate(
    ciphertext_var
)

# Combine classical and PQC shared secrets
shared_key = shared_key + pqc_shared_secret
# Perform key derivation.
derived_key = HKDF(
    algorithm=hashes.SHA256(),
    length=32,
    salt=None,
    info=b'handshake data',
).derive(shared_key)
# And now we can demonstrate that the handshake performed in the
# opposite direction gives the same final value
same_shared_key = peer_private_key.exchange(
    ec.ECDH(), server_private_key.public_key())
ciphertext_var = "ciphertext"

pqc_shared_secret = peer_private_key_pqc.decapsulate(
    ciphertext_var
)

# Combine classical and PQC shared secrets
same_shared_key = same_shared_key + pqc_shared_secret
# Perform key derivation.
same_derived_key = HKDF(
    algorithm=hashes.SHA256(),
    length=32,
    salt=None,
    info=b'handshake data',
).derive(same_shared_key)
derived_key == same_derived_key