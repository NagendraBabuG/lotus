from cryptography.hazmat.primitives.asymmetric import mldsa


def ed_pub_from_bytes(raw: bytes) -> Ed25519PublicKey:
    pub_key: Ed25519PublicKey = mldsa.MLDSA65PublicKey.from_public_bytes(raw)
    return pub_key

def ed_priv_gen() -> Ed25519PrivateKey:
    priv_key: Ed25519PrivateKey = mldsa.MLDSA65PrivateKey.generate()
    return priv_key
