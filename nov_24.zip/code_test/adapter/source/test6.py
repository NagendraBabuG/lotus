from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec


class ECAdapter:

    def generate_private_key(self):
        return ec.generate_private_key(ec.SECP384R1())

    def sign(self, private_key, data):
        return private_key.sign(data, ec.ECDSA(hashes.SHA256()))

    def get_public_key(self, private_key):
        return private_key.public_key()

    def verify(self, public_key, signature, data):
        return public_key.verify(signature, data, ec.ECDSA(hashes.SHA256()))
