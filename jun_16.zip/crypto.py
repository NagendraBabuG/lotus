import base64
import os
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey,
    X25519PublicKey,
)
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.hashes import SHA256
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from quantcrypt.kem import MLKEM_768


# Chunk encryption format (per chunk):
#   [nonce 12B][ciphertext][tag 16B]
#
# Crypto header (stored in metadata, NOT in chunk files):
#   x25519_ephemeral_pk (32B) + mlkem_ciphertext
#
# AAD (associated data) for each chunk:
#   eph_pk_bytes || ml_ct || chunk_index (4B big-endian)
#
# This ensures:
#   - Each chunk has a unique nonce (no GCM counter overflow for files >64GB)
#   - The header is authenticated via AAD (tampering = immediate tag failure)
#   - Chunk index in AAD prevents chunk reordering attacks

_kem = MLKEM_768()
_MLKEM_CT_SIZE = _kem.param_sizes.ct_size


def generate_keypair() -> tuple[dict, dict]:
    """Generate hybrid X25519 + MLKEM768 keypair.
    Returns (public_keys, private_keys) as base64 dicts.
    """
    x_sk = X25519PrivateKey.generate()
    x_pk = x_sk.public_key()

    ml_pk, ml_sk = _kem.keygen()

    public_keys = {
        "x25519": base64.b64encode(
            x_pk.public_bytes_raw()
        ).decode(),
        "mlkem768": base64.b64encode(ml_pk).decode(),
    }
    private_keys = {
        "x25519": base64.b64encode(
            x_sk.private_bytes_raw()
        ).decode(),
        "mlkem768": base64.b64encode(ml_sk).decode(),
    }
    return public_keys, private_keys


def _derive_symmetric_key(x_shared: bytes, ml_shared: bytes) -> bytes:
    """Derive a 256-bit symmetric key from combined shared secrets via HKDF."""
    combined = x_shared + ml_shared
    return HKDF(
        algorithm=SHA256(),
        length=32,
        salt=None,
        info=b"catdrive-x25519-mlkem768",
    ).derive(combined)


def perform_key_exchange(public_keys: dict) -> tuple[bytes, bytes, bytes]:
    """Perform hybrid X25519 + MLKEM768 key exchange (sender side).

    Returns:
        (sym_key, eph_pk_bytes, ml_ct)
        - sym_key: 32-byte AES-256 key
        - eph_pk_bytes: 32-byte X25519 ephemeral public key
        - ml_ct: MLKEM768 ciphertext
    """
    # X25519: ephemeral key exchange
    x_peer_pk = X25519PublicKey.from_public_bytes(
        base64.b64decode(public_keys["x25519"])
    )
    x_eph_sk = X25519PrivateKey.generate()
    eph_pk_bytes = x_eph_sk.public_key().public_bytes_raw()
    x_shared = x_eph_sk.exchange(x_peer_pk)

    # MLKEM768: encapsulation
    ml_pk = base64.b64decode(public_keys["mlkem768"])
    ml_ct, ml_shared = _kem.encaps(ml_pk)

    # Derive symmetric key
    sym_key = _derive_symmetric_key(x_shared, ml_shared)

    return sym_key, eph_pk_bytes, ml_ct


def recover_key(private_keys: dict, eph_pk_bytes: bytes, ml_ct: bytes) -> bytes:
    """Recover the symmetric key from private keys and crypto header (receiver side).

    Returns:
        sym_key: 32-byte AES-256 key
    """
    # X25519: recover shared secret
    x_sk = X25519PrivateKey.from_private_bytes(
        base64.b64decode(private_keys["x25519"])
    )
    x_eph_pk = X25519PublicKey.from_public_bytes(eph_pk_bytes)
    x_shared = x_sk.exchange(x_eph_pk)

    # MLKEM768: decapsulate
    ml_sk = base64.b64decode(private_keys["mlkem768"])
    ml_shared = _kem.decaps(ml_sk, ml_ct)

    # Derive symmetric key
    sym_key = _derive_symmetric_key(x_shared, ml_shared)

    return sym_key


def build_chunk_aad(eph_pk_bytes: bytes, ml_ct: bytes, chunk_index: int) -> bytes:
    """Build the Associated Authenticated Data for a specific chunk.

    AAD = eph_pk_bytes || ml_ct || chunk_index (4-byte big-endian)

    This authenticates:
      - The crypto header (prevents header tampering)
      - The chunk position (prevents chunk reordering)
    """
    return eph_pk_bytes + ml_ct + chunk_index.to_bytes(4, "big")


def encrypt_chunk(sym_key: bytes, plaintext: bytes, aad: bytes) -> bytes:
    """Encrypt a single chunk with AES-256-GCM.

    Args:
        sym_key: 32-byte symmetric key from key exchange
        plaintext: raw chunk data (≤200MB)
        aad: associated authenticated data from build_chunk_aad()

    Returns:
        nonce (12B) || ciphertext || tag (16B)
    """
    aesgcm = AESGCM(sym_key)
    nonce = os.urandom(12)
    ciphertext = aesgcm.encrypt(nonce, plaintext, aad)
    return nonce + ciphertext


def decrypt_chunk(sym_key: bytes, chunk_data: bytes, aad: bytes) -> bytes:
    """Decrypt a single chunk with AES-256-GCM.

    Args:
        sym_key: 32-byte symmetric key from key recovery
        chunk_data: nonce (12B) || ciphertext || tag (16B)
        aad: associated authenticated data from build_chunk_aad()

    Returns:
        Decrypted plaintext bytes

    Raises:
        cryptography.exceptions.InvalidTag: if authentication fails
            (tampered data, wrong key, or mismatched AAD)
    """
    nonce = chunk_data[:12]
    ciphertext = chunk_data[12:]
    aesgcm = AESGCM(sym_key)
    return aesgcm.decrypt(nonce, ciphertext, aad)
