from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import ec

class ECAdapter:

    def generate_private_key(self):
        return ec.generate_private_key(ec.SECP521R1(), default_backend())

    def get_public_key(self, alice_private):
        return alice_private.public_key()

    def serialize_public_key(self, alice_public, ser_encoding, pub_format):
        return alice_public.public_bytes(ser_encoding, pub_format)

    def serialize_private_key(self, alice_private, ser_encoding, pri_format, pri_encrypt):
        return alice_private.private_bytes(ser_encoding, pri_format, pri_encrypt)

