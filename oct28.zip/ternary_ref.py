import ast

class TernaryRefactor(ast.NodeTransformer):
    def visit_If(self, node):
        self.generic_visit(node)

        if (len(node.body) == 1 and isinstance(node.body[0], ast.Expr) and
            len(node.orelse) == 1 and isinstance(node.orelse[0], ast.Expr)):

            return ast.Expr(
                value=ast.IfExp(
                    test=node.test,
                    body=node.body[0].value,
                    orelse=node.orelse[0].value
                )
            )
        elif (len(node.body) == 1 and isinstance(node.body[0], ast.Assign) and
              len(node.orelse) == 1 and isinstance(node.orelse[0], ast.Assign)):
            body_assign = node.body[0]
            else_assign = node.orelse[0]
            if len(body_assign.targets) == 1 and len(else_assign.targets) == 1:
                if ast.dump(body_assign.targets[0]) == ast.dump(else_assign.targets[0]):
                    return ast.Assign(
                        targets=body_assign.targets,
                        value=ast.IfExp(
                            test=node.test,
                            body=body_assign.value,
                            orelse=else_assign.value
                        )
                    )
        return node

    def visit_Assign(self, node):
        self.generic_visit(node)

        if isinstance(node.value, ast.IfExp):
            return ast.If(
                test=node.value.test,
                body=[ast.Assign(targets=node.targets, value=node.value.body)],
                orelse=[ast.Assign(targets=node.targets, value=node.value.orelse)]
            )
        return node

    def visit_Expr(self, node):
        self.generic_visit(node)

        if isinstance(node.value, ast.IfExp):
            # Convert ternary into if-else with Expr
            return ast.If(
                test=node.value.test,
                body=[ast.Expr(value=node.value.body)],
                orelse=[self.visit_Expr(ast.Expr(value=node.value.orelse))]
            )
        return node

    def get_refactored_code(self, source_code):
        try:
            tree = ast.parse(source_code)
            transformed = self.visit(tree)
            ast.fix_missing_locations(transformed)
            return ast.unparse(transformed)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")
        
wrapper = TernaryRefactor()
code = """ 
x = 10
if x > 5:
    print("x")
elif x >= 2: print("y")
else: print("z")

y = 20

if y%2 == 0: y = y + 1
else: y = y + 2


temperature = 25
weather_description = "Warm" if temperature > 20 else "Cool"
print(weather_description)
"""
tar = wrapper.get_refactored_code(code)

print(tar)