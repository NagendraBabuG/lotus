from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)

class Ed25519Adapter:

    def generate_private_key(self):
        return Ed25519PrivateKey.generate()

    def get_public_key(self, private):
        return private.public_key()

    def load_public_key(self, raw):
        return Ed25519PublicKey.from_public_bytes(raw)

    def exchange(self, private, public):
        return private.exchange(public)

    def sign(self, private, message):
        return private.sign(message)

    def verify(self, public, signature, message):
        return public.verify(signature, message)

