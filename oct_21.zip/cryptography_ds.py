"""from quantcrypt.dss import MLDSA_87
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
private_key_pub, private_key = MLDSA_87().keygen()
signature = MLDSA_87().sign(private_key, b"my authenticated message")
public_key = private_key_pub
# Raises InvalidSignature if verification fails
print(signature)
value = MLDSA_87().verify(private_key_pub, b"my authenticated message", signature)
print(value)"""
from quantcrypt.dss import MLDSA_65
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import dsa
private_key_pub, private_key = MLDSA_65().keygen()
data = b"this is some data I'd like to sign"
signature = MLDSA_65().sign(
    data,
    hashes.SHA256()
)

print(MLDSA_65().verify(private_key_pub, data, signature))