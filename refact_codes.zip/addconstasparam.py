import ast
import os
#takes constant value in functions and add it's as function parameter
#currently works on string constants only

class AddDefaultArgValue(ast.NodeTransformer):
    def __init__(self):
        self.func_par_map = {}  # Maps function names to parameter lists
        self.par_con_map = {}   # Maps parameter names to constant values
        self.con_par_map = {}   # Maps constant values to parameter names
        self.used_params = set()  # Track used parameter names to avoid duplicates

    def collect_mappings(self, tree):
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                var_idx = 0
                current_list = [] # List to keep track of the arguments being captured in the current function node.
                for node2 in node.body:
                    # check for the presence of constant-type argument/keywords within function calls.
                    if isinstance(node2, ast.Assign) and isinstance(node2.value, ast.Call):
                        # In case of constant-type arguments.
                        if node2.value.args:
                            for arg in node2.value.args:
                                if isinstance(arg, ast.Constant):
                                    var_name = f"var{var_idx}" # Generate a new parameter name for the argument.
                                    self.par_con_map[var_name] = arg.value # Map the new parameter to the argument.
                                    current_list.append(var_name)
                                    var_idx += 1
                        # In case of constant-type keywords
                        if node2.value.keywords:
                            temp_kw_list = []
                            for kw in node2.value.keywords:
                                if isinstance(kw.value, ast.Constant):
                                    self.par_con_map[kw.arg] = kw.value.value # Use the keyword as a parameter and map it to its constant object
                                    current_list.append(kw.arg)
                # Map the function name with the list of parameters extracted from its function call statements.
                self.func_par_map[node.name] = current_list

        return tree

    def secondtraverse(self, tree):
        self.con_par_map = {} # Mapping between constants and their parameters.
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                # Check if the current function has been recorded or not.
                if node.name in self.func_par_map:
                    # Loop through each argument recorded and add it as a parameter to the function definition.
                    for parameter in self.func_par_map[node.name]:
                        if parameter:
                            # Update the args and default values.
                            node.args.args.append(ast.arg(arg=parameter))
                            node.args.defaults.append(ast.Constant(value=self.par_con_map[parameter]))
                            # Map the constants with their resp. parameters.
                            self.con_par_map[self.par_con_map[parameter]] = parameter

            # Replacement of constants within function calls with their resp. parameters.
            elif isinstance(node, ast.Call):
                # At each call node, remove the contents present within the ‘keyword’ fields and update the ‘arg’ fields.
                if node.args:
                    for arg in node.args:
                        if isinstance(arg, ast.Constant) and arg.value in self.con_par_map:
                            node.args.remove(arg)
                            node.args.append(ast.Name(
                                id=self.con_par_map[arg.value], ctx=ast.Load()
                            ))

                if node.keywords:
                    for kw in node.keywords:
                        if kw.value.value in self.con_par_map:
                            node.args.append(ast.Name(
                                id=self.con_par_map[kw.value.value], ctx=ast.Load()
                            ))
                            node.keywords.remove(kw)

            ast.fix_missing_locations(node)

        return tree
    def refactor_functions(self, tree):
        tree = self.collect_mappings(tree)
        tree = self.secondtraverse(tree)
        return ast.unparse(tree)

    def get_refactored_code(self, source_code):
        try:
            tree = ast.parse(source_code)
            return self.refactor_functions(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")
#working for only few testcases