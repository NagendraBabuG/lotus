import ast
import importlib.util
import sys
import os
from pathlib import Path
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from Levenshtein import distance
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

tokenizer = AutoTokenizer.from_pretrained("microsoft/codebert-base")
model = AutoModelForSequenceClassification.from_pretrained("microsoft/codebert-base")


MAX_LENGTH = 512

def tokenize_code(code1, code2):
    return tokenizer(code1, code2, return_tensors="pt", max_length=MAX_LENGTH,
                     truncation=True, padding="max_length")

def predict_clone_probability(code1, code2):
    inputs = tokenize_code(code1, code2)
    model.eval()
    with torch.no_grad():
        outputs = model(**inputs)
        prob = torch.softmax(outputs.logits, dim=1)[:, 1].item() 
    return prob

def levenshtein_difference_percentage(code1, code2):
    lev_dist = distance(code1, code2)
    max_len = max(len(code1), len(code2))
    return 0.0 if max_len == 0 else (lev_dist / max_len) * 100

def embedding_similarity_difference(code1, code2):
    inputs1 = tokenizer(code1, return_tensors="pt", max_length=MAX_LENGTH, truncation=True, padding=False)
    inputs2 = tokenizer(code2, return_tensors="pt", max_length=MAX_LENGTH, truncation=True, padding=False)

    with torch.no_grad():
        emb1 = model.roberta(**inputs1).last_hidden_state.mean(dim=1).numpy()
        emb2 = model.roberta(**inputs2).last_hidden_state.mean(dim=1).numpy()

    similarity = cosine_similarity(emb1, emb2)[0][0]
    return (1 - similarity) * 100  

def get_function_names(code):
    try:
        tree = ast.parse(code)
        return [node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)]
    except:
        return []

def check_behavioral_equivalence(code1, code2, temp_dir="temp_modules"):
    os.makedirs(temp_dir, exist_ok=True)
    path1 = os.path.join(temp_dir, "original.py")
    path2 = os.path.join(temp_dir, "refactored.py")

    try:
        with open(path1, "w", encoding="utf-8") as f:
            f.write(code1)
        with open(path2, "w", encoding="utf-8") as f:
            f.write(code2)

        func_names1 = get_function_names(code1)
        func_names2 = get_function_names(code2)
        common_funcs = set(func_names1) & set(func_names2)

        if not common_funcs:
            try:
                ast1 = ast.parse(code1)
                ast2 = ast.parse(code2)
                if ast.dump(ast1, annotate_fields=False) == ast.dump(ast2, annotate_fields=False):
                    return True, "No functions, but AST structure is identical"
                else:
                    return False, "No common functions and AST differs"
            except Exception as e:
                return False, f"AST parsing failed: {str(e)}"

        spec1 = importlib.util.spec_from_file_location("original", path1)
        mod1 = importlib.util.module_from_spec(spec1)
        spec1.loader.exec_module(mod1)

        spec2 = importlib.util.spec_from_file_location("refactored", path2)
        mod2 = importlib.util.module_from_spec(spec2)
        spec2.loader.exec_module(mod2)

        test_inputs = [(1,), (2,), (0,), (10,), (), (5, 3), (0, 0)]

        for func_name in common_funcs:
            func1 = getattr(mod1, func_name, None)
            func2 = getattr(mod2, func_name, None)
            if not (callable(func1) and callable(func2)):
                continue

            for args in test_inputs:
                try:
                    result1 = func1(*args)
                    result2 = func2(*args)
                    if result1 != result2:
                        return False, f"Output differs for {func_name}{args}: {result1} vs {result2}"
                except Exception:
                    continue  

        return True, "All tested functions behave identically"

    except Exception as e:
        return False, f"Execution/AST error: {str(e)}"
    finally:
        for p in [path1, path2]:
            if os.path.exists(p):
                os.remove(p)
        if os.path.exists(temp_dir) and not os.listdir(temp_dir):
            os.rmdir(temp_dir)


def analyze_code_pair(code_before: str, code_after: str) -> dict:
    clone_prob = predict_clone_probability(code_before, code_after)

    syntactic_diff = levenshtein_difference_percentage(code_before, code_after)

    embedding_diff = embedding_similarity_difference(code_before, code_after)

    behavior_ok, behavior_msg = check_behavioral_equivalence(code_before, code_after)

    is_clone = clone_prob > 0.5
    conclusion = "Likely a clean refactor (semantic clone)" if (is_clone and behavior_ok) else "Not a clone or behavior changed"

    result = {
        "clone_probability": clone_prob,
        "is_clone": is_clone,
        "syntactic_difference_percent": round(syntactic_diff, 2),
        "semantic_difference_percent": round(embedding_diff, 2),
        "behavior_equivalent": behavior_ok,
        "behavior_message": behavior_msg,
        "conclusion": conclusion
    }

    
    print(f"Clone Probability      : {clone_prob:.2%}")
    print(f"Syntactic Diff (Lev.)  : {syntactic_diff:.2f}%")
    print(f"Semantic Diff (Emb.)   : {embedding_diff:.2f}%")
    print(f"Behavioral Equivalence : {behavior_ok} → {behavior_msg}")
    print(f"Conclusion             : {conclusion}")
    print("=" * 50)

    return result
"""

if __name__ == "__main__":
    code_before = "
def add(a, b):
    return a + b

def multiply(x, y):
    result = 0
    for _ in range(y):
        result += x
    return result
"

    code_after = "
def add(x, y):
    return x + y

def multiply(a, b):
    return a * b
"

    analyze_code_pair(code_before, code_after)

"""