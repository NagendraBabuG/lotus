# Hiero Identity MVP (Prework)

Minimal Python prototype demonstrating a DID + simple Verifiable Credential (VC) flow for contributor onboarding and PR verification.

## Quick start

1. Create a virtualenv and install requirements:

```bash
python -m venv .venv
# macOS / Linux
source .venv/bin/activate
# Windows PowerShell
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

2. Run the demo:

```bash
python demo.py
```

## What this prototype shows

- Generate issuer and contributor Ed25519 keypairs and simple DIDs
- Issue a signed VC binding a contributor DID to an email
- Verify the VC signature and check a commit-author email against the VC

## Files

- `src/mvp/keys.py` — key generation and simple DID helper
- `src/mvp/vc.py` — minimal VC issuance and signature verification
- `demo.py` — quick runnable demo
- `pr_verify.py` — CLI to generate/verify VCs (used by the action)
- `.github/actions/pr-verify/action.yml` — composite local action that runs the CLI
- `.github/workflows/pr-verify.yml` — workflow that runs the action on PR events

## GitHub repo / CI

1. Create a repo on GitHub (for example `hiero-identity-mvp`) and push this folder as the repository root.
2. The workflow `.github/workflows/pr-verify.yml` demonstrates running verification on PRs; the action is a local composite action that runs the `pr_verify.py` CLI.

## Quick CLI examples

```bash
# generate a sample VC
python pr_verify.py --generate-sample examples/sample_vc.json

# verify sample VC against an email
python pr_verify.py --vc examples/sample_vc.json --email alice@example.com
```

## Notes

This is a compact proof-of-concept intended to show how DIDs and VCs could be used to add an extra verification layer to PRs. It is deliberately minimal so it can be extended later (Heka integration, persistent credential storage, VC/LD compliance, GitHub App integration, etc.).
