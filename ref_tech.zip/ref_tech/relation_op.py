import ast

class RelationRefactors(ast.NodeTransformer):

    def change_exp(self, node: ast.Compare):
        if not (
            isinstance(node.left, ast.Name)
            and len(node.ops) == 1
            and len(node.comparators) == 1
            and isinstance(node.comparators[0], ast.Name)
        ):
            return node

        left = node.left.id
        right = node.comparators[0].id
        op = node.ops[0]

        op_map = {
            ast.Gt: ast.Lt,
            ast.GtE: ast.LtE,
            ast.Lt: ast.Gt,
            ast.LtE: ast.GtE,
            ast.Eq: ast.Eq,
            ast.NotEq: ast.NotEq,
        }

        new_op_cls = op_map.get(type(op))
        if not new_op_cls:
            return node

        new_node = ast.Compare(
            left=ast.Name(id=right, ctx=ast.Load()),
            ops=[new_op_cls()],
            comparators=[ast.Name(id=left, ctx=ast.Load())],
        )

        return ast.copy_location(new_node, node)

    def conditional_check(self, node):
        if isinstance(node, ast.Compare):
            return self.change_exp(node)

        if isinstance(node, ast.BoolOp):
            return ast.copy_location(
                ast.BoolOp(
                    op=node.op,
                    values=[self.conditional_check(v) for v in node.values],
                ),
                node,
            )

        return node  
    def get_refactored_code(self, code):
        tree = ast.parse(code)

        for node in ast.walk(tree):
            if isinstance(node, (ast.If, ast.While)):
                node.test = self.conditional_check(node.test)

        ast.fix_missing_locations(tree)
        return ast.unparse(tree)

