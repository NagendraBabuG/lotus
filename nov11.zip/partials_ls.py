import ast
from typing import List, Dict, Set
#partials refactor 

class PartialsRefactor(ast.NodeTransformer):
    def __init__(self):
        self.var_to_const: Dict[str, ast.Constant] = {}
        self.var_uses: Dict[str, List[ast.Name]] = {}
        self.scope: List[str] = ["module"]

    def _qname(self, name: str) -> str:
        return ".".join(self.scope + [name])

    def _is_constant_assignment(self, node: ast.AST) -> bool:
        if isinstance(node, ast.Assign):
            return (len(node.targets) == 1 and
                    isinstance(node.targets[0], ast.Name) and
                    isinstance(node.value, ast.Constant))
        if isinstance(node, ast.AnnAssign):
            return (isinstance(node.target, ast.Name) and
                    isinstance(node.value, ast.Constant))
        return False

    def _collect(self, tree: ast.Module) -> None:
        self.var_to_const.clear()
        self.var_uses.clear()
        self.scope = ["module"]

        for node in ast.walk(tree):
            for child in ast.iter_child_nodes(node):
                child.parent = node  # type: ignore

        for node in ast.walk(tree):
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
                q = self._qname(node.id)
                self.var_uses.setdefault(q, []).append(node)

            if isinstance(node, (ast.FunctionDef, ast.ClassDef)):
                self.scope.append(node.name)
            elif isinstance(node, ast.Return):
                if len(self.scope) > 1:
                    self.scope.pop()

        for node in ast.walk(tree):
            if self._is_constant_assignment(node):
                target = (node.targets[0] if isinstance(node, ast.Assign)
                          else node.target)
                q = self._qname(target.id)
                self.var_to_const[q] = node.value

        safe_vars: Set[str] = set()
        for q, const in self.var_to_const.items():
            uses = self.var_uses.get(q, [])
            if all(hasattr(u, 'parent') and
                   isinstance(u.parent, ast.Call) and
                   u in u.parent.args
                   for u in uses):
                safe_vars.add(q)
        self.var_to_const = {q: v for q, v in self.var_to_const.items() if q in safe_vars}

    def _replace_and_remove(self, tree: ast.Module) -> ast.Module:
        new_body: List[ast.AST] = []
        for stmt in tree.body:
            if self._is_constant_assignment(stmt):
                target = (stmt.targets[0] if isinstance(stmt, ast.Assign)
                          else stmt.target)
                q = self._qname(target.id)
                if q in self.var_to_const:
                    continue
            new_body.append(stmt)
        tree.body = new_body

        class KeywordInjector(ast.NodeTransformer):
            def __init__(self, var_to_const: Dict[str, ast.Constant]):
                self.var_to_const = var_to_const
                self.scope = ["module"]

            def _qname(self, name: str) -> str:
                return ".".join(self.scope + [name])

            def visit_FunctionDef(self, node: ast.FunctionDef):
                self.scope.append(node.name)
                node = self.generic_visit(node)
                self.scope.pop()
                return node

            def visit_ClassDef(self, node: ast.ClassDef):
                self.scope.append(node.name)
                node = self.generic_visit(node)
                self.scope.pop()
                return node

            def visit_Call(self, node: ast.Call):
                node = self.generic_visit(node)
                kw_names = {kw.arg for kw in node.keywords if kw.arg}
                args_to_remove: List[ast.AST] = []
                for arg in node.args:
                    if isinstance(arg, ast.Name):
                        q = self._qname(arg.id)
                        if q in self.var_to_const and arg.id not in kw_names:
                            const = self.var_to_const[q]
                            node.keywords.append(
                                ast.keyword(
                                    arg=arg.id,
                                    value=ast.copy_location(const, arg)
                                )
                            )
                            args_to_remove.append(arg)
                for a in args_to_remove:
                    node.args.remove(a)
                return node

        return KeywordInjector(self.var_to_const).visit(tree)

    def visit(self, node: ast.AST) -> ast.AST:
        if isinstance(node, ast.Module):
            self._collect(node)
            node = self._replace_and_remove(node)
        return self.generic_visit(node)

    def get_refactored_code(self, source_code: str) -> str:
        tree = ast.parse(source_code)
        transformed = self.visit(tree)
        ast.fix_missing_locations(transformed)
        return ast.unparse(transformed)


if __name__ == "__main__":
    src = '''
def sign(key, msg):
    signer = pkcs1_15.new(key)
    signature = signer.sign(msg)
    return signature

key = keygen(102)
msg = b'hello'
signed = sign(key, msg)
signed2 = sign(key, msg=b'bye')
'''

    injector = PartialsRefactor()
    print(injector.get_refactored_code(src))