from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec


class ECAdapter:

    def get_public_key(self, private_key):
        return private_key.public_key()

    def sign(self, private_key, data):
        return private_key.sign(data, ec.ECDSA(hashes.SHA256()))
