def show():
    print(MESSAGE)
MESSAGE = 'Hello'
show()