import base64, json, hashlib, requests, secrets, sys, time
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import ec

class ECDHAdapter:

    def generate_private_key(self):
        return ec.generate_private_key(ec.BrainpoolP256R1(), default_backend())

    def BrainpoolP256R1(self):
        return ec.BrainpoolP256R1()

    def get_public_key(self, private_key):
        return private_key.public_key()

    def exchange(self, private_key, fdz_public_key):
        return private_key.exchange(ec.ECDH(), fdz_public_key)

    def ECDH(self):
        return ec.ECDH()

