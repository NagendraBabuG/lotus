def handled():
    try:
        x = 1 / 0
    except:
        print("Handled")

        
def validate(x):
    if x < 0:
        raise ValueError("x must be non-negative")
