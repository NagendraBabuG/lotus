from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import dsa

class DSAAdapter:

    def generate_private_key(self):
        return dsa.generate_private_key(key_size=1024)

    def sign(self, private_key, data):
        return private_key.sign(data, hashes.SHA256())

    def get_public_key(self, private_key):
        return private_key.public_key()

    def verify(self, public_key, signature, data):
        return public_key.verify(signature, data, hashes.SHA256())

