def countdown_for(n):
    for i in range(n, 0, -1):
        print(i)
countdown_for(5)