def outer():
    def inner(y): return y + 1
    return inner(10)



def power(base, exp=2): return base ** exp


def sum_all(*args): return sum(args)

