def update(x):
    x += 1
    return x


def mutate_list(items):
    for i in range(len(items)):
        items[i] += 1
