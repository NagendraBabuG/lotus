import ast


class LoopStyleTransformer(ast.NodeTransformer):
    def __init__(self):
        self.loop_stack = []

    def visit_For(self, node):
        if (isinstance(node.iter, ast.Call) and
            isinstance(node.iter.func, ast.Name) and
            node.iter.func.id == "range"):

            self.generic_visit(node)

            if not isinstance(node.target, ast.Name):
                return node

            loop_var = node.target.id

            args = node.iter.args
            if len(args) == 1:
                start = ast.Constant(value=0)
                stop = args[0]
                step = ast.Constant(value=1)
            elif len(args) == 2:
                start = args[0]
                stop = args[1]
                step = ast.Constant(value=1)
            elif len(args) == 3:
                start = args[0]
                stop = args[1]
                step = args[2]
            else:
                return node

            ops = [ast.Lt()]
            if isinstance(step, ast.Constant) and step.value < 0:
                ops = [ast.Gt()]

            init = ast.Assign(
                targets=[ast.Name(id=loop_var, ctx=ast.Store())],
                value=start
            )

            cond = ast.Compare(
                left=ast.Name(id=loop_var, ctx=ast.Load()),
                ops=ops,
                comparators=[stop]
            )

            incr = ast.AugAssign(
                target=ast.Name(id=loop_var, ctx=ast.Store()),
                op=ast.Add(),
                value=step
            )

            while_node = ast.While(
                test=cond,
                body=node.body + [incr],
                orelse=node.orelse
            )

            ast.fix_missing_locations(init)
            ast.fix_missing_locations(while_node)

            return [init, while_node]

        else:
            if not isinstance(node.target, ast.Name):
                return node

            loop_var = node.target.id

            node.iter = self.visit(node.iter)
            node.orelse = [self.visit(o) for o in node.orelse]

            idx_name = f"_idx_{loop_var}_{len(self.loop_stack)}"

            init_idx = ast.Assign(
                targets=[ast.Name(id=idx_name, ctx=ast.Store())],
                value=ast.Constant(value=0)
            )

            len_call = ast.Call(
                func=ast.Name(id="len", ctx=ast.Load()),
                args=[node.iter],
                keywords=[]
            )

            cond = ast.Compare(
                left=ast.Name(id=idx_name, ctx=ast.Load()),
                ops=[ast.Lt()],
                comparators=[len_call]
            )

            incr_idx = ast.AugAssign(
                target=ast.Name(id=idx_name, ctx=ast.Store()),
                op=ast.Add(),
                value=ast.Constant(value=1)
            )

            self.loop_stack.append((loop_var, node.iter, idx_name))

            new_body = [self.visit(stmt) for stmt in node.body] + [incr_idx]

            self.loop_stack.pop()

            while_node = ast.While(
                test=cond,
                body=new_body,
                orelse=node.orelse
            )

            ast.fix_missing_locations(init_idx)
            ast.fix_missing_locations(while_node)

            return [init_idx, while_node]

    def visit_While(self, node):
        self.generic_visit(node)

        if not isinstance(node.test, ast.Compare):
            return node

        if len(node.test.ops) != 1 or len(node.test.comparators) != 1:
            return node

        op = node.test.ops[0]
        left = node.test.left
        right = node.test.comparators[0]

        if not isinstance(left, ast.Name):
            return node

        loop_var = left.id

        incr_stmt = None
        step_node = ast.Constant(value=1)
        is_add = True

        new_body = node.body[:]

        for i, stmt in enumerate(new_body):
            if isinstance(stmt, ast.AugAssign) and isinstance(stmt.target, ast.Name) and stmt.target.id == loop_var:
                if isinstance(stmt.op, ast.Add):
                    is_add = True
                    step_node = stmt.value
                elif isinstance(stmt.op, ast.Sub):
                    is_add = False
                    step_node = stmt.value
                incr_stmt = stmt
                del new_body[i]
                break

            elif isinstance(stmt, ast.Assign) and len(stmt.targets) == 1 and isinstance(stmt.targets[0], ast.Name) and stmt.targets[0].id == loop_var and isinstance(stmt.value, ast.BinOp) and isinstance(stmt.value.left, ast.Name) and stmt.value.left.id == loop_var:
                if isinstance(stmt.value.op, ast.Add):
                    is_add = True
                    step_node = stmt.value.right
                elif isinstance(stmt.value.op, ast.Sub):
                    is_add = False
                    step_node = stmt.value.right
                incr_stmt = stmt
                del new_body[i]
                break

        if not incr_stmt:
            return node

        if isinstance(op, ast.Lt) and is_add:
            start_node = ast.Name(id=loop_var, ctx=ast.Load())
            stop_node = right
            step_node = step_node

        elif isinstance(op, ast.Gt) and not is_add:
            start_node = ast.Name(id=loop_var, ctx=ast.Load())
            stop_node = right
            step_node = ast.UnaryOp(op=ast.USub(), operand=step_node)

        else:
            return node

        for_node = ast.For(
            target=ast.Name(id=loop_var, ctx=ast.Store()),
            iter=ast.Call(
                func=ast.Name(id="range", ctx=ast.Load()),
                args=[start_node, stop_node, step_node],
                keywords=[]
            ),
            body=new_body,
            orelse=node.orelse
        )

        ast.fix_missing_locations(for_node)
        return for_node

    def visit_Name(self, node):
        if not self.loop_stack or not isinstance(node.ctx, ast.Load):
            return node

        for loop_var, iterable, idx_name in reversed(self.loop_stack):
            if node.id == loop_var:
                return ast.Subscript(
                    value=iterable,
                    slice=ast.Name(id=idx_name, ctx=ast.Load()),
                    ctx=ast.Load()
                )
        return node

    def visit_Subscript(self, node):
        self.generic_visit(node)

        if not self.loop_stack:
            return node

        for loop_var, _, idx_name in reversed(self.loop_stack):
            if isinstance(node.slice, ast.Name) and node.slice.id == loop_var:
                node.slice = ast.Name(id=idx_name, ctx=ast.Load())
                break

        return node

    def get_refactored_code(self, source_code):
        try:
            tree = ast.parse(source_code)
            tree = self.visit(tree)
            ast.fix_missing_locations(tree)
            return ast.unparse(tree)
        except Exception as e:
            raise ValueError(f"Error during transformation: {type(e).__name__}: {str(e)}")

