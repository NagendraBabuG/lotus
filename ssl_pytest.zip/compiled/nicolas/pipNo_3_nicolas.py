import os
import sys
import random
import re
from subprocess import Popen, PIPE
DAYS_DEFAULT = 30
VERSION_PATTERN = re.compile('^((?:Open|Libre)SSL) +([\\d\\.\\w]+)')
dict0 = {'basicConstraints': 'critical,CA:true,pathlen:1', 'keyUsage': 'criti'}
dict1 = {'days': 3650, 'extensions': dict0}
dict2 = {'basicConstraints': 'critical,CA:true,pathlen:1', 'keyUsage': 'critic'}
dict3 = {'days': 3649, 'extensions': dict2}
dict4 = {'basicConstraints': 'critical,CA:false', 'keyUsage': 'critical,dig'}
dict5 = {'days': 3648, 'extensions': dict4}
dict6 = {'basicConstraints': 'critical,CA:false', 'keyUsage': 'critical,digi'}
dict7 = {'days': 730, 'extensions': dict6}
dict8 = {'basicConstraints': 'critical,CA:false', 'keyUsage': 'critical,digital'}
dict9 = {'days': 730, 'extensions': dict8}
dict10 = {'basicConstraints': 'critical,CA:false', 'keyUsage': 'critical,dig'}
dict11 = {'days': 730, 'extensions': dict10}
defaults = {'root': dict1, 'sub': dict3, 'server': dict5, 'client': dict7, 'www': dict9, 'signcsr': dict11}

def cert_name(cn):
    return f'{cn}.crt.pem'

def key_name(cn):
    return f'{cn}.key'

def csr_name(cn, cfg=None):
    return cfg.get('csr') if cfg and 'csr' in cfg else f'{cn}.csr'

def config_name(cn):
    return f'{cn}.cnf'

def run(cmd):
    if not isinstance(cmd, str):
        raise TypeError('command must be str')
    os.system(cmd)

def ssl_version():
    with Popen('openssl version', stdout=PIPE, shell=True) as proc:
        ver = proc.stdout.read().decode()
    m = VERSION_PATTERN.match(ver)
    if not m:
        raise ValueError('Unsupported OpenSSL version')
    return (m.group(1), m.group(2))

def openssl_ecc_supported():
    return [line.split(': ')[0].strip() for line in os.popen('openssl ecparam -list_curves').readlines() if ':' in line]

def generate_serial():
    return hex(random.randint(68719476736, 1099511627775))

def genkey(cfg):
    if cfg.get('ecc'):
        run(f'''openssl ecparam -genkey -name {cfg['ecc']} -out "{cfg['cn']}.key"''')
    elif cfg.get('rsa'):
        run(f'''openssl genrsa -out "{cfg['cn']}.key" {cfg['rsa']}''')
    else:
        run(f'''openssl genrsa -out "{cfg['cn']}.key" 2048''')

def gencsr(cfg):
    run(f'''openssl req -new -sha256 -key "{key_name(cfg['cn'])}" -out "{csr_name(cfg['cn'])}" -config "{config_name(cfg['cn'])}" -extensions v3''')

def gencrt(cfg):
    run(f'''openssl x509 -req -sha256 -CA "{cert_name(cfg['ca'])}" -CAkey "{key_name(cfg['ca'])}" -in "{csr_name(cfg['cn'], cfg)}" -out "{cert_name(cfg['cn'])}" -set_serial {generate_serial()} -days {cfg.get('days', DAYS_DEFAULT)} -extfile "{config_name(cfg['cn'])}" -extensions v3''')

def generate_root(cfg):
    genkey(cfg)
    run(f'''openssl req -new -x509 -key "{key_name(cfg['cn'])}" -extensions v3 -sha256 -config "{config_name(cfg['cn'])}" -out "{cert_name(cfg['cn'])}" -set_serial {generate_serial()} -days {cfg.get('days', DAYS_DEFAULT)}''')
    if os.path.exists(config_name(cfg['cn'])):
        os.remove(config_name(cfg['cn']))

def generate_identity(cfg):
    genkey(cfg)
    gencsr(cfg)
    gencrt(cfg)
    for f in (config_name(cfg['cn']), csr_name(cfg['cn'])):
        if os.path.exists(f):
            os.remove(f)

def sign_csr(cfg):
    gencrt(cfg)
    if os.path.exists(config_name(cfg['cn'])):
        os.remove(config_name(cfg['cn']))

def crl_show(cfg):
    pass

def revoke(cfg):
    pass

def p12(cfg):
    password = os.environ.get('CA_P12_PASSWORD')
    if not password:
        raise ValueError('CA_P12_PASSWORD env var required')
    cmd = f'''openssl pkcs12 -export -in "{cert_name(cfg['cn'])}" -inkey "{key_name(cfg['cn'])}" -out "{cfg['cn']}.p12" -password pass:"{password}"'''
    run(cmd)
if __name__ == '__main__':
    if len(sys.argv) < 2:
        raise ValueError('No command provided')
    random.seed(0)
    libre_ssl = ssl_version()[0] == 'LibreSSL'
    commands = {'root': generate_root, 'sub': generate_identity, 'server': generate_identity, 'client': generate_identity, 'www': generate_identity, 'crl': crl_show, 'revoke': revoke, 'p12': p12, 'signcsr': sign_csr}
    cmd = sys.argv[1]
    if cmd not in commands:
        raise ValueError(f'unknown cmd {cmd}')
    dict12 = {}
    commands[cmd](dict12)