from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec


class ECAdapter:

    def verify(self, public_key, signature, data):
        return public_key.verify(signature, data, ec.ECDSA(hashes.SHA256()))
