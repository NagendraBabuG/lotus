@staticmethod
def identity(x): return x

def square(x): return x*x