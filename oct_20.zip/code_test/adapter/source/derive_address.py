from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization

class Ed25519Adapter:

    def load_private_key(self, sk_bytes):
        return Ed25519PrivateKey.from_private_bytes(sk_bytes)

    def get_public_key(self, private_key):
        return private_key.public_key()

    def serialize_public_key(self, public_key):
        return public_key.public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)

