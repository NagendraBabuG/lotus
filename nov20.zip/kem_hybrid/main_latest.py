#!/usr/bin/env python3
"""
Generalized adapter test harness for classical and hybrid (PQC + classical) adapters.
"""

from __future__ import annotations

import ast
import csv
import importlib.util
import os
import sys
import traceback
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

try:
    from matching_adapter import get_expected_target
except ImportError:
    def get_expected_target(source_name: str, source_file: Path) -> Optional[str]:
        return source_name

ROOT = Path(__file__).resolve().parent / "adapter"
SOURCE_DIR = ROOT / "source"
TARGET_DIR = ROOT / "target"
RESULT_FILE = ROOT / "test_results.csv"


def get_class_names(file_path: Path) -> List[str]:
    tree = ast.parse(file_path.read_text(encoding="utf-8"))
    return [node.name for node in tree.body if isinstance(node, ast.ClassDef)]


def load_classes(file_path: Path) -> Dict[str, type]:
    module_name = f"adapter_test_{file_path.stem}_{abs(hash(str(file_path)))}"
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {file_path}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)

    return {
        name: getattr(module, name)
        for name in get_class_names(file_path)
        if hasattr(module, name)
    }


METHOD_ALIASES = {
    "load_private_key": ("load_private_key", "deserialize_private_key"),
    "load_public_key": ("load_public_key", "deserialize_public_key"),
    "serialize_private_key": ("serialize_private_key", "serialize_private"),
    "serialize_public_key": ("serialize_public_key", "serialize_public"),
}


def _candidate_names(base: str) -> Tuple[str, ...]:
    aliases = METHOD_ALIASES.get(base, (base,))
    prefixed = []
    for a in aliases:
        prefixed.extend([f"classical_{a}", f"pqc_{a}"])
    return aliases + tuple(prefixed)


def get_method(adapter: Any, method_name: str) -> Callable:
    for name in _candidate_names(method_name):
        method = getattr(adapter, name, None)
        if callable(method):
            return method
    raise AttributeError(f"Missing method: {method_name} (tried {_candidate_names(method_name)})")


def has_method(adapter_or_cls: Any, method_name: str) -> bool:
    try:
        get_method(adapter_or_cls, method_name)
        return True
    except AttributeError:
        return False


def is_hybrid(adapter_or_cls: Any) -> bool:
    has_classical = any(
        callable(getattr(adapter_or_cls, f"classical_{m}", None))
        for m in ("generate_private_key", "load_private_key", "get_public_key")
    )
    has_pqc = any(
        callable(getattr(adapter_or_cls, f"pqc_{m}", None))
        for m in ("generate_private_key", "load_private_key", "get_public_key")
    )
    return has_classical and has_pqc


def generate_private_key(adapter: Any, component: str = "auto"):
    if component == "classical" and hasattr(adapter, "classical_generate_private_key"):
        return adapter.classical_generate_private_key()
    if component == "pqc" and hasattr(adapter, "pqc_generate_private_key"):
        return adapter.pqc_generate_private_key()
    for name in ("generate_private_key", "classical_generate_private_key", "pqc_generate_private_key"):
        if callable(getattr(adapter, name, None)):
            return getattr(adapter, name)()
    raise AttributeError("No generate_private_key variant found")


def get_public_key(adapter: Any, private_key: Any, component: str = "auto"):
    if component == "classical" and hasattr(adapter, "classical_get_public_key"):
        return adapter.classical_get_public_key(private_key)
    if component == "pqc" and hasattr(adapter, "pqc_get_public_key"):
        return adapter.pqc_get_public_key(private_key)
    for name in ("get_public_key", "classical_get_public_key", "pqc_get_public_key"):
        if callable(getattr(adapter, name, None)):
            return getattr(adapter, name)(private_key)
    raise AttributeError("No get_public_key variant found")


def load_private_key(adapter: Any, data: bytes, component: str = "auto"):
    if component == "classical" and hasattr(adapter, "classical_load_private_key"):
        return adapter.classical_load_private_key(data)
    if component == "pqc" and hasattr(adapter, "pqc_load_private_key"):
        return adapter.pqc_load_private_key(data)
    for name in ("load_private_key", "classical_load_private_key", "pqc_load_private_key"):
        if callable(getattr(adapter, name, None)):
            return getattr(adapter, name)(data)
    raise AttributeError("No load_private_key variant found")


def perform_key_exchange(adapter: Any, private_key: Any, peer_public_key: Any):
    exchange = getattr(adapter, "exchange", None)
    if callable(exchange):
        return exchange(private_key, peer_public_key)

    encapsulate = getattr(adapter, "encapsulate", None)
    decapsulate = getattr(adapter, "decapsulate", None)
    if callable(encapsulate) and callable(decapsulate):
        ciphertext, shared_secret = encapsulate(peer_public_key)
        recovered = decapsulate(private_key, ciphertext)
        return shared_secret, recovered

    for prefix in ("classical_", "pqc_", ""):
        exch = getattr(adapter, f"{prefix}exchange", None)
        if callable(exch):
            return exch(private_key, peer_public_key)

    raise AttributeError("No exchange / encapsulate+decapsulate methods found")


def _guess_seed_size(adapter: Any, component: str = "auto") -> int:
    name = type(adapter).__name__.upper()
    if component == "pqc" or "MLKEM" in name or "KYBER" in name:
        return 64
    if "X448" in name:
        return 56
    if "X25519" in name or "ED25519" in name:
        return 32
    return 32


def make_seed(adapter: Any, component: str = "auto") -> bytes:
    return os.urandom(_guess_seed_size(adapter, component))


def test_generate_private_key(adapter: Any):
    pk = generate_private_key(adapter)
    assert pk is not None

    if is_hybrid(adapter):
        if hasattr(adapter, "classical_generate_private_key"):
            assert adapter.classical_generate_private_key() is not None
        if hasattr(adapter, "pqc_generate_private_key"):
            assert adapter.pqc_generate_private_key() is not None


def test_get_public_key(adapter: Any):
    priv = generate_private_key(adapter)
    pub = get_public_key(adapter, priv)
    assert pub is not None

    if is_hybrid(adapter):
        if hasattr(adapter, "classical_generate_private_key") and hasattr(adapter, "classical_get_public_key"):
            c_priv = adapter.classical_generate_private_key()
            assert adapter.classical_get_public_key(c_priv) is not None
        if hasattr(adapter, "pqc_generate_private_key") and hasattr(adapter, "pqc_get_public_key"):
            p_priv = adapter.pqc_generate_private_key()
            assert adapter.pqc_get_public_key(p_priv) is not None


def test_load_private_key(adapter: Any):
    if is_hybrid(adapter):
        if hasattr(adapter, "classical_load_private_key"):
            seed = make_seed(adapter, "classical")
            assert adapter.classical_load_private_key(seed) is not None
        if hasattr(adapter, "pqc_load_private_key"):
            seed = make_seed(adapter, "pqc")
            assert adapter.pqc_load_private_key(seed) is not None
        if has_method(adapter, "load_private_key"):
            seed = make_seed(adapter)
            assert load_private_key(adapter, seed) is not None
    else:
        seed = make_seed(adapter)
        priv = load_private_key(adapter, seed)
        assert priv is not None


def test_exchange_shared_secret(adapter: Any):
    priv1 = generate_private_key(adapter)
    pub1 = get_public_key(adapter, priv1)

    has_enc = callable(getattr(adapter, "encapsulate", None))
    has_dec = callable(getattr(adapter, "decapsulate", None))
    has_ex = callable(getattr(adapter, "exchange", None))

    if has_enc and has_dec:
        ct, ss1 = adapter.encapsulate(pub1)
        ss2 = adapter.decapsulate(priv1, ct)
        assert ss1 is not None and ss2 is not None
        assert ss1 == ss2
        return

    if has_ex:
        priv2 = generate_private_key(adapter)
        pub2 = get_public_key(adapter, priv2)
        ss1 = adapter.exchange(priv1, pub2)
        ss2 = adapter.exchange(priv2, pub1)
        assert ss1 is not None and ss2 is not None
        assert ss1 == ss2
        return

    if is_hybrid(adapter):
        if hasattr(adapter, "classical_exchange"):
            c_priv1 = adapter.classical_generate_private_key()
            c_pub1 = adapter.classical_get_public_key(c_priv1)
            c_priv2 = adapter.classical_generate_private_key()
            c_pub2 = adapter.classical_get_public_key(c_priv2)
            ss1 = adapter.classical_exchange(c_priv1, c_pub2)
            ss2 = adapter.classical_exchange(c_priv2, c_pub1)
            assert ss1 == ss2
            return
        if hasattr(adapter, "pqc_encapsulate") and hasattr(adapter, "pqc_decapsulate"):
            p_priv = adapter.pqc_generate_private_key()
            p_pub = adapter.pqc_get_public_key(p_priv)
            ct, ss1 = adapter.pqc_encapsulate(p_pub)
            ss2 = adapter.pqc_decapsulate(p_priv, ct)
            assert ss1 == ss2
            return

    raise AttributeError(
        "Could not find a usable key-exchange path "
        "(exchange / encapsulate+decapsulate / classical_* / pqc_*)"
    )


def test_serialize_roundtrip(adapter: Any):
    if not (has_method(adapter, "serialize_private_key") and has_method(adapter, "load_private_key")):
        raise AttributeError("serialize/load private key not available")

    priv = generate_private_key(adapter)
    data = get_method(adapter, "serialize_private_key")(priv)
    assert isinstance(data, (bytes, bytearray))
    loaded = load_private_key(adapter, data)
    assert loaded is not None

    if has_method(adapter, "serialize_public_key") and has_method(adapter, "load_public_key"):
        pub = get_public_key(adapter, priv)
        pub_data = get_method(adapter, "serialize_public_key")(pub)
        loaded_pub = get_method(adapter, "load_public_key")(pub_data)
        assert loaded_pub is not None


TESTS: List[Tuple[str, bool, Tuple[str, ...], Callable]] = [
    (
        "Generate private key",
        True,
        ("generate_private_key",),
        test_generate_private_key,
    ),
    (
        "Get public key",
        True,
        ("generate_private_key", "get_public_key"),
        test_get_public_key,
    ),
    (
        "Load private key",
        True,
        ("load_private_key",),
        test_load_private_key,
    ),
    (
        "Exchange / KEM shared secret",
        True,
        ("generate_private_key", "get_public_key"),
        test_exchange_shared_secret,
    ),
    (
        "Serialize / load round-trip",
        True,
        ("serialize_private_key", "load_private_key"),
        test_serialize_roundtrip,
    ),
]


def execute_test(
    adapter_cls: type,
    expected_success: bool,
    required_methods: Tuple[str, ...],
    test_func: Callable,
) -> Dict[str, Any]:
    missing = []
    for name in required_methods:
        if not has_method(adapter_cls, name):
            if not (has_method(adapter_cls, f"classical_{name}") or has_method(adapter_cls, f"pqc_{name}")):
                missing.append(name)

    if missing:
        return {
            "result": "SKIP",
            "behavior": ("SKIP", tuple(missing)),
            "details": f"Missing methods: {', '.join(missing)}",
        }

    try:
        instance = adapter_cls()
        test_func(instance)
        return {
            "result": "PASS" if expected_success else "FAIL",
            "behavior": ("RETURNED",),
            "details": "Completed successfully" if expected_success else "Expected exception, none raised",
        }
    except Exception as exc:
        return {
            "result": "FAIL" if expected_success else "PASS",
            "behavior": ("EXCEPTION", type(exc).__name__),
            "details": f"{type(exc).__name__}: {exc}",
        }


def compare_test(
    source_cls: type,
    target_cls: type,
    test_name: str,
    expected_success: bool,
    required_methods: Tuple[str, ...],
    test_func: Callable,
    source_name: str,
    target_name: str,
    file_name: str,
) -> Dict[str, Any]:
    source_result = execute_test(source_cls, expected_success, required_methods, test_func)
    target_result = execute_test(target_cls, expected_success, required_methods, test_func)

    if source_result["result"] == "SKIP" and target_result["result"] == "SKIP":
        comparison = "BOTH SKIPPED"
    elif source_result["behavior"] == target_result["behavior"]:
        comparison = "EQUIVALENT BEHAVIOUR"
    else:
        comparison = "DIVERGENT BEHAVIOUR"

    print(f"{file_name}: {source_name} → {target_name}")
    print(f"  Test      : {test_name}")
    print(f"  Source    : {source_result['result']} – {source_result['details']}")
    print(f"  Target    : {target_result['result']} – {target_result['details']}")
    print(f"  Comparison: {comparison}\n")

    return {
        "file": file_name,
        "source_class": source_name,
        "target_class": target_name,
        "test": test_name,
        "source_result": source_result["result"],
        "source_details": source_result["details"],
        "target_result": target_result["result"],
        "target_details": target_result["details"],
        "comparison": comparison,
    }


def main() -> None:
    all_results: List[Dict[str, Any]] = []

    if not SOURCE_DIR.exists():
        print(f"Source directory not found: {SOURCE_DIR}")
        return

    for source_file in sorted(SOURCE_DIR.rglob("*.py")):
        relative_path = source_file.relative_to(SOURCE_DIR)
        target_file = TARGET_DIR / relative_path

        if not target_file.exists():
            print(f"Missing target file: {relative_path}\n")
            continue

        try:
            source_classes = load_classes(source_file)
            target_classes = load_classes(target_file)
        except Exception as exc:
            print(f"Could not load {relative_path}: {type(exc).__name__}: {exc}\n")
            traceback.print_exc()
            continue

        if not source_classes or not target_classes:
            print(f"No adapter classes found in {relative_path}\n")
            continue

        if len(source_classes) != len(target_classes):
            print(
                f"WARNING: different class counts in {relative_path}: "
                f"source={len(source_classes)}, target={len(target_classes)}\n"
            )

        for source_name, source_cls in source_classes.items():
            expected_target = get_expected_target(source_name, source_file)
            if expected_target is None:
                print(f"MAPPING NOT DEFINED: {relative_path}: {source_name}\n")
                continue
            if expected_target not in target_classes:
                print(f"MATCH NOT PRESENT: {relative_path}: {source_name} → {expected_target}\n")
                continue

            target_cls = target_classes[expected_target]

            for test_name, expected, methods, test_func in TESTS:
                result = compare_test(
                    source_cls,
                    target_cls,
                    test_name,
                    expected,
                    methods,
                    test_func,
                    source_name,
                    expected_target,
                    str(relative_path),
                )
                if result["source_result"] == "SKIP" and result["target_result"] == "SKIP":
                    continue
                all_results.append(result)

    RESULT_FILE.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "file", "source_class", "target_class", "test",
        "source_result", "source_details",
        "target_result", "target_details", "comparison",
    ]
    with RESULT_FILE.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(all_results)

    print(f"Finished. Results written to {RESULT_FILE}")
    print(f"Total recorded test cases: {len(all_results)}")


if __name__ == "__main__":
    main()