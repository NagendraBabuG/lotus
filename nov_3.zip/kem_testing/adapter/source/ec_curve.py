from cryptography.hazmat.primitives.asymmetric import ec

class ECDHAdapter:

    def generate_private_key(self):
        return ec.generate_private_key(ec.SECP384R1())

    def SECP384R1(self):
        return ec.SECP384R1()

    def exchange(self, server_private_key, peer_private_key):
        return server_private_key.exchange(ec.ECDH(), peer_private_key.public_key())

    def ECDH(self):
        return ec.ECDH()

    def get_public_key(self, peer_private_key):
        return peer_private_key.public_key()

