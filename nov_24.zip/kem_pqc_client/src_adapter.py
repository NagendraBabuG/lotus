import builtins
import sys
import libcst as cst
from pathlib import Path


_EMPTY_MODULE = cst.Module([])

BUILTIN_NAMES = set(dir(builtins))
LITERAL_NAMES = {"None", "True", "False", "Ellipsis", "NotImplemented"}
BUILTIN_TYPE_METHOD_RECEIVERS = {
    "bytes": {"fromhex", "maketrans"},
    "bytearray": {"fromhex", "maketrans"},
    "int": {"from_bytes"},
    "float": {"fromhex"},
    "str": {"maketrans"},
    "dict": {"fromkeys"},
}

CLASSICAL_ALGORITHMS = {
    "X25519PrivateKey",
    "X25519PublicKey",
    "X448PrivateKey",
    "X448PublicKey",
    "EllipticCurvePrivateKey",
    "EllipticCurvePublicKey",
    "DHPrivateKey",
    "DHPublicKey",
}

PQC_ALGORITHMS = set()

CRYPTO_MODULES = {
    "x25519",
    "x448",
    "ec",
    "dh",
}

PQC_MODULES = set()

MODULE_GENERATORS = {
    "ec": "EllipticCurvePrivateKey",
}

DIRECT_FUNCTION_GENERATORS = {
    ("cryptography.hazmat.primitives.asymmetric.ec", "generate_private_key"): (
        "ec",
        "EllipticCurvePrivateKey",
    ),
    ("cryptography.hazmat.primitives.asymmetric.dh", "generate_parameters"): (
        "dh",
        "DHParameters",
    ),
}

INSTANCE_RESULT_TYPES = {
    ("DHParameters", "generate_private_key"): "DHPrivateKey",
    ("DHPrivateKey", "public_key"): "DHPublicKey",
    ("DHPrivateKey", "parameters"): "DHParameters",
    ("DHPublicKey", "parameters"): "DHParameters",
    ("DHPrivateKey", "private_numbers"): "DHPrivateNumbers",
    ("DHPublicKey", "public_numbers"): "DHPublicNumbers",
    ("DHParameters", "parameter_numbers"): "DHParameterNumbers",
    ("DHPrivateNumbers", "private_key"): "DHPrivateKey",
    ("DHPublicNumbers", "public_key"): "DHPublicKey",
    ("DHParameterNumbers", "parameters"): "DHParameters",
    ("X25519PrivateKey", "public_key"): "X25519PublicKey",
    ("X448PrivateKey", "public_key"): "X448PublicKey",
    ("EllipticCurvePrivateKey", "public_key"): "EllipticCurvePublicKey",
    ("EllipticCurvePrivateKey", "private_numbers"): "EllipticCurvePrivateNumbers",
    ("EllipticCurvePublicKey", "public_numbers"): "EllipticCurvePublicNumbers",
    ("EllipticCurvePrivateNumbers", "private_key"): "EllipticCurvePrivateKey",
    ("EllipticCurvePublicNumbers", "public_key"): "EllipticCurvePublicKey",
}

METHOD_NAME_MAP = {
    "generate": "generate_private_key",
    "generate_private_key": "generate_private_key",
    "generate_parameters": "generate_parameters",
    "from_private_bytes": "load_private_key",
    "from_public_bytes": "load_public_key",
    "private_bytes": "serialize_private_key",
    "public_bytes": "serialize_public_key",
    "private_bytes_raw": "serialize_private_key_raw",
    "public_bytes_raw": "serialize_public_key_raw",
    "public_key": "get_public_key",
    "exchange": "exchange",
    "private_numbers": "get_private_numbers",
    "public_numbers": "get_public_numbers",
}

CURVE_PREFIXES = ("SECP", "SECT", "Brainpool")
HASH_PREFIXES = ("SHA", "BLAKE2", "MD5")


def _code_for(node):
    return _EMPTY_MODULE.code_for_node(node)


def _default_receiver_name(receiver_type):
    if not receiver_type:
        return "key"
    if "PrivateNumbers" in receiver_type:
        return "private_numbers"
    if "PublicNumbers" in receiver_type:
        return "public_numbers"
    if "ParameterNumbers" in receiver_type:
        return "parameter_numbers"
    if "Parameters" in receiver_type:
        return "parameters"
    if "PublicKey" in receiver_type:
        return "public_key"
    if "PrivateKey" in receiver_type:
        return "private_key"
    return "key"


class CryptoCall:

    def __init__(
        self,
        name,
        receiver,
        arguments,
        keywords,
        receiver_type=None,
        is_class_method=False,
        module_name=None,
        source_expression=None,
    ):
        self.name = name
        self.receiver = receiver
        self.arguments = arguments
        self.keywords = keywords
        self.receiver_type = receiver_type
        self.is_class_method = is_class_method
        self.module_name = module_name
        self.source_expression = source_expression


class CryptoCallExtractor(cst.CSTVisitor):

    def __init__(self):
        # alias -> canonical module name (e.g. {"ec_mod": "ec"})
        self.crypto_module_aliases = {}
        self.pqc_module_aliases = {}
        self.hash_module_aliases = {"hashes"}

        self.crypto_class_aliases = {}
        self.pqc_class_aliases = {}
        # alias -> (canonical_module, original_func_name, receiver_type)
        self.crypto_func_aliases = {}

        self.direct_curve_aliases = set()
        self.direct_hash_aliases = set()
        self.direct_ecdh_aliases = set()

        self.crypto_variables = {}
        self.pqc_variables = {}

        self.calls = []
        # list of (import_code, bound_names_set, is_star, is_cryptography)
        self.imports = []
        self._seen_import_codes = set()
        self.imported_names = set()

        self.ec_configuration_values = {}

    def _record_import(self, import_code, bound_names, is_star=False, is_crypto=False):
        if import_code not in self._seen_import_codes:
            self._seen_import_codes.add(import_code)
            self.imports.append((import_code, set(bound_names), is_star, is_crypto))

    def _get_ec_configuration_kind(self, expression):
        if not isinstance(expression, cst.Call):
            return None

        function = expression.func

        if isinstance(function, cst.Attribute):
            module = function.value
            attr = function.attr.value

            if isinstance(module, cst.Name):
                canonical = self.crypto_module_aliases.get(module.value, module.value)
                if canonical == "ec" and attr.startswith(CURVE_PREFIXES):
                    return "curve"

                if (
                    module.value in self.hash_module_aliases
                    and attr.startswith(HASH_PREFIXES)
                ):
                    return "hash"

        if isinstance(function, cst.Name):
            if function.value in self.direct_curve_aliases:
                return "curve"
            if function.value in self.direct_hash_aliases:
                return "hash"

        return None

    def _is_ecdh_expression(self, expr_str):
        compact = expr_str.replace(" ", "")
        if compact == "ec.ECDH()":
            return True
        for alias, canonical in self.crypto_module_aliases.items():
            if canonical == "ec" and compact == f"{alias}.ECDH()":
                return True
        for alias in self.direct_ecdh_aliases:
            if compact == f"{alias}()":
                return True
        return False

    def _resolve_ec_curve_expression(self, expression):

        class CurveResolver(cst.CSTTransformer):

            def __init__(self, values):
                self.values = values

            def leave_Name(self, original_node, updated_node):
                item = self.values.get(original_node.value)

                if item is None or item[0] != "curve":
                    return updated_node

                try:
                    return cst.parse_expression(item[1])
                except Exception:
                    return updated_node

        for _ in range(5):
            updated = expression.visit(
                CurveResolver(self.ec_configuration_values)
            )

            if updated.deep_equals(expression):
                break

            expression = updated

        return expression

    def _resolve_ec_prehashed_value(self, expression):

        class PrehashedResolver(cst.CSTTransformer):

            def __init__(self, values):
                self.values = values

            def leave_Call(self, original_node, updated_node):
                function = updated_node.func

                is_prehashed_attr = (
                    isinstance(function, cst.Attribute)
                    and function.attr.value == "Prehashed"
                )
                is_prehashed_name = (
                    isinstance(function, cst.Name)
                    and function.value == "Prehashed"
                )

                if not (
                    (is_prehashed_attr or is_prehashed_name)
                    and len(updated_node.args) == 1
                    and updated_node.args[0].keyword is None
                ):
                    return updated_node

                class HashNameResolver(cst.CSTTransformer):

                    def __init__(self, values):
                        self.values = values

                    def leave_Name(self, original_name, updated_name):
                        item = self.values.get(original_name.value)

                        if item is None or item[0] != "hash":
                            return updated_name

                        try:
                            return cst.parse_expression(item[1])
                        except Exception:
                            return updated_name

                value = updated_node.args[0].value
                return value.visit(HashNameResolver(self.values))

        for _ in range(5):
            updated = expression.visit(
                PrehashedResolver(self.ec_configuration_values)
            )

            if updated.deep_equals(expression):
                break

            expression = updated

        return expression

    def visit_ImportFrom(self, node):

        if node.module is None:
            return

        module_name = _code_for(node.module)
        import_code = _code_for(node)
        is_crypto = module_name.startswith("cryptography")

        if isinstance(node.names, cst.ImportStar):
            self._record_import(import_code, set(), is_star=True, is_crypto=is_crypto)
            return

        bound_names = set()

        for imported in node.names:
            imported_name = imported.name.value
            alias = (
                imported.asname.name.value
                if imported.asname
                else imported_name
            )

            bound_names.add(alias)
            self.imported_names.add(alias)

            if imported_name in CLASSICAL_ALGORITHMS:
                self.crypto_class_aliases[alias] = imported_name

            if imported_name in PQC_ALGORITHMS:
                self.pqc_class_aliases[alias] = imported_name

            if not is_crypto:
                continue

            if imported_name in CRYPTO_MODULES:
                self.crypto_module_aliases[alias] = imported_name

            if imported_name in PQC_MODULES:
                self.pqc_module_aliases[alias] = imported_name

            if imported_name == "hashes":
                self.hash_module_aliases.add(alias)

            func_key = (module_name, imported_name)
            if func_key in DIRECT_FUNCTION_GENERATORS:
                canonical_mod, receiver_type = DIRECT_FUNCTION_GENERATORS[func_key]
                self.crypto_func_aliases[alias] = (
                    canonical_mod,
                    imported_name,
                    receiver_type,
                )

            if module_name.endswith(".ec"):
                if imported_name.startswith(CURVE_PREFIXES):
                    self.direct_curve_aliases.add(alias)
                elif imported_name == "ECDH":
                    self.direct_ecdh_aliases.add(alias)

            if module_name.endswith(".hashes") and imported_name.startswith(HASH_PREFIXES):
                self.direct_hash_aliases.add(alias)

        self._record_import(import_code, bound_names, is_star=False, is_crypto=is_crypto)

    def visit_Import(self, node):

        import_code = _code_for(node)
        bound_names = set()
        any_crypto = False

        for imported in node.names:
            module_name = _code_for(imported.name)

            if imported.asname:
                alias = imported.asname.name.value
            else:
                alias = module_name.split(".")[0]

            bound_names.add(alias)
            self.imported_names.add(alias)

            if not module_name.startswith("cryptography"):
                continue

            any_crypto = True
            module_leaf = module_name.split(".")[-1]

            if module_leaf in PQC_MODULES:
                self.pqc_module_aliases[alias] = module_leaf
            elif module_leaf in CRYPTO_MODULES:
                self.crypto_module_aliases[alias] = module_leaf
            elif module_leaf == "hashes":
                self.hash_module_aliases.add(alias)

        self._record_import(import_code, bound_names, is_star=False, is_crypto=any_crypto)

    def _get_arguments(self, node):

        positional = []
        keywords = []

        for arg in node.args:
            value = _code_for(arg.value)

            if arg.keyword is not None:
                keywords.append((arg.keyword.value, value))
            else:
                positional.append(value)

        return positional, keywords

    def _get_class_call(self, node):

        function = node.func

        # Direct function import, e.g. from ...ec import generate_private_key
        if isinstance(function, cst.Name):
            func_alias = function.value
            if func_alias in self.crypto_func_aliases:
                _, _, receiver_type = self.crypto_func_aliases[func_alias]
                return {
                    "receiver": None,
                    "method": func_alias,
                    "receiver_type": receiver_type,
                    "module_name": None,
                    "source_expression": _code_for(node),
                    "pqc": False,
                }
            return None

        if not isinstance(function, cst.Attribute):
            return None

        method_name = function.attr.value
        value = function.value

        # Pattern: module.ClassName.method(...)
        if isinstance(value, cst.Attribute):
            class_name = value.attr.value
            module = value.value

            if isinstance(module, cst.Name):
                module_alias = module.value

                if (
                    module_alias in self.pqc_module_aliases
                    and class_name in PQC_ALGORITHMS
                ):
                    return {
                        "receiver": class_name,
                        "method": method_name,
                        "receiver_type": class_name,
                        "module_name": module_alias,
                        "source_expression": _code_for(node),
                        "pqc": True,
                    }

                if (
                    module_alias in self.crypto_module_aliases
                    and class_name in CLASSICAL_ALGORITHMS
                ):
                    return {
                        "receiver": class_name,
                        "method": method_name,
                        "receiver_type": class_name,
                        "module_name": module_alias,
                        "source_expression": _code_for(node),
                        "pqc": False,
                    }

        # Pattern: ClassName.method(...) or module.generate_*(...)
        if isinstance(value, cst.Name):
            name = value.value

            if name in self.pqc_class_aliases:
                return {
                    "receiver": name,
                    "method": method_name,
                    "receiver_type": self.pqc_class_aliases[name],
                    "module_name": None,
                    "source_expression": _code_for(node),
                    "pqc": True,
                }

            if name in self.crypto_class_aliases:
                return {
                    "receiver": name,
                    "method": method_name,
                    "receiver_type": self.crypto_class_aliases[name],
                    "module_name": None,
                    "source_expression": _code_for(node),
                    "pqc": False,
                }

            canonical_mod = self.crypto_module_aliases.get(name, name)

            if canonical_mod == "dh" and method_name == "generate_parameters":
                return {
                    "receiver": name,
                    "method": method_name,
                    "receiver_type": "DHParameters",
                    "module_name": name,
                    "source_expression": _code_for(node),
                    "pqc": False,
                }

            if (
                canonical_mod in MODULE_GENERATORS
                and method_name == "generate_private_key"
            ):
                return {
                    "receiver": name,
                    "method": method_name,
                    "receiver_type": MODULE_GENERATORS[canonical_mod],
                    "module_name": name,
                    "source_expression": _code_for(node),
                    "pqc": False,
                }

        return None

    def _get_instance_call(self, node):

        function = node.func

        if not isinstance(function, cst.Attribute):
            return None

        receiver = function.value
        method_name = function.attr.value

        if isinstance(receiver, cst.Name):
            receiver_name = receiver.value

            if receiver_name in self.pqc_variables:
                receiver_type = self.pqc_variables[receiver_name]
                result_type = (
                    receiver_type.replace("PrivateKey", "PublicKey")
                    if method_name == "public_key"
                    else None
                )
                return {
                    "receiver": receiver_name,
                    "method": method_name,
                    "receiver_type": receiver_type,
                    "result_type": result_type,
                    "module_name": None,
                    "source_expression": _code_for(node),
                    "pqc": True,
                }

            if receiver_name in self.crypto_variables:
                receiver_type = self.crypto_variables[receiver_name]
                result_type = INSTANCE_RESULT_TYPES.get((receiver_type, method_name))

                return {
                    "receiver": receiver_name,
                    "method": method_name,
                    "receiver_type": receiver_type,
                    "result_type": result_type,
                    "module_name": None,
                    "source_expression": _code_for(node),
                    "pqc": False,
                }

            return None

        # Chained call: e.g. X25519PrivateKey.generate().public_key()
        # or dh.generate_parameters(...).generate_private_key()
        # or priv.public_key().public_bytes(...)
        if isinstance(receiver, cst.Call):
            receiver_type = None
            is_pqc = False

            class_call = self._get_class_call(receiver)
            if class_call:
                receiver_type = class_call["receiver_type"]
                is_pqc = class_call["pqc"]
            else:
                inner_instance = self._get_instance_call(receiver)
                if inner_instance and inner_instance.get("result_type"):
                    receiver_type = inner_instance["result_type"]
                    is_pqc = inner_instance["pqc"]

            if receiver_type:
                result_type = INSTANCE_RESULT_TYPES.get((receiver_type, method_name))
                if result_type is None and is_pqc and method_name == "public_key":
                    result_type = receiver_type.replace("PrivateKey", "PublicKey")

                return {
                    "receiver": _default_receiver_name(receiver_type),
                    "method": method_name,
                    "receiver_type": receiver_type,
                    "result_type": result_type,
                    "module_name": None,
                    "source_expression": _code_for(node),
                    "pqc": is_pqc,
                }

        return None

    def _update_variable_binding(self, target_name, value_node, annotation_node=None):
        # Track ec curve / hash config variables
        if isinstance(value_node, cst.Call):
            configuration_kind = self._get_ec_configuration_kind(value_node)
            if configuration_kind:
                self.ec_configuration_values[target_name] = (
                    configuration_kind,
                    _code_for(value_node),
                )
                self.crypto_variables.pop(target_name, None)
                self.pqc_variables.pop(target_name, None)
                return

        # Propagate simple variable aliasing (e.g. k2 = k1 or curve2 = curve1)
        if isinstance(value_node, cst.Name):
            src_name = value_node.value
            if src_name in self.ec_configuration_values:
                self.ec_configuration_values[target_name] = self.ec_configuration_values[src_name]
            if src_name in self.pqc_variables:
                self.pqc_variables[target_name] = self.pqc_variables[src_name]
                self.crypto_variables.pop(target_name, None)
                return
            if src_name in self.crypto_variables:
                self.crypto_variables[target_name] = self.crypto_variables[src_name]
                self.pqc_variables.pop(target_name, None)
                return

        crypto_type = None
        is_pqc = False

        if isinstance(value_node, cst.Call):
            class_call = self._get_class_call(value_node)
            if class_call:
                crypto_type = class_call["receiver_type"]
                is_pqc = class_call["pqc"]
            else:
                instance_call = self._get_instance_call(value_node)
                if instance_call:
                    crypto_type = instance_call.get("result_type")
                    is_pqc = instance_call["pqc"]

        # Fallback to explicit type annotation if RHS type wasn't inferred
        if crypto_type is None and annotation_node is not None:
            ann_expr = annotation_node.annotation
            ann_name = None
            if isinstance(ann_expr, cst.Name):
                ann_name = ann_expr.value
            elif isinstance(ann_expr, cst.Attribute):
                ann_name = ann_expr.attr.value

            if ann_name in self.pqc_class_aliases:
                crypto_type = self.pqc_class_aliases[ann_name]
                is_pqc = True
            elif ann_name in PQC_ALGORITHMS:
                crypto_type = ann_name
                is_pqc = True
            elif ann_name in self.crypto_class_aliases:
                crypto_type = self.crypto_class_aliases[ann_name]
            elif ann_name in CLASSICAL_ALGORITHMS or ann_name == "DHParameters":
                crypto_type = ann_name

        if crypto_type:
            if is_pqc:
                self.pqc_variables[target_name] = crypto_type
                self.crypto_variables.pop(target_name, None)
            else:
                self.crypto_variables[target_name] = crypto_type
                self.pqc_variables.pop(target_name, None)
        else:
            # Variable was reassigned to a non-key value (e.g. bytes from exchange/private_bytes)
            self.crypto_variables.pop(target_name, None)
            self.pqc_variables.pop(target_name, None)

    def leave_Assign(self, original_node):
        for target in original_node.targets:
            target_node = target.target
            if isinstance(target_node, cst.Name):
                self._update_variable_binding(
                    target_node.value,
                    original_node.value,
                )

    def leave_AnnAssign(self, original_node):
        if isinstance(original_node.target, cst.Name):
            self._update_variable_binding(
                original_node.target.value,
                original_node.value,
                annotation_node=original_node.annotation,
            )

    def visit_Call(self, node):

        class_call = self._get_class_call(node)

        if class_call:
            arguments, keywords = self._get_arguments(node)

            if (
                class_call["receiver_type"]
                in {"EllipticCurvePrivateKey", "EllipticCurvePublicKey"}
                and class_call["method"]
                in {"generate_private_key", "from_encoded_point"}
            ):
                arguments = [
                    _code_for(
                        self._resolve_ec_curve_expression(
                            cst.parse_expression(arg)
                        )
                    )
                    for arg in arguments
                ]

                keywords = [
                    (
                        key,
                        _code_for(
                            self._resolve_ec_curve_expression(
                                cst.parse_expression(value)
                            )
                        ),
                    )
                    for key, value in keywords
                ]

            self.calls.append(
                CryptoCall(
                    name=class_call["method"],
                    receiver=class_call["receiver"],
                    arguments=arguments,
                    keywords=keywords,
                    receiver_type=class_call["receiver_type"],
                    is_class_method=True,
                    module_name=class_call["module_name"],
                    source_expression=class_call["source_expression"],
                )
            )
            return

        instance_call = self._get_instance_call(node)

        if instance_call:
            arguments, keywords = self._get_arguments(node)

            if (
                instance_call["receiver_type"] in {
                    "EllipticCurvePrivateKey",
                    "EllipticCurvePublicKey",
                }
                and instance_call["method"] in {"sign", "verify"}
            ):
                arguments = [
                    _code_for(
                        self._resolve_ec_prehashed_value(
                            cst.parse_expression(arg)
                        )
                    )
                    for arg in arguments
                ]

                keywords = [
                    (
                        key,
                        _code_for(
                            self._resolve_ec_prehashed_value(
                                cst.parse_expression(value)
                            )
                        ),
                    )
                    for key, value in keywords
                ]

            source_expression = instance_call["source_expression"]

            if (
                instance_call["receiver_type"] in {
                    "EllipticCurvePrivateKey",
                    "EllipticCurvePublicKey",
                }
                and instance_call["method"] in {"sign", "verify"}
                and source_expression
            ):
                try:
                    source_node = cst.parse_expression(source_expression)
                    source_node = self._resolve_ec_prehashed_value(source_node)
                    source_expression = _code_for(source_node)
                except Exception:
                    pass

            receiver_name = instance_call["receiver"]
            receiver_type = instance_call["receiver_type"]

            is_ec_ecdh = (
                receiver_type == "EllipticCurvePrivateKey"
                and instance_call["method"] == "exchange"
                and (
                    (arguments and self._is_ecdh_expression(arguments[0]))
                    or any(
                        k == "algorithm" and self._is_ecdh_expression(v)
                        for k, v in keywords
                    )
                )
            )

            if is_ec_ecdh:
                receiver_name = "private_key"
                arguments = ["peer_public_key"]
                keywords = []

            self.calls.append(
                CryptoCall(
                    name=instance_call["method"],
                    receiver=receiver_name,
                    arguments=arguments,
                    keywords=keywords,
                    receiver_type=receiver_type,
                    is_class_method=False,
                    module_name=instance_call["module_name"],
                    source_expression=source_expression,
                )
            )


class BytesFromHexNormalizer(cst.CSTTransformer):

    def __init__(self):
        super().__init__()
        self._counter = 0

    def leave_Call(self, original_node, updated_node):
        function = updated_node.func

        if not (
            isinstance(function, cst.Attribute)
            and function.attr.value == "fromhex"
            and isinstance(function.value, cst.Name)
            and function.value.value == "bytes"
            and len(updated_node.args) == 1
            and updated_node.args[0].keyword is None
        ):
            return updated_node

        value = updated_node.args[0].value

        # Leave hardcoded string literals untouched
        if isinstance(value, (cst.SimpleString, cst.ConcatenatedString)):
            return updated_node

        # Simple expressions can be safely referenced twice
        if isinstance(value, (cst.Name, cst.Attribute, cst.Subscript)):
            return cst.IfExp(
                test=cst.Call(
                    func=cst.Name("isinstance"),
                    args=[
                        cst.Arg(value=value),
                        cst.Arg(value=cst.Name("bytes")),
                    ],
                ),
                body=value,
                orelse=updated_node,
                lpar=[cst.LeftParen()],
                rpar=[cst.RightParen()],
            )

        # Complex expressions (e.g. calls) are evaluated once via walrus
        tmp_name = cst.Name(f"_b_{self._counter}")
        self._counter += 1

        return cst.IfExp(
            test=cst.Call(
                func=cst.Name("isinstance"),
                args=[
                    cst.Arg(
                        value=cst.NamedExpr(
                            target=tmp_name,
                            value=value,
                            lpar=[cst.LeftParen()],
                            rpar=[cst.RightParen()],
                        )
                    ),
                    cst.Arg(value=cst.Name("bytes")),
                ],
            ),
            body=tmp_name,
            orelse=cst.Call(
                func=updated_node.func,
                args=[cst.Arg(value=tmp_name)],
            ),
            lpar=[cst.LeftParen()],
            rpar=[cst.RightParen()],
        )


def clean_argument(argument_str):
    try:
        expression = cst.parse_expression(argument_str)
        expression = expression.visit(BytesFromHexNormalizer())
        return _code_for(expression)
    except Exception:
        return argument_str


def get_parameter_names(arguments, ignored_names=None):

    if ignored_names is None:
        ignored_names = set()

    ignored_names = set(ignored_names) | LITERAL_NAMES | {"self"}
    parameters = []

    class VariableExtractor(cst.CSTVisitor):

        def __init__(self):
            self.local_bindings = set()

        def visit_Arg(self, node):
            # Visit only the value, never the keyword parameter label
            node.value.visit(self)
            return False

        def visit_Subscript(self, node):
            node.value.visit(self)
            for sl in node.slice:
                sl.visit(self)
            return False

        def visit_Attribute(self, node):
            # Skip builtin classmethod receivers like bytes.fromhex / int.from_bytes
            if (
                isinstance(node.value, cst.Name)
                and node.value.value in BUILTIN_TYPE_METHOD_RECEIVERS
                and node.attr.value in BUILTIN_TYPE_METHOD_RECEIVERS[node.value.value]
            ):
                return False

            node.value.visit(self)
            return False

        def visit_Call(self, node):
            is_builtin_call = (
                isinstance(node.func, cst.Name)
                and node.func.value in BUILTIN_NAMES
            )

            if not is_builtin_call:
                node.func.visit(self)

            # Skip builtin type names in isinstance(x, bytes) / issubclass(a, b)
            is_type_check = (
                isinstance(node.func, cst.Name)
                and node.func.value in {"isinstance", "issubclass"}
            )

            for idx, arg in enumerate(node.args):
                if is_type_check and idx == 1 and isinstance(arg.value, cst.Name):
                    if arg.value.value in BUILTIN_NAMES:
                        continue
                arg.visit(self)

            return False

        def visit_CompFor(self, node):
            if isinstance(node.target, cst.Name):
                self.local_bindings.add(node.target.value)
            elif isinstance(node.target, cst.Tuple):
                for el in node.target.elements:
                    if isinstance(el.value, cst.Name):
                        self.local_bindings.add(el.value.value)
            return True

        def visit_Name(self, node):
            name = node.value

            if name in ignored_names or name in self.local_bindings:
                return

            if name not in parameters:
                parameters.append(name)

    for argument in arguments:
        try:
            expression = cst.parse_expression(argument)
            extractor = VariableExtractor()
            expression.visit(extractor)
        except Exception:
            continue

    return parameters


def get_method_name(call):
    return METHOD_NAME_MAP.get(call.name, call.name)


def create_class_method(call, imported_names):

    method_name = get_method_name(call)

    argument_expressions = list(call.arguments)
    argument_expressions.extend(value for _, value in call.keywords)

    parameters = get_parameter_names(
        argument_expressions,
        imported_names,
    )

    parameter_text = ""
    if parameters:
        parameter_text = ", " + ", ".join(parameters)

    call_arguments = [clean_argument(arg) for arg in call.arguments]

    for keyword, value in call.keywords:
        cleaned_val = clean_argument(value)
        call_arguments.append(f"{keyword}={cleaned_val}")

    arguments_text = ", ".join(call_arguments)

    if call.receiver is None:
        return (
            f"    def {method_name}(self{parameter_text}):\n"
            f"        return {call.name}({arguments_text})\n"
        )

    if call.module_name:
        if call.receiver == call.module_name:
            function_call = f"{call.module_name}.{call.name}"
        else:
            function_call = f"{call.module_name}.{call.receiver}.{call.name}"

        return (
            f"    def {method_name}(self{parameter_text}):\n"
            f"        return {function_call}({arguments_text})\n"
        )

    return (
        f"    def {method_name}(self{parameter_text}):\n"
        f"        return {call.receiver}.{call.name}({arguments_text})\n"
    )


def create_instance_method(call, imported_names):

    if (
        call.receiver_type == "EllipticCurvePrivateKey"
        and call.name == "exchange"
    ):
        return (
            "    def exchange(self, private_key, peer_public_key):\n"
            "        return private_key.exchange(ec.ECDH(), peer_public_key)\n"
        )

    method_name = get_method_name(call)

    argument_expressions = list(call.arguments)
    argument_expressions.extend(value for _, value in call.keywords)

    parameters = get_parameter_names(
        argument_expressions,
        set(imported_names) | {call.receiver},
    )

    parameter_text = ""
    if parameters:
        parameter_text = ", " + ", ".join(parameters)

    call_arguments = [clean_argument(arg) for arg in call.arguments]

    for keyword, value in call.keywords:
        cleaned_val = clean_argument(value)
        call_arguments.append(f"{keyword}={cleaned_val}")

    arguments_text = ", ".join(call_arguments)

    return (
        f"    def {method_name}(self, {call.receiver}{parameter_text}):\n"
        f"        return {call.receiver}.{call.name}({arguments_text})\n"
    )


def get_algorithm_prefix(receiver_type):

    if not receiver_type:
        return "Source"

    for alg in [
        "X25519",
        "X448",
        "EllipticCurve",
        "DH",
    ]:
        if alg.lower() in receiver_type.lower():
            if alg == "EllipticCurve":
                return "EC"
            return alg

    return "Source"


def _collect_referenced_names(classes_code):
    """Collect free top-level identifier names referenced inside generated adapter classes."""
    referenced = set()

    class ReferenceCollector(cst.CSTVisitor):

        def __init__(self):
            self.scope_stack = []

        def visit_FunctionDef(self, node):
            params = set()
            for p in (
                list(node.params.posonly_params)
                + list(node.params.params)
                + list(node.params.kwonly_params)
            ):
                params.add(p.name.value)
            if isinstance(node.params.star_arg, cst.Param):
                params.add(node.params.star_arg.name.value)
            if node.params.star_kwarg:
                params.add(node.params.star_kwarg.name.value)

            self.scope_stack.append(params)
            node.body.visit(self)
            self.scope_stack.pop()
            return False

        def visit_NamedExpr(self, node):
            if isinstance(node.target, cst.Name) and self.scope_stack:
                self.scope_stack[-1].add(node.target.value)
            node.value.visit(self)
            return False

        def visit_Arg(self, node):
            node.value.visit(self)
            return False

        def visit_Attribute(self, node):
            node.value.visit(self)
            return False

        def visit_Name(self, node):
            name = node.value
            if name in BUILTIN_NAMES or name in LITERAL_NAMES:
                return
            for scope in self.scope_stack:
                if name in scope:
                    return
            referenced.add(name)

    try:
        tree = cst.parse_module(classes_code)
        tree.visit(ReferenceCollector())
    except Exception:
        pass

    return referenced


def generate_adapter_code(extractor):

    all_calls = extractor.calls

    if not all_calls:
        return ""

    unique_calls = []
    seen = set()

    for call in all_calls:
        key = (
            call.receiver,
            call.name,
            tuple(call.arguments),
            tuple(call.keywords),
            call.module_name,
            call.receiver_type,
        )

        if key in seen:
            continue

        seen.add(key)
        unique_calls.append(call)

    variant_calls = {}

    for call in unique_calls:
        prefix = get_algorithm_prefix(call.receiver_type)
        variant_calls.setdefault(prefix, []).append(call)

    # Build adapter classes first so we know the exact symbols they reference
    classes_code = ""

    for prefix, calls in variant_calls.items():
        class_name = f"{prefix}Adapter"
        classes_code += f"class {class_name}:\n\n"

        generated_methods = set()

        for call in calls:
            method_name = get_method_name(call)

            if method_name in generated_methods:
                continue

            generated_methods.add(method_name)

            if call.is_class_method:
                method = create_class_method(
                    call,
                    extractor.imported_names,
                )
            else:
                method = create_instance_method(
                    call,
                    extractor.imported_names,
                )

            classes_code += method + "\n"

    referenced_names = _collect_referenced_names(classes_code)

    used_imports = []
    bound_by_used_imports = set()

    for import_code, bound_names, is_star, is_crypto in extractor.imports:
        if not is_star and (bound_names & referenced_names):
            used_imports.append(import_code)
            bound_by_used_imports.update(bound_names)

    # Include cryptography star imports only if unresolved symbols remain
    unresolved = referenced_names - bound_by_used_imports
    if unresolved:
        for import_code, _, is_star, is_crypto in extractor.imports:
            if is_star and is_crypto and import_code not in used_imports:
                used_imports.append(import_code)

    # Ensure `ec` is imported if ECAdapter.exchange emitted `ec.ECDH()`
    if "ec" in referenced_names and "ec" not in bound_by_used_imports:
        ec_import = "from cryptography.hazmat.primitives.asymmetric import ec"
        if ec_import not in used_imports:
            used_imports.append(ec_import)

    code = ""
    for import_statement in used_imports:
        code += import_statement + "\n"

    if used_imports:
        code += "\n"

    code += classes_code
    return code


def generate_adapter(source_code):
    module = cst.parse_module(source_code)
    extractor = CryptoCallExtractor()
    module.visit(extractor)
    return generate_adapter_code(extractor)


def process_files(input_folder, output_folder):

    input_folder = Path(input_folder)
    output_folder = Path(output_folder)

    output_folder.mkdir(
        parents=True,
        exist_ok=True,
    )

    for file_path in sorted(input_folder.glob("*.py")):
        print(f"\nProcessing: {file_path.name}")

        try:
            with open(file_path, "r", encoding="utf-8") as file:
                source_code = file.read()

            modified_code = generate_adapter(source_code)

            if not modified_code:
                print(
                    "  No crypto usage found - adapter classes not created"
                )
                continue

            output_file = output_folder / f"{file_path.stem}.py"

            with open(output_file, "w", encoding="utf-8") as file:
                file.write(modified_code)

            print(f"  Created: {output_file}")

        except Exception as error:
            print(
                f"  ERROR processing {file_path.name}: {error}"
            )


if __name__ == "__main__":
    in_dir = sys.argv[1] if len(sys.argv) > 1 else "../kem_files/input"
    out_dir = sys.argv[2] if len(sys.argv) > 2 else "./adapter/source"
    process_files(in_dir, out_dir)