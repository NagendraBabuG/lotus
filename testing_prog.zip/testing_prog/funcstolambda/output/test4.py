def outer():

    def inner(y):
        return y + 1
    return inner(10)
power = lambda base, exp=2: base ** exp
sum_all = lambda *args: sum(args)