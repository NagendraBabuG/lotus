import libcst as cst


class ElseTransformer(cst.CSTTransformer):

    def leave_If(self, original: cst.If, updated: cst.If):

        if isinstance(updated.orelse, cst.If):
            return self._elif_to_else_if(updated)

        if self._is_else_if(updated):
            return self._else_if_to_elif(updated)

        return updated

    def _is_else_if(self, node: cst.If):
        orelse = node.orelse

        return (
            isinstance(orelse, cst.Else)
            and len(orelse.body.body) == 1
            and isinstance(orelse.body.body[0], cst.If)
        )

    def _elif_to_else_if(self, node: cst.If) -> cst.If:

        return node.with_changes(
            orelse=cst.Else(
                body=cst.IndentedBlock(
                    body=[node.orelse]
                )
            )
        )

    def _else_if_to_elif(self, node: cst.If) -> cst.If:

        inner_if = node.orelse.body.body[0].with_changes(
            leading_lines=[]
        )

        return node.with_changes(
            orelse=inner_if
        )

    def get_refactored_code(self, source: str) -> str:
        module = cst.parse_module(source)
        return module.visit(self).code


