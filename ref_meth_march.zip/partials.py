import ast
from typing import Dict, List

class PartialsRefactor(ast.NodeTransformer):
    def __init__(self):
        self.call_context: Dict[int, Dict[str, ast.Constant]] = {}
        self.scope_stack: List[Dict[str, ast.Constant]] = [{}]

    def _is_constant_assignment(self, node: ast.AST) -> bool:
        if isinstance(node, ast.Assign) and len(node.targets) == 1:
            return isinstance(node.targets[0], ast.Name) and isinstance(node.value, ast.Constant)
        if isinstance(node, ast.AnnAssign):
            return isinstance(node.target, ast.Name) and isinstance(node.value, ast.Constant)
        return False

    def _process_block(self, body: List[ast.stmt]) -> List[ast.stmt]:
        new_body = []
        for stmt in body:
            if self._is_constant_assignment(stmt):
                name = stmt.targets[0].id if isinstance(stmt, ast.Assign) else stmt.target.id
                self.scope_stack[-1][name] = stmt.value
                continue 
            
            if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                self.scope_stack.append(self.scope_stack[-1].copy())
                stmt.body = self._process_block(stmt.body)
                self.scope_stack.pop()
            
            else:
                for subnode in ast.walk(stmt):
                    if isinstance(subnode, ast.Call):
                        self.call_context[id(subnode)] = self.scope_stack[-1].copy()
            
            new_body.append(stmt)
        return new_body

    def visit_Module(self, node: ast.Module):
        node.body = self._process_block(node.body)
        return self.generic_visit(node)

    def visit_Name(self, node: ast.Name):
        if isinstance(node.ctx, ast.Load):
            current_scope = self.scope_stack[-1]
            if node.id in current_scope:
                return ast.copy_location(current_scope[node.id], node)
        return node

    def visit_Call(self, node: ast.Call):
        available = self.call_context.get(id(node), {})
        new_args = []
        
        for arg in node.args:
            if isinstance(arg, ast.Name) and arg.id in available:
                const_val = available[arg.id]
                node.keywords.insert(0, ast.keyword(
                    arg=arg.id, 
                    value=ast.copy_location(const_val, arg)
                ))
            else:
                new_args.append(self.visit(arg))
        
        node.args = new_args
        node.keywords = [self.visit(kw) for kw in node.keywords]
        return node

    def get_refactored_code(self, source_code: str) -> str:
        tree = ast.parse(source_code)
        tree = self.visit(tree)
        ast.fix_missing_locations(tree)
        return ast.unparse(tree)