from PyQt5.QtGui import QFont, QPalette, QColor, QKeySequence
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import rsa
from pynput.keyboard import Controller as KeyCtl, Key

class RSAAdapter:

    def generate_private_key(self):
        return rsa.generate_private_key(public_exponent=65537, key_size=2048)

    def get_public_key(self, key):
        return key.public_key()

    def serialize_private_key(self, key):
        return key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL, serialization.NoEncryption())

