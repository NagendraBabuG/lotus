def process(a, b, c):
    a_copy = a
    b_copy = b
    c_copy = c
    a_copy += 1
    c_copy = c_copy * 2
    return a_copy + b_copy + c_copy

def maybe_modify(x):
    x_copy = x
    if x_copy > 0:
        x_copy -= 1
    return x_copy