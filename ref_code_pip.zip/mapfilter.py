import ast
import random
class MapFilterRefactor(ast.NodeTransformer):
    def methodToList(method_name, target_id, func_id, arg_id):
        node = ast.Assign(
            targets=[
                ast.Name(id=target_id, ctx=ast.Store())
            ],
            value=ast.Call(
                func=ast.Name(id='list', ctx=ast.Load()),
                args=[
                    ast.Call(
                        func=ast.Name(id=method_name, ctx=ast.Load()),
                        args=[
                            ast.Name(id=func_id, ctx=ast.Load()),
                            ast.Name(id=arg_id, ctx=ast.Load())
                        ],
                        keywords=[]
                    )
                ],
                keywords=[]
            )

        )
        return node

    def mapfilterrefactor(self, tree):
        self.func_name = []
        self.arg_map = {}

        self.func_name_l2f = []
        self.arg_map_l2f = {}

        self.func_name_l2m = []
        self.arg_map_l2m = {}

        self.func_name_m2l = []
        self.arg_map_m2l = {}

        self.target_l2f = []
        self.target_l2m = []
        self.target_f2l = []
        self.target_m2l = []

        self.PLACEHOLDERS = ['elem_', 'var_', 'iter_']

        # Tree traversal for extracting the identifiers and their associations.
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                if isinstance(node.value, ast.Call):
                    if not isinstance(node.value.func, ast.Attribute):
                        # Check if node consists of list and filter methods.
                        if isinstance(node.value.func, ast.Name) and node.value.func.id == 'list':
                            for arg in node.value.args:
                                if isinstance(arg, ast.Call) and arg.func.id == 'filter':
                                    self.target_f2l = [elm.id for elm in node.targets]
                                    self.func_name.append(arg.args[0].id)  
                                    self.arg_map[arg.args[0].id] = arg.args[1].id
                                elif isinstance(arg, ast.Call) and arg.func.id == 'map':
                                    self.target_m2l = [elm.id for elm in node.targets]
                                    self.func_name_m2l.append(arg.args[0].id)
                                    self.arg_map_m2l[arg.args[0].id] = arg.args[1].id

                        # Check if the node comprises of a list comprehension.
                        elif isinstance(node.value, ast.ListComp):
                            for gen in node.value.generators:
                                if isinstance(gen, ast.comprehension) and isinstance(node.value.elt, ast.Name):
                                    # Extracting the target variable, function name and corresponding arguments.
                                    self.target_l2f = [elm.id for elm in node.targets]
                                    temp = gen.iter.id
                                    for elem in gen.ifs:
                                        if isinstance(elem, ast.Call) and isinstance(elem.func, ast.Name):
                                            self.func_name_l2f.append(elem.func.id)
                                            self.arg_map_l2f[elem.func.id] = temp
                                elif isinstance(gen, ast.comprehension) and isinstance(node.value.elt, ast.Call):
                                    self.target_l2m = [elm.id for elm in node.targets]
                                    self.func_name_l2m.append(node.value.elt.func.id)
                                    self.arg_map_l2m[node.value.elt.func.id] = gen.iter.id
        self.idx_l2f = -1
        self.idx_f2l = -1
        self.idx_l2m = -1
        self.idx_m2l = -1

        for node in ast.walk(tree):
            if isinstance(node, ast.Module):
                for idx, node2 in enumerate(node.body):
                    if isinstance(node2, ast.Assign) and isinstance(node2.value, ast.Call) and not isinstance(node2.value.func, ast.Attribute):
                        if isinstance(node2.value.func, ast.Name) and node2.value.func.id == 'list':
                            for arg in node2.value.args:
                                if isinstance(arg, ast.Call) and arg.func.id=='filter':
                                    self.idx_f2l += 1
                                    placeholder = random.choice(self.PLACEHOLDERS)
                                    node.body[idx] = ast.Assign(
                                        targets=[ast.Name(id=self.target_f2l[self.idx_f2l], ctx=ast.Store())],
                                        value=ast.ListComp(
                                            elt=ast.Name(id=placeholder, ctx=ast.Load()),
                                            generators=[
                                                ast.comprehension(
                                                    target=ast.Name(id=placeholder, ctx=ast.Store()),
                                                    iter=ast.Name(id=self.arg_map[self.func_name[self.idx_f2l]], ctx=ast.Load()),
                                                    ifs=[
                                                        ast.Call(
                                                            func=ast.Name(id=self.func_name[self.idx_f2l], ctx=ast.Load()),
                                                            args=[
                                                                ast.Name(id=placeholder, ctx=ast.Load())], keywords=[])], is_async=0)]))
                                elif isinstance(arg, ast.Call) and arg.func.id=='map':
                                    self.idx_m2l += 1
                                    placeholder = random.choice(self.PLACEHOLDERS)

                                    node.body[idx] = ast.Assign(
                                        targets=[
                                            ast.Name(id=self.target_m2l[self.idx_m2l], ctx=ast.Store())
                                        ],
                                        value=ast.ListComp(
                                            elt=ast.Call(
                                                func=ast.Name(id=self.func_name_m2l[self.idx_m2l], ctx=ast.Load()),
                                                args=[ast.Name(id=placeholder, ctx=ast.Load())],
                                                keywords=[]
                                            ),
                                            generators=[
                                                ast.comprehension(
                                                    target=ast.Name(id=placeholder, ctx=ast.Store()),
                                                    iter=ast.Name(id=self.arg_map_m2l[self.func_name_m2l[self.idx_m2l]], ctx=ast.Load()),
                                                    ifs=[],
                                                    is_async=0
                                                )
                                            ]
                                        )
                                    )
                                                

                    elif isinstance(node2, ast.Assign):
                        if isinstance(node2.value, ast.ListComp) and isinstance(node2.value.elt, ast.Name):
                            self.idx_l2f += 1
                            for gen in node2.value.generators:
                                if isinstance(gen, ast.comprehension):
                                    if gen.iter.id in self.arg_map_l2f.values():
                                        node.body[idx] = self.methodToList('filter', self.target_l2f[self.idx_l2f], self.func_name_l2f[self.idx_l2f],
                                                                           self.arg_map_l2f[self.idx_l2f])
                        elif isinstance(node2.value, ast.ListComp) and isinstance(node2.value.elt, ast.Call):
                            self.idx_l2m += 1
                            for gen in node2.value.generators:
                                if isinstance(gen, ast.comprehension):
                                    if gen.iter.id in self.arg_map_l2m.values():
                                        node.body[idx]=self.methodToList('map', self.target_l2m[self.idx_l2m], self.func_name_l2m[self.idx_l2m],
                                                                         self.arg_map_l2m[self.func_name_l2m[self.idx_l2m]])
            ast.fix_missing_locations(tree)
            return tree

    def get_refactored_code(self, source_code):
        try:
            tree = ast.parse(source_code)
            tree = self.mapfilterrefactor(tree)
            return ast.unparse(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")
