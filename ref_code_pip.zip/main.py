# main.py
import os


from looprefact import ForWhileRefact
from mapfilter import MapFilterRefactor
from hardcode import HardcodedValues
path='hardcode'


"""
loop refact
hardcoded values
common params for functionalliy need to be done


"""
def process_files(dir_path):
    loop_refact = ForWhileRefact()
    hardcode = HardcodedValues()
    mapfilter = MapFilterRefactor()
    os.makedirs(f"./testing_prog/{path}/output/", exist_ok=True)
    for filename in os.listdir(dir_path):
        if filename.endswith(".py"):
            file_path = os.path.join(dir_path, filename)
            with open(file_path, "r", encoding="utf-8") as f:
                source_code = f.read()


            refactored_code = hardcode.get_refactored_code(source_code)
            print(f"\n****** Final Code for {filename} ******\n")
            print(refactored_code)
            #os.makedirs
            res_file_path = os.path.join(f"./testing_prog/{path}/output/", filename)
            with open(res_file_path, "w", encoding="utf-8") as f:
                f.write(refactored_code)

if __name__ == "__main__":
    process_files(f"./testing_prog/{path}/")
