import os
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from Levenshtein import distance
from sklearn.metrics.pairwise import cosine_similarity
import ast
import importlib.util
import sys
import numpy as np
from pathlib import Path

ORIGINAL_DIR = "source"
REFACTORED_DIR = "target"
MAX_LENGTH = 512  # Max token length for CodeBERT

tokenizer = AutoTokenizer.from_pretrained("microsoft/codebert-base")
model = AutoModelForSequenceClassification.from_pretrained("microsoft/codebert-base")

def read_code(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read()

def tokenize_code(code1, code2, tokenizer):
    inputs = tokenizer(code1, code2, return_tensors="pt", max_length=MAX_LENGTH, 
                      truncation=True, padding="max_length")
    return inputs

def predict_clone(code1, code2, model, tokenizer):
    inputs = tokenize_code(code1, code2, tokenizer)
    model.eval()
    with torch.no_grad():
        outputs = model(**inputs)
        logits = outputs.logits
        prediction = torch.softmax(logits, dim=1)[:, 1].item()
    return prediction

def calculate_difference_percentage(code1, code2):
    lev_distance = distance(code1, code2)
    max_len = max(len(code1), len(code2))
    if max_len == 0:
        return 0.0
    return (lev_distance / max_len) * 100

def embedding_similarity(code1, code2, model, tokenizer):
    inputs1 = tokenizer(code1, return_tensors="pt", max_length=MAX_LENGTH, truncation=True)
    inputs2 = tokenizer(code2, return_tensors="pt", max_length=MAX_LENGTH, truncation=True)
    with torch.no_grad():
        emb1 = model.roberta(**inputs1).last_hidden_state.mean(dim=1)
        emb2 = model.roberta(**inputs2).last_hidden_state.mean(dim=1)
    similarity = cosine_similarity(emb1, emb2)[0][0]
    print("similarity", similarity)
    return (1 - similarity) * 100

def get_function_names(code):
    try:
        tree = ast.parse(code)
        return [node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)]
    except SyntaxError:
        return []

def check_behavior(original_file, refactored_file):
    try:
        original_code = read_code(original_file)
        refactored_code = read_code(refactored_file)

        original_functions = get_function_names(original_code)
        refactored_functions = get_function_names(refactored_code)

        if original_functions and refactored_functions:
            original_module_name = Path(original_file).stem
            refactored_module_name = Path(refactored_file).stem

            spec1 = importlib.util.spec_from_file_location(original_module_name, original_file)
            original_module = importlib.util.module_from_spec(spec1)
            sys.modules[original_module_name] = original_module
            spec1.loader.exec_module(original_module)

            spec2 = importlib.util.spec_from_file_location(refactored_module_name, refactored_file)
            refactored_module = importlib.util.module_from_spec(spec2)
            sys.modules[refactored_module_name] = refactored_module
            spec2.loader.exec_module(refactored_module)

            common_functions = set(original_functions).intersection(refactored_functions)
            if not common_functions:
                return False, "No common functions found to test behavior"

            test_inputs = [(1, 2), (0, 0), (5, 10)]  
            for func_name in common_functions:
                for input_args in test_inputs:
                    original_result = getattr(original_module, func_name)(*input_args)
                    refactored_result = getattr(refactored_module, func_name)(*input_args)
                    if original_result != refactored_result:
                        return False, f"Behavioral mismatch in {func_name} for input {input_args}"
            return True, "Behavior is equivalent for all common functions"

        else:
            try:
                tree1 = ast.parse(original_code)
                tree2 = ast.parse(refactored_code)
                if ast.dump(tree1, annotate_fields=False) == ast.dump(tree2, annotate_fields=False):
                    return True, "AST structure is identical"
                else:
                    return False, "AST structure differs (non-executable code)"
            except SyntaxError as e:
                return False, f"Invalid Python code: {str(e)}"

    except Exception as e:
        return False, f"Error checking behavior: {str(e)}"

def analyze_code_clones(original_dir, refactored_dir):
    if not os.path.exists(original_dir) or not os.path.exists(refactored_dir):
        print(f"Error: One or both directories ({original_dir}, {refactored_dir}) do not exist.")
        return

    original_files = sorted([f for f in os.listdir(original_dir) if f.endswith(".py")])
    refactored_files = sorted([f for f in os.listdir(refactored_dir) if f.endswith(".py")])
    common_files = set(original_files).intersection(set(refactored_files))

    if not common_files:
        print("No matching .py files found in both directories.")
        return

    print(f"Analyzing {len(common_files)} code pairs...\n")
    for file_name in common_files:
        original_path = os.path.join(original_dir, file_name)
        refactored_path = os.path.join(refactored_dir, file_name)
        original_code = read_code(original_path)
        refactored_code = read_code(refactored_path)

        clone_probability = predict_clone(original_code, refactored_code, model, tokenizer)
        is_clone = clone_probability > 0.5

        syntactic_diff = calculate_difference_percentage(original_code, refactored_code)
        embedding_diff = embedding_similarity(original_code, refactored_code, model, tokenizer)

        behavior_equivalent, behavior_message = check_behavior(original_path, refactored_path)

        print(f"File: {file_name}")
        print(f"Clone Probability: {clone_probability:.2%}")
        print(f"Syntactic Difference (Levenshtein): {syntactic_diff:.2f}%")
        print(f"Embedding Difference (Cosine): {embedding_diff:.2f}%")
        print(f"Behavioral Equivalence: {behavior_message}")
        print(f"Conclusion: {'Clone' if is_clone and behavior_equivalent else 'Not a clone or behavior differs'}")
        print("-" * 50)

if __name__ == "__main__":
    analyze_code_clones(ORIGINAL_DIR, REFACTORED_DIR)