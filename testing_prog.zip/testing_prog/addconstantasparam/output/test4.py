def keygen(key_size=2048):
    key = RSA.generate(key_size)
    return key

def sign(key, var0='this is a message'):
    signer = pkcs1_15.new(key)
    signature = signer.sign(var0)
    return signature
k = ECC.generate('ed448')
k2 = ECC.generate(curve='p521')