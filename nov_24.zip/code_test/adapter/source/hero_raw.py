from cryptography.hazmat.primitives import serialization


class Ed25519Adapter:

    def sign(self, private_key, data):
        return private_key.sign(data)

    def load_public_key_pem(self, data):
        return serialization.load_pem_public_key(data)

    def verify(self, public_key, signature, data):
        return public_key.verify(signature, data)
