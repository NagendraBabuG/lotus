from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import mldsa

private_key = mldsa.MLDSA44PrivateKey.generate()
data = b"this is some data I'd like to sign"
signature = private_key.sign(data)

public_key = private_key.public_key()
public_key.verify(signature, data)