from arta import RulesEngine
import libcst as cst

from libcst.display import dump

eng = RulesEngine(config_path="./arta_files")


def get_target_hybrid_kem_server(code):

    libname = "cryptography"

    inputs = {
        "tree":code,
        "library":libname
    }


    extracted_result = eng.apply_rules(inputs, rule_set="mapping_creator_rule_set")
    mappings = extracted_result['get_mapping_ids']


    libname = "cryptography"
    mod_inputs = {
        "tree":code,
        "mappings":mappings,
        "library":libname
        
    }

    result = eng.apply_rules(mod_inputs, rule_set="kem_keygen_rule_set")
    modified_keygen_tree = result['check_generate']


    return modified_keygen_tree.code

def get_target_pqc_kem_server(code):

    libname = "cryptography"

    inputs = {
        "tree":code,
        "library":libname
    }


    extracted_result = eng.apply_rules(inputs, rule_set="mapping_creator_rule_set")
    mappings = extracted_result['get_mapping_ids']


    libname = "cryptography"
    mod_inputs = {
        "tree":code,
        "mappings":mappings,
        "library":libname
        
    }

    result = eng.apply_rules(mod_inputs, rule_set="kem_transform_pqc_rule_set")
    modified_keygen_tree = result['check_generate']


    return modified_keygen_tree.code




if __name__ == "__main__":
    with open("./new_files/test1.py", "r") as f:
        src = f.read()


    tree = cst.parse_module(src)
    res = get_target_hybrid_kem_server(tree)
    print(res)

    print("\n pure PQC key exchange\n\n")

    res = get_target_pqc_kem_server(tree)
    print(res)
