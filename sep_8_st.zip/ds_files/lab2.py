import hashlib
import base64
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.backends import default_backend
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def get_file_path(filename):
    return os.path.join(BASE_DIR, filename)

def generate_keys():
    print("Generating RSA key pair (1024 bits)...")
    private_key = rsa.generate_private_key(
        public_exponent=65537, # numero de Fermat
        key_size=1024,
        backend=default_backend()
    )
    public_key = private_key.public_key()
    
    private_pem = private_key.private_bytes(
        # serialization.Encoding.PEM Privacy-Enhanced Mail
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )
    private_key_b64 = base64.b64encode(private_pem)
    
    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    public_key_b64 = base64.b64encode(public_pem)
    
    with open(get_file_path("private_key_b64.txt"), "wb") as f:
        f.write(private_key_b64)
    
    with open(get_file_path("public_key_b64.txt"), "wb") as f:
        f.write(public_key_b64)
        
    print("Keys generated and saved successfully:")
    print(f"Private key saved to {get_file_path('private_key_b64.txt')} (Base64) 🔐")
    print(f"Public key saved to {get_file_path('public_key_b64.txt')} (Base64) 🔓")
    
    return private_key, public_key


def sign_message(private_key, message_file):
    print(f"Signing message from '{message_file}'...")
    try:
        with open(get_file_path(message_file), "rb") as f:
            message = f.read()
    except FileNotFoundError:
        print(f"Error: Message file '{get_file_path(message_file)}' not found.")
        return
    
    try:
        with open(get_file_path("private_key_b64.txt"), "rb") as f:
            private_key_b64 = f.read()
        private_pem = base64.b64decode(private_key_b64)
        private_key = serialization.load_pem_private_key(private_pem, password=None, backend=default_backend())
    except FileNotFoundError:
        print(f"Error: Private key file '{get_file_path('private_key_b64.txt')}' not found.")
        return
    except Exception as e:
        print(f"Error loading private key: {e}")
        return

    d = private_key.private_numbers().d
    n = private_key.private_numbers().public_numbers.n
    h = int.from_bytes(hashlib.sha256(message).digest(), 'big')

    s = pow(h, d, n)
    
    signature_b64 = base64.b64encode(s.to_bytes((s.bit_length() + 7) // 8, 'big'))
    print("Message signed successfully! The signature is:")
    print(signature_b64.decode('utf-8'))
    
    with open(get_file_path("signature_b64.txt"), "wb") as f:
        f.write(signature_b64)
    
    print("Signature saved to signature_b64.txt")
    return s

def verify_signature(message_file, signature_file, public_key_file):
    print(f"Verifying signature for '{message_file}' using public key from '{public_key_file}'...")
    
    try:
        with open(get_file_path(public_key_file), "rb") as f:
            public_key_b64 = f.read()
        public_pem = base64.b64decode(public_key_b64)
        public_key = serialization.load_pem_public_key(public_pem, backend=default_backend())
        
    except FileNotFoundError:
        print(f"Error: Public key file '{get_file_path(public_key_file)}' not found. Please generate keys first (option 1).")
        return False
    except Exception as e:
        print(f"Error loading public key: {e}")
        return False

    try:
        with open(get_file_path(message_file), "rb") as f:
            message = f.read()
    except FileNotFoundError:
        print(f"Error: Message file '{get_file_path(message_file)}' not found.")
        return False
    
    try:
        with open(get_file_path(signature_file), "rb") as f:
            signature_b64 = f.read()
        s = int.from_bytes(base64.b64decode(signature_b64), 'big')
    except FileNotFoundError:
        print(f"Error: Signature file '{get_file_path(signature_file)}' not found. Please sign a message first.")
        return False
    except Exception as e:
        print(f"Error decoding signature: {e}")
        return False
    e = public_key.public_numbers().e
    n = public_key.public_numbers().n

    h_prime = int.from_bytes(hashlib.sha256(message).digest(), 'big')
    h = pow(s, e, n)
    
    if h == h_prime:
        print("Signature is valid! ✅")
        return True
    else:
        print("Signature is NOT valid. ❌")
        return False

def main():
    key_params = None
    while True:
        print("\n--- Lab 2 - Ejercicios ---")
        print("1. Generate RSA Key Pair")
        print("2. Sign a Message")
        print("3. Verify a Signature")
        print("4. Test all")
        print("5. Exit")
        
        choice = input("Enter your choice: ")
        
        if choice == '1':
            key_params = generate_keys()
            
        elif choice == '2':
            if key_params is None:
                print("Error: Please generate keys first (option 1).")
                continue
            if not os.path.exists("message.txt"):
                print("Please create a file named 'message.txt' with the message you want to sign.")
                continue
            sign_message(key_params, "message.txt")
            
        elif choice == '3':
            verify_signature("message.txt", "signature_b64.txt", "public_key_b64.txt")

        elif choice == '4':
            print("--- Testing the complete process ---")
            
            key_params = generate_keys()
            
            with open("message.txt", "w") as f:
                f.write("This is a test message to be signed.")
            
            sign_message(key_params, "message.txt")
            
            verify_signature("message.txt", "signature_b64.txt")
            
            print("--- End of test ---")

        elif choice == '5':
            print("Exiting...")
            break
            
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()