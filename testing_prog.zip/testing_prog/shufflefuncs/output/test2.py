def b():
    c()

def a():
    b()

def c():
    print('C')
a()