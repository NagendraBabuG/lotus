from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import libcst as cst
from libcst.metadata import MetadataWrapper, QualifiedNameProvider


PQC_PRIV_CLASSES = {
    "MLDSA44PrivateKey": "MLDSA44",
    "MLDSA65PrivateKey": "MLDSA65",
    "MLDSA87PrivateKey": "MLDSA87",
}

PQC_PUB_CLASSES = {
    "MLDSA44PublicKey": "MLDSA44",
    "MLDSA65PublicKey": "MLDSA65",
    "MLDSA87PublicKey": "MLDSA87",
}

CLASS_METHODS = {
    "generate",
    "from_seed_bytes",
    "from_public_bytes",
}

PRIVATE_KEY_METHODS = {
    "public_key",
    "sign",
    "private_bytes",
    "private_bytes_raw",
}

PUBLIC_KEY_METHODS = {
    "verify",
    "public_bytes",
    "public_bytes_raw",
}

SERIALIZATION_LOADERS = {
    "load_pem_private_key": ("private", "pem"),
    "load_der_private_key": ("private", "der"),
    "load_pem_public_key": ("public", "pem"),
    "load_der_public_key": ("public", "der"),
}

X509_SYMBOLS = {
    "CertificateBuilder",
    "CertificateSigningRequestBuilder",
    "CertificateRevocationListBuilder",
    "OCSPResponseBuilder",
    "load_pem_x509_certificate",
    "load_der_x509_certificate",
    "load_pem_x509_csr",
    "load_der_x509_csr",
    "load_pem_x509_crl",
    "load_der_x509_crl",
}

X509_VAR_NAMES = {"cert", "certificate", "csr", "crl", "builder", "x509_cert"}

VALID_ENCODINGS = {"PEM", "DER", "Raw"}
VALID_PRIVATE_FORMATS = {"PKCS8", "Raw"}
VALID_PUBLIC_FORMATS = {"SubjectPublicKeyInfo", "Raw"}

KeyTypeSet = set[tuple[str, str]]


@dataclass(frozen=True)
class AdapterMethodSpec:
    variant: str
    base_name: str
    params: tuple[str, ...]
    body: str
    variant_suffix: str = ""
    uses_serialization: bool = False
    is_raw: bool = False


class _BasePQCVisitor(cst.CSTVisitor):
    METADATA_DEPENDENCIES = (QualifiedNameProvider,)

    def _get_qnames(self, node: cst.CSTNode) -> set[str]:
        qnames = self.get_metadata(QualifiedNameProvider, node, default=set())
        return {q.name for q in qnames} if qnames else set()

    def _get_node_name(self, node: cst.BaseExpression | None) -> str | None:
        if node is None:
            return None
        if isinstance(node, cst.Name):
            return node.value
        if isinstance(node, cst.Attribute):
            return cst.helpers.get_full_name_for_node(node)
        return None

    def _get_arg(
        self, args: tuple[cst.Arg, ...], kw_name: str, pos_index: int
    ) -> cst.Arg | None:
        for arg in args:
            if arg.keyword is not None and arg.keyword.value == kw_name:
                return arg
        pos_args = [a for a in args if a.keyword is None and not a.star]
        if 0 <= pos_index < len(pos_args):
            return pos_args[pos_index]
        return None

    def _extract_enum_leaf(self, expr: cst.BaseExpression | None) -> str | None:
        if expr is None:
            return None
        for q in self._get_qnames(expr):
            return q.rsplit(".", 1)[-1]
        name = self._get_node_name(expr)
        return name.rsplit(".", 1)[-1] if name else None

    def _extract_mldsa_classes(
        self,
        expr: cst.BaseExpression,
        type_aliases: dict[str, KeyTypeSet] | None = None,
    ) -> KeyTypeSet:
        found: KeyTypeSet = set()
        aliases = type_aliases or {}

        def check_leaf(leaf: str) -> None:
            if leaf in PQC_PRIV_CLASSES:
                found.add((PQC_PRIV_CLASSES[leaf], "private"))
            elif leaf in PQC_PUB_CLASSES:
                found.add((PQC_PUB_CLASSES[leaf], "public"))
            elif leaf in aliases:
                found.update(aliases[leaf])

        for q in self._get_qnames(expr):
            check_leaf(q.rsplit(".", 1)[-1])

        class _Finder(cst.CSTVisitor):
            def visit_Attribute(self, node: cst.Attribute) -> bool:
                leaf = node.attr.value
                before = len(found)
                check_leaf(leaf)
                return len(found) == before

            def visit_Name(self, node: cst.Name) -> None:
                check_leaf(node.value)

        expr.visit(_Finder())
        return found

    def _detect_pqc_class_call(self, call: cst.Call) -> tuple[str, str, str] | None:
        if not isinstance(call.func, cst.Attribute):
            return None
        method = call.func.attr.value
        if method not in CLASS_METHODS:
            return None

        cls_types = self._extract_mldsa_classes(call.func.value)
        if len(cls_types) != 1:
            return None

        variant, kind = next(iter(cls_types))
        if kind == "private" and method in {"generate", "from_seed_bytes"}:
            return variant, kind, method
        if kind == "public" and method == "from_public_bytes":
            return variant, kind, method
        return None

    def _detect_serialization_loader(self, call: cst.Call) -> str | None:
        for q in self._get_qnames(call.func):
            leaf = q.rsplit(".", 1)[-1]
            if leaf in SERIALIZATION_LOADERS:
                return leaf
        raw = self._get_node_name(call.func)
        if raw:
            leaf = raw.rsplit(".", 1)[-1]
            if leaf in SERIALIZATION_LOADERS:
                return leaf
        return None

    def _is_x509_call(self, expr: cst.BaseExpression) -> bool:
        curr: cst.BaseExpression | None = expr
        while curr is not None:
            if any(q.rsplit(".", 1)[-1] in X509_SYMBOLS for q in self._get_qnames(curr)):
                return True
            if isinstance(curr, cst.Call):
                if any(
                    q.rsplit(".", 1)[-1] in X509_SYMBOLS
                    for q in self._get_qnames(curr.func)
                ):
                    return True
                fname = self._get_node_name(curr.func)
                if fname and fname.rsplit(".", 1)[-1] in X509_SYMBOLS:
                    return True
                if isinstance(curr.func, cst.Attribute):
                    curr = curr.func.value
                    continue
            break
        return False

    def _block_always_raises(self, block: cst.BaseSuite) -> bool:
        if isinstance(block, cst.SimpleStatementSuite):
            return any(isinstance(s, cst.Raise) for s in block.body)
        if isinstance(block, cst.IndentedBlock):
            for stmt in block.body:
                if isinstance(stmt, cst.SimpleStatementLine):
                    if any(isinstance(s, cst.Raise) for s in stmt.body):
                        return True
        return False

    def _extract_subscript_int(self, sub: cst.Subscript) -> int | None:
        if len(sub.slice) != 1:
            return None
        sl = sub.slice[0].slice
        if isinstance(sl, cst.Index):
            if isinstance(sl.value, cst.Integer):
                return int(sl.value.value, 0)
            if (
                isinstance(sl.value, cst.UnaryOperation)
                and isinstance(sl.value.operator, cst.Minus)
                and isinstance(sl.value.expression, cst.Integer)
            ):
                return -int(sl.value.expression.value, 0)
        return None


class _PQCSymbolCollector(_BasePQCVisitor):
    def __init__(self) -> None:
        self.seen_variants: set[str] = set()
        self.imported_variants: set[str] = set()
        self.defined_classes: set[str] = set()
        self.type_aliases: dict[str, KeyTypeSet] = {}

        self.class_stack: list[str] = []
        self.func_stack: list[str] = []
        self.local_scopes: list[dict[str, KeyTypeSet]] = [{}]
        self.var_class_scopes: list[dict[str, str]] = [{}]
        self.skip_isinstance_tests: set[int] = set()
        self._in_raise_if_test = 0

        self.class_attr_types: dict[tuple[str, ...], dict[str, KeyTypeSet]] = {}
        self.class_property_types: dict[tuple[str, str], KeyTypeSet] = {}
        self.func_param_names: dict[tuple[tuple[str, ...], str], list[str]] = {}
        self.func_param_types: dict[
            tuple[tuple[str, ...], str], dict[str, KeyTypeSet]
        ] = {}
        self.func_return_types: dict[
            tuple[tuple[str, ...], str], list[KeyTypeSet]
        ] = {}
        self.global_name_hints: dict[str, KeyTypeSet] = {}
        self.x509_vars: set[str] = set()

    def _cur_class(self) -> tuple[str, ...]:
        return tuple(self.class_stack)

    def _cur_func_key(self) -> tuple[tuple[str, ...], str] | None:
        if not self.func_stack:
            return None
        return self._cur_class(), self.func_stack[-1]

    def _add_key_types(self, name: str, types: KeyTypeSet) -> None:
        if not types:
            return
        for variant, _ in types:
            self.seen_variants.add(variant)
        self.local_scopes[-1].setdefault(name, set()).update(types)
        if name.startswith("self.") and self.class_stack:
            self.class_attr_types.setdefault(self._cur_class(), {}).setdefault(
                name, set()
            ).update(types)
        elif "." not in name:
            self.global_name_hints.setdefault(name, set()).update(types)

    def _lookup_var_class(self, name: str) -> str | None:
        for scope in reversed(self.var_class_scopes):
            if name in scope:
                return scope[name]
        return None

    def _lookup_key_types(self, name: str | None) -> KeyTypeSet:
        if not name:
            return set()
        for scope in reversed(self.local_scopes):
            if name in scope:
                return set(scope[name])
        if name.startswith("self.") and self.class_stack:
            found = self.class_attr_types.get(self._cur_class(), {}).get(name)
            if found:
                return set(found)
        if "." in name:
            obj_name, attr = name.split(".", 1)
            if "." not in attr:
                cls_name = self._lookup_var_class(obj_name)
                if cls_name:
                    prop_types = self.class_property_types.get((cls_name, attr))
                    if prop_types:
                        return set(prop_types)
        func_key = self._cur_func_key()
        if func_key and name in self.func_param_types.get(func_key, {}):
            return set(self.func_param_types[func_key][name])
        return set()

    def _lookup_func_return(self, call: cst.Call) -> list[KeyTypeSet] | None:
        func_name = self._get_node_name(call.func)
        if not func_name:
            return None
        if func_name.startswith("self.") and self.class_stack:
            return self.func_return_types.get(
                (self._cur_class(), func_name.split(".", 1)[1])
            )
        return self.func_return_types.get(
            ((), func_name)
        ) or self.func_return_types.get((self._cur_class(), func_name))

    def _infer_expr(self, expr: cst.BaseExpression | None) -> KeyTypeSet:
        if expr is None:
            return set()

        name = self._get_node_name(expr)
        if name:
            found = self._lookup_key_types(name)
            if found:
                return found

        if isinstance(expr, cst.Subscript) and isinstance(expr.value, cst.Call):
            idx = self._extract_subscript_int(expr)
            ret_types = self._lookup_func_return(expr.value)
            if idx is not None and ret_types and -len(ret_types) <= idx < len(ret_types):
                return set(ret_types[idx])

        if not isinstance(expr, cst.Call):
            return set()

        cls_call = self._detect_pqc_class_call(expr)
        if cls_call:
            self.seen_variants.add(cls_call[0])
            return {(cls_call[0], cls_call[1])}

        if isinstance(expr.func, cst.Attribute) and expr.func.attr.value == "public_key":
            recv_types = self._infer_expr(expr.func.value)
            return {(v, "public") for v, k in recv_types if k == "private"}

        ret_types = self._lookup_func_return(expr)
        if ret_types and len(ret_types) == 1:
            return set(ret_types[0])

        return set()

    def _merge_return_types(
        self, func_key: tuple[tuple[str, ...], str], slots: list[KeyTypeSet]
    ) -> None:
        if not any(slots):
            return
        existing = self.func_return_types.get(func_key)
        if existing is None or len(existing) != len(slots):
            self.func_return_types[func_key] = [set(s) for s in slots]
        else:
            for i, s in enumerate(slots):
                existing[i].update(s)

    def visit_ImportFrom(self, node: cst.ImportFrom) -> bool:
        if isinstance(node.names, cst.ImportStar):
            return False
        for alias in node.names:
            iname = alias.name.value
            if iname in PQC_PRIV_CLASSES:
                self.imported_variants.add(PQC_PRIV_CLASSES[iname])
            elif iname in PQC_PUB_CLASSES:
                self.imported_variants.add(PQC_PUB_CLASSES[iname])
        return False

    def visit_If(self, node: cst.If) -> bool:
        if self._block_always_raises(node.body):
            self.skip_isinstance_tests.add(id(node.test))
        return True

    def visit_If_test(self, node: cst.If) -> None:
        if id(node.test) in self.skip_isinstance_tests:
            self._in_raise_if_test += 1

    def leave_If_test(self, node: cst.If) -> None:
        if id(node.test) in self.skip_isinstance_tests:
            self._in_raise_if_test = max(0, self._in_raise_if_test - 1)

    def visit_ClassDef(self, node: cst.ClassDef) -> bool:
        self.defined_classes.add(node.name.value)
        self.class_stack.append(node.name.value)
        self.local_scopes.append({})
        self.var_class_scopes.append({})
        return True

    def leave_ClassDef(self, original_node: cst.ClassDef) -> None:
        self.var_class_scopes.pop()
        self.local_scopes.pop()
        self.class_stack.pop()

    def visit_FunctionDef(self, node: cst.FunctionDef) -> bool:
        self.func_stack.append(node.name.value)
        self.local_scopes.append({})
        self.var_class_scopes.append({})
        func_key = (self._cur_class(), node.name.value)

        all_params = (
            list(node.params.posonly_params)
            + list(node.params.params)
            + list(node.params.kwonly_params)
        )
        param_names: list[str] = []
        for idx, param in enumerate(all_params):
            pname = param.name.value
            if idx == 0 and self.class_stack and pname in {"self", "cls"}:
                continue
            param_names.append(pname)
            if param.annotation is not None:
                ann_expr = param.annotation.annotation
                ann_name = self._get_node_name(ann_expr)
                if ann_name and ann_name.rsplit(".", 1)[-1] in self.defined_classes:
                    self.var_class_scopes[-1][pname] = ann_name.rsplit(".", 1)[-1]
                ann_types = self._extract_mldsa_classes(ann_expr, self.type_aliases)
                if ann_types:
                    self._add_key_types(pname, ann_types)
                    self.func_param_types.setdefault(func_key, {}).setdefault(
                        pname, set()
                    ).update(ann_types)

        self.func_param_names[func_key] = param_names

        for pname, ptypes in self.func_param_types.get(func_key, {}).items():
            self.local_scopes[-1].setdefault(pname, set()).update(ptypes)

        if node.returns is not None:
            ret_types = self._extract_mldsa_classes(
                node.returns.annotation, self.type_aliases
            )
            if ret_types:
                self._merge_return_types(func_key, [ret_types])
                if self.class_stack and any(
                    self._get_node_name(d.decorator) == "property"
                    for d in node.decorators
                ):
                    self.class_property_types.setdefault(
                        (self.class_stack[-1], node.name.value), set()
                    ).update(ret_types)

        return True

    def leave_FunctionDef(self, original_node: cst.FunctionDef) -> None:
        self.var_class_scopes.pop()
        self.local_scopes.pop()
        self.func_stack.pop()

    def visit_Return(self, node: cst.Return) -> bool:
        func_key = self._cur_func_key()
        if not func_key or node.value is None:
            return True
        if isinstance(node.value, cst.Tuple):
            slots = [
                self._infer_expr(el.value) if isinstance(el, cst.Element) else set()
                for el in node.value.elements
            ]
            self._merge_return_types(func_key, slots)
        else:
            inferred = self._infer_expr(node.value)
            if inferred:
                self._merge_return_types(func_key, [inferred])
                if self.class_stack and self.func_stack:
                    self.class_property_types.setdefault(
                        (self.class_stack[-1], self.func_stack[-1]), set()
                    ).update(inferred)
        return True

    def visit_Assign(self, node: cst.Assign) -> bool:
        if len(node.targets) != 1:
            return True
        target = node.targets[0].target

        if isinstance(target, (cst.Tuple, cst.List)) and isinstance(node.value, cst.Call):
            ret_types = self._lookup_func_return(node.value)
            if ret_types:
                for el, rtypes in zip(target.elements, ret_types):
                    if isinstance(el, cst.Element) and rtypes:
                        tname = self._get_node_name(el.value)
                        if tname:
                            self._add_key_types(tname, rtypes)
            return True

        target_name = self._get_node_name(target)
        if not target_name:
            return True

        if not self.func_stack and not isinstance(node.value, cst.Call):
            alias_types = self._extract_mldsa_classes(node.value, self.type_aliases)
            if alias_types:
                self.type_aliases[target_name] = alias_types
                return True

        if self._is_x509_call(node.value):
            self.x509_vars.add(target_name)
            return True

        inferred = self._infer_expr(node.value)
        if inferred:
            self._add_key_types(target_name, inferred)
            return True

        if isinstance(node.value, cst.Call):
            loader = self._detect_serialization_loader(node.value)
            if loader and len(self.seen_variants) == 1:
                kind, _ = SERIALIZATION_LOADERS[loader]
                self._add_key_types(target_name, {(next(iter(self.seen_variants)), kind)})

        return True

    def visit_AnnAssign(self, node: cst.AnnAssign) -> bool:
        target_name = self._get_node_name(node.target)
        if not target_name:
            return True

        if node.value is not None and self._is_x509_call(node.value):
            self.x509_vars.add(target_name)
            return True

        ann_name = self._get_node_name(node.annotation.annotation)
        if ann_name and ann_name.rsplit(".", 1)[-1] in self.defined_classes:
            self.var_class_scopes[-1][target_name] = ann_name.rsplit(".", 1)[-1]

        ann_types = self._extract_mldsa_classes(
            node.annotation.annotation, self.type_aliases
        )
        inferred = self._infer_expr(node.value)

        if inferred:
            self._add_key_types(target_name, inferred)
        elif ann_types:
            self._add_key_types(target_name, ann_types)
        elif isinstance(node.value, cst.Call):
            loader = self._detect_serialization_loader(node.value)
            if loader and len(self.seen_variants) == 1:
                kind, _ = SERIALIZATION_LOADERS[loader]
                self._add_key_types(target_name, {(next(iter(self.seen_variants)), kind)})

        return True

    def visit_Call(self, node: cst.Call) -> bool:
        cls_call = self._detect_pqc_class_call(node)
        if cls_call:
            self.seen_variants.add(cls_call[0])
            return True

        if (
            isinstance(node.func, cst.Name)
            and node.func.value == "isinstance"
            and len(node.args) >= 2
            and not self._in_raise_if_test
        ):
            var_name = self._get_node_name(node.args[0].value)
            cls_types = self._extract_mldsa_classes(node.args[1].value, self.type_aliases)
            if var_name and cls_types:
                self._add_key_types(var_name, cls_types)
                func_key = self._cur_func_key()
                if func_key and var_name in self.func_param_names.get(func_key, []):
                    self.func_param_types.setdefault(func_key, {}).setdefault(
                        var_name, set()
                    ).update(cls_types)
            return True

        func_name = self._get_node_name(node.func)
        if not func_name:
            return True

        callee_key: tuple[tuple[str, ...], str] | None = None
        if func_name == "cls" and self.class_stack:
            candidate = (self._cur_class(), "__init__")
            if candidate in self.func_param_names:
                callee_key = candidate
        elif func_name in self.defined_classes:
            candidate = ((func_name,), "__init__")
            if candidate in self.func_param_names:
                callee_key = candidate
        elif func_name.startswith("self.") and self.class_stack:
            candidate = (self._cur_class(), func_name.split(".", 1)[1])
            if candidate in self.func_param_names:
                callee_key = candidate
        elif ((), func_name) in self.func_param_names:
            callee_key = ((), func_name)
        elif (self._cur_class(), func_name) in self.func_param_names:
            callee_key = (self._cur_class(), func_name)

        if callee_key is not None:
            param_names = self.func_param_names[callee_key]
            pos_idx = 0
            for arg in node.args:
                if arg.star:
                    continue
                arg_types = self._infer_expr(arg.value)
                if arg.keyword is not None:
                    pname = arg.keyword.value
                    if arg_types and pname in param_names:
                        self.func_param_types.setdefault(callee_key, {}).setdefault(
                            pname, set()
                        ).update(arg_types)
                else:
                    if arg_types and pos_idx < len(param_names):
                        pname = param_names[pos_idx]
                        self.func_param_types.setdefault(callee_key, {}).setdefault(
                            pname, set()
                        ).update(arg_types)
                    pos_idx += 1

        return True


class PQCDSCallExtractor(_BasePQCVisitor):
    def __init__(self, symbols: _PQCSymbolCollector) -> None:
        self.symbols = symbols
        self.seen_variants = (
            set(symbols.seen_variants)
            if symbols.seen_variants
            else set(symbols.imported_variants)
        )
        self.concrete_variants: set[str] = set()
        self.class_stack: list[str] = []
        self.func_stack: list[str] = []
        self.key_scopes: list[dict[str, KeyTypeSet]] = [{}]
        self.var_class_scopes: list[dict[str, str]] = [{}]

        self.methods: list[AdapterMethodSpec] = []
        self.pending_loaders: list[tuple[str, bool]] = []

    def _cur_class(self) -> tuple[str, ...]:
        return tuple(self.class_stack)

    def _single_variant(self) -> str | None:
        active = self.concrete_variants if self.concrete_variants else self.seen_variants
        return next(iter(active)) if len(active) == 1 else None

    def _add_key_types(self, name: str, types: KeyTypeSet) -> None:
        if not types:
            return
        self.key_scopes[-1].setdefault(name, set()).update(types)
        for v, _ in types:
            self.seen_variants.add(v)

    def _lookup_var_class(self, name: str) -> str | None:
        for scope in reversed(self.var_class_scopes):
            if name in scope:
                return scope[name]
        return None

    def _get_key_types(self, name: str | None) -> KeyTypeSet:
        if not name:
            return set()
        for scope in reversed(self.key_scopes):
            if name in scope:
                return set(scope[name])
        if name.startswith("self.") and self.class_stack:
            found = self.symbols.class_attr_types.get(self._cur_class(), {}).get(name)
            if found:
                return set(found)
        if "." in name:
            obj_name, attr = name.split(".", 1)
            if "." not in attr:
                cls_name = self._lookup_var_class(obj_name)
                if cls_name:
                    prop_types = self.symbols.class_property_types.get((cls_name, attr))
                    if prop_types:
                        return set(prop_types)
        if self.func_stack:
            func_key = (self._cur_class(), self.func_stack[-1])
            found = self.symbols.func_param_types.get(func_key, {}).get(name)
            if found:
                return set(found)
        hint = self.symbols.global_name_hints.get(name)
        return set(hint) if hint else set()

    def _lookup_func_return(self, call: cst.Call) -> list[KeyTypeSet] | None:
        func_name = self._get_node_name(call.func)
        if not func_name:
            return None
        if func_name.startswith("self.") and self.class_stack:
            return self.symbols.func_return_types.get(
                (self._cur_class(), func_name.split(".", 1)[1])
            )
        return self.symbols.func_return_types.get(
            ((), func_name)
        ) or self.symbols.func_return_types.get((self._cur_class(), func_name))

    def _is_x509_receiver(self, expr: cst.BaseExpression) -> bool:
        if self._is_x509_call(expr):
            return True
        name = self._get_node_name(expr)
        if name:
            if name in self.symbols.x509_vars:
                return True
            if name.rsplit(".", 1)[-1].lower() in X509_VAR_NAMES:
                return True
        return False

    def _infer_expr_key_types(self, expr: cst.BaseExpression | None) -> KeyTypeSet:
        if expr is None:
            return set()

        name = self._get_node_name(expr)
        if name:
            tracked = self._get_key_types(name)
            if tracked:
                return tracked

        if isinstance(expr, cst.Subscript) and isinstance(expr.value, cst.Call):
            idx = self._extract_subscript_int(expr)
            ret_types = self._lookup_func_return(expr.value)
            if idx is not None and ret_types and -len(ret_types) <= idx < len(ret_types):
                return set(ret_types[idx])

        if not isinstance(expr, cst.Call):
            return set()

        cls_call = self._detect_pqc_class_call(expr)
        if cls_call:
            return {(cls_call[0], cls_call[1])}

        if isinstance(expr.func, cst.Attribute) and expr.func.attr.value == "public_key":
            recv_types = self._infer_expr_key_types(expr.func.value)
            return {(v, "public") for v, k in recv_types if k == "private"}

        ret_types = self._lookup_func_return(expr)
        if ret_types and len(ret_types) == 1:
            return set(ret_types[0])

        return set()

    def _fallback_key_types(self, method: str, call: cst.Call) -> KeyTypeSet:
        variant = self._single_variant()
        if not variant:
            return set()
        if not isinstance(call.func, cst.Attribute):
            return set()
        if self._is_x509_receiver(call.func.value):
            return set()

        kw_names = {a.keyword.value for a in call.args if a.keyword is not None}

        if method == "public_key" and len(call.args) == 0:
            return {(variant, "private")}
        if method == "private_bytes_raw" and len(call.args) == 0:
            return {(variant, "private")}
        if method == "private_bytes" and len(call.args) >= 3:
            return {(variant, "private")}
        if method == "public_bytes_raw" and len(call.args) == 0:
            return {(variant, "public")}
        if method == "public_bytes" and len(call.args) >= 2:
            return {(variant, "public")}
        if (
            method == "sign"
            and 1 <= len(call.args) <= 2
            and not (kw_names & {"algorithm", "private_key", "rsa_padding"})
        ):
            return {(variant, "private")}
        if method == "verify" and 2 <= len(call.args) <= 3:
            return {(variant, "public")}

        return set()

    def _build_private_bytes_spec(
        self, variant: str, call: cst.Call
    ) -> AdapterMethodSpec:
        enc_arg = self._get_arg(call.args, "encoding", 0)
        fmt_arg = self._get_arg(call.args, "format", 1)
        alg_arg = self._get_arg(call.args, "encryption_algorithm", 2)

        enc_leaf = self._extract_enum_leaf(enc_arg.value if enc_arg else None)
        fmt_leaf = self._extract_enum_leaf(fmt_arg.value if fmt_arg else None)

        enc_is_dynamic = (
            enc_arg is not None
            and enc_leaf not in VALID_ENCODINGS
            and isinstance(enc_arg.value, cst.Name)
        )
        fmt_is_dynamic = (
            fmt_arg is not None
            and fmt_leaf not in VALID_PRIVATE_FORMATS
            and isinstance(fmt_arg.value, cst.Name)
        )

        enc = enc_leaf if enc_leaf in VALID_ENCODINGS else "PEM"
        if enc == "Raw":
            fmt = "Raw"
        elif fmt_leaf in VALID_PRIVATE_FORMATS and fmt_leaf != "Raw":
            fmt = fmt_leaf
        else:
            fmt = "PKCS8"

        params: list[str] = ["private_key"]
        if enc_is_dynamic:
            params.append(f"encoding=serialization.Encoding.{enc}")
            enc_expr = "encoding"
        else:
            enc_expr = f"serialization.Encoding.{enc}"

        if fmt_is_dynamic:
            params.append(f"format=serialization.PrivateFormat.{fmt}")
            fmt_expr = "format"
        else:
            fmt_expr = f"serialization.PrivateFormat.{fmt}"

        use_password = False
        alg_is_dynamic = False
        if enc != "Raw" and alg_arg is not None:
            if isinstance(alg_arg.value, cst.Call):
                if self._extract_enum_leaf(alg_arg.value.func) == "BestAvailableEncryption":
                    use_password = True
            elif isinstance(alg_arg.value, cst.Name):
                alg_is_dynamic = True

        if use_password:
            params.append("password=None")
            alg_expr = (
                "serialization.BestAvailableEncryption(password) "
                "if password is not None else serialization.NoEncryption()"
            )
        elif alg_is_dynamic:
            params.append("encryption_algorithm=None")
            alg_expr = (
                "encryption_algorithm if encryption_algorithm is not None "
                "else serialization.NoEncryption()"
            )
        else:
            alg_expr = "serialization.NoEncryption()"

        body = (
            "return private_key.private_bytes(\n"
            f"            encoding={enc_expr},\n"
            f"            format={fmt_expr},\n"
            f"            encryption_algorithm={alg_expr},\n"
            "        )"
        )
        suffix = f"_{enc.lower()}" + ("_encrypted" if use_password else "")
        return AdapterMethodSpec(
            variant=variant,
            base_name="serialize_private_key",
            params=tuple(params),
            body=body,
            variant_suffix=suffix,
            uses_serialization=True,
            is_raw=(enc == "Raw" and not enc_is_dynamic),
        )

    def _build_public_bytes_spec(
        self, variant: str, call: cst.Call
    ) -> AdapterMethodSpec:
        enc_arg = self._get_arg(call.args, "encoding", 0)
        fmt_arg = self._get_arg(call.args, "format", 1)

        enc_leaf = self._extract_enum_leaf(enc_arg.value if enc_arg else None)
        fmt_leaf = self._extract_enum_leaf(fmt_arg.value if fmt_arg else None)

        enc_is_dynamic = (
            enc_arg is not None
            and enc_leaf not in VALID_ENCODINGS
            and isinstance(enc_arg.value, cst.Name)
        )
        fmt_is_dynamic = (
            fmt_arg is not None
            and fmt_leaf not in VALID_PUBLIC_FORMATS
            and isinstance(fmt_arg.value, cst.Name)
        )

        enc = enc_leaf if enc_leaf in VALID_ENCODINGS else "PEM"
        if enc == "Raw":
            fmt = "Raw"
        elif fmt_leaf in VALID_PUBLIC_FORMATS and fmt_leaf != "Raw":
            fmt = fmt_leaf
        else:
            fmt = "SubjectPublicKeyInfo"

        params: list[str] = ["public_key"]
        if enc_is_dynamic:
            params.append(f"encoding=serialization.Encoding.{enc}")
            enc_expr = "encoding"
        else:
            enc_expr = f"serialization.Encoding.{enc}"

        if fmt_is_dynamic:
            params.append(f"format=serialization.PublicFormat.{fmt}")
            fmt_expr = "format"
        else:
            fmt_expr = f"serialization.PublicFormat.{fmt}"

        body = (
            "return public_key.public_bytes(\n"
            f"            encoding={enc_expr},\n"
            f"            format={fmt_expr},\n"
            "        )"
        )
        return AdapterMethodSpec(
            variant=variant,
            base_name="serialize_public_key",
            params=tuple(params),
            body=body,
            variant_suffix=f"_{enc.lower()}",
            uses_serialization=True,
            is_raw=(enc == "Raw" and not enc_is_dynamic),
        )

    def _build_loader_spec(
        self, variant: str, loader_name: str, has_password: bool
    ) -> AdapterMethodSpec:
        kind, fmt = SERIALIZATION_LOADERS[loader_name]
        if kind == "private":
            params = ("data", "password=None") if has_password else ("data",)
            call_args = "data, password=password" if has_password else "data, password=None"
            return AdapterMethodSpec(
                variant=variant,
                base_name=f"load_private_key_{fmt}",
                params=params,
                body=f"return serialization.{loader_name}({call_args})",
                uses_serialization=True,
            )
        return AdapterMethodSpec(
            variant=variant,
            base_name=f"load_public_key_{fmt}",
            params=("data",),
            body=f"return serialization.{loader_name}(data)",
            uses_serialization=True,
        )

    def visit_ClassDef(self, node: cst.ClassDef) -> bool:
        self.class_stack.append(node.name.value)
        self.key_scopes.append({})
        self.var_class_scopes.append({})
        return True

    def leave_ClassDef(self, original_node: cst.ClassDef) -> None:
        self.var_class_scopes.pop()
        self.key_scopes.pop()
        self.class_stack.pop()

    def visit_FunctionDef(self, node: cst.FunctionDef) -> bool:
        self.func_stack.append(node.name.value)
        self.key_scopes.append({})
        self.var_class_scopes.append({})
        func_key = (self._cur_class(), node.name.value)

        for pname, ptypes in self.symbols.func_param_types.get(func_key, {}).items():
            self._add_key_types(pname, ptypes)

        all_params = (
            list(node.params.posonly_params)
            + list(node.params.params)
            + list(node.params.kwonly_params)
        )
        for param in all_params:
            if param.annotation is not None:
                ann_expr = param.annotation.annotation
                ann_name = self._get_node_name(ann_expr)
                if ann_name and ann_name.rsplit(".", 1)[-1] in self.symbols.defined_classes:
                    self.var_class_scopes[-1][param.name.value] = ann_name.rsplit(".", 1)[-1]
                key_types = self._extract_mldsa_classes(ann_expr, self.symbols.type_aliases)
                if key_types:
                    self._add_key_types(param.name.value, key_types)
        return True

    def leave_FunctionDef(self, original_node: cst.FunctionDef) -> None:
        self.var_class_scopes.pop()
        self.key_scopes.pop()
        self.func_stack.pop()

    def _register_loader_target(
        self,
        target_name: str,
        call: cst.Call,
        annotated_types: KeyTypeSet,
    ) -> None:
        loader_name = self._detect_serialization_loader(call)
        if not loader_name:
            return
        kind, _ = SERIALIZATION_LOADERS[loader_name]
        pw_arg = self._get_arg(call.args, "password", 1)
        has_password = pw_arg is not None and self._get_node_name(pw_arg.value) != "None"

        variants = {v for v, _ in annotated_types} if annotated_types else set()
        if not variants:
            sv = self._single_variant()
            if sv:
                variants = {sv}

        if variants:
            self._add_key_types(target_name, {(v, kind) for v in variants})
            for v in sorted(variants):
                self.methods.append(self._build_loader_spec(v, loader_name, has_password))
        else:
            self.pending_loaders.append((loader_name, has_password))

    def visit_Assign(self, node: cst.Assign) -> bool:
        if len(node.targets) != 1:
            return True
        target = node.targets[0].target

        if isinstance(target, (cst.Tuple, cst.List)) and isinstance(node.value, cst.Call):
            ret_types = self._lookup_func_return(node.value)
            if ret_types:
                for el, rtypes in zip(target.elements, ret_types):
                    if isinstance(el, cst.Element) and rtypes:
                        tname = self._get_node_name(el.value)
                        if tname:
                            self._add_key_types(tname, rtypes)
            return True

        target_name = self._get_node_name(target)
        if not target_name:
            return True

        inferred = self._infer_expr_key_types(node.value)
        if inferred:
            self._add_key_types(target_name, inferred)
            return True

        if isinstance(node.value, cst.Call):
            self._register_loader_target(target_name, node.value, set())

        return True

    def visit_AnnAssign(self, node: cst.AnnAssign) -> bool:
        target_name = self._get_node_name(node.target)
        if not target_name:
            return True

        ann_name = self._get_node_name(node.annotation.annotation)
        if ann_name and ann_name.rsplit(".", 1)[-1] in self.symbols.defined_classes:
            self.var_class_scopes[-1][target_name] = ann_name.rsplit(".", 1)[-1]

        ann_types = self._extract_mldsa_classes(
            node.annotation.annotation, self.symbols.type_aliases
        )
        inferred = self._infer_expr_key_types(node.value)

        if inferred:
            self._add_key_types(target_name, inferred)
        elif ann_types:
            self._add_key_types(target_name, ann_types)

        if isinstance(node.value, cst.Call):
            self._register_loader_target(target_name, node.value, ann_types)

        return True

    def visit_Call(self, node: cst.Call) -> bool:
        cls_call = self._detect_pqc_class_call(node)
        if cls_call:
            variant, _, method = cls_call
            self.seen_variants.add(variant)
            self.concrete_variants.add(variant)
            if method == "generate":
                self.methods.append(
                    AdapterMethodSpec(
                        variant=variant,
                        base_name="generate_private_key",
                        params=(),
                        body=f"return mldsa.{variant}PrivateKey.generate()",
                    )
                )
            elif method == "from_seed_bytes":
                self.methods.append(
                    AdapterMethodSpec(
                        variant=variant,
                        base_name="load_private_key",
                        params=("data",),
                        body=f"return mldsa.{variant}PrivateKey.from_seed_bytes(data)",
                    )
                )
            elif method == "from_public_bytes":
                self.methods.append(
                    AdapterMethodSpec(
                        variant=variant,
                        base_name="load_public_key",
                        params=("data",),
                        body=f"return mldsa.{variant}PublicKey.from_public_bytes(data)",
                    )
                )
            return True

        if not isinstance(node.func, cst.Attribute):
            return True

        method = node.func.attr.value
        if method not in PRIVATE_KEY_METHODS and method not in PUBLIC_KEY_METHODS:
            return True

        recv_types = self._infer_expr_key_types(node.func.value)
        if not recv_types:
            recv_types = self._fallback_key_types(method, node)
        if not recv_types:
            return True

        for variant, kind in sorted(recv_types):
            if kind == "private" and method in PRIVATE_KEY_METHODS:
                if method == "public_key":
                    self.methods.append(
                        AdapterMethodSpec(
                            variant=variant,
                            base_name="get_public_key",
                            params=("private_key",),
                            body="return private_key.public_key()",
                        )
                    )
                elif method == "sign":
                    has_context = self._get_arg(node.args, "context", 1) is not None
                    if has_context:
                        self.methods.append(
                            AdapterMethodSpec(
                                variant=variant,
                                base_name="sign",
                                params=("private_key", "data", "context=None"),
                                body=(
                                    "if context is None:\n"
                                    "            return private_key.sign(data)\n"
                                    "        return private_key.sign(data, context=context)"
                                ),
                                variant_suffix="_with_context",
                            )
                        )
                    else:
                        self.methods.append(
                            AdapterMethodSpec(
                                variant=variant,
                                base_name="sign",
                                params=("private_key", "data"),
                                body="return private_key.sign(data)",
                            )
                        )
                elif method == "private_bytes":
                    self.methods.append(self._build_private_bytes_spec(variant, node))
                elif method == "private_bytes_raw":
                    self.methods.append(
                        AdapterMethodSpec(
                            variant=variant,
                            base_name="serialize_private_key",
                            params=("private_key",),
                            body="return private_key.private_bytes_raw()",
                            variant_suffix="_raw",
                            is_raw=True,
                        )
                    )

            elif kind == "public" and method in PUBLIC_KEY_METHODS:
                if method == "verify":
                    has_context = self._get_arg(node.args, "context", 2) is not None
                    if has_context:
                        self.methods.append(
                            AdapterMethodSpec(
                                variant=variant,
                                base_name="verify",
                                params=("public_key", "signature", "data", "context=None"),
                                body=(
                                    "if context is None:\n"
                                    "            return public_key.verify(signature, data)\n"
                                    "        return public_key.verify(signature, data, context=context)"
                                ),
                                variant_suffix="_with_context",
                            )
                        )
                    else:
                        self.methods.append(
                            AdapterMethodSpec(
                                variant=variant,
                                base_name="verify",
                                params=("public_key", "signature", "data"),
                                body="return public_key.verify(signature, data)",
                            )
                        )
                elif method == "public_bytes":
                    self.methods.append(self._build_public_bytes_spec(variant, node))
                elif method == "public_bytes_raw":
                    self.methods.append(
                        AdapterMethodSpec(
                            variant=variant,
                            base_name="serialize_public_key",
                            params=("public_key",),
                            body="return public_key.public_bytes_raw()",
                            variant_suffix="_raw",
                            is_raw=True,
                        )
                    )

        return True

    def finalize_pending_loaders(self) -> None:
        variant = self._single_variant()
        if not variant or not self.pending_loaders:
            return
        for loader_name, has_password in self.pending_loaders:
            self.methods.append(
                self._build_loader_spec(variant, loader_name, has_password)
            )


def generate_adapter_code(extractor: PQCDSCallExtractor) -> str:
    extractor.finalize_pending_loaders()
    if not extractor.methods:
        return ""

    variant_methods: dict[str, list[AdapterMethodSpec]] = {}
    seen_specs: set[tuple[str, str, tuple[str, ...], str]] = set()

    for spec in extractor.methods:
        dedup_key = (spec.variant, spec.base_name, spec.params, spec.body)
        if dedup_key in seen_specs:
            continue
        seen_specs.add(dedup_key)
        variant_methods.setdefault(spec.variant, []).append(spec)

    if extractor.concrete_variants:
        variant_methods = {
            v: specs
            for v, specs in variant_methods.items()
            if v in extractor.concrete_variants
        }

    if not variant_methods:
        return ""

    needs_serialization = any(
        spec.uses_serialization
        for specs in variant_methods.values()
        for spec in specs
    )

    imports = []
    if needs_serialization:
        imports.append("from cryptography.hazmat.primitives import serialization")
    imports.append("from cryptography.hazmat.primitives.asymmetric import mldsa")

    blocks = ["\n".join(imports) + "\n"]

    for variant in sorted(variant_methods):
        specs = variant_methods[variant]
        base_names = {s.base_name for s in specs}

        if "load_private_key" in base_names:
            specs.sort(
                key=lambda s: 0 if (s.base_name == "serialize_private_key" and s.is_raw) else 1
            )
        if "load_public_key" in base_names:
            specs.sort(
                key=lambda s: 0 if (s.base_name == "serialize_public_key" and s.is_raw) else 1
            )

        used_names: set[str] = set()
        method_defs = []

        for spec in specs:
            method_name = spec.base_name
            if method_name in used_names:
                candidate = f"{spec.base_name}{spec.variant_suffix}"
                if candidate not in used_names:
                    method_name = candidate
                else:
                    idx = 2
                    while f"{candidate}_{idx}" in used_names:
                        idx += 1
                    method_name = f"{candidate}_{idx}"
            used_names.add(method_name)

            params_str = ", ".join(("self", *spec.params))
            method_defs.append(
                f"    def {method_name}({params_str}):\n"
                f"        {spec.body}\n"
            )

        class_block = f"class {variant}Adapter:\n\n" + "\n".join(method_defs)
        blocks.append(class_block)

    return "\n\n".join(blocks).rstrip() + "\n"


def generate_adapter(source_code: str) -> str:
    module = cst.parse_module(source_code)
    wrapper = MetadataWrapper(module)

    collector = _PQCSymbolCollector()
    for _ in range(3):
        wrapper.visit(collector)

    extractor = PQCDSCallExtractor(collector)
    wrapper.visit(extractor)
    return generate_adapter_code(extractor)


def process_files(input_folder: str | Path, output_folder: str | Path) -> None:
    input_folder = Path(input_folder)
    output_folder = Path(output_folder)
    output_folder.mkdir(parents=True, exist_ok=True)

    for file_path in sorted(input_folder.glob("*.py")):
        print(f"\nProcessing: {file_path.name}")
        try:
            src = file_path.read_text(encoding="utf-8")
            modified_code = generate_adapter(src)
            if not modified_code:
                print("  No PQC ML-DSA usage found - adapter classes not created")
                continue

            output_file = output_folder / f"{file_path.stem}.py"
            output_file.write_text(modified_code, encoding="utf-8")
            print(f"  Created: {output_file}")
        except Exception as e:
            print(f"  ERROR processing {file_path.name}: {e}")


if __name__ == "__main__":
    process_files("../testing/output", "./adapter/target")