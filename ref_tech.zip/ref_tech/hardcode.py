import ast
from collections import defaultdict


class HardcodedValues(ast.NodeTransformer):

    SUPPORTED_TYPES = (str, int)

    def _collect_from_call(self, call, collected):
        for arg in call.args:
            if isinstance(arg, ast.Constant) and isinstance(arg.value, self.SUPPORTED_TYPES):
                collected["p"].add(arg.value)

        for kw in call.keywords:
            if (
                isinstance(kw.value, ast.Constant)
                and isinstance(kw.value.value, self.SUPPORTED_TYPES)
            ):
                collected["p"].add(kw.value.value)

    def _build_vars_and_map(self, node):
        raw = defaultdict(set)

        for sub in ast.walk(node):
            if isinstance(sub, ast.Call):
                self._collect_from_call(sub, raw)

        var_list = []
        counters = defaultdict(int)

        for lit in raw["p"]:
            idx = counters["p"]
            counters["p"] += 1
            var_list.append((f"var{idx}", lit))

        literal_to_var = {lit: name for name, lit in var_list}

        assignments = [
            ast.Assign(
                targets=[ast.Name(id=name, ctx=ast.Store())],
                value=ast.Constant(value=lit),
            )
            for name, lit in var_list
        ]

        for a in assignments:
            ast.fix_missing_locations(a)

        return assignments, literal_to_var

    class _Replacer(ast.NodeTransformer):
        def __init__(self, literal_to_var):
            self.l2v = literal_to_var

        def visit_Call(self, node):
            self.generic_visit(node)

            node.args = [
                ast.Name(id=self.l2v[arg.value], ctx=ast.Load())
                if (
                    isinstance(arg, ast.Constant)
                    and arg.value in self.l2v
                )
                else arg
                for arg in node.args
            ]

            node.keywords = [
                ast.keyword(
                    arg=kw.arg,
                    value=ast.Name(id=self.l2v[kw.value.value], ctx=ast.Load()),
                )
                if (
                    isinstance(kw.value, ast.Constant)
                    and kw.value.value in self.l2v
                )
                else kw
                for kw in node.keywords
            ]

            return node

    def _inject(self, node):
        assignments, literal_to_var = self._build_vars_and_map(node)

        if assignments:
            node.body[0:0] = assignments

        if literal_to_var:
            self._Replacer(literal_to_var).visit(node)

    def refactor(self, tree):
        self._inject(tree)

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                self._inject(node)

        return ast.unparse(tree)

    def get_refactored_code(self, source_code):
        try:
            tree = ast.parse(source_code)
            return self.refactor(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")
