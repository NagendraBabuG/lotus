from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding


class RSAAdapter:

    def load_private_key_pem(self, data):
        return serialization.load_pem_private_key(data, password=None)

    def serialize_private_key(self, private_key):
        return private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )

    def serialize_public_key(self, public_key):
        return public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )

    def get_public_key(self, private_key):
        return private_key.public_key()

    def verify(self, public_key, signature, data):
        return public_key.verify(signature, data, padding.PKCS1v15(), hashes.SHA256())
