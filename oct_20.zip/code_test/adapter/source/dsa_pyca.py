from cryptography.hazmat.primitives.asymmetric import dsa

class DSAAdapter:

    def generate_private_key(self, key_size, openssl_backend):
        return dsa.generate_private_key(key_size, openssl_backend)

    def get_public_key(self, private_key):
        return private_key.public_key()

    def sign(self, private_key, m, param_hash):
        return private_key.sign(m, param_hash)

    def verify(self, public_key, signature, m, param_hash):
        return public_key.verify(signature, m, param_hash)

