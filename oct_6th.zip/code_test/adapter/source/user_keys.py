import io
import logging
import os
import re
import tempfile
import paramiko
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

class Ed25519Adapter:

    def generate_private_key(self):
        return Ed25519PrivateKey.generate()

    def serialize_private_key(self, crypto_key):
        return crypto_key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.OpenSSH, serialization.NoEncryption())

    def decode(self, pem):
        return pem.decode()

