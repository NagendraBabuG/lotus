from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa


class RSAAdapter:

    def generate_private_key(self):
        return rsa.generate_private_key(public_exponent=65537, key_size=2048)

    def get_public_key(self, private_key):
        return private_key.public_key()

    def load_private_key_pem(self, data):
        return serialization.load_pem_private_key(data, password=None)
