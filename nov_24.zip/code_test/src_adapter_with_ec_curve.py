from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import libcst as cst
from libcst.metadata import MetadataWrapper, QualifiedNameProvider


CLASSICAL_PRIV_CLASSES = {
    "Ed25519PrivateKey": "Ed25519",
    "Ed448PrivateKey": "Ed448",
    "RSAPrivateKey": "RSA",
    "EllipticCurvePrivateKey": "EC",
    "DSAPrivateKey": "DSA",
}

CLASSICAL_PUB_CLASSES = {
    "Ed25519PublicKey": "Ed25519",
    "Ed448PublicKey": "Ed448",
    "RSAPublicKey": "RSA",
    "EllipticCurvePublicKey": "EC",
    "DSAPublicKey": "DSA",
}

MODULE_GENERATORS = {
    "rsa": "RSA",
    "dsa": "DSA",
    "ec": "EC",
}

CLASS_METHODS = {
    "generate",
    "generate_private_key",
    "from_private_bytes",
    "from_public_bytes",
    "from_encoded_point",
}

PRIVATE_KEY_METHODS = {
    "public_key",
    "sign",
    "private_bytes",
    "private_bytes_raw",
}

PUBLIC_KEY_METHODS = {
    "verify",
    "public_bytes",
    "public_bytes_raw",
}

NON_DS_METHODS = {
    "exchange",
    "encrypt",
    "decrypt",
}

SERIALIZATION_LOADERS = {
    "load_pem_private_key": ("private", "pem"),
    "load_der_private_key": ("private", "der"),
    "load_pem_public_key": ("public", "pem"),
    "load_der_public_key": ("public", "der"),
}

X509_SYMBOLS = {
    "CertificateBuilder",
    "CertificateSigningRequestBuilder",
    "CertificateRevocationListBuilder",
    "OCSPResponseBuilder",
    "load_pem_x509_certificate",
    "load_der_x509_certificate",
    "load_pem_x509_csr",
    "load_der_x509_csr",
    "load_pem_x509_crl",
    "load_der_x509_crl",
}

X509_VAR_NAMES = {"cert", "certificate", "csr", "crl", "builder", "x509_cert"}

EC_CURVE_PREFIXES = ("SECP", "SECT", "BrainpoolP")

VALID_HASHES = {
    "SHA224",
    "SHA256",
    "SHA384",
    "SHA512",
    "SHA512_224",
    "SHA512_256",
    "SHA3_224",
    "SHA3_256",
    "SHA3_384",
    "SHA3_512",
    "SHA1",
    "BLAKE2b",
    "BLAKE2s",
}

VALID_ENCODINGS = {"PEM", "DER", "Raw", "OpenSSH", "X962"}
VALID_PRIVATE_FORMATS = {"PKCS8", "TraditionalOpenSSL", "Raw", "OpenSSH"}
VALID_PUBLIC_FORMATS = {
    "SubjectPublicKeyInfo",
    "PKCS1",
    "Raw",
    "OpenSSH",
    "UncompressedPoint",
    "CompressedPoint",
}

VALID_DSA_KEY_SIZES = {1024, 2048, 3072, 4096}

IMPORT_STATEMENTS = {
    "serialization": "from cryptography.hazmat.primitives import serialization",
    "hashes": "from cryptography.hazmat.primitives import hashes",
    "ed25519": "from cryptography.hazmat.primitives.asymmetric import ed25519",
    "ed448": "from cryptography.hazmat.primitives.asymmetric import ed448",
    "rsa": "from cryptography.hazmat.primitives.asymmetric import rsa",
    "ec": "from cryptography.hazmat.primitives.asymmetric import ec",
    "dsa": "from cryptography.hazmat.primitives.asymmetric import dsa",
    "padding": "from cryptography.hazmat.primitives.asymmetric import padding",
}


@dataclass(frozen=True)
class AdapterMethodSpec:
    variant: str
    base_name: str
    params: tuple[str, ...]
    body: str
    required_imports: frozenset[str]
    variant_suffix: str = ""
    is_raw: bool = False


class _BaseClassicalVisitor(cst.CSTVisitor):
    METADATA_DEPENDENCIES = (QualifiedNameProvider,)

    def _get_qnames(self, node: cst.CSTNode) -> set[str]:
        qnames = self.get_metadata(QualifiedNameProvider, node, default=set())
        return {q.name for q in qnames} if qnames else set()

    def _get_node_name(self, node: cst.BaseExpression | None) -> str | None:
        if node is None:
            return None
        if isinstance(node, cst.Name):
            return node.value
        if isinstance(node, cst.Attribute):
            return cst.helpers.get_full_name_for_node(node)
        return None

    def _get_arg(
        self, args: tuple[cst.Arg, ...], kw_name: str, pos_index: int
    ) -> cst.Arg | None:
        for arg in args:
            if arg.keyword is not None and arg.keyword.value == kw_name:
                return arg
        pos_args = [a for a in args if a.keyword is None]
        if 0 <= pos_index < len(pos_args):
            return pos_args[pos_index]
        return None

    def _extract_enum_leaf(self, expr: cst.BaseExpression | None) -> str | None:
        if expr is None:
            return None
        for q in self._get_qnames(expr):
            return q.rsplit(".", 1)[-1]
        name = self._get_node_name(expr)
        return name.rsplit(".", 1)[-1] if name else None

    def _extract_int_literal(self, expr: cst.BaseExpression | None) -> int | None:
        if isinstance(expr, cst.Integer):
            try:
                return int(expr.value, 0)
            except ValueError:
                return None
        return None

    def _extract_classical_class(
        self, node: cst.BaseExpression
    ) -> tuple[str, str] | None:
        candidates = {q.rsplit(".", 1)[-1] for q in self._get_qnames(node)}
        raw = self._get_node_name(node)
        if raw:
            candidates.add(raw.rsplit(".", 1)[-1])
        for name in candidates:
            if name in CLASSICAL_PRIV_CLASSES:
                return CLASSICAL_PRIV_CLASSES[name], "private"
            if name in CLASSICAL_PUB_CLASSES:
                return CLASSICAL_PUB_CLASSES[name], "public"
        return None

    def _extract_annotation_key_type(
        self, expr: cst.BaseExpression
    ) -> tuple[str, str] | None:
        direct = self._extract_classical_class(expr)
        if direct:
            return direct

        found: set[tuple[str, str]] = set()

        class _Finder(cst.CSTVisitor):
            def visit_Attribute(self, node: cst.Attribute) -> bool:
                leaf = node.attr.value
                if leaf in CLASSICAL_PRIV_CLASSES:
                    found.add((CLASSICAL_PRIV_CLASSES[leaf], "private"))
                    return False
                if leaf in CLASSICAL_PUB_CLASSES:
                    found.add((CLASSICAL_PUB_CLASSES[leaf], "public"))
                    return False
                return True

            def visit_Name(self, node: cst.Name) -> None:
                if node.value in CLASSICAL_PRIV_CLASSES:
                    found.add((CLASSICAL_PRIV_CLASSES[node.value], "private"))
                elif node.value in CLASSICAL_PUB_CLASSES:
                    found.add((CLASSICAL_PUB_CLASSES[node.value], "public"))

        expr.visit(_Finder())
        return next(iter(found)) if len(found) == 1 else None

    def _detect_classical_class_call(
        self, call: cst.Call
    ) -> tuple[str, str, str] | None:
        qnames = self._get_qnames(call.func)
        for q in qnames:
            for mod, variant in MODULE_GENERATORS.items():
                if q.endswith(f".{mod}.generate_private_key") or q == f"{mod}.generate_private_key":
                    return variant, "private", "generate_private_key"

        if not isinstance(call.func, cst.Attribute):
            return None

        method = call.func.attr.value
        if method not in CLASS_METHODS:
            return None

        if method == "generate_private_key":
            recv_name = self._get_node_name(call.func.value)
            if recv_name:
                leaf = recv_name.rsplit(".", 1)[-1]
                if leaf in MODULE_GENERATORS:
                    return MODULE_GENERATORS[leaf], "private", "generate_private_key"
            return None

        cls_info = self._extract_classical_class(call.func.value)
        if not cls_info:
            return None

        variant, kind = cls_info
        if kind == "private" and method in {"generate", "from_private_bytes"}:
            return variant, kind, method
        if kind == "public" and method in {"from_public_bytes", "from_encoded_point"}:
            return variant, kind, method
        return None

    def _detect_serialization_loader(self, call: cst.Call) -> str | None:
        for q in self._get_qnames(call.func):
            leaf = q.rsplit(".", 1)[-1]
            if leaf in SERIALIZATION_LOADERS:
                return leaf
        raw = self._get_node_name(call.func)
        if raw:
            leaf = raw.rsplit(".", 1)[-1]
            if leaf in SERIALIZATION_LOADERS:
                return leaf
        return None

    def _is_x509_call(self, expr: cst.BaseExpression) -> bool:
        curr: cst.BaseExpression | None = expr
        while curr is not None:
            if any(q.rsplit(".", 1)[-1] in X509_SYMBOLS for q in self._get_qnames(curr)):
                return True
            if isinstance(curr, cst.Call):
                if any(
                    q.rsplit(".", 1)[-1] in X509_SYMBOLS
                    for q in self._get_qnames(curr.func)
                ):
                    return True
                fname = self._get_node_name(curr.func)
                if fname and fname.rsplit(".", 1)[-1] in X509_SYMBOLS:
                    return True
                if isinstance(curr.func, cst.Attribute):
                    curr = curr.func.value
                    continue
            break
        return False

    def _extract_subscript_int(self, sub: cst.Subscript) -> int | None:
        if len(sub.slice) != 1:
            return None
        sl = sub.slice[0].slice
        if isinstance(sl, cst.Index):
            if isinstance(sl.value, cst.Integer):
                return int(sl.value.value, 0)
            if (
                isinstance(sl.value, cst.UnaryOperation)
                and isinstance(sl.value.operator, cst.Minus)
                and isinstance(sl.value.expression, cst.Integer)
            ):
                return -int(sl.value.expression.value, 0)
        return None

    def _direct_curve_name(self, expr: cst.BaseExpression | None) -> str | None:
        if expr is None:
            return None
        target = expr.func if isinstance(expr, cst.Call) else expr
        for q in self._get_qnames(target):
            leaf = q.rsplit(".", 1)[-1]
            if leaf.startswith(EC_CURVE_PREFIXES):
                return leaf
        name = self._get_node_name(target)
        if name:
            leaf = name.rsplit(".", 1)[-1]
            if leaf.startswith(EC_CURVE_PREFIXES):
                return leaf
        return None

    def _direct_hash_name(self, expr: cst.BaseExpression | None) -> str | None:
        if expr is None:
            return None
        target = expr.func if isinstance(expr, cst.Call) else expr
        for q in self._get_qnames(target):
            leaf = q.rsplit(".", 1)[-1]
            if leaf in VALID_HASHES:
                return leaf
        name = self._get_node_name(target)
        if name:
            leaf = name.rsplit(".", 1)[-1]
            if leaf in VALID_HASHES:
                return leaf
        return None


class _ClassicalSymbolCollector(_BaseClassicalVisitor):
    def __init__(self) -> None:
        self.seen_variants: set[str] = set()
        self.imported_variants: set[str] = set()
        self.class_stack: list[str] = []
        self.func_stack: list[str] = []
        self.local_scopes: list[dict[str, tuple[str, str]]] = [{}]

        self.class_attr_types: dict[tuple[str, ...], dict[str, tuple[str, str]]] = {}
        self.func_param_names: dict[tuple[tuple[str, ...], str], list[str]] = {}
        self.func_param_types: dict[
            tuple[tuple[str, ...], str], dict[str, tuple[str, str]]
        ] = {}
        self.func_return_types: dict[
            tuple[tuple[str, ...], str], tuple[tuple[str, str] | None, ...]
        ] = {}
        self.global_name_hints: dict[str, tuple[str, str] | None] = {}

        self.const_ints: dict[str, int] = {}
        self.const_curves: dict[str, str] = {}
        self.const_hashes: dict[str, str] = {}
        self.const_paddings: dict[str, str] = {}
        self.default_ec_curve: str | None = None
        self.x509_vars: set[str] = set()

    def _cur_class(self) -> tuple[str, ...]:
        return tuple(self.class_stack)

    def _cur_func_key(self) -> tuple[tuple[str, ...], str] | None:
        if not self.func_stack:
            return None
        return self._cur_class(), self.func_stack[-1]

    def _record_global_hint(self, name: str, key_type: tuple[str, str]) -> None:
        if name not in self.global_name_hints:
            self.global_name_hints[name] = key_type
        elif self.global_name_hints[name] != key_type:
            self.global_name_hints[name] = None

    def _set_key(self, name: str, variant: str, kind: str) -> None:
        key_type = (variant, kind)
        self.seen_variants.add(variant)
        self.local_scopes[-1][name] = key_type
        if name.startswith("self.") and self.class_stack:
            self.class_attr_types.setdefault(self._cur_class(), {})[name] = key_type
        elif "." not in name:
            self._record_global_hint(name, key_type)

    def _lookup_key(self, name: str | None) -> tuple[str, str] | None:
        if not name:
            return None
        for scope in reversed(self.local_scopes):
            if name in scope:
                return scope[name]
        if name.startswith("self.") and self.class_stack:
            found = self.class_attr_types.get(self._cur_class(), {}).get(name)
            if found:
                return found
        func_key = self._cur_func_key()
        if func_key and name in self.func_param_types.get(func_key, {}):
            return self.func_param_types[func_key][name]
        return None

    def _lookup_func_return(
        self, call: cst.Call
    ) -> tuple[tuple[str, str] | None, ...] | None:
        func_name = self._get_node_name(call.func)
        if not func_name:
            return None
        if func_name.startswith("self.") and self.class_stack:
            method_name = func_name.split(".", 1)[1]
            return self.func_return_types.get((self._cur_class(), method_name))
        return self.func_return_types.get(((), func_name)) or self.func_return_types.get(
            (self._cur_class(), func_name)
        )

    def _resolve_curve(self, expr: cst.BaseExpression | None) -> str | None:
        curve = self._direct_curve_name(expr)
        if curve:
            return curve
        name = self._get_node_name(expr)
        if name and name in self.const_curves:
            return self.const_curves[name]
        return None

    def _resolve_hash(self, expr: cst.BaseExpression | None) -> str | None:
        h = self._direct_hash_name(expr)
        if h:
            return h
        name = self._get_node_name(expr)
        if name and name in self.const_hashes:
            return self.const_hashes[name]
        return None

    def _resolve_padding_expr(self, expr: cst.BaseExpression | None) -> str | None:
        if expr is None:
            return None
        name = self._get_node_name(expr)
        if name and name in self.const_paddings:
            return self.const_paddings[name]
        if not isinstance(expr, cst.Call):
            return None

        leaf = self._extract_enum_leaf(expr.func)
        if leaf == "PKCS1v15":
            return "padding.PKCS1v15()"
        if leaf == "PSS":
            mgf_arg = self._get_arg(expr.args, "mgf", 0)
            salt_arg = self._get_arg(expr.args, "salt_length", 1)

            mgf_hash = "SHA256"
            if mgf_arg is not None and isinstance(mgf_arg.value, cst.Call):
                h_arg = self._get_arg(mgf_arg.value.args, "algorithm", 0)
                resolved_h = self._resolve_hash(h_arg.value if h_arg else None)
                if resolved_h:
                    mgf_hash = resolved_h

            salt_expr = "padding.PSS.MAX_LENGTH"
            if salt_arg is not None:
                salt_int = self._extract_int_literal(salt_arg.value)
                if salt_int is not None:
                    salt_expr = str(salt_int)
                else:
                    salt_leaf = self._extract_enum_leaf(salt_arg.value)
                    if salt_leaf in {"MAX_LENGTH", "AUTO", "DIGEST_LENGTH"}:
                        salt_expr = f"padding.PSS.{salt_leaf}"

            return (
                f"padding.PSS(mgf=padding.MGF1(hashes.{mgf_hash}()), "
                f"salt_length={salt_expr})"
            )
        return None

    def _record_const(self, name: str, value: cst.BaseExpression | None) -> None:
        if value is None:
            return
        int_val = self._extract_int_literal(value)
        if int_val is not None:
            self.const_ints[name] = int_val
            return

        curve = self._resolve_curve(value)
        if curve:
            self.const_curves[name] = curve
            if self.default_ec_curve is None:
                self.default_ec_curve = curve
            return

        h = self._resolve_hash(value)
        if h:
            self.const_hashes[name] = h
            return

        pad = self._resolve_padding_expr(value)
        if pad:
            self.const_paddings[name] = pad
            return

        ref_name = self._get_node_name(value)
        if ref_name and ref_name in self.const_ints:
            self.const_ints[name] = self.const_ints[ref_name]

    def _infer_expr(self, expr: cst.BaseExpression | None) -> tuple[str, str] | None:
        if expr is None:
            return None

        name = self._get_node_name(expr)
        if name:
            found = self._lookup_key(name)
            if found:
                return found

        if isinstance(expr, cst.Subscript) and isinstance(expr.value, cst.Call):
            idx = self._extract_subscript_int(expr)
            ret_types = self._lookup_func_return(expr.value)
            if idx is not None and ret_types and -len(ret_types) <= idx < len(ret_types):
                return ret_types[idx]

        if not isinstance(expr, cst.Call):
            return None

        cls_call = self._detect_classical_class_call(expr)
        if cls_call:
            self.seen_variants.add(cls_call[0])
            return cls_call[0], cls_call[1]

        if isinstance(expr.func, cst.Attribute) and expr.func.attr.value == "public_key":
            recv_type = self._infer_expr(expr.func.value)
            if recv_type and recv_type[1] == "private":
                return recv_type[0], "public"

        ret_types = self._lookup_func_return(expr)
        if ret_types and len(ret_types) == 1:
            return ret_types[0]

        return None

    def visit_ImportFrom(self, node: cst.ImportFrom) -> bool:
        if isinstance(node.names, cst.ImportStar):
            return False
        for alias in node.names:
            iname = alias.name.value
            if iname in CLASSICAL_PRIV_CLASSES:
                self.imported_variants.add(CLASSICAL_PRIV_CLASSES[iname])
            elif iname in CLASSICAL_PUB_CLASSES:
                self.imported_variants.add(CLASSICAL_PUB_CLASSES[iname])
            elif iname == "ed25519":
                self.imported_variants.add("Ed25519")
            elif iname == "ed448":
                self.imported_variants.add("Ed448")
            elif iname in MODULE_GENERATORS:
                self.imported_variants.add(MODULE_GENERATORS[iname])
        return False

    def visit_ClassDef(self, node: cst.ClassDef) -> bool:
        self.class_stack.append(node.name.value)
        self.local_scopes.append({})
        return True

    def leave_ClassDef(self, original_node: cst.ClassDef) -> None:
        self.local_scopes.pop()
        self.class_stack.pop()

    def visit_FunctionDef(self, node: cst.FunctionDef) -> bool:
        self.func_stack.append(node.name.value)
        self.local_scopes.append({})
        func_key = (self._cur_class(), node.name.value)

        all_params = (
            list(node.params.posonly_params)
            + list(node.params.params)
            + list(node.params.kwonly_params)
        )
        param_names: list[str] = []
        for idx, param in enumerate(all_params):
            pname = param.name.value
            if idx == 0 and self.class_stack and pname in {"self", "cls"}:
                continue
            param_names.append(pname)
            if param.default is not None:
                self._record_const(pname, param.default)
            if param.annotation is not None:
                ann_type = self._extract_annotation_key_type(param.annotation.annotation)
                if ann_type:
                    self._set_key(pname, ann_type[0], ann_type[1])
                    self.func_param_types.setdefault(func_key, {})[pname] = ann_type

        self.func_param_names[func_key] = param_names

        for pname, ptype in self.func_param_types.get(func_key, {}).items():
            self.local_scopes[-1][pname] = ptype

        if node.returns is not None:
            ret_ann = self._extract_annotation_key_type(node.returns.annotation)
            if ret_ann:
                self.seen_variants.add(ret_ann[0])
                self.func_return_types[func_key] = (ret_ann,)

        return True

    def leave_FunctionDef(self, original_node: cst.FunctionDef) -> None:
        self.local_scopes.pop()
        self.func_stack.pop()

    def visit_Return(self, node: cst.Return) -> bool:
        func_key = self._cur_func_key()
        if not func_key or node.value is None:
            return True
        if isinstance(node.value, cst.Tuple):
            types = tuple(
                self._infer_expr(el.value) if isinstance(el, cst.Element) else None
                for el in node.value.elements
            )
            if any(t is not None for t in types):
                self.func_return_types[func_key] = types
        else:
            inferred = self._infer_expr(node.value)
            if inferred is not None:
                self.func_return_types[func_key] = (inferred,)
        return True

    def visit_Assign(self, node: cst.Assign) -> bool:
        if len(node.targets) != 1:
            return True
        target = node.targets[0].target

        if isinstance(target, (cst.Tuple, cst.List)) and isinstance(node.value, cst.Call):
            ret_types = self._lookup_func_return(node.value)
            if ret_types:
                for el, rtype in zip(target.elements, ret_types):
                    if isinstance(el, cst.Element) and rtype is not None:
                        tname = self._get_node_name(el.value)
                        if tname:
                            self._set_key(tname, rtype[0], rtype[1])
            return True

        target_name = self._get_node_name(target)
        if not target_name:
            return True

        self._record_const(target_name, node.value)

        if self._is_x509_call(node.value):
            self.x509_vars.add(target_name)
            return True

        inferred = self._infer_expr(node.value)
        if inferred is not None:
            self._set_key(target_name, inferred[0], inferred[1])
            return True

        if isinstance(node.value, cst.Call):
            loader = self._detect_serialization_loader(node.value)
            if loader and len(self.seen_variants) == 1:
                kind, _ = SERIALIZATION_LOADERS[loader]
                self._set_key(target_name, next(iter(self.seen_variants)), kind)

        return True

    def visit_AnnAssign(self, node: cst.AnnAssign) -> bool:
        target_name = self._get_node_name(node.target)
        if not target_name:
            return True

        self._record_const(target_name, node.value)

        if node.value is not None and self._is_x509_call(node.value):
            self.x509_vars.add(target_name)
            return True

        ann_type = self._extract_annotation_key_type(node.annotation.annotation)
        inferred = self._infer_expr(node.value)

        if inferred is not None:
            self._set_key(target_name, inferred[0], inferred[1])
        elif ann_type is not None:
            self._set_key(target_name, ann_type[0], ann_type[1])
        elif isinstance(node.value, cst.Call):
            loader = self._detect_serialization_loader(node.value)
            if loader and len(self.seen_variants) == 1:
                kind, _ = SERIALIZATION_LOADERS[loader]
                self._set_key(target_name, next(iter(self.seen_variants)), kind)

        return True

    def visit_Call(self, node: cst.Call) -> bool:
        cls_call = self._detect_classical_class_call(node)
        if cls_call:
            variant, _, method = cls_call
            self.seen_variants.add(variant)
            if variant == "EC" and method in {"generate_private_key", "from_encoded_point"}:
                curve_arg = self._get_arg(node.args, "curve", 0)
                curve = self._resolve_curve(curve_arg.value if curve_arg else None)
                if curve and self.default_ec_curve is None:
                    self.default_ec_curve = curve
            return True

        if (
            isinstance(node.func, cst.Name)
            and node.func.value == "isinstance"
            and len(node.args) >= 2
        ):
            var_name = self._get_node_name(node.args[0].value)
            cls_info = self._extract_classical_class(node.args[1].value)
            if var_name and cls_info:
                self._set_key(var_name, cls_info[0], cls_info[1])
                func_key = self._cur_func_key()
                if func_key and var_name in self.func_param_names.get(func_key, []):
                    self.func_param_types.setdefault(func_key, {})[var_name] = cls_info
            return True

        func_name = self._get_node_name(node.func)
        if not func_name:
            return True

        callee_key: tuple[tuple[str, ...], str] | None = None
        if func_name.startswith("self.") and self.class_stack:
            candidate = (self._cur_class(), func_name.split(".", 1)[1])
            if candidate in self.func_param_names:
                callee_key = candidate
        elif ((), func_name) in self.func_param_names:
            callee_key = ((), func_name)
        elif (self._cur_class(), func_name) in self.func_param_names:
            callee_key = (self._cur_class(), func_name)

        if callee_key is not None:
            param_names = self.func_param_names[callee_key]
            pos_idx = 0
            for arg in node.args:
                arg_type = self._infer_expr(arg.value)
                if arg.keyword is not None:
                    pname = arg.keyword.value
                    if arg_type and pname in param_names:
                        self.func_param_types.setdefault(callee_key, {})[pname] = arg_type
                else:
                    if arg_type and pos_idx < len(param_names):
                        pname = param_names[pos_idx]
                        self.func_param_types.setdefault(callee_key, {})[pname] = arg_type
                    pos_idx += 1

        return True


class ClassicalDSCallExtractor(_BaseClassicalVisitor):
    def __init__(self, symbols: _ClassicalSymbolCollector) -> None:
        self.symbols = symbols
        self.seen_variants = (
            set(symbols.seen_variants)
            if symbols.seen_variants
            else set(symbols.imported_variants)
        )
        self.class_stack: list[str] = []
        self.func_stack: list[str] = []
        self.key_scopes: list[dict[str, tuple[str, str]]] = [{}]

        self.methods: list[AdapterMethodSpec] = []
        self.pending_loaders: list[tuple[str, bool]] = []

    def _cur_class(self) -> tuple[str, ...]:
        return tuple(self.class_stack)

    def _single_variant(self) -> str | None:
        return next(iter(self.seen_variants)) if len(self.seen_variants) == 1 else None

    def _set_key(self, name: str, variant: str, kind: str) -> None:
        self.key_scopes[-1][name] = (variant, kind)
        self.seen_variants.add(variant)

    def _get_key(self, name: str | None) -> tuple[str, str] | None:
        if not name:
            return None
        for scope in reversed(self.key_scopes):
            if name in scope:
                return scope[name]
        if name.startswith("self.") and self.class_stack:
            found = self.symbols.class_attr_types.get(self._cur_class(), {}).get(name)
            if found:
                return found
        if self.func_stack:
            func_key = (self._cur_class(), self.func_stack[-1])
            found = self.symbols.func_param_types.get(func_key, {}).get(name)
            if found:
                return found
        return self.symbols.global_name_hints.get(name)

    def _lookup_func_return(
        self, call: cst.Call
    ) -> tuple[tuple[str, str] | None, ...] | None:
        func_name = self._get_node_name(call.func)
        if not func_name:
            return None
        if func_name.startswith("self.") and self.class_stack:
            return self.symbols.func_return_types.get(
                (self._cur_class(), func_name.split(".", 1)[1])
            )
        return self.symbols.func_return_types.get(
            ((), func_name)
        ) or self.symbols.func_return_types.get((self._cur_class(), func_name))

    def _is_x509_receiver(self, expr: cst.BaseExpression) -> bool:
        if self._is_x509_call(expr):
            return True
        name = self._get_node_name(expr)
        if name:
            if name in self.symbols.x509_vars:
                return True
            if name.rsplit(".", 1)[-1].lower() in X509_VAR_NAMES:
                return True
        return False

    def _resolve_int(self, expr: cst.BaseExpression | None, default: int) -> int:
        val = self._extract_int_literal(expr)
        if val is not None:
            return val
        name = self._get_node_name(expr)
        if name and name in self.symbols.const_ints:
            return self.symbols.const_ints[name]
        return default

    def _resolve_curve(self, expr: cst.BaseExpression | None) -> str:
        curve = self._direct_curve_name(expr)
        if curve:
            return curve
        name = self._get_node_name(expr)
        if name and name in self.symbols.const_curves:
            return self.symbols.const_curves[name]
        return self.symbols.default_ec_curve or "SECP256R1"

    def _resolve_hash(self, expr: cst.BaseExpression | None, default: str = "SHA256") -> str:
        if expr is None:
            return default

        direct = self._direct_hash_name(expr)
        if direct:
            return direct

        name = self._get_node_name(expr)
        if name and name in self.symbols.const_hashes:
            return self.symbols.const_hashes[name]

        if isinstance(expr, cst.Call):
            leaf = self._extract_enum_leaf(expr.func)
            if leaf in {"Prehashed", "ECDSA"} and expr.args:
                return self._resolve_hash(expr.args[0].value, default=default)

        return default

    def _resolve_rsa_padding(
        self, expr: cst.BaseExpression | None, fallback_hash: str
    ) -> str:
        if expr is None:
            return (
                f"padding.PSS(mgf=padding.MGF1(hashes.{fallback_hash}()), "
                "salt_length=padding.PSS.MAX_LENGTH)"
            )

        name = self._get_node_name(expr)
        if name and name in self.symbols.const_paddings:
            return self.symbols.const_paddings[name]

        if isinstance(expr, cst.Call):
            leaf = self._extract_enum_leaf(expr.func)
            if leaf == "PKCS1v15":
                return "padding.PKCS1v15()"
            if leaf == "PSS":
                mgf_arg = self._get_arg(expr.args, "mgf", 0)
                salt_arg = self._get_arg(expr.args, "salt_length", 1)

                mgf_hash = fallback_hash
                if mgf_arg is not None and isinstance(mgf_arg.value, cst.Call):
                    h_arg = self._get_arg(mgf_arg.value.args, "algorithm", 0)
                    mgf_hash = self._resolve_hash(
                        h_arg.value if h_arg else None, default=fallback_hash
                    )

                salt_expr = "padding.PSS.MAX_LENGTH"
                if salt_arg is not None:
                    salt_int = self._extract_int_literal(salt_arg.value)
                    if salt_int is not None:
                        salt_expr = str(salt_int)
                    else:
                        salt_leaf = self._extract_enum_leaf(salt_arg.value)
                        if salt_leaf in {"MAX_LENGTH", "AUTO", "DIGEST_LENGTH"}:
                            salt_expr = f"padding.PSS.{salt_leaf}"

                return (
                    f"padding.PSS(mgf=padding.MGF1(hashes.{mgf_hash}()), "
                    f"salt_length={salt_expr})"
                )

        return (
            f"padding.PSS(mgf=padding.MGF1(hashes.{fallback_hash}()), "
            "salt_length=padding.PSS.MAX_LENGTH)"
        )

    def _infer_expr_key_type(
        self, expr: cst.BaseExpression | None
    ) -> tuple[str, str] | None:
        if expr is None:
            return None

        name = self._get_node_name(expr)
        if name:
            tracked = self._get_key(name)
            if tracked:
                return tracked

        if isinstance(expr, cst.Subscript) and isinstance(expr.value, cst.Call):
            idx = self._extract_subscript_int(expr)
            ret_types = self._lookup_func_return(expr.value)
            if idx is not None and ret_types and -len(ret_types) <= idx < len(ret_types):
                return ret_types[idx]

        if not isinstance(expr, cst.Call):
            return None

        cls_call = self._detect_classical_class_call(expr)
        if cls_call:
            return cls_call[0], cls_call[1]

        if isinstance(expr.func, cst.Attribute) and expr.func.attr.value == "public_key":
            recv_type = self._infer_expr_key_type(expr.func.value)
            if recv_type and recv_type[1] == "private":
                return recv_type[0], "public"

        ret_types = self._lookup_func_return(expr)
        if ret_types and len(ret_types) == 1:
            return ret_types[0]

        return None

    def _fallback_key_type(
        self, method: str, call: cst.Call
    ) -> tuple[str, str] | None:
        variant = self._single_variant()
        if not variant:
            return None
        if not isinstance(call.func, cst.Attribute):
            return None
        if self._is_x509_receiver(call.func.value):
            return None

        kw_names = {a.keyword.value for a in call.args if a.keyword is not None}

        if method == "public_key" and len(call.args) == 0:
            return variant, "private"
        if method == "private_bytes_raw" and len(call.args) == 0:
            return variant, "private"
        if method == "private_bytes" and len(call.args) >= 3:
            return variant, "private"
        if method == "public_bytes_raw" and len(call.args) == 0:
            return variant, "public"
        if method == "public_bytes" and len(call.args) >= 2:
            return variant, "public"
        if method == "sign" and not (kw_names & {"private_key", "rsa_padding"}):
            if variant in {"Ed25519", "Ed448"} and len(call.args) == 1:
                return variant, "private"
            if variant in {"EC", "DSA"} and len(call.args) == 2:
                return variant, "private"
            if variant == "RSA" and len(call.args) == 3:
                return variant, "private"
        if method == "verify":
            if variant in {"Ed25519", "Ed448"} and len(call.args) == 2:
                return variant, "public"
            if variant in {"EC", "DSA"} and len(call.args) == 3:
                return variant, "public"
            if variant == "RSA" and len(call.args) == 4:
                return variant, "public"

        return None

    def _build_generate_spec(
        self, variant: str, call: cst.Call
    ) -> AdapterMethodSpec:
        if variant == "Ed25519":
            return AdapterMethodSpec(
                variant="Ed25519",
                base_name="generate_private_key",
                params=(),
                body="return ed25519.Ed25519PrivateKey.generate()",
                required_imports=frozenset({"ed25519"}),
            )
        if variant == "Ed448":
            return AdapterMethodSpec(
                variant="Ed448",
                base_name="generate_private_key",
                params=(),
                body="return ed448.Ed448PrivateKey.generate()",
                required_imports=frozenset({"ed448"}),
            )
        if variant == "RSA":
            exp_arg = self._get_arg(call.args, "public_exponent", 0)
            size_arg = self._get_arg(call.args, "key_size", 1)
            pub_exp = self._resolve_int(exp_arg.value if exp_arg else None, 65537)
            if pub_exp < 3 or pub_exp % 2 == 0:
                pub_exp = 65537
            key_size = self._resolve_int(size_arg.value if size_arg else None, 2048)
            if key_size < 512:
                key_size = 2048
            return AdapterMethodSpec(
                variant="RSA",
                base_name="generate_private_key",
                params=(),
                body=(
                    f"return rsa.generate_private_key("
                    f"public_exponent={pub_exp}, key_size={key_size})"
                ),
                required_imports=frozenset({"rsa"}),
            )
        if variant == "DSA":
            size_arg = self._get_arg(call.args, "key_size", 0)
            key_size = self._resolve_int(size_arg.value if size_arg else None, 2048)
            if key_size not in VALID_DSA_KEY_SIZES:
                key_size = 2048
            return AdapterMethodSpec(
                variant="DSA",
                base_name="generate_private_key",
                params=(),
                body=f"return dsa.generate_private_key(key_size={key_size})",
                required_imports=frozenset({"dsa"}),
            )
        curve_arg = self._get_arg(call.args, "curve", 0)
        curve = self._resolve_curve(curve_arg.value if curve_arg else None)
        return AdapterMethodSpec(
            variant="EC",
            base_name="generate_private_key",
            params=(),
            body=f"return ec.generate_private_key(ec.{curve}())",
            required_imports=frozenset({"ec"}),
        )

    def _build_sign_spec(
        self, variant: str, call: cst.Call
    ) -> AdapterMethodSpec:
        if variant in {"Ed25519", "Ed448"}:
            return AdapterMethodSpec(
                variant=variant,
                base_name="sign",
                params=("private_key", "data"),
                body="return private_key.sign(data)",
                required_imports=frozenset(),
            )
        if variant == "EC":
            alg_arg = self._get_arg(call.args, "signature_algorithm", 1)
            hash_name = self._resolve_hash(alg_arg.value if alg_arg else None)
            return AdapterMethodSpec(
                variant="EC",
                base_name="sign",
                params=("private_key", "data"),
                body=f"return private_key.sign(data, ec.ECDSA(hashes.{hash_name}()))",
                required_imports=frozenset({"ec", "hashes"}),
            )
        if variant == "DSA":
            alg_arg = self._get_arg(call.args, "algorithm", 1)
            hash_name = self._resolve_hash(alg_arg.value if alg_arg else None)
            return AdapterMethodSpec(
                variant="DSA",
                base_name="sign",
                params=("private_key", "data"),
                body=f"return private_key.sign(data, hashes.{hash_name}())",
                required_imports=frozenset({"hashes"}),
            )
        pad_arg = self._get_arg(call.args, "padding", 1)
        alg_arg = self._get_arg(call.args, "algorithm", 2)
        hash_name = self._resolve_hash(alg_arg.value if alg_arg else None)
        pad_expr = self._resolve_rsa_padding(
            pad_arg.value if pad_arg else None, fallback_hash=hash_name
        )
        return AdapterMethodSpec(
            variant="RSA",
            base_name="sign",
            params=("private_key", "data"),
            body=f"return private_key.sign(data, {pad_expr}, hashes.{hash_name}())",
            required_imports=frozenset({"padding", "hashes"}),
        )

    def _build_verify_spec(
        self, variant: str, call: cst.Call
    ) -> AdapterMethodSpec:
        if variant in {"Ed25519", "Ed448"}:
            return AdapterMethodSpec(
                variant=variant,
                base_name="verify",
                params=("public_key", "signature", "data"),
                body="return public_key.verify(signature, data)",
                required_imports=frozenset(),
            )
        if variant == "EC":
            alg_arg = self._get_arg(call.args, "signature_algorithm", 2)
            hash_name = self._resolve_hash(alg_arg.value if alg_arg else None)
            return AdapterMethodSpec(
                variant="EC",
                base_name="verify",
                params=("public_key", "signature", "data"),
                body=(
                    "return public_key.verify("
                    f"signature, data, ec.ECDSA(hashes.{hash_name}()))"
                ),
                required_imports=frozenset({"ec", "hashes"}),
            )
        if variant == "DSA":
            alg_arg = self._get_arg(call.args, "algorithm", 2)
            hash_name = self._resolve_hash(alg_arg.value if alg_arg else None)
            return AdapterMethodSpec(
                variant="DSA",
                base_name="verify",
                params=("public_key", "signature", "data"),
                body=f"return public_key.verify(signature, data, hashes.{hash_name}())",
                required_imports=frozenset({"hashes"}),
            )
        pad_arg = self._get_arg(call.args, "padding", 2)
        alg_arg = self._get_arg(call.args, "algorithm", 3)
        hash_name = self._resolve_hash(alg_arg.value if alg_arg else None)
        pad_expr = self._resolve_rsa_padding(
            pad_arg.value if pad_arg else None, fallback_hash=hash_name
        )
        return AdapterMethodSpec(
            variant="RSA",
            base_name="verify",
            params=("public_key", "signature", "data"),
            body=(
                "return public_key.verify("
                f"signature, data, {pad_expr}, hashes.{hash_name}())"
            ),
            required_imports=frozenset({"padding", "hashes"}),
        )

    def _build_private_bytes_spec(
        self, variant: str, call: cst.Call
    ) -> AdapterMethodSpec:
        enc_arg = self._get_arg(call.args, "encoding", 0)
        fmt_arg = self._get_arg(call.args, "format", 1)
        alg_arg = self._get_arg(call.args, "encryption_algorithm", 2)

        enc_leaf = self._extract_enum_leaf(enc_arg.value if enc_arg else None)
        fmt_leaf = self._extract_enum_leaf(fmt_arg.value if fmt_arg else None)

        enc_is_dynamic = (
            enc_arg is not None
            and enc_leaf not in VALID_ENCODINGS
            and isinstance(enc_arg.value, cst.Name)
        )
        fmt_is_dynamic = (
            fmt_arg is not None
            and fmt_leaf not in VALID_PRIVATE_FORMATS
            and isinstance(fmt_arg.value, cst.Name)
        )

        enc = enc_leaf if enc_leaf in VALID_ENCODINGS and enc_leaf != "X962" else "PEM"
        if enc == "Raw":
            if variant in {"Ed25519", "Ed448"}:
                fmt = "Raw"
            else:
                enc = "PEM"
                fmt = "PKCS8"
        elif enc == "OpenSSH":
            fmt = "OpenSSH"
        elif fmt_leaf in {"PKCS8", "TraditionalOpenSSL"}:
            fmt = fmt_leaf
        else:
            fmt = "PKCS8"

        params: list[str] = ["private_key"]
        if enc_is_dynamic:
            params.append(f"encoding=serialization.Encoding.{enc}")
            enc_expr = "encoding"
        else:
            enc_expr = f"serialization.Encoding.{enc}"

        if fmt_is_dynamic:
            params.append(f"format=serialization.PrivateFormat.{fmt}")
            fmt_expr = "format"
        else:
            fmt_expr = f"serialization.PrivateFormat.{fmt}"

        use_password = False
        alg_is_dynamic = False
        if enc != "Raw" and alg_arg is not None:
            if isinstance(alg_arg.value, cst.Call):
                if self._extract_enum_leaf(alg_arg.value.func) == "BestAvailableEncryption":
                    use_password = True
            elif isinstance(alg_arg.value, cst.Name):
                alg_is_dynamic = True

        if use_password:
            params.append("password=None")
            alg_expr = (
                "serialization.BestAvailableEncryption(password) "
                "if password is not None else serialization.NoEncryption()"
            )
        elif alg_is_dynamic:
            params.append("encryption_algorithm=None")
            alg_expr = (
                "encryption_algorithm if encryption_algorithm is not None "
                "else serialization.NoEncryption()"
            )
        else:
            alg_expr = "serialization.NoEncryption()"

        body = (
            "return private_key.private_bytes(\n"
            f"            encoding={enc_expr},\n"
            f"            format={fmt_expr},\n"
            f"            encryption_algorithm={alg_expr},\n"
            "        )"
        )
        suffix = f"_{enc.lower()}" + ("_encrypted" if use_password else "")
        return AdapterMethodSpec(
            variant=variant,
            base_name="serialize_private_key",
            params=tuple(params),
            body=body,
            required_imports=frozenset({"serialization"}),
            variant_suffix=suffix,
            is_raw=(enc == "Raw" and not enc_is_dynamic),
        )

    def _build_public_bytes_spec(
        self, variant: str, call: cst.Call
    ) -> AdapterMethodSpec:
        enc_arg = self._get_arg(call.args, "encoding", 0)
        fmt_arg = self._get_arg(call.args, "format", 1)

        enc_leaf = self._extract_enum_leaf(enc_arg.value if enc_arg else None)
        fmt_leaf = self._extract_enum_leaf(fmt_arg.value if fmt_arg else None)

        enc_is_dynamic = (
            enc_arg is not None
            and enc_leaf not in VALID_ENCODINGS
            and isinstance(enc_arg.value, cst.Name)
        )
        fmt_is_dynamic = (
            fmt_arg is not None
            and fmt_leaf not in VALID_PUBLIC_FORMATS
            and isinstance(fmt_arg.value, cst.Name)
        )

        enc = enc_leaf if enc_leaf in VALID_ENCODINGS else "PEM"
        if enc == "Raw":
            if variant in {"Ed25519", "Ed448"}:
                fmt = "Raw"
            else:
                enc = "PEM"
                fmt = "SubjectPublicKeyInfo"
        elif enc == "X962":
            if variant == "EC":
                fmt = (
                    fmt_leaf
                    if fmt_leaf in {"UncompressedPoint", "CompressedPoint"}
                    else "UncompressedPoint"
                )
            else:
                enc = "PEM"
                fmt = "SubjectPublicKeyInfo"
        elif enc == "OpenSSH":
            fmt = "OpenSSH"
        elif fmt_leaf in {"SubjectPublicKeyInfo", "PKCS1"}:
            fmt = fmt_leaf
        else:
            fmt = "SubjectPublicKeyInfo"

        params: list[str] = ["public_key"]
        if enc_is_dynamic:
            params.append(f"encoding=serialization.Encoding.{enc}")
            enc_expr = "encoding"
        else:
            enc_expr = f"serialization.Encoding.{enc}"

        if fmt_is_dynamic:
            params.append(f"format=serialization.PublicFormat.{fmt}")
            fmt_expr = "format"
        else:
            fmt_expr = f"serialization.PublicFormat.{fmt}"

        body = (
            "return public_key.public_bytes(\n"
            f"            encoding={enc_expr},\n"
            f"            format={fmt_expr},\n"
            "        )"
        )
        return AdapterMethodSpec(
            variant=variant,
            base_name="serialize_public_key",
            params=tuple(params),
            body=body,
            required_imports=frozenset({"serialization"}),
            variant_suffix=f"_{enc.lower()}",
            is_raw=(enc in {"Raw", "X962"} and not enc_is_dynamic),
        )

    def _build_loader_spec(
        self, variant: str, loader_name: str, has_password: bool
    ) -> AdapterMethodSpec:
        kind, fmt = SERIALIZATION_LOADERS[loader_name]
        if kind == "private":
            params = ("data", "password=None") if has_password else ("data",)
            call_args = "data, password=password" if has_password else "data, password=None"
            return AdapterMethodSpec(
                variant=variant,
                base_name=f"load_private_key_{fmt}",
                params=params,
                body=f"return serialization.{loader_name}({call_args})",
                required_imports=frozenset({"serialization"}),
            )
        return AdapterMethodSpec(
            variant=variant,
            base_name=f"load_public_key_{fmt}",
            params=("data",),
            body=f"return serialization.{loader_name}(data)",
            required_imports=frozenset({"serialization"}),
        )

    def visit_ClassDef(self, node: cst.ClassDef) -> bool:
        self.class_stack.append(node.name.value)
        self.key_scopes.append({})
        return True

    def leave_ClassDef(self, original_node: cst.ClassDef) -> None:
        self.key_scopes.pop()
        self.class_stack.pop()

    def visit_FunctionDef(self, node: cst.FunctionDef) -> bool:
        self.func_stack.append(node.name.value)
        self.key_scopes.append({})
        func_key = (self._cur_class(), node.name.value)

        for pname, ptype in self.symbols.func_param_types.get(func_key, {}).items():
            self._set_key(pname, ptype[0], ptype[1])

        all_params = (
            list(node.params.posonly_params)
            + list(node.params.params)
            + list(node.params.kwonly_params)
        )
        for param in all_params:
            if param.annotation is not None:
                key_type = self._extract_annotation_key_type(param.annotation.annotation)
                if key_type:
                    self._set_key(param.name.value, key_type[0], key_type[1])
        return True

    def leave_FunctionDef(self, original_node: cst.FunctionDef) -> None:
        self.key_scopes.pop()
        self.func_stack.pop()

    def _register_loader_target(
        self,
        target_name: str,
        call: cst.Call,
        annotated_type: tuple[str, str] | None,
    ) -> None:
        loader_name = self._detect_serialization_loader(call)
        if not loader_name:
            return
        kind, _ = SERIALIZATION_LOADERS[loader_name]
        pw_arg = self._get_arg(call.args, "password", 1)
        has_password = pw_arg is not None and self._get_node_name(pw_arg.value) != "None"

        variant = annotated_type[0] if annotated_type else self._single_variant()
        if variant:
            self._set_key(target_name, variant, kind)
            self.methods.append(self._build_loader_spec(variant, loader_name, has_password))
        else:
            self.pending_loaders.append((loader_name, has_password))

    def visit_Assign(self, node: cst.Assign) -> bool:
        if len(node.targets) != 1:
            return True
        target = node.targets[0].target

        if isinstance(target, (cst.Tuple, cst.List)) and isinstance(node.value, cst.Call):
            ret_types = self._lookup_func_return(node.value)
            if ret_types:
                for el, rtype in zip(target.elements, ret_types):
                    if isinstance(el, cst.Element) and rtype is not None:
                        tname = self._get_node_name(el.value)
                        if tname:
                            self._set_key(tname, rtype[0], rtype[1])
            return True

        target_name = self._get_node_name(target)
        if not target_name:
            return True

        inferred = self._infer_expr_key_type(node.value)
        if inferred is not None:
            self._set_key(target_name, inferred[0], inferred[1])
            return True

        if isinstance(node.value, cst.Call):
            self._register_loader_target(target_name, node.value, None)

        return True

    def visit_AnnAssign(self, node: cst.AnnAssign) -> bool:
        target_name = self._get_node_name(node.target)
        if not target_name:
            return True

        ann_type = self._extract_annotation_key_type(node.annotation.annotation)
        inferred = self._infer_expr_key_type(node.value)

        if inferred is not None:
            self._set_key(target_name, inferred[0], inferred[1])
        elif ann_type is not None:
            self._set_key(target_name, ann_type[0], ann_type[1])

        if isinstance(node.value, cst.Call):
            self._register_loader_target(target_name, node.value, ann_type)

        return True

    def visit_Call(self, node: cst.Call) -> bool:
        cls_call = self._detect_classical_class_call(node)
        if cls_call:
            variant, _, method = cls_call
            self.seen_variants.add(variant)
            if method in {"generate", "generate_private_key"}:
                self.methods.append(self._build_generate_spec(variant, node))
            elif method == "from_private_bytes":
                mod = variant.lower()
                self.methods.append(
                    AdapterMethodSpec(
                        variant=variant,
                        base_name="load_private_key",
                        params=("data",),
                        body=f"return {mod}.{variant}PrivateKey.from_private_bytes(data)",
                        required_imports=frozenset({mod}),
                    )
                )
            elif method == "from_public_bytes":
                mod = variant.lower()
                self.methods.append(
                    AdapterMethodSpec(
                        variant=variant,
                        base_name="load_public_key",
                        params=("data",),
                        body=f"return {mod}.{variant}PublicKey.from_public_bytes(data)",
                        required_imports=frozenset({mod}),
                    )
                )
            elif method == "from_encoded_point" and variant == "EC":
                curve_arg = self._get_arg(node.args, "curve", 0)
                curve = self._resolve_curve(curve_arg.value if curve_arg else None)
                self.methods.append(
                    AdapterMethodSpec(
                        variant="EC",
                        base_name="load_public_key",
                        params=("data",),
                        body=(
                            f"return ec.EllipticCurvePublicKey.from_encoded_point("
                            f"ec.{curve}(), data)"
                        ),
                        required_imports=frozenset({"ec"}),
                    )
                )
            return True

        if not isinstance(node.func, cst.Attribute):
            return True

        method = node.func.attr.value
        if method in NON_DS_METHODS:
            return True
        if method not in PRIVATE_KEY_METHODS and method not in PUBLIC_KEY_METHODS:
            return True

        recv_type = self._infer_expr_key_type(node.func.value)
        if not recv_type:
            recv_type = self._fallback_key_type(method, node)
        if not recv_type:
            return True

        variant, kind = recv_type

        if kind == "private" and method in PRIVATE_KEY_METHODS:
            if method == "public_key":
                self.methods.append(
                    AdapterMethodSpec(
                        variant=variant,
                        base_name="get_public_key",
                        params=("private_key",),
                        body="return private_key.public_key()",
                        required_imports=frozenset(),
                    )
                )
            elif method == "sign":
                self.methods.append(self._build_sign_spec(variant, node))
            elif method == "private_bytes":
                self.methods.append(self._build_private_bytes_spec(variant, node))
            elif method == "private_bytes_raw":
                self.methods.append(
                    AdapterMethodSpec(
                        variant=variant,
                        base_name="serialize_private_key",
                        params=("private_key",),
                        body="return private_key.private_bytes_raw()",
                        required_imports=frozenset(),
                        variant_suffix="_raw",
                        is_raw=True,
                    )
                )

        elif kind == "public" and method in PUBLIC_KEY_METHODS:
            if method == "verify":
                self.methods.append(self._build_verify_spec(variant, node))
            elif method == "public_bytes":
                self.methods.append(self._build_public_bytes_spec(variant, node))
            elif method == "public_bytes_raw":
                self.methods.append(
                    AdapterMethodSpec(
                        variant=variant,
                        base_name="serialize_public_key",
                        params=("public_key",),
                        body="return public_key.public_bytes_raw()",
                        required_imports=frozenset(),
                        variant_suffix="_raw",
                        is_raw=True,
                    )
                )

        return True

    def finalize_pending_loaders(self) -> None:
        variant = self._single_variant()
        if not variant or not self.pending_loaders:
            return
        for loader_name, has_password in self.pending_loaders:
            self.methods.append(
                self._build_loader_spec(variant, loader_name, has_password)
            )


def generate_adapter_code(extractor: ClassicalDSCallExtractor) -> str:
    extractor.finalize_pending_loaders()
    if not extractor.methods:
        return ""

    variant_methods: dict[str, list[AdapterMethodSpec]] = {}
    seen_specs: set[tuple[str, str, tuple[str, ...], str]] = set()
    used_import_keys: set[str] = set()

    for spec in extractor.methods:
        dedup_key = (spec.variant, spec.base_name, spec.params, spec.body)
        if dedup_key in seen_specs:
            continue
        seen_specs.add(dedup_key)
        variant_methods.setdefault(spec.variant, []).append(spec)
        used_import_keys.update(spec.required_imports)

    ordered_imports = [
        IMPORT_STATEMENTS[key]
        for key in IMPORT_STATEMENTS
        if key in used_import_keys
    ]

    blocks: list[str] = []
    if ordered_imports:
        blocks.append("\n".join(ordered_imports) + "\n")

    for variant in sorted(variant_methods):
        specs = variant_methods[variant]
        base_names = {s.base_name for s in specs}

        if "load_private_key" in base_names:
            specs.sort(
                key=lambda s: 0 if (s.base_name == "serialize_private_key" and s.is_raw) else 1
            )
        if "load_public_key" in base_names:
            specs.sort(
                key=lambda s: 0 if (s.base_name == "serialize_public_key" and s.is_raw) else 1
            )

        used_names: set[str] = set()
        method_defs = []

        for spec in specs:
            method_name = spec.base_name
            if method_name in used_names:
                candidate = f"{spec.base_name}{spec.variant_suffix}"
                if candidate not in used_names:
                    method_name = candidate
                else:
                    idx = 2
                    while f"{candidate}_{idx}" in used_names:
                        idx += 1
                    method_name = f"{candidate}_{idx}"
            used_names.add(method_name)

            params_str = ", ".join(("self", *spec.params))
            method_defs.append(
                f"    def {method_name}({params_str}):\n"
                f"        {spec.body}\n"
            )

        class_block = f"class {variant}Adapter:\n\n" + "\n".join(method_defs)
        blocks.append(class_block)

    return "\n\n".join(blocks).rstrip() + "\n"


def generate_adapter(source_code: str) -> str:
    module = cst.parse_module(source_code)
    wrapper = MetadataWrapper(module)

    collector = _ClassicalSymbolCollector()
    wrapper.visit(collector)
    wrapper.visit(collector)

    extractor = ClassicalDSCallExtractor(collector)
    wrapper.visit(extractor)
    return generate_adapter_code(extractor)


def process_files(input_folder: str | Path, output_folder: str | Path) -> None:
    input_folder = Path(input_folder)
    output_folder = Path(output_folder)
    output_folder.mkdir(parents=True, exist_ok=True)

    for file_path in sorted(input_folder.glob("*.py")):
        print(f"\nProcessing: {file_path.name}")
        try:
            source_code = file_path.read_text(encoding="utf-8")
            modified_code = generate_adapter(source_code)
            if not modified_code:
                print("  No classical DS crypto usage found - adapter classes not created")
                continue

            output_file = output_folder / f"{file_path.stem}.py"
            output_file.write_text(modified_code, encoding="utf-8")
            print(f"  Created: {output_file}")
        except Exception as error:
            print(f"  ERROR processing {file_path.name}: {error}")


if __name__ == "__main__":
    process_files("../testing/input", "./adapter/source")