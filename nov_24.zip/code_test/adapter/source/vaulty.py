from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519


class Ed25519Adapter:

    def serialize_public_key(self, public_key):
        return public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )

    def serialize_private_key(self, private_key):
        return private_key.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        )

    def get_public_key(self, private_key):
        return private_key.public_key()

    def generate_private_key(self):
        return ed25519.Ed25519PrivateKey.generate()

    def load_private_key(self, data):
        return ed25519.Ed25519PrivateKey.from_private_bytes(data)

    def sign(self, private_key, data):
        return private_key.sign(data)

    def load_public_key(self, data):
        return ed25519.Ed25519PublicKey.from_public_bytes(data)

    def verify(self, public_key, signature, data):
        return public_key.verify(signature, data)
