from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import mldsa

private_key = mldsa.MLDSA87PrivateKey.generate()
data = b"this is some data I'd like to sign"
signature = private_key.sign(data)