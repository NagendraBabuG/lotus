
import ast
import csv
import importlib.util
import sys
from pathlib import Path
from matching_adapter import get_expected_target
import os
from cryptography.hazmat.primitives.asymmetric import mlkem


ROOT = Path(__file__).resolve().parent / "adapter"
SOURCE_DIR = ROOT / "source"
TARGET_DIR = ROOT / "target"
RESULT_FILE = ROOT / "test_results.csv"


def get_class_names(file_path):
    tree = ast.parse(file_path.read_text(encoding="utf-8"))
    return [
        node.name
        for node in tree.body
        if isinstance(node, ast.ClassDef)
    ]


def load_classes(file_path):
    module_name = f"adapter_test_{file_path.stem}_{abs(hash(str(file_path)))}"
    spec = importlib.util.spec_from_file_location(module_name, file_path)

    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {file_path}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)

    return {
        name: getattr(module, name)
        for name in get_class_names(file_path)
        if hasattr(module, name)
    }


METHOD_ALIASES = {
    "load_private_key": ("load_private_key", "deserialize_private_key"),
    "load_public_key": ("load_public_key", "deserialize_public_key"),
}


def get_method(adapter, method_name):
    names = METHOD_ALIASES.get(method_name, (method_name,))

    for name in names:
        method = getattr(adapter, name, None)
        if callable(method):
            return method

    raise AttributeError(f"Missing method: {method_name}")





def generate_private_key(adapter):
    return get_method(adapter, "generate_private_key")()


def get_public_key(adapter, private_key):
    return get_method(adapter, "get_public_key")(private_key)


def serialize_private_key(adapter, private_key):
    return get_method(adapter, "serialize_private_key")(private_key)


def load_private_key(adapter, private_bytes):
    return get_method(adapter, "load_private_key")(private_bytes)


def serialize_public_key(adapter, public_key):
    return get_method(adapter, "serialize_public_key")(public_key)


def load_public_key(adapter, public_bytes):
    return get_method(adapter, "load_public_key")(public_bytes)


def perform_key_exchange(adapter, private_key, peer_public_key):
    exchange = getattr(adapter, "exchange", None)

    if callable(exchange):
        return exchange(private_key, peer_public_key)

    encapsulate = getattr(adapter, "encapsulate", None)
    decapsulate = getattr(adapter, "decapsulate", None)

    if callable(encapsulate) and callable(decapsulate):
        ciphertext, shared_secret = encapsulate(peer_public_key)
        recovered_secret = decapsulate(private_key, ciphertext)

        return shared_secret, recovered_secret

    raise AttributeError("Missing exchange or encapsulate/decapsulate methods")



#tests

def test_generate_private_key(adapter):
    private_key = adapter.generate_private_key()
    assert private_key is not None



def test_generate_public_key(adapter):
    private_key = adapter.generate_private_key()
    public_key = adapter.get_public_key(private_key)

    assert public_key is not None


def test_exchange_shared_secret(adapter):
    private_key1 = adapter.generate_private_key()
    public_key1 = adapter.get_public_key(private_key1)

    has_encapsulate = callable(getattr(adapter, "encapsulate", None))
    has_decapsulate = callable(getattr(adapter, "decapsulate", None))
    has_exchange   = callable(getattr(adapter, "exchange", None))

    if has_encapsulate and has_decapsulate:
        secret1, ciphertext = adapter.encapsulate(public_key1)
        secret2 = adapter.decapsulate(private_key1, ciphertext)

        assert secret1 is not None
        assert secret2 is not None
        assert secret1 == secret2
        return

    if has_encapsulate and not has_decapsulate:
        secret1, ciphertext = adapter.encapsulate(public_key1)
        assert secret1 is not None
        return

    # Case 3: Only decapsulate present (almost never useful alone)
    if has_decapsulate and not has_encapsulate:

        secret1, ciphertext = public_key1.encapsulate()

        secret2 = adapter.decapsulate(private_key1, ciphertext)
        assert secret1 == secret2

    if has_exchange:
        private_key2 = adapter.generate_private_key()
        public_key2 = adapter.get_public_key(private_key2)

        secret1 = adapter.exchange(private_key1, public_key2)
        secret2 = adapter.exchange(private_key2, public_key1)

        assert secret1 is not None
        assert secret2 is not None
        assert secret1 == secret2
        return
def test_load_private_key(adapter):
    if callable(getattr(adapter, "encapsulate", None)) or "MLKEM" in type(adapter).__name__.upper():
        seed = os.urandom(64)
    elif "X25519" in type(adapter).__name__.upper():
        seed = os.urandom(32)
    elif "X448" in type(adapter).__name__.upper():
        seed = os.urandom(56)
    else:
        raise NotImplementedError(
            f"Seed generation not defined for {type(adapter).__name__}"
        )

    private_key = adapter.load_private_key(seed)

    assert private_key is not None


TESTS = [
    (
        "Generate private key",
        True,
        ("generate_private_key",),
        test_generate_private_key,
    ),
    (
        "Load private key",
        True,
        ("generate_private_key", "serialize_private_key", "load_private_key"),
        test_load_private_key,
    ),
    (
        "Generate public key",
        True,
        ("generate_private_key", "get_public_key"),
        test_generate_public_key,
    ),
    (
        "Exchange shared secret",
        True,
        ("generate_private_key", "get_public_key"),
        test_exchange_shared_secret,
    ),
    (
        "Load private key",
        True,
        ("load_private_key",),
        test_load_private_key,
    ),
]


def execute_test(adapter_class, expected_success, required_methods, test_func):

    missing = [
        name for name in required_methods
        if not any(
            callable(getattr(adapter_class, alias, None))
            for alias in METHOD_ALIASES.get(name, (name,))
        )
    ]

    if missing:
        return {
            "result": "SKIP",
            "behavior": ("SKIP", tuple(missing)),
            "details": f"Missing methods: {', '.join(missing)}",
        }

    try:
        test_func(adapter_class())

        return {
            "result": "PASS" if expected_success else "FAIL",
            "behavior": ("RETURNED",),
            "details": (
                "Completed successfully"
                if expected_success
                else "Expected an exception, but none was raised"
            ),
        }

    except Exception as exc:
        return {
            "result": "FAIL" if expected_success else "PASS",
            "behavior": ("EXCEPTION", type(exc).__name__),
            "details": f"{type(exc).__name__}: {exc}",
        }


def compare_test(
    source_class,
    target_class,
    test_name,
    expected_success,
    required_methods,
    test_func,
    source_name,
    target_name,
    file_name,
):

    source_result = execute_test(
        source_class, expected_success, required_methods, test_func
    )

    target_result = execute_test(
        target_class, expected_success, required_methods, test_func
    )

    if (
        source_result["result"] == "SKIP"
        and target_result["result"] == "SKIP"
    ):
        comparison = "BOTH SKIPPED"

    elif source_result["behavior"] == target_result["behavior"]:
        comparison = "EQUIVALENT BEHAVIOUR"

    else:
        comparison = "DIVERGENT BEHAVIOUR"

    print(f"{file_name}: {source_name} -> {target_name}")
    print(f"Test: {test_name}")
    print(f"Source: {source_result['result']} - {source_result['details']}")
    print(f"Target: {target_result['result']} - {target_result['details']}")
    print(f"Comparison: {comparison}\n")

    return {
        "file": file_name,
        "source_class": source_name,
        "target_class": target_name,
        "test": test_name,
        "source_result": source_result["result"],
        "source_details": source_result["details"],
        "target_result": target_result["result"],
        "target_details": target_result["details"],
        "comparison": comparison,
    }


def main():
    all_results = []

    for source_file in sorted(SOURCE_DIR.rglob("*.py")):

        relative_path = source_file.relative_to(SOURCE_DIR)
        target_file = TARGET_DIR / relative_path

        if not target_file.exists():
            print(f"Missing target file: {relative_path}\n")
            continue

        try:
            source_classes = load_classes(source_file)
            target_classes = load_classes(target_file)

        except Exception as exc:
            print(
                f"Could not load {relative_path}: "
                f"{type(exc).__name__}: {exc}\n"
            )
            continue

        if not source_classes or not target_classes:
            print(f"No adapter classes found in {relative_path}\n")
            continue

        if len(source_classes) != len(target_classes):
            print(
                f"WARNING: Different class counts in {relative_path}: "
                f"source={len(source_classes)}, "
                f"target={len(target_classes)}\n"
            )

        for source_name, source_class in source_classes.items():

            expected_target = get_expected_target(
                source_name,
                source_file
            )

            if expected_target is None:
                print(
                    f"MAPPING NOT DEFINED: {relative_path}: "
                    f"{source_name}\n"
                )
                continue

            if expected_target not in target_classes:
                print(
                    f"MATCH NOT PRESENT: {relative_path}: "
                    f"{source_name} -> {expected_target}\n"
                )
                continue

            target_class = target_classes[expected_target]

            for test_name, expected, methods, test_func in TESTS:

                result = compare_test(
                    source_class,
                    target_class,
                    test_name,
                    expected,
                    methods,
                    test_func,
                    source_name,
                    expected_target,
                    str(relative_path),
                )

                if (
                    result["source_result"] == "SKIP"
                    and result["target_result"] == "SKIP"
                ):
                    continue

                all_results.append(result)

    RESULT_FILE.parent.mkdir(parents=True, exist_ok=True)

    fieldnames = [
        "file",
        "source_class",
        "target_class",
        "test",
        "source_result",
        "source_details",
        "target_result",
        "target_details",
        "comparison",
    ]

    with RESULT_FILE.open("w", newline="", encoding="utf-8") as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(all_results)

    print(f"Test execution completed. Results saved to: {RESULT_FILE}")
    print(f"Total test cases executed or skipped: {len(all_results)}")


if __name__ == "__main__":
    main()
