from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from quantcrypt.kem import MLKEM_1024

# Generate a private key for use in the exchange.
server_private_key = ec.generate_private_key(
    ec.SECP384R1()
)
# In a real handshake the peer is a remote client. For this
# example we'll generate another local private key though.
peer_private_key = ec.generate_private_key(
    ec.SECP384R1()
)
mlkem = MLKEM_1024()
ct_pqc, shared_key = mlkem.encaps(peer_private_key.public_key)
# Perform key derivation.
derived_key = HKDF(
    algorithm=hashes.SHA256(),
    length=32,
    salt=None,
    info=b'handshake data',
).derive(shared_key)
mlkem = MLKEM_1024()
ct_pqc, same_shared_key = mlkem.encaps(server_private_key.public_key)
# Perform key derivation.
same_derived_key = HKDF(
    algorithm=hashes.SHA256(),
    length=32,
    salt=None,
    info=b'handshake data',
).derive(same_shared_key)
derived_key == same_derived_key