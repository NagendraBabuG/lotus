import ast
from collections import defaultdict
import random
import re

HEX_PATTERN = re.compile(r"0x[0-9A-Fa-f]+")


class AddDefaultArgValue(ast.NodeTransformer):
    

    def __init__(self):
        self.func_par_map: dict[str, list[tuple[str, str]]] = {}

    def _collect_from_call(self, call, collected):
        for arg in call.args:
            if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                collected["p"].add(arg.value)

        for kw in call.keywords:
            if isinstance(kw.value, ast.Constant) and isinstance(kw.value.value, str):
                base = kw.arg or "p"
                collected[base].add(kw.value.value)

    def collect_mappings(self, tree):
        for node in ast.walk(tree):
            if not isinstance(node, ast.FunctionDef):
                continue

            raw = defaultdict(set)

            for sub in ast.walk(node):
                if isinstance(sub, ast.Call):
                    self._collect_from_call(sub, raw)

            param_list = []
            counters = defaultdict(int)

            for base, values in list(raw.items()):
                if base != "p":              
                    for v in values:
                        param_list.append((base, v))
                    del raw[base]

            
            for v in raw["p"]:
                idx = counters["p"]
                counters["p"] += 1
                param_list.append((f"var{idx}", v))

            self.func_par_map[node.name] = param_list

        return tree

    def transform_functions(self, tree):
        class _Injector(ast.NodeTransformer):
            def __init__(self, param_map):
                self.param_map = param_map

            def visit_Call(self, node):
                self.generic_visit(node)     

                new_args = []
                for arg in node.args:
                    if (isinstance(arg, ast.Constant) and
                            isinstance(arg.value, str) and
                            arg.value in self.param_map):
                        new_args.append(
                            ast.Name(id=self.param_map[arg.value], ctx=ast.Load())
                        )
                    else:
                        new_args.append(arg)

                new_keywords = []
                for kw in node.keywords:
                    if (isinstance(kw.value, ast.Constant) and
                            isinstance(kw.value.value, str) and
                            kw.value.value in self.param_map):
                        new_args.append(
                            ast.Name(id=self.param_map[kw.value.value], ctx=ast.Load())
                        )
                    else:
                        new_keywords.append(kw)

                node.args = new_args
                node.keywords = new_keywords
                return node

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name in self.func_par_map:
                literal_to_param: dict[str, str] = {}
                for param, lit in self.func_par_map[node.name]:
                    literal_to_param[lit] = param
                    node.args.args.append(ast.arg(arg=param))
                    node.args.defaults.append(ast.Constant(value=lit))

                _Injector(literal_to_param).visit(node)

        return tree
    def get_refactored_code(self, source_code):
        hex_literals = HEX_PATTERN.findall(source_code)
        print(hex_literals, '\n')
        try:
            tree = ast.parse(source_code)
            tree = self.collect_mappings(tree)
            tree = self.transform_functions(tree)
            ast.fix_missing_locations(tree)
            result = ast.unparse(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")

        for hx in hex_literals:
            dec = str(int(hx, 16))
            result = result.replace(dec, hx)

        return result

