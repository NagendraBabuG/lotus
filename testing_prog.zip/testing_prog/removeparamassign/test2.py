def increment(a):
    a += 1
    return a
