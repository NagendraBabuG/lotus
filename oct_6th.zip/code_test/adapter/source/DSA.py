from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import dsa
from cryptography.hazmat.primitives import serialization
import hashlib

class DSAAdapter:

    def generate_private_key(self):
        return dsa.generate_private_key(key_size=1024)

    def get_public_key(self, private_key):
        return private_key.public_key()

    def sign(self, private_key, message):
        return private_key.sign(message, hashes.SHA256())

    def decode(self, signature):
        return signature.decode('ISO-8859-1')

    def encode(self, signature_str):
        return signature_str.encode('ISO-8859-1')

