import ast
import random
import re

HEX_PATTERN = re.compile(r"0x[0-9A-Fa-f]+")

class ParameterRefactor(ast.NodeTransformer):
    def __init__(self, copy_probability: float = 0.5):
        self.copy_probability = copy_probability
        self.rng = random.Random()

    def visit_FunctionDef(self, node):
        param_names = [a.arg for a in node.args.args if a.arg not in ('self', 'cls')]
        num_params = len(param_names)

        par_var_map = {}
        init_assignments = []

        if num_params == 0:
            pass 

        elif num_params == 1:
            param = param_names[0]
            copy_name = f"{param}_copy"
            par_var_map[param] = copy_name
            init_assignments.append(
                ast.Assign(
                    targets=[ast.Name(id=copy_name, ctx=ast.Store())],
                    value=ast.Name(id=param, ctx=ast.Load()),
                    lineno=0, col_offset=0
                )
            )

        else:
            for param in param_names:
                if self.rng.random() < self.copy_probability:
                    copy_name = f"{param}_copy"
                    par_var_map[param] = copy_name
                    init_assignments.append(
                        ast.Assign(
                            targets=[ast.Name(id=copy_name, ctx=ast.Store())],
                            value=ast.Name(id=param, ctx=ast.Load()),
                            lineno=0, col_offset=0
                        )
                    )

        old_map = getattr(self, '_current_par_map', None)
        self._current_par_map = par_var_map

        new_body = init_assignments + [self.visit(stmt) for stmt in node.body]

        if old_map is None:
            if hasattr(self, '_current_par_map'):
                del self._current_par_map
        else:
            self._current_par_map = old_map

        node.body = new_body
        return node

    def visit_Name(self, node):
        if hasattr(self, '_current_par_map') and node.id in self._current_par_map:
            return ast.copy_location(
                ast.Name(id=self._current_par_map[node.id], ctx=node.ctx), node
            )
        return node

    def get_refactored_code(self, source_code):
        hex_literals = HEX_PATTERN.findall(source_code)
        print(hex_literals, '\n')
        try:
            tree = ast.parse(source_code)
            tree = self.visit(tree)
            result = ast.unparse(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")

        for hx in hex_literals:
            dec = str(int(hx, 16))
            result = result.replace(dec, hx)

        return result
    
wrapper = ParameterRefactor(copy_probability=0.6) 

source = """  
class f1:
    x = 2
    def f2(self, pas):
        self.x = self.x + 2
        return 2
    def f3(self, p2):
        return p2
    def f4(self, a, b, c):
        a = a + 1
        b = b.upper()
        return a, b, c

def func2(x):
    x = x.upper()
    return x

def many(p1, p2, p3, p4):
    p1 += 1
    p2 = p2.strip()
    return p1, p2
def verify_sign(msg, sing, pub_key):
    key = RSA.import_key(pub_key)
def create_siv_cipher(factory, **kwargs):
    key_copy = kwargs.pop()
def creat_cipher(v):
    v_int = bytes_to_long(v)
    q = v_int & 0xFFFFFFFFFFFFFFFF7FFFFFFF7FFFFFFF
"""

target = wrapper.get_refactored_code(source)
print(target)