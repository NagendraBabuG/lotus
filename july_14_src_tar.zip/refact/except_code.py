def test_password(word):
    try:
        word_copy = word
        key = word_copy.decode('utf-8')
        if len(word_copy) == len(key):
            raise Exception("Operation Failed")
        else:
            raise Exception("OPeration Failed")

    except Exception as exception:
        print(f"operation failed: {exception}")

