from quantcrypt.dss import MLDSA_65


# Generate a new random signing key
public_signing_key, signing_key = MLDSA_65().keygen()

# Sign a message with the signing key
signed = MLDSA_65().sign(signing_key, b"Attack at Dawn")

# Obtain the verify key for a given signing key
verify_key = public_signing_key

# Serialize the verify key to send it to a third party
verify_key_bytes = verify_key.encode()