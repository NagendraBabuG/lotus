import libcst as cst


class ElseTransformer(cst.CSTTransformer):
    def __init__(self, to_style: str = "elif"):
        self.to_style = to_style

    def leave_If(self, original: cst.If, updated: cst.If) -> cst.If:
        if self.to_style == "elif":
            return self._else_if_to_elif(updated)
        else:
            return self._elif_to_else_if(updated)

    def _elif_to_else_if(self, node: cst.If) -> cst.If:
        if isinstance(node.orelse, cst.If):
            return node.with_changes(
                orelse=cst.Else(
                    body=cst.IndentedBlock(
                        body=[self._elif_to_else_if(node.orelse)]
                    )
                )
            )

        if isinstance(node.orelse, cst.Else):
            new_body = [
                self._elif_to_else_if(b) if isinstance(b, cst.If) else b
                for b in node.orelse.body.body
            ]
            return node.with_changes(
                orelse=node.orelse.with_changes(
                    body=cst.IndentedBlock(body=new_body)
                )
            )

        return node

    # ---------- else: if -> elif ----------
    def _else_if_to_elif(self, node: cst.If) -> cst.If:
        orelse = node.orelse

        if (
            isinstance(orelse, cst.Else)
            and len(orelse.body.body) == 1
            and isinstance(orelse.body.body[0], cst.If)
        ):
            child = orelse.body.body[0]
            return node.with_changes(
                orelse=self._else_if_to_elif(
                    child.with_changes(leading_lines=[])
                )
            )

        if isinstance(orelse, cst.Else):
            new_body = [
                self._else_if_to_elif(b) if isinstance(b, cst.If) else b
                for b in orelse.body.body
            ]
            return node.with_changes(
                orelse=orelse.with_changes(
                    body=cst.IndentedBlock(body=new_body)
                )
            )

        return node

    def get_refactored_code(self, source: str) -> str:
        return cst.parse_module(source).visit(self).code

