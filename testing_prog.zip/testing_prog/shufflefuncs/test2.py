def c():
    print("C")

def b():
    c()

def a():
    b()

a()
