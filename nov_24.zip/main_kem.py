from arta import RulesEngine
import libcst as cst

from libcst.display import dump
from pathlib import Path


eng = RulesEngine(config_path="./arta_files")



def get_target_pqc_kem_server(code):

    libname = "cryptography"

    inputs = {
        "tree":code,
        "library":libname
    }


    extracted_result = eng.apply_rules(inputs, rule_set="mapping_creator_rule_set")
    mappings = extracted_result['get_mapping_ids']


    libname = "cryptography"
    mod_inputs = {
        "tree":code,
        "mappings":mappings,
        "library":libname
        
    }

    result = eng.apply_rules(mod_inputs, rule_set="kem_transform_pqc_server_rule_set")
    modified_keygen_tree = result['check_generate']


    return modified_keygen_tree.code





def get_target_pqc_kem_client(code):

    libname = "cryptography"

    inputs = {
        "tree":code,
        "library":libname
    }


    extracted_result = eng.apply_rules(inputs, rule_set="mapping_creator_rule_set")
    mappings = extracted_result['get_mapping_ids']


    libname = "cryptography"
    mod_inputs = {
        "tree":code,
        "mappings":mappings,
        "library":libname
        
    }

    result = eng.apply_rules(mod_inputs, rule_set="kem_transform_pqc_client_rule_set")
    modified_keygen_tree = result['check_generate']


    return modified_keygen_tree.code



def process_folder(input_folder, output_folder):
    

    input_folder = Path(input_folder)
    output_folder = Path(output_folder)

    output_folder.mkdir(parents=True, exist_ok=True)

    for file_path in input_folder.glob("*.py"):

        print(f"\nProcessing: {file_path.name}")

        try:
            with open(file_path, "r", encoding="utf-8") as f:
                src = f.read()

            tree = cst.parse_module(src)
            #code = get_target_pqc_kem_client(tree)
            code = get_target_pqc_kem_server(tree)
            variants = {
                "pqc_server": code,
            }

            base_name = file_path.stem

            for variant, modified_code in variants.items():

                output_file = (
                    output_folder
                    / f"{base_name}.py"
                )

                with open(
                    output_file,
                    "w",
                    encoding="utf-8"
                ) as f:
                    f.write(modified_code)

                ##print(f"  Created: {output_file}")

        except Exception as e:
            print(
                f"  ERROR processing {file_path.name}: {e}"
            )




if __name__ == "__main__":
    

    #process_folder("./kem_files/input", "./kem_files/output")
    process_folder("./kem_files/input_server", "./kem_files/output_server")