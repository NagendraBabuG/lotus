from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.asymmetric import mlkem

# Generate a private key for use in the exchange.
server_private_key = ec.generate_private_key(
    ec.SECP384R1()
)
# In a real handshake the peer is a remote client. For this
# example we'll generate another local private key though.
peer_private_key = ec.generate_private_key(
    ec.SECP384R1()
)
shared_key = server_private_key.exchange(
    ec.ECDH(), ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP384R1(), peer_private_key.public_key()[:97]))
pqc_shared_secret, ct_pqc = mlkem.MLKEM1024PublicKey.from_public_bytes(peer_private_key.public_key()[97:]).encapsulate()  # TODO: send/return ct_pqc alongside server public key
shared_key = shared_key + pqc_shared_secret
# Perform key derivation.
derived_key = HKDF(
    algorithm=hashes.SHA256(),
    length=32,
    salt=None,
    info=b'handshake data',
).derive(shared_key)
# And now we can demonstrate that the handshake performed in the
# opposite direction gives the same final value
same_shared_key = peer_private_key.exchange(
    ec.ECDH(), ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP384R1(), server_private_key.public_key()[:97]))
pqc_shared_secret, ct_pqc = mlkem.MLKEM1024PublicKey.from_public_bytes(server_private_key.public_key()[97:]).encapsulate()  # TODO: send/return ct_pqc alongside server public key
same_shared_key = same_shared_key + pqc_shared_secret
# Perform key derivation.
same_derived_key = HKDF(
    algorithm=hashes.SHA256(),
    length=32,
    salt=None,
    info=b'handshake data',
).derive(same_shared_key)
derived_key == same_derived_key