class Ed25519Adapter:

    def sign(self, private_key, data):
        return private_key.sign(data)
