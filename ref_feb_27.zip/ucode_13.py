from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP, AES
from Crypto import Random


def key_exchange(self):

    if self.role == 'server':
        rsa_key = RSA.generate(2048)
        pub_key = rsa_key.publickey().exportKey()
        pub_key_b64 = base64.b64encode(pub_key).decode()

        self.send_unencrypted_json(
            {"type": self.CMDS['RSAKEY'], "public_key": pub_key_b64}
        )

        response = self.recv_unencrypted_json()

        if response.get("type") != self.CMDS['AESKEY']:
            raise ValueError("Invalid AESKEY response")

        encrypted_aes_key = base64.b64decode(
            response.get("encrypted_aes_key")
        )

        cipher = PKCS1_OAEP.new(rsa_key)
        self.aes_key = cipher.decrypt(encrypted_aes_key)

    else:
        init_msg = self.recv_unencrypted_json()

        if init_msg.get("type") != self.CMDS['RSAKEY']:
            raise ValueError("Invalid RSAKEY message")

        pub_key = base64.b64decode(init_msg.get("public_key"))
        cipher = PKCS1_OAEP.new(RSA.importKey(pub_key))

        self.aes_key = Random.new().read(32)
        encrypted_aes_key = cipher.encrypt(self.aes_key)
        encrypted_aes_key_b64 = base64.b64encode(
            encrypted_aes_key
        ).decode()

        self.send_unencrypted_json(
            {"type": self.CMDS['AESKEY'], "encrypted_aes_key": encrypted_aes_key_b64}
        )