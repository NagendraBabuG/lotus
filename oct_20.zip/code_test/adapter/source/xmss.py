from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization

class Ed25519Adapter:

    def generate_private_key(self):
        return Ed25519PrivateKey.generate()

    def get_public_key(self, priv_key):
        return priv_key.public_key()

    def sign(self, priv_key, message):
        return priv_key.sign(message)

    def verify(self, pub_key, signature, message):
        return pub_key.verify(signature, message)

    def serialize_public_key(self, pub_key):
        return pub_key.public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)

