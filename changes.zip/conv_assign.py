import ast
import re

HEX_PATTERN = re.compile(r"\b0x[0-9A-Fa-f]+\b")

class AugAssignRefactor(ast.NodeTransformer):
    
    def visit_AugAssign(self, node):
        if not isinstance(node.target, ast.Name):
            return node  
        
        new_assign = ast.Assign(
            targets=[node.target],
            value=ast.BinOp(
                left=ast.Name(id=node.target.id, ctx=ast.Load()),
                op=node.op,
                right=node.value
            )
        )
        ast.copy_location(new_assign, node)
        ast.fix_missing_locations(new_assign)
        return new_assign
    
    def visit_Assign(self, node):
        if len(node.targets) != 1:
            return node
        
        target = node.targets[0]
        if not isinstance(target, ast.Name):
            return node
        
        value = node.value
        if not isinstance(value, ast.BinOp):
            return node
        
        left = value.left
        
        if not (isinstance(left, ast.Name) and left.id == target.id):
            return node 
        
        if isinstance(value.right, ast.Call):
            return node  
        
        new_aug = ast.AugAssign(
            target=target,
            op=value.op,
            value=value.right  
        )
        ast.copy_location(new_aug, node)
        ast.fix_missing_locations(new_aug)
        return new_aug
    
    def get_refactored_code(self, source_code):
        hex_map = {}
        for match in HEX_PATTERN.finditer(source_code):
            hx = match.group()
            dec = str(int(hx, 16))
            if dec not in hex_map:
                hex_map[dec] = hx

        try:
            tree = ast.parse(source_code)
            tree = self.visit(tree)
            result = ast.unparse(tree)
        except Exception as e:
            raise ValueError(f"Failed to parse/transform: {e}")

        for dec, hx in hex_map.items():
            result = result.replace(dec, hx)

        return result


