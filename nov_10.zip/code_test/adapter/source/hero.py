from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization

class Ed25519Adapter:

    def generate_private_key(self):
        return Ed25519PrivateKey.generate()

    def get_public_key(self, priv):
        return priv.public_key()

    def serialize_private_key(self, priv):
        return priv.private_bytes(encoding=serialization.Encoding.PEM, format=serialization.PrivateFormat.PKCS8, encryption_algorithm=serialization.NoEncryption())

    def serialize_public_key(self, pub):
        return pub.public_bytes(encoding=serialization.Encoding.PEM, format=serialization.PublicFormat.SubjectPublicKeyInfo)

