import ast 
import random 


class idCollector(ast.NodeVisitor):
    def __init__(self):
        self.ids = set()
        self.func_ids = set()
        self.class_ids = set()
    def visit_ClassDef(self, node):
        self.generic_visit(node)
        self.class_ids.add(node.name)
        return node 
    def visit_FunctionDef(self, node):
        self.generic_visit(node)
        self.func_ids.add(node.name)
        for elt in node.args.args: 
            if elt.arg != 'self':
                self.ids.add(elt.arg)
        return node 
    def visit_Assign(self, node):
        self.generic_visit(node)
        for inner_node in node.targets:
            if isinstance(inner_node, ast.Name):
                self.ids.add(inner_node.id)
            elif isinstance(inner_node, ast.Tuple):
                for elt in inner_node.elts:
                    if isinstance(elt, ast.Name):
                        self.ids.add(elt.id)
            elif isinstance(inner_node, ast.Attribute) and isinstance(inner_node.value, ast.Name) and inner_node.value.id == 'self':
                self.ids.add(inner_node.attr)
        return node 
    

class idReplacer(ast.NodeTransformer):
    def __init__(self, ids, func_ids, class_ids):
        self.ids = list(ids)
        self.func_ids = list(func_ids)
        self.class_ids = list(class_ids)
        self.var_mapper = {}
        self.helper(self.ids, 'var')
        self.helper(self.func_ids, 'func')
        self.helper(self.class_ids, 'class')
    def helper(self, arr, obj):
        for idx in range(len(arr)):
            num = 0 
            for idx2 in arr[idx]:
                num += ord(idx2)
            random.seed(num)
            ran = random.randrange(100, 10000)
            self.var_mapper[arr[idx]] = f'{obj}_{ran}'
        return 
    def visit_ClassDef(self, node):
        self.generic_visit(node)
        node.name = self.var_mapper[node.name]
        ast.fix_missing_locations(node)
        return node 
    def visit_FunctionDef(self, node):
        self.generic_visit(node)
        node.name = self.var_mapper[node.name]
        for elt in node.args.args:
            if elt.arg in self.var_mapper:
                elt.arg = self.var_mapper[elt.arg]
        ast.fix_missing_locations(node)
        return node 
    def visit_Attribute(self, node):
        self.generic_visit(node)
        if node.attr in self.var_mapper:
            node.attr = self.var_mapper[node.attr]
        ast.fix_missing_locations(node)
        return node 
    def visit_keyword(self, node):
        self.generic_visit(node)
        if node.arg in self.var_mapper:
            node.arg = self.var_mapper[node.arg]
        return node 
    def visit_Name(self, node):
        if node.id in self.var_mapper:
            node.id = self.var_mapper[node.id]
        ast.fix_missing_locations(node)
        return node 
    
class Id_gen(ast.NodeTransformer):   
    def get_refactored_code(self, code):
        try:
            tree = ast.parse(code)
            obj = idCollector()
            obj.visit(tree) 
            obj2 = idReplacer(obj.ids, obj.func_ids, obj.class_ids)
            mod_tree = obj2.visit(tree)
            return ast.unparse(mod_tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")
        