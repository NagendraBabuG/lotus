@staticmethod
def identity(x):
    return x
square = lambda x: x * x