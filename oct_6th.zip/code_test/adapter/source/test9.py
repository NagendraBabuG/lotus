from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey, Ed25519PrivateKey

class SourceAdapter:

    def load_public_key(self, raw):
        return Ed25519PublicKey.from_public_bytes(raw)

    def generate_private_key(self):
        return Ed25519PrivateKey.generate()

