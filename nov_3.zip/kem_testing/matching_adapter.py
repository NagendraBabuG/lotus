import ast


FIXED_KEX_MAPPING = {
    "X25519Adapter": "MLKEM768Adapter",
    "X448Adapter": "MLKEM1024Adapter",
}


def get_pqc_kexwith_ec_curve(curve):
    if curve is None:
        return "MLKEM1024Adapter"

    curve = curve.lower()

    if curve in [
        "secp224r1", "secp192r1", "sect233k1",
        "sect163k1", "sect233r1", "sect163r2"
    ]:
        return "MLKEM512Adapter"

    elif curve in [
        "secp256r1", "secp256k1", "sect283r1", "sect283k1"
    ]:
        return "MLKEM768Adapter"

    elif curve in [
        "secp521r1", "secp384r1", "sect409k1",
        "sect409r1", "sect571k1", "sect571r1"
    ]:
        return "MLKEM1024Adapter"

    return "MLKEM1024Adapter"


def get_source_ec_curve(source_file):
    tree = ast.parse(source_file.read_text(encoding="utf-8"))

    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            if node.func.attr.startswith(("SECP", "SECT")):
                return node.func.attr.lower()

    return None


def get_expected_target(source_name, source_file):

    if source_name in FIXED_KEX_MAPPING:
        return FIXED_KEX_MAPPING[source_name]

    if source_name in ("ECAdapter", "ECDHAdapter", "EllipticCurveAdapter"):
        curve = get_source_ec_curve(source_file)
        return get_pqc_kexwith_ec_curve(curve)

    return None