import sys
import os, base64, getpass
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.asymmetric.x448 import X448PrivateKey
from cryptography.hazmat.primitives.asymmetric.x448 import X448PublicKey
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.exceptions import InvalidSignature
from cryptography.exceptions import InvalidTag

class SourceAdapter:

    def generate_private_key(self):
        return Ed25519PrivateKey.generate()

    def get_public_key(self, private_ed25519):
        return private_ed25519.public_key()

    def serialize_private_key(self, private_ed25519):
        return private_ed25519.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption())

    def load_private_key(self, private_key):
        return Ed25519PrivateKey.from_private_bytes(private_key[58:])

    def sign(self, key, data):
        return key.sign(data)

    def load_public_key(self, public_key):
        return Ed25519PublicKey.from_public_bytes(public_key[58:90])

    def verify(self, key, signature, data):
        return key.verify(signature[2:], data)

