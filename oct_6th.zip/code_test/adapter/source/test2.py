from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

class Ed25519Adapter:

    def generate_private_key(self):
        return ed25519.Ed25519PrivateKey.generate()

    def serialize_private_key(self, private_key):
        return private_key.private_bytes(encoding=serialization.Encoding.Raw, format=serialization.PrivateFormat.Raw, encryption_algorithm=serialization.NoEncryption())

    def load_private_key(self, private_bytes):
        return ed25519.Ed25519PrivateKey.from_private_bytes(private_bytes)

