import ast

class RemoveUnusedParameter(ast.NodeTransformer):
    def removeUnusedParameteer(self, tree):
        self.func_unused_map = {}

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                cur_params = []
                unused_params = []
                for arg in node.args.args:
                    cur_params.append(arg.arg)
                for param in cur_params:
                    flag = 0
                    for node2 in ast.walk(node):
                        if isinstance(node2, ast.Name):

                            if node2.id == param and not isinstance(node2.ctx, ast.Store):
                                flag = 1
                                break

                    if not flag:
                        unused_params.append(param)
                    self.func_unused_map[node.name] = unused_params
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name in self.func_unused_map:
                for idx, arg in enumerate(node.args.args):
                    if arg.arg in self.func_unused_map[node.name]:
                        node.args.args.remove(node.args.args[idx])
        
        return tree

    def get_refactored_code(self, source_code):
        try:
            tree = ast.parse(source_code)
            tree = self.removeUnusedParameteer(tree)
            ast.fix_missing_locations(tree)
            return ast.unparse(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")