import ast

def remove_docstrings(code):
    tree = ast.parse(code)
    
    class DocstringRemover(ast.NodeTransformer):
        def visit_Module(self, node):
            if node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Str):
                node.body.pop(0)
            self.generic_visit(node)
            return node
        
        def visit_FunctionDef(self, node):
            if node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Str):
                node.body.pop(0)
            self.generic_visit(node)
            return node
        
        def visit_ClassDef(self, node):
            if node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Str):
                node.body.pop(0)
            self.generic_visit(node)
            return node

    transformer = DocstringRemover()
    modified_tree = transformer.visit(tree)
    return ast.unparse(modified_tree)

if __name__ == "__main__":
    sample_code = '''
"""comments"""
def fun1():
    """comment1"""
    st1 = "hello"
    print("in func1")
    
class MyClass:
    """class comments"""
    def method(self):
        """method inside class"""
        print("hello2")
'''

    without_comments_code = remove_docstrings(sample_code)
    print(without_comments_code)