# line_stmts.py
import libcst as cst


class AssignGroupers(cst.CSTTransformer):
    def _is_invalid_block(self, node):
        return isinstance(node, (
            cst.FunctionDef, cst.ClassDef, cst.If, cst.While,
            cst.For, cst.Try, cst.With, cst.AsyncFor, cst.AsyncWith
        ))

    def _is_simple_assign_line(self, stmt):
        return (
            isinstance(stmt, cst.SimpleStatementLine) and
            len(stmt.body) == 1 and
            isinstance(stmt.body[0], cst.Assign) and
            self._is_valid_assign_value(stmt.body[0])
        )

    def _is_valid_assign_value(self, assign_node: cst.Assign) -> bool:
        # Allow simple targets and literal-like values
        for target in assign_node.targets:
            if not isinstance(target.target, (cst.Name, cst.Attribute, cst.Subscript)):
                return False
        value = assign_node.value
        return isinstance(value, (
            cst.Integer, cst.Float, cst.SimpleString,
            cst.Name, cst.Tuple, cst.List, cst.Dict,
            cst.FormattedString, cst.Call  # optionally allow simple calls?
        ))

    def _group_statements(self, statements):
        grouped = []
        current_group = []

        for stmt in statements:
            if self._is_simple_assign_line(stmt):
                current_group.append(stmt.body[0])  # the raw Assign node
            else:
                if current_group:
                    grouped.append(cst.SimpleStatementLine(body=current_group))
                    current_group = []
                grouped.append(stmt)

        if current_group:
            grouped.append(cst.SimpleStatementLine(body=current_group))

        return grouped

    def leave_Module(self, original_node: cst.Module, updated_node: cst.Module) -> cst.Module:
        new_body = self._group_statements(updated_node.body)
        return updated_node.with_changes(body=new_body)

    def leave_FunctionDef(self, original_node: cst.FunctionDef, updated_node: cst.FunctionDef) -> cst.FunctionDef:
        # This handles BOTH def and async def
        if not isinstance(updated_node.body, cst.IndentedBlock):
            return updated_node

        new_body_stmts = self._group_statements(updated_node.body.body)
        new_block = updated_node.body.with_changes(body=new_body_stmts)
        return updated_node.with_changes(body=new_block)

    # Optional: also handle class bodies if you want
    def leave_ClassDef(self, original_node: cst.ClassDef, updated_node: cst.ClassDef) -> cst.ClassDef:
        if not isinstance(updated_node.body, cst.IndentedBlock):
            return updated_node
        new_body_stmts = self._group_statements(updated_node.body.body)
        new_block = updated_node.body.with_changes(body=new_body_stmts)
        return updated_node.with_changes(body=new_block)

    def get_refactored_code(self, source_code: str) -> str:
        module = cst.parse_module(source_code)
        wrapper = cst.MetadataWrapper(module)
        modified = wrapper.visit(self)
        return modified.code