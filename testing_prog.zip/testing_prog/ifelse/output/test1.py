def test1(score):
    if score >= 90:
        grade = 'A'
    else:
        grade = 'B' if score >= 80 else 'C'
    return grade
x = 5
if x < 0:
    print('negative')
elif x > 0:
    print('positive')
elif not x:
    print('zero')
else:
    print('Fin')