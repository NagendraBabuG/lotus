from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec


class ECAdapter:

    def generate_private_key(self):
        return ec.generate_private_key(ec.SECP521R1())

    def get_public_key(self, private_key):
        return private_key.public_key()

    def serialize_public_key(self, public_key, encoding=serialization.Encoding.PEM, format=serialization.PublicFormat.SubjectPublicKeyInfo):
        return public_key.public_bytes(
            encoding=encoding,
            format=format,
        )

    def load_public_key_der(self, data):
        return serialization.load_der_public_key(data)

    def serialize_private_key(self, private_key, encoding=serialization.Encoding.PEM, format=serialization.PrivateFormat.PKCS8, encryption_algorithm=None):
        return private_key.private_bytes(
            encoding=encoding,
            format=format,
            encryption_algorithm=encryption_algorithm if encryption_algorithm is not None else serialization.NoEncryption(),
        )
