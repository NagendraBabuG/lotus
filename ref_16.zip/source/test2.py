class SecureStore:
    def __init__(self):
        self.key = Fernet.generate_key()
        self.cipher = Fernet(self.key)

    def encrypt_and_save(self, data, path):
        encrypted = self.cipher.encrypt(data.encode())
        with open(path, "wb") as f:
            f.write(encrypted)

    def read_and_decrypt(self, path):
        with open(path, "rb") as f:
            encrypted = f.read()
        return self.cipher.decrypt(encrypted).decode()
