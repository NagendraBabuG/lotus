from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

class Ed25519Adapter:

    def load_private_key(self, _signing_seed, signing_key):
        return Ed25519PrivateKey.from_private_bytes(_signing_seed(signing_key))

    def get_public_key(self, private_key):
        return private_key.public_key()

    def sign(self, private_key, manifest_bytes):
        return private_key.sign(manifest_bytes)

