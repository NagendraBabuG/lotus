def add(a, b):
    return a + 10


def multiply(x, y):
    return x * y


def greet(name, greeting, punctuation):
    print("Hello")
