import os
import shutil
from pathlib import Path
from collections import defaultdict, Counter
import numpy as np
import bert_code  

from defaut_arg_deep import AddDefaultArgValue
from except_code import ExceptionRefactor
from hardcode_deep import HardcodedValues
from forwhilev2 import ForWhile
from lambda_refactor import LambdaRefactor
from asserts import AddAssertions
from partials_ls import PartialsRefactor
from ternary_ref import TernaryRefactor
from try_crypto import CryptoTryExceptInjector
from conv_assign import AugAssignRefactor
from conv_except_assertion import RaiseRefactor
from multi_sinline_stmts import AssignGroupers
from elif_ren import ElIfConverter
from elseIf import ElseIfConverter
from param_refact_v2 import ParameterRefactor
from var_extract import CryptoVarExtractor
import rem_comments  


refactor_classes = {
    "raise_refact": RaiseRefactor(),
    "line_stmts": AssignGroupers(),
    "elif_ref": ElIfConverter(),
    "elseif": ElseIfConverter(),
    "add_default_arg": AddDefaultArgValue(),
    "hardcoded_values": HardcodedValues(),
    "exception_code": ExceptionRefactor(),
    "var_extract": CryptoVarExtractor(),
    "loops": ForWhile(),
    "lambda_refactor": LambdaRefactor(),
    "assertions": AddAssertions(),
    "partials": PartialsRefactor(),
    "param_refactor": ParameterRefactor(),
    "ternary": TernaryRefactor(),
    "crypto_try": CryptoTryExceptInjector(),
    "conv_assign": AugAssignRefactor(),
}

refactor_classes = {k: v for k, v in refactor_classes.items() if v is not None}

def read_code(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read()

def apply_technique(code: str, tech_name: str) -> str:
    refactor = refactor_classes[tech_name]
    return refactor.get_refactored_code(code)

def apply_pipeline(code: str, pipeline: list) -> str:
    current = code
    current = rem_comments.get_refactored_code(code)
    for tech in pipeline:
        try:
            current = apply_technique(current, tech)
        except Exception as e:
            print(f"  [Warning] {tech} failed: {e}")
    return current

def measure_divergence(original_code: str, refactored_code: str) -> float:
    result = bert_code.analyze_code_pair(original_code, refactored_code, filename="temp")
    similarity_percent = 100 - result["semantic_difference_percent"]
    divergence = result["semantic_difference_percent"]
    return divergence

def evaluate_all_techniques(source_dir: str = "source"):
    programs = list(Path(source_dir).glob("*.py"))
    if not programs:
        raise ValueError(f"No .py files in {source_dir}")

    print(f"Evaluating {len(refactor_classes)} techniques on {len(programs)} programs...")

    technique_divergence = defaultdict(list)

    for prog_path in programs:
        code = read_code(prog_path)
        for tech_name in refactor_classes:
            try:
                variant = apply_technique(code, tech_name)
                div = measure_divergence(code, variant)
                technique_divergence[tech_name].append(div)
            except Exception as e:
                print(f"  [Failed] {tech_name} on {prog_path.name}: {e}")
                technique_divergence[tech_name].append(0)

    mean_divergence = {tech: np.mean(scores) for tech, scores in technique_divergence.items()}
    return mean_divergence

def select_top_divergent_pipelines(source_dir: str = "source", num_pipelines: int = 4, tech_per_pipeline: int = 4):
    programs = list(Path(source_dir).glob("*.py"))
    if len(programs) == 0:
        raise ValueError("No programs found!")

    available_techniques = list(refactor_classes.keys())
    used_techniques = set()
    pipelines = []

    print(f"\nBuilding {num_pipelines} pipelines × {tech_per_pipeline} techniques (max diversity)...")

    for pipe_idx in range(num_pipelines):
        print(f"\n[Pipeline {pipe_idx + 1}/{num_pipelines}] Selecting {tech_per_pipeline} techniques...")
        pipeline = []
        candidates = [t for t in available_techniques if t not in used_techniques]

        for pos in range(tech_per_pipeline):
            best_tech = None
            best_score = -1

            for tech in candidates:
                total_div = 0
                success_count = 0

                for prog_path in programs:
                    code = read_code(prog_path)
                    temp_code = apply_pipeline(code, pipeline)
                    try:
                        final_code = apply_technique(temp_code, tech)
                        div = measure_divergence(code, final_code)
                        total_div += div
                        success_count += 1
                    except:
                        continue

                if success_count > 0:
                    avg_div = total_div / success_count
                    if avg_div > best_score:
                        best_score = avg_div
                        best_tech = tech

            if best_tech is None:
                print("  No more valid techniques.")
                break

            pipeline.append(best_tech)
            candidates.remove(best_tech)
            used_techniques.add(best_tech)
            print(f"  → Added: {best_tech} (divergence: {best_score:.2f}%)")

        pipelines.append(pipeline)
        print(f"  Pipeline {pipe_idx + 1}: {pipeline}")

    return pipelines

def generate_pipeline_variants(pipelines, source_dir="source", target_base="target_divergent"):
    os.makedirs(target_base, exist_ok=True)
    programs = list(Path(source_dir).glob("*.py"))

    for idx, pipeline in enumerate(pipelines, 1):
        pipe_dir = Path(target_base) / f"pipeline_{idx}_divergent"
        shutil.rmtree(pipe_dir, ignore_errors=True)
        pipe_dir.mkdir(parents=True)

        print(f"\nGenerating Pipeline {idx}: {pipeline}")

        for prog_path in programs:
            code = read_code(prog_path)
            refactored = apply_pipeline(code, pipeline)
            output_path = pipe_dir / prog_path.name
            output_path.write_text(refactored, encoding="utf-8")

        print(f"  → Saved {len(programs)} files → {pipe_dir}")

    print(f"\nAll done! 4 highly divergent pipelines saved in '{target_base}'")

def main():
    print("Step 1: Evaluating individual technique divergence...")
    individual_scores = evaluate_all_techniques("source")

    print("\nTop individual techniques (by divergence):")
    for tech, score in sorted(individual_scores.items(), key=lambda x: x[1], reverse=True)[:10]:
        print(f"  {tech:20} → {score:6.2f}% divergence")

    print("\nStep 2: Building 4 maximally divergent, non-overlapping pipelines...")
    pipelines = select_top_divergent_pipelines(
        source_dir="source",
        num_pipelines=4,
        tech_per_pipeline=4
    )

    for i, p in enumerate(pipelines, 1):
        print(f"Pipeline {i}: {p}")

    print("\nStep 3: Generating refactored variants...")
    generate_pipeline_variants(pipelines)

    print("\nSuccess: Created 4 highly divergent refactoring pipelines!")

if __name__ == "__main__":
    main()