import sys
var_1 = None
var_0 = None
try:
    var_1 = sys.getdlopenflags()
except AttributeError:
    from OpenSSL import crypto
else:
    try:
        try:
            import DLFCN
            var_0 = DLFCN.RTLD_NOW | DLFCN.RTLD_GLOBAL
        except ImportError:
            try:
                import dl
                var_0 = dl.RTLD_NOW | dl.RTLD_GLOBAL
            except ImportError:
                try:
                    import ctypes
                    var_0 = 2 | ctypes.RTLD_GLOBAL
                except ImportError:
                    var_0 = 2
    finally:
        if var_0 is not None:
            try:
                sys.setdlopenflags(var_0)
            except Exception:
                pass
try:
    from OpenSSL import crypto
finally:
    if var_1 is not None:
        try:
            sys.setdlopenflags(var_1)
        except Exception:
            pass
from OpenSSL import rand, SSL
from OpenSSL.version import __version__
__all__ = ['rand', 'crypto', 'SSL', '__version__']