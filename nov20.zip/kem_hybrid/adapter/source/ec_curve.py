from cryptography.hazmat.primitives.asymmetric import ec

class ECAdapter:

    def generate_private_key(self):
        return ec.generate_private_key(ec.SECP384R1())

    def exchange(self, private_key, peer_public_key):
        return private_key.exchange(ec.ECDH(), peer_public_key)

    def get_public_key(self, peer_private_key):
        return peer_private_key.public_key()

