import ast


class CryptoVarExtractor(ast.NodeTransformer):

    def __init__(self):
        self.next_var_id = 0
        self.pending_assigns = []

    def _new_var(self):
        name = f"cond_{self.next_var_id}"
        self.next_var_id += 1
        return name

    def _extract_expr(self, node):
        var_name = self._new_var()

        assign = ast.Assign(
            targets=[ast.Name(id=var_name, ctx=ast.Store())],
            value=node,
        )
        ast.fix_missing_locations(assign)

        self.pending_assigns.append(assign)

        return ast.Name(id=var_name, ctx=ast.Load())

    def visit_Compare(self, node):
        self.generic_visit(node)
        return self._extract_expr(node)

    def visit_BoolOp(self, node):
        self.generic_visit(node)
        return self._extract_expr(node)

    def _visit_block(self, stmts):
        new_body = []

        for stmt in stmts:
            result = self.visit(stmt)

            if isinstance(result, list):
                new_body.extend(result)
            else:
                new_body.append(result)

        return new_body

    def _inject_before(self, stmt):
        stmt = self.generic_visit(stmt)

        if self.pending_assigns:
            nodes = self.pending_assigns + [stmt]
            self.pending_assigns = []
            return nodes

        return stmt

    def visit_Assign(self, node):
        return self._inject_before(node)

    def visit_Expr(self, node):
        return self._inject_before(node)

    def visit_For(self, node):
        node.target = self.visit(node.target)
        node.iter = self.visit(node.iter)

        assigns = self.pending_assigns
        self.pending_assigns = []

        node.body = self._visit_block(node.body)
        node.orelse = self._visit_block(node.orelse)

        if assigns:
            return assigns + [node]

        return node


    def visit_If(self, node):
        
        node.test = self.visit(node.test)

        assigns = self.pending_assigns
        self.pending_assigns = []

        node.body = self._visit_block(node.body)
        node.orelse = self._visit_block(node.orelse)

        if assigns:
            return assigns + [node]

        return node

    def visit_While(self, node):
        node.test = self.visit(node.test)

        assigns = self.pending_assigns
        self.pending_assigns = []

        node.body = self._visit_block(node.body)
        node.orelse = self._visit_block(node.orelse)

        if assigns:
            recompute = []
            for a in assigns:
                recompute.append(
                    ast.Assign(
                        targets=a.targets,
                        value=a.value
                    )
                )

            node.body.extend(recompute)

            return assigns + [node]

        return node

    def visit_FunctionDef(self, node):
        node.body = self._visit_block(node.body)
        return node

    def get_refactored_code(self, source_code):
        tree = ast.parse(source_code)

        self.next_var_id = 0
        self.pending_assigns = []

        new_tree = self.visit(tree)
        ast.fix_missing_locations(new_tree)

        return ast.unparse(new_tree)