from cryptography.hazmat.primitives.asymmetric import mldsa


def ed_pub_from_bytes(raw: bytes) -> mldsa.MLDSA65PublicKey:
    pub_key: mldsa.MLDSA65PublicKey = mldsa.MLDSA65PublicKey.from_public_bytes(raw)
    return pub_key

def ed_priv_gen() -> mldsa.MLDSA65PrivateKey:
    priv_key: mldsa.MLDSA65PrivateKey = mldsa.MLDSA65PrivateKey.generate()
    return priv_key
