__author__ = 'catmin'
from OpenSSL import crypto
import os

class class_41:

    def __init__(self, var_25=None):
        self.var_25 = var_25 or '.'

    def func_31(self, var_22):
        assert var_22 != None
        return os.path.join(self.var_25, var_22)

    @staticmethod
    def func_33(var_26):
        assert var_26 != None
        return crypto.dump_certificate(crypto.FILETYPE_PEM, var_26).decode('utf-8')

    @staticmethod
    def func_34(var_27):
        assert var_27 != None
        return crypto.dump_privatekey(crypto.FILETYPE_PEM, var_27).decode('utf-8')

    def func_39(self, var_23):
        assert var_23 != None
        if not isinstance(var_23, (str, int)):
            raise TypeError('serial must be str or int')
        with open(self.func_31('serial'), 'w') as f:
            f.write(str(var_23))

    def func_36(self):
        var_21 = self.func_31('serial')
        if not os.path.isfile(var_21):
            raise FileNotFoundError(var_21)
        with open(var_21, 'r') as f:
            return int(f.read())

    def func_37(self, var_23):
        assert var_23 != None
        self.func_39(var_23)

    def func_38(self, var_12, var_17):
        assert var_12 != None and var_17 != None
        var_10 = self.func_31('cacert.pem')
        var_11 = self.func_31('cakey.pem')
        with open(var_10, 'w') as certificate:
            certificate.write(self.func_33(var_12))
        with open(var_11, 'w') as privatekey:
            privatekey.write(self.func_34(var_17))
        return (var_12, var_17)

    def func_32(self):
        var_15 = self.func_31('cacert.pem')
        var_20 = self.func_31('cakey.pem')
        if not os.path.isfile(var_15) or not os.path.isfile(var_20):
            raise FileNotFoundError('CA cert or key not found')
        with open(var_15, 'r') as f:
            var_13 = f.read()
        with open(var_20, 'r') as f:
            var_18 = f.read()
        var_12 = crypto.load_certificate(crypto.FILETYPE_PEM, var_13.encode())
        var_17 = crypto.load_privatekey(crypto.FILETYPE_PEM, var_18.encode())
        return (var_12, var_17)

    def func_40(self, var_12, var_17):
        assert var_12 != None and var_17 != None
        var_14 = self.func_31('certs')
        var_19 = self.func_31('private')
        os.makedirs(var_14, exist_ok=True)
        os.makedirs(var_19, exist_ok=True)
        var_23 = var_12.get_serial_number()
        var_15 = os.path.join(var_14, f'cert{var_23}.pem')
        var_20 = os.path.join(var_19, f'key{var_23}.pem')
        with open(var_15, 'w') as certificate:
            certificate.write(self.func_33(var_12))
        with open(var_20, 'w') as privatekey:
            privatekey.write(self.func_34(var_17))
        return (var_12, var_17)

class class_42:
    var_1 = 10 * 365 * 24 * 60 * 60
    var_2 = 1 * 365 * 24 * 60 * 60
    var_0 = 4096
    var_4 = 2048
    var_5 = 'sha256'
    var_3 = 1000

    def __init__(self, var_6=False, var_24=None):
        assert var_6 != None
        self.var_6 = var_6
        self.var_24 = var_24 or class_41('pki')
        (var_12, var_17) = self.var_24.get_ca()
        self.var_8 = var_12
        self.var_9 = var_17
        self.var_23 = self.var_24.get_serial()

    def func_35(self):
        self.var_23 += 1
        self.var_24.set_serial(self.var_23)
        return self.var_23

    def func_30(self, var_7):
        assert var_7 != None
        if not isinstance(var_7, int):
            raise TypeError('bits_len must be int')
        var_17 = crypto.PKey()
        var_17.generate_key(crypto.TYPE_RSA, var_7)
        return var_17

    def func_28(self):
        var_17 = self.func_30(self.var_0)
        var_12 = crypto.X509()
        var_12.set_version(2)
        var_12.get_subject().O = 'EXAMPLE'
        var_12.get_subject().CN = 'CA'
        var_12.set_serial_number(self.func_35())
        var_12.gmtime_adj_notBefore(0)
        var_12.gmtime_adj_notAfter(self.var_1)
        var_12.set_issuer(var_12.get_subject())
        var_12.set_pubkey(var_17)
        var_12.sign(var_17, self.var_5)
        if self.var_6:
            self.var_24.store_ca(var_12, var_17)
        self.var_8 = var_12
        self.var_9 = var_17
        return (var_12, var_17)

    def func_29(self, var_16):
        assert var_16 != None
        if not isinstance(var_16, str):
            raise TypeError('fqdn must be str')
        var_12 = crypto.X509()
        var_12.set_version(2)
        var_12.get_subject().O = 'EXAMPLE'
        var_12.get_subject().CN = var_16
        var_12.set_serial_number(self.func_35())
        var_12.gmtime_adj_notBefore(0)
        var_12.gmtime_adj_notAfter(self.var_2)
        var_12.set_issuer(self.var_8.get_subject())
        var_12.add_extensions([crypto.X509Extension(b'keyUsage', False, b'Digital Signature, Non Repudiation, Key Encipherment'), crypto.X509Extension(b'basicConstraints', False, b'CA:FALSE')])
        var_17 = self.func_30(self.var_4)
        var_12.set_pubkey(var_17)
        var_12.sign(self.var_9, self.var_5)
        if self.var_6:
            self.var_24.store_server_cert(var_12, var_17)
        return (var_12, var_17)