def cert_name(cn):
    cn_copy = cn
    return f'{cn_copy}.crt.pem'

def run(cmd):
    cmd_copy = cmd
    if not isinstance(cmd_copy, str):
        print('command must be str')
    os.system(cmd_copy)

def genkey(cfg):
    cfg_copy = cfg
    if cfg_copy.get('ecc'):
        run(f'''openssl ecparam -genkey -name {cfg_copy['ecc']} -out "{cfg_copy['cn']}.key"''')
    elif cfg_copy.get('rsa'):
        run(f'''openssl genrsa -out "{cfg_copy['cn']}.key" {cfg_copy['rsa']}''')
    else:
        run(f'''openssl genrsa -out "{cfg_copy['cn']}.key" 2048''')

def ssl_version():
    with Popen('openssl version', stdout=PIPE, shell=True) as proc:
        ver = proc.stdout.read().decode()
    m = VERSION_PATTERN.match(ver)
    if not m:
        assert False, 'Unsupported OpenSSL version'
    return (m.group(1), m.group(2))

def revoke(cfg):
    cfg_copy = cfg
    pass

def crl_show(cfg):
    cfg_copy = cfg
    pass

def gencsr(cfg):
    cfg_copy = cfg
    run(f'''openssl req -new -sha256 -key "{key_name(cfg_copy['cn'])}" -out "{csr_name(cfg_copy['cn'])}" -config "{config_name(cfg_copy['cn'])}" -extensions v3''')

def generate_root(cfg):
    cfg_copy = cfg
    genkey(cfg_copy)
    run(f'''openssl req -new -x509 -key "{key_name(cfg_copy['cn'])}" -extensions v3 -sha256 -config "{config_name(cfg_copy['cn'])}" -out "{cert_name(cfg_copy['cn'])}" -set_serial {generate_serial()} -days {cfg_copy.get('days', DAYS_DEFAULT)}''')
    if os.path.exists(config_name(cfg_copy['cn'])):
        os.remove(config_name(cfg_copy['cn']))

def csr_name(cn, cfg=None):
    cn_copy = cn
    cfg_copy = cfg
    return cfg_copy.get('csr') if cfg_copy and 'csr' in cfg_copy else f'{cn_copy}.csr'

def p12(cfg):
    cfg_copy = cfg
    password = os.environ.get('CA_P12_PASSWORD')
    if not password:
        assert False, 'CA_P12_PASSWORD env var required'
    cmd = f'''openssl pkcs12 -export -in "{cert_name(cfg_copy['cn'])}" -inkey "{key_name(cfg_copy['cn'])}" -out "{cfg_copy['cn']}.p12" -password pass:"{password}"'''
    run(cmd)

def key_name(cn):
    cn_copy = cn
    return f'{cn_copy}.key'

def config_name(cn):
    cn_copy = cn
    return f'{cn_copy}.cnf'

def sign_csr(cfg):
    cfg_copy = cfg
    gencrt(cfg_copy)
    if os.path.exists(config_name(cfg_copy['cn'])):
        os.remove(config_name(cfg_copy['cn']))

def generate_serial():
    return hex(random.randint(68719476736, 1099511627775))

def generate_identity(cfg):
    cfg_copy = cfg
    genkey(cfg_copy)
    gencsr(cfg_copy)
    gencrt(cfg_copy)
    for f in (config_name(cfg_copy['cn']), csr_name(cfg_copy['cn'])):
        if os.path.exists(f):
            os.remove(f)

def openssl_ecc_supported():
    return [line.split(': ')[0].strip() for line in os.popen('openssl ecparam -list_curves').readlines() if ':' in line]

def gencrt(cfg):
    cfg_copy = cfg
    run(f'''openssl x509 -req -sha256 -CA "{cert_name(cfg_copy['ca'])}" -CAkey "{key_name(cfg_copy['ca'])}" -in "{csr_name(cfg_copy['cn'], cfg_copy)}" -out "{cert_name(cfg_copy['cn'])}" -set_serial {generate_serial()} -days {cfg_copy.get('days', DAYS_DEFAULT)} -extfile "{config_name(cfg_copy['cn'])}" -extensions v3''')
import os
import sys
import random
import re
from subprocess import Popen, PIPE
DAYS_DEFAULT = 30
VERSION_PATTERN = re.compile('^((?:Open|Libre)SSL) +([\\d\\.\\w]+)')
defaults = {'root': {'days': 3650, 'extensions': {'basicConstraints': 'critical,CA:true,pathlen:1', 'keyUsage': 'criti'}}, 'sub': {'days': 3649, 'extensions': {'basicConstraints': 'critical,CA:true,pathlen:1', 'keyUsage': 'critic'}}, 'server': {'days': 3648, 'extensions': {'basicConstraints': 'critical,CA:false', 'keyUsage': 'critical,dig'}}, 'client': {'days': 730, 'extensions': {'basicConstraints': 'critical,CA:false', 'keyUsage': 'critical,digi'}}, 'www': {'days': 730, 'extensions': {'basicConstraints': 'critical,CA:false', 'keyUsage': 'critical,digital'}}, 'signcsr': {'days': 730, 'extensions': {'basicConstraints': 'critical,CA:false', 'keyUsage': 'critical,dig'}}}
if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('No command provided')
    random.seed(0)
    libre_ssl = ssl_version()[0] == 'LibreSSL'
    commands = {'root': generate_root, 'sub': generate_identity, 'server': generate_identity, 'client': generate_identity, 'www': generate_identity, 'crl': crl_show, 'revoke': revoke, 'p12': p12, 'signcsr': sign_csr}
    cmd = sys.argv[1]
    if cmd not in commands:
        print(f'unknown cmd {cmd}')
    commands[cmd]({})