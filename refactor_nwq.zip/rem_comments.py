import ast
import random
import re

HEX_PATTERN = re.compile(r"0x[0-9A-Fa-f]+")

class DocstringRemover(ast.NodeTransformer):
        def visit_Module(self, node):
            if node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Str):
                node.body.pop(0)
            self.generic_visit(node)
            return node
        
        def visit_FunctionDef(self, node):
            if node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Str):
                node.body.pop(0)
            self.generic_visit(node)
            return node
        
        def visit_ClassDef(self, node):
            if node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Str):
                node.body.pop(0)
            self.generic_visit(node)
            return node

    
    

def get_refactored_code(self, source_code):
        hex_literals = HEX_PATTERN.findall(source_code)
        try:
            tree = ast.parse(source_code)
            transformer = DocstringRemover()
            modified_tree = transformer.visit(tree)
            result = ast.unparse(modified_tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")

        for hx in hex_literals:
            dec = str(int(hx, 16))
            result = result.replace(dec, hx)

        return result
