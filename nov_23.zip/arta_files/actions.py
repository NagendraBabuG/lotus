import libcst as cst
import libcst.matchers as m

from libcst.metadata import FullyQualifiedNameProvider, FullRepoManager, QualifiedNameProvider, MetadataWrapper, ScopeProvider
from libcst import FlattenSentinel
import textwrap

def update_imports(tree, import_statements):
    class UpdateImportsNacl(cst.CSTTransformer):
        def __init__(self, new_imports):
            self.new_imports = [cst.parse_statement(stmt).body[0] for stmt in new_imports]


        def leave_Module(self, original_node, updated_node) -> cst.Module:
            imports = [
                stmt for stmt in updated_node.body
                if isinstance(stmt, cst.SimpleStatementLine)
                and any(isinstance(el, (cst.Import, cst.ImportFrom)) for el in stmt.body)
            ]

            all_imports = imports + self.new_imports

            seen = set()
            unique_imports = []
            for stmt in all_imports:
                if not isinstance(stmt, cst.SimpleStatementLine):
                    stmt = cst.SimpleStatementLine(body=[stmt])
                code = updated_node.code_for_node(stmt).strip()
                if code not in seen:
                    seen.add(code)
                    unique_imports.append(stmt)

            non_imports = [
                stmt for stmt in updated_node.body
                if not (
                    isinstance(stmt, cst.SimpleStatementLine)
                    and any(isinstance(el, (cst.Import, cst.ImportFrom)) for el in stmt.body)
                )
            ]

            if unique_imports and non_imports:
                unique_imports.append(cst.EmptyLine())

            return updated_node.with_changes(body=unique_imports + non_imports)

    transformer = UpdateImportsNacl(import_statements)
    return tree.visit(transformer)

def remove_imports(tree):
    class UpdateImports(cst.CSTTransformer):

        classical_names = {
            "ed25519",
            "ed448",
            "rsa",
            "ec",
            "dsa",
            "x25519",
            "x448",
        }

        classical_modules = {
            "cryptography.hazmat.primitives.asymmetric.ed25519",
            "cryptography.hazmat.primitives.asymmetric.ed448",
            "cryptography.hazmat.primitives.asymmetric.rsa",
            "cryptography.hazmat.primitives.asymmetric.ec",
            "cryptography.hazmat.primitives.asymmetric.dsa",
            "cryptography.hazmat.primitives.asymmetric.x25519",
            "cryptography.hazmat.primitives.asymmetric.x448",
        }

        def get_module_name(self, module):
            if isinstance(module, cst.Name):
                return module.value

            if isinstance(module, cst.Attribute):
                parts = []
                node = module

                while isinstance(node, cst.Attribute):
                    parts.append(node.attr.value)
                    node = node.value

                if isinstance(node, cst.Name):
                    parts.append(node.value)

                return ".".join(reversed(parts))

            return None

        def leave_Import(self, original_node, updated_node):
            filtered_names = []

            for name in updated_node.names:
                module_name = self.get_module_name(name.name)

                if module_name and module_name.startswith("nacl"):
                    continue

                if module_name in self.classical_modules:
                    continue

                filtered_names.append(name)

            if not filtered_names:
                return cst.RemoveFromParent()

            return updated_node.with_changes(names=filtered_names)

        def leave_ImportFrom(self, original_node, updated_node):
            if not updated_node.module:
                return updated_node

            module_name = self.get_module_name(updated_node.module)

            if not module_name:
                return updated_node

            if module_name.startswith("nacl"):
                return cst.RemoveFromParent()

            if module_name in self.classical_modules:
                return cst.RemoveFromParent()

            if module_name == "cryptography.hazmat.primitives.asymmetric":
                filtered_names = [
                    name
                    for name in updated_node.names
                    if not (
                        isinstance(name, cst.ImportAlias)
                        and isinstance(name.name, cst.Name)
                        and name.name.value in self.classical_names
                    )
                ]

                if not filtered_names:
                    return cst.RemoveFromParent()

                return updated_node.with_changes(
                    names=tuple(
                        name.with_changes(comma=cst.MaybeSentinel.DEFAULT)
                        for name in filtered_names[:-1]
                    ) + (
                        filtered_names[-1].with_changes(
                            comma=cst.MaybeSentinel.DEFAULT
                        ),
                    )
                )

            return updated_node
        
    transformer = UpdateImports()
    return tree.visit(transformer)




temp_map = {}

def get_pqc_sign(key):
    class_to_pqc_ds = {
        "ECC-256": "MLDSA_44",
        "ECC-1024": "MLDSA_65",
        "ECC-2048": "MLDSA_87",
        "RSA-256": "MLDSA_44",
        "RSA-1024": "MLDSA_65",
        "RSA-2048": "MLDSA_87",
        "DSA-256": "MLDSA_44",
        "DSA-1024": "MLDSA_65",
        "DSA-2048": "MLDSA_87"}
    if key not in class_to_pqc_ds: return "MLDSA_65"
     
    return class_to_pqc_ds[key]
    
def get_ec_curve_ds_alternate(curve):
    #mldsa 44 < 128  65 < 256  87 >=256
    if curve == "secp256r1" or curve == "secp384r1" or curve == "secp256k1" or curve == "sect409k1" or curve == "sect409r1" or curve == "sect283k1" or curve == "sect283r1":
        return "MLDSA_65"
    elif curve == "secp521r1" or curve == "sect571k1" or curve == "sect571r1": return "MLDSA_87"
    elif curve == "secp224r1" or curve == "secp192r1" or curve == "sect233k1" or curve == "sect163k1" or curve == "sect233r1"or curve == "sect163r2":
        return "MLDSA_44"
    elif curve == "ECDH" or curve == "ECDSA":
        return "MLDSA_65"
    else:
        return "MLDSA_65"

def get_ec_curve_kem_alternate(curve):
    if curve == "p256":
        return "MLKEM_768"
    if curve == "secp256r1" or curve == "secp384r1" or curve == "secp256k1" or curve == "sect409k1" or curve == "sect409r1" or curve == "sect283k1" or curve == "sect283r1":
        return "MLKEM_768"
    elif curve == "secp521r1" or curve == "sect571k1" or curve == "sect571r1": return "MLKEM_1024"
    elif curve == "secp224r1" or curve == "secp192r1" or curve == "sect233k1" or curve == "sect163k1" or curve == "sect233r1"or curve == "sect163r2":
        return "MLKEM_512"
    elif curve == "ECDH" or curve == "ECDSA":
        return "MLKEM_768"
    else:
        return "MLKEM_768"




def return_empty_list(tree):
    return []

def return_tree(tree, **args):
    return tree
def set_primitive(tree):
    #needs to add
    return tree

def add_hash_nodes(tree):
    #needse to add
    return tree

def remove_public_key(tree, mappings):
    #needs to add
    return tree

def update_imports_cryptography(tree):


    return tree


def record_keypair_ids_pycryptodome(tree):
    mappings = {}
    class CheckCryptographyImport(cst.CSTVisitor):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def __init__(self, metadata_wrapper):
            super().__init__()
            self.metadata_wrapper = metadata_wrapper

        def visit_Assign(self, node):
            if not m.matches(node, m.Assign(value=m.Call())):
                return

            qualified_names = self.get_metadata(QualifiedNameProvider, node.value.func, default=None)
            if not qualified_names:
                return

            qualified_names = [q.name for q in qualified_names]

            
            if any(name.endswith("RSA.generate") for name in qualified_names):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("generate"))))):
                    mappings["private_key"] = node.targets[0].target.value
                    mappings['algorithm'] = 'RSA'
            elif any(name.endswith("DSA.generate") for name in qualified_names):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("generate"))))):
                    mappings["private_key"] = node.targets[0].target.value
                    mappings['algorithm'] = 'DSA'
            elif any(name.endswith("ECC.generate") for name in qualified_names):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("generate"))))):
                    mappings["private_key"] = node.targets[0].target.value
                    mappings['algorithm'] = 'ECC'
            elif any(name.endswith("sign") for name in qualified_names):
                    mappings["signature"] = node.targets[0].target.value
                    mappings["signing_key"] = node.value.func.value.args[0].value.value
            elif  any(name.endswith("sign") for name in qualified_names):
                if "signature" not in mappings.keys():
                    mappings["signature"] = node.targets[1].target.value
                    mappings["verifying_key"] = node.value.func.args[0].value.value
            if any(name.endswith("SHA256.new") for name in qualified_names):
                arg_key = node.value.args[0].value.value
                mappings["message"] = arg_key
    wrapper = MetadataWrapper(tree)
    mappings['algorithm'] = 'na'
    visitor = CheckCryptographyImport(wrapper)
    wrapper.visit(visitor)
    return mappings


def record_keypair_ids_nacl(tree):
    mappings = {}

    class CheckNaClImport(cst.CSTVisitor):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def __init__(self, metadata_wrapper):
            super().__init__()
            self.metadata_wrapper = metadata_wrapper
            self.key_ind = 0
            self.pk_ind = 0
        def visit_Assign(self, node):
            if not m.matches(node, m.Assign(value=m.Call())) and not m.matches(node, m.Assign(value=m.Attribute())):
                return

            qualified_names = self.get_metadata(QualifiedNameProvider, node.value.func if m.matches(node, m.Assign(value=m.Call())) else node.value, default=None)
            if not qualified_names:
                return

            qualified_names = [q.name for q in qualified_names]
            if any(name.endswith("public_key") for name in qualified_names):
                if isinstance(node.targets[0].target, cst.Name):
                    pkname = f"pub_key_{self.pk_ind}"
                    mappings[pkname] = node.targets[0].target.value
            if any(name == "nacl.signing.SigningKey.generate" for name in qualified_names):
                if isinstance(node.targets[0].target, cst.Name):
                    mappings["private_key"] = node.targets[0].target.value

            elif any(name == "nacl.signing.SigningKey.verify_key" for name in qualified_names):
                if isinstance(node.targets[0].target, cst.Name):
                    mappings["public_key"] = node.targets[0].target.value

        def visit_Call(self, node):
            if not isinstance(node.func, cst.Attribute):
                return

            qualified_names = self.get_metadata(QualifiedNameProvider, node.func, default=None)
            if not qualified_names:
                return

            qualified_names = [q.name for q in qualified_names]

            if any(name.endswith("PrivateKey.generate") for name in qualified_names):
                keyname = f"priv_key_{self.key_ind}"
                self.key_ind += 1
                if hasattr(node, "_parent_node") and m.matches(node._parent_node, m.Assign()):
                    for target in node._parent_node.targets:
                        if isinstance(target.target, cst.Name):
                            mappings[keyname] = target.target.value

            

            if any(name.endswith("sign") for name in qualified_names):
                if node.args:
                    arg = node.args[0]
                    mappings["message"] = arg.value.value
                   
                if isinstance(node.func.value, cst.Name):
                    mappings["signing_key"] = node.func.value.value

                if hasattr(node, "_parent_node") and m.matches(node._parent_node, m.Assign()):
                    for target in node._parent_node.targets:
                        if isinstance(target.target, cst.Name):
                            mappings["signature"] = target.target.value

            elif any(name == "nacl.signing.VerifyKey.encode" for name in qualified_names):
               
                if hasattr(node, "_parent_node") and m.matches(node._parent_node, m.Assign()):
                    for target in node._parent_node.targets:
                        if isinstance(target.target, cst.Name):
                            mappings["verifying_key"] = target.target.value

    wrapper = MetadataWrapper(tree)
    visitor = CheckNaClImport(wrapper)
    wrapper.visit(visitor)
    return mappings





def record_keypair_ids_cryptography(tree):
    mappings = {}
    
    class CheckCryptographyImport(cst.CSTVisitor):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)
        def get_target_name(self, target):
            if isinstance(target, cst.Name):
                return target.value

            if isinstance(target, cst.Attribute):
                return cst.helpers.get_full_name_for_node(target)

            return None

        def __init__(self, metadata_wrapper):
            super().__init__()
            self.metadata_wrapper = metadata_wrapper
        def leave_Assign(self, node):
            if not m.matches(node, m.Assign(value=m.Call())):
                return

            qualified_names = self.get_metadata(QualifiedNameProvider, node.value.func, default=None)
            
            if not qualified_names:
                return

            qualified_names = [q.name for q in qualified_names]
            
            if any(name == "cryptography.hazmat.primitives.asymmetric.rsa.generate_private_key" for name in qualified_names):
                if "private_key" not in mappings:
                    mappings["private_key"] = []
                mappings["private_key"].append(self.get_target_name(node.targets[0].target))
                
                mappings['algorithm'] = 'rsa'
                mappings["pqc_alg"] = "MLDSA_65"
                key_size = 256
                for arg in node.value.args:
                    if arg.keyword and arg.keyword.value == "key_size":
                        if isinstance(arg.value, cst.Integer):
                            key_size = int(arg.value.value)
                        else: key_size = None
                        break
                mappings["pqc_alg"] = get_pqc_ds_with_keysize_rsa_or_dsa(key_size)
                
            elif any(name == "cryptography.hazmat.primitives.asymmetric.dsa.generate_private_key" for name in qualified_names):
                if isinstance(node.targets[0].target, cst.Name):
                    if "private_key" not in mappings:
                        mappings["private_key"] = []
                    mappings["private_key"].append(self.get_target_name(node.targets[0].target))
                    mappings['algorithm'] = 'dsa'
                    key_size = 256
                    for arg in node.value.args:
                        if arg.keyword and arg.keyword.value == "key_size":
                            if isinstance(arg.value, cst.Integer):
                                key_size = int(arg.value.value)
                            else: key_size = None
                            break
                    mappings["pqc_alg"] = get_pqc_ds_with_keysize_rsa_or_dsa(key_size)
            
            elif any(name == "cryptography.hazmat.primitives.asymmetric.rsa.RSAPrivateKey.public_key" for name in qualified_names):
                mappings["public_key"] = self.get_target_name(node.targets[0].target)
                mappings['algorithm'] = 'rsa' 
            elif any(name == "cryptography.hazmat.primitives.asymmetric.ec.ECPrivateKey.public_key" for name in qualified_names):
                if isinstance(node.targets[0].target, cst.Name):
                    mappings["public_key"] = self.get_target_name(node.targets[0].target)
                    mappings['algorithm']='ec'
            elif any(name.endswith("X25519PrivateKey.generate") for name in qualified_names):
                mappings["kem_private_generate"] = self.get_target_name(node.targets[0].target)
                mappings['algorithm']='x25519'
                priv_key = self.get_target_name(node.targets[0].target)
                if "private_key" not in mappings:
                    mappings["private_key"] = []
                mappings['private_key'].append(priv_key)
            elif any(name.endswith("load_pem_private_key") for name in qualified_names):
                priv_key = self.get_target_name(node.targets[0].target)
                if "private_key" not in mappings:
                    mappings["private_key"] = []
                mappings['private_key'].append(priv_key)

                            
            elif any(name.endswith("Ed25519PrivateKey.generate") for name in qualified_names):
                mappings["kem_private_generate"] = self.get_target_name(node.targets[0].target)
                mappings['algorithm']='Ed25519'
                mappings['pqc_alg'] = 'MLDSA_65'
                if "private_key" not in mappings:
                    mappings["private_key"] = []
                priv_key = self.get_target_name(node.targets[0].target)
                mappings['private_key'].append(priv_key)
            elif any(name.endswith("Ed448PrivateKey.generate") for name in qualified_names):
                mappings['algorithm']='Ed448'
                mappings['pqc_alg'] = 'MLDSA_87'
                priv_key = self.get_target_name(node.targets[0].target)
                if "private_key" not in mappings:
                    mappings["private_key"] = []
                
                mappings['private_key'].append(priv_key)
            elif any(name.endswith("ec.generate_private_key") for name in qualified_names):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("generate_private_key"))))):
                    mappings['algorithm'] = 'ec'
                    mappings["kem_private_generate"] = self.get_target_name(node.targets[0].target)
                    target_var = self.get_target_name(node.targets[0].target)
                    if "private_key" not in mappings:
                        mappings["private_key"] = []
                    mappings["private_key"].append(target_var)
                    #ec_curve = node.value.args[0].value.func.attr.value
                    arg = node.value.args[0].value
                    ec_curve = None

                    if isinstance(arg, cst.Call):

                        if isinstance(arg.func, cst.Attribute):
                            ec_curve = arg.func.attr.value

                        elif isinstance(arg.func, cst.Name):
                            ec_curve = arg.func.value

                    elif isinstance(arg, cst.Attribute):
                        ec_curve = arg.attr.value

                    elif isinstance(arg, cst.Name):
                        ec_curve = arg.value
                    if ec_curve is None: mappings['pqc_alg'] = 'MLDSA_65'
                    else: mappings['pqc_alg'] = get_ec_curve_kem_alternate(ec_curve)

                    if ec_curve is not None: mappings['ec_curve'] = ec_curve
                    if ec_curve is not None: mappings['pqc_alg'] = get_pqc_ds_ec_curve(mappings['ec_curve'])

            #kem 
            elif any(name.endswith("X25519PrivateKey.generate.public_key") for name in qualified_names):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("public_key"))))):
                    target_var = self.get_target_name(node.targets[0].target)
                    mappings['peer_public_key'] = target_var
                    mappings['algorithm'] = 'x25519'
            if any(name.endswith("X448PrivateKey.generate.public_key") for name in qualified_names):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("public_key"))))):
                    target_var = self.get_target_name(node.targets[0].target)
                    mappings['peer_public_key'] = target_var
                    mappings['algorithm'] = 'x448'
            
            if any(name.endswith("exchange") for name in qualified_names):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("exchange"))))):
                    arg = node.value.args[0].value  
                    arg_in_exchange = None
                    if (isinstance(arg, cst.Call) and 
                        isinstance(arg.func, cst.Attribute) and 
                        isinstance(arg.func.value, cst.Name)):
                        arg_in_exchange = arg.func.value.value
                          
                    elif isinstance(arg, cst.Name):
                        arg_in_exchange = arg.value
                    if arg_in_exchange:
                        if 'peer_public_key' in mappings:
                            if isinstance(mappings['peer_public_key'], list):
                                mappings['peer_public_key'].append(arg_in_exchange)
                            else:
                                ls = [mappings['peer_public_key']]
                                ls.append(arg_in_exchange)
                                mappings['peer_public_key'] = ls

                        else:
                            mappings['peer_public_key'] = arg_in_exchange
            if any(name.endswith("dh.generate_parameters") for name in qualified_names):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("generate_parameters"))))):
                
                    target_var = self.get_target_name(node.targets[0].target)  
                    try:
                        call_node = node.value
                        key_size = None
                        for arg in call_node.args:
                            if arg.keyword and arg.keyword.value == "key_size":
                                if isinstance(arg.value, cst.Integer):
                                    key_size = int(arg.value.value)
                                else: key_size = None
                                break
                        mappings['kem_param'] = target_var
                        mappings['kem_key_size'] = key_size
                        mappings['algorithm'] = 'dh'
                    except Exception as e:
                        print('dh error', e)
            if any(name.endswith("dh.generate_parameters.parameter_bytes") for name in qualified_names):
                print('in param call dh param bytes\n')
                target_var = self.get_target_name(node.targets[0].target)  
                target = node.targets[0].target
                if isinstance(target, cst.Attribute):
                    base = cst.helpers.get_full_name_for_node(target.value)
                    attr = target.attr.value
                    target_var = f"{base}.{attr}"
                elif isinstance(target, cst.Name):
                    target_var = target.value
                
                try:
                    call_node = node.value          
                    generate_call = call_node.func.value 
                    key_size = None
                    for arg in generate_call.args:
                        if arg.keyword and arg.keyword.value == "key_size":
                            if isinstance(arg.value, cst.Integer):
                                key_size = int(arg.value.value)
                            else: key_size = None
                            break
                    mappings['kem_param'] = target_var
                    mappings['kem_key_size'] = key_size
                    mappings['algorithm'] = 'dh'
                except Exception as e:
                    print('dh error', e)
            if "kem_param" in mappings and any(name.endswith(f"{mappings['kem_param']}.generate_private_key") for name in qualified_names):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("generate_private_key"))))):
                    target_var = self.get_target_name(node.targets[0].target)  
                    target = node.targets[0].target
                    if isinstance(target, cst.Attribute):
                        base = cst.helpers.get_full_name_for_node(target.value)
                        attr = target.attr.value
                        target_var = f"{base}.{attr}"
                    elif isinstance(target, cst.Name):
                        target_var = target.value
                    
                    mappings['kem_private_generate'] = target_var
            if any(name.endswith("load_der_parameters.generate_private_key") for name in qualified_names):
                target_var = self.get_target_name(node.targets[0].target)  
                target = node.targets[0].target
                if isinstance(target, cst.Attribute):
                    base = cst.helpers.get_full_name_for_node(target.value)
                    attr = target.attr.value
                    target_var = f"{base}.{attr}"
                elif isinstance(target, cst.Name):
                    target_var = target.value
                mappings['kem_private_generate'] = target_var
            
            if any(name.endswith("public_key.public_bytes") for name in qualified_names):
                target_var = self.get_target_name(node.targets[0].target)  
                target = node.targets[0].target
                if isinstance(target, cst.Attribute):
                    base = cst.helpers.get_full_name_for_node(target.value)
                    attr = target.attr.value
                    target_var = f"{base}.{attr}"
                elif isinstance(target, cst.Name):
                    target_var = target.value
                mappings['peer_public_key'] = target_var
            
            
        def visit_Call(self, node):
            if not isinstance(node.func, cst.Attribute):
                return

            qualified_names = self.get_metadata(QualifiedNameProvider, node.func, default=None)
            if not qualified_names:
                return

            qualified_names = [q.name for q in qualified_names]

            if any(name.endswith("sign") for name in qualified_names) and \
               any(name.startswith("cryptography.hazmat.primitives.asymmetric") for name in qualified_names):
                if node.args:
                    mappings["message"] = node.args[0].value.value
                if isinstance(node.func.value, cst.Name):
                    mappings["signing_key"] = node.func.value.value
                if hasattr(node, "_parent_node") and m.matches(node._parent_node, m.Assign()):
                    for target in node._parent_node.targets:
                        if isinstance(target.target, cst.Name):
                            mappings["signature"] = target.target.value

            elif any(name.endswith("verify") for name in qualified_names) and \
                 any(name.startswith("cryptography.hazmat.primitives.asymmetric") for name in qualified_names):
                if node.args:
                    mappings["signature"] = node.args[0].value.value
                if isinstance(node.func.value, cst.Name):
                    mappings["verifying_key"] = node.func.value.value

            elif any(name.startswith("cryptography.hazmat.primitives.hashes") for name in qualified_names):
                mappings["hash_algo"] = node.func.attr.value
                mappings["digest_id"] = "digest"
            

    wrapper = MetadataWrapper(tree)
    mappings['algorithm'] = 'na'
    visitor = CheckCryptographyImport(wrapper)
    wrapper.visit(visitor)
    return mappings





def remove_publickey(tree, mappings):


    class RemovePublicKey(cst.CSTTransformer):
        def leave_Assign(self, original_node, updated_node):
            if isinstance(updated_node.value, cst.Call):
                if isinstance(updated_node.value.func, cst.Attribute) and updated_node.value.func.attr.value == "publickey":
                    return cst.RemoveFromParent()
            return updated_node

    transformer = RemovePublicKey()
    tree = tree.visit(transformer)
    #tree.validate()
    return tree



def has_generate_cryptography(tree):
    class keywordChecker(cst.CSTVisitor):
        value = False
        def visit_Assign(self, node):
            if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name(value="generate"))))) or \
               m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name(value="generate_private_key"))))):
                self.value = True

    obj = keywordChecker()
    tree.visit(obj)
    return obj.value


def has_publickey(tree):
    class pkeyChecker(cst.CSTVisitor):
        value = False
        def visit_Assign(self, node):
            if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name(value="publicKey"))))):
                self.value = True

    obj = pkeyChecker()
    tree.visit(obj)
    return obj.value

def get_pqc_ds_ec_curve(curve):
    if curve is None:
        return "MLDSA65PrivateKey"
    curve = curve.lower()
    # ~128
    if curve in ["secp224r1", "secp192r1", "sect233k1", "sect163k1", "sect233r1", "sect163r2"]:
        return "MLDSA65PrivateKey"
    elif curve in ["secp256r1", "secp256k1", "sect283r1", "sect283k1"]:  # ~192
        return "MLDSA65PrivateKey"
    elif curve in ["secp521r1", "secp384r1", "sect409k1", "sect409r1", "sect571k1", "sect571r1"]:  # ~256
        return "MLDSA87PrivateKey"
    else:
        return "MLDSA87PrivateKey"


def get_pqc_ds_with_keysize_rsa_or_dsa(key_size):
    if key_size is None:
        return "MLDSA87PrivateKey"
    if key_size < 3072:
        return "MLDSA44PrivateKey"
    elif key_size < 7680:
        return "MLDSA65PrivateKey"
    else:
        return "MLDSA87PrivateKey"


def transform_dskeysign_cryptography(tree, mappings, library):
    imp_stmts = []

    class updateSign(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def __init__(self):
            pass

        def get_target_name(self, target):
            if target is None:
                return None
            if isinstance(target, cst.Name):
                return target.value
            elif isinstance(target, cst.Attribute):
                return cst.helpers.get_full_name_for_node(target)
            return None

        def get_node_code(self, node: cst.CSTNode) -> str:
            return cst.Module([]).code_for_node(node)

        def leave_Annotation(self, node: cst.Annotation, updated_node: cst.Annotation) -> cst.Annotation:
            expr_code = self.get_node_code(node.annotation).strip()

            type_mappings = {
                "Ed25519PublicKey": "mldsa.MLDSA65PublicKey",
                "Ed25519PrivateKey": "mldsa.MLDSA65PrivateKey",
                "Ed448PublicKey": "mldsa.MLDSA87PublicKey",
                "Ed448PrivateKey": "mldsa.MLDSA87PrivateKey",
                "RSAPublicKey": "mldsa.MLDSA65PublicKey",
                "RSAPrivateKey": "mldsa.MLDSA65PrivateKey",
                "EllipticCurvePublicKey": "mldsa.MLDSA65PublicKey",
                "EllipticCurvePrivateKey": "mldsa.MLDSA65PrivateKey",
                "DSAPublicKey": "mldsa.MLDSA65PublicKey",
                "DSAPrivateKey": "mldsa.MLDSA65PrivateKey",
            }

            if expr_code in type_mappings:
                imp_stmts.append("from cryptography.hazmat.primitives.asymmetric import mldsa")
                new_type_expr = cst.parse_expression(type_mappings[expr_code])
                return updated_node.with_changes(annotation=new_type_expr)

            return updated_node

        def leave_FunctionDef(self, node: cst.FunctionDef, updated_node: cst.FunctionDef) -> cst.FunctionDef:
            if node.returns:
                returns_code = self.get_node_code(node.returns.annotation).strip()
                if returns_code == "Ed25519PublicKey":
                    imp_stmts.append("from cryptography.hazmat.primitives.asymmetric import mldsa")
                    new_returns = cst.Annotation(
                        annotation=cst.parse_expression("mldsa.MLDSA65PublicKey")
                    )
                    return updated_node.with_changes(returns=new_returns)
            return updated_node

        def leave_Call(self, node: cst.Call, updated_node: cst.Call) -> cst.Call:
            qualified_names = self.get_metadata(QualifiedNameProvider, node)
            qnames = [q.name for q in qualified_names]

            if isinstance(node.func, cst.Name) and node.func.value == "isinstance":
                if len(updated_node.args) >= 2:
                    type_code = self.get_node_code(updated_node.args[1].value).strip()
                    type_mappings = {
                        "Ed25519PublicKey": "mldsa.MLDSA65PublicKey",
                        "Ed25519PrivateKey": "mldsa.MLDSA65PrivateKey",
                        "Ed448PublicKey": "mldsa.MLDSA87PublicKey",
                        "Ed448PrivateKey": "mldsa.MLDSA87PrivateKey",
                        "RSAPublicKey": "mldsa.MLDSA65PublicKey",
                        "RSAPrivateKey": "mldsa.MLDSA65PrivateKey",
                        "EllipticCurvePublicKey": "mldsa.MLDSA65PublicKey",
                        "EllipticCurvePrivateKey": "mldsa.MLDSA65PrivateKey",
                        "DSAPublicKey": "mldsa.MLDSA65PublicKey",
                        "DSAPrivateKey": "mldsa.MLDSA65PrivateKey",
                    }
                    if type_code in type_mappings:
                        imp_stmt = "from cryptography.hazmat.primitives.asymmetric import mldsa"
                        if imp_stmt not in imp_stmts:
                            imp_stmts.append(imp_stmt)
                        new_args = list(updated_node.args)
                        new_args[1] = new_args[1].with_changes(
                            value=cst.parse_expression(type_mappings[type_code])
                        )
                        return updated_node.with_changes(args=tuple(new_args))

            if any(name.startswith("cryptography.x509.CertificateBuilder") and name.endswith(".sign") for name in qnames):
                if len(updated_node.args) >= 1:
                    key_arg = updated_node.args[0]
                    remaining_positional = [arg for arg in updated_node.args[2:] if arg.keyword is None]
                    remaining_keywords = [
                        arg for arg in updated_node.args[1:]
                        if arg.keyword is not None and arg.keyword.value != "algorithm"
                    ]
                    null_alg_arg = cst.Arg(value=cst.Name("None"))
                    new_args = (key_arg, *remaining_positional, null_alg_arg, *remaining_keywords)
                    return updated_node.with_changes(args=new_args)

            if isinstance(node.func, cst.Attribute) and node.func.attr.value in ("private_bytes", "public_bytes"):
                new_args = []
                updated_args = False
                for i, arg in enumerate(updated_node.args):
                    is_format_arg = (
                        (arg.keyword is not None and arg.keyword.value == "format")
                        or (arg.keyword is None and i == 1)
                    )
                    is_encoding_arg = (
                        (arg.keyword is not None and arg.keyword.value == "encoding")
                        or (arg.keyword is None and i == 0)
                    )
                    if (
                        (is_format_arg or is_encoding_arg)
                        and isinstance(arg.value, cst.Attribute)
                        and arg.value.attr.value != "Raw"
                    ):
                        new_val = arg.value.with_changes(attr=cst.Name("Raw"))
                        new_args.append(arg.with_changes(value=new_val))
                        updated_args = True
                    else:
                        new_args.append(arg)
                if updated_args:
                    return updated_node.with_changes(args=new_args)

            if any(name.endswith("Ed25519PublicKey.from_public_bytes") for name in qnames):
                imp_stmt = "from cryptography.hazmat.primitives.asymmetric import mldsa"
                if imp_stmt not in imp_stmts:
                    imp_stmts.append(imp_stmt)
                return updated_node.with_changes(
                    func=cst.parse_expression("mldsa.MLDSA65PublicKey.from_public_bytes")
                )
            if any(name.endswith("Ed448PublicKey.from_public_bytes") for name in qnames):
                imp_stmt = "from cryptography.hazmat.primitives.asymmetric import mldsa"
                if imp_stmt not in imp_stmts:
                    imp_stmts.append(imp_stmt)
                return updated_node.with_changes(
                    func=cst.parse_expression("mldsa.MLDSA87PublicKey.from_public_bytes")
                )

            if any(
                name.endswith("load_pem_public_key") or name.endswith("load_der_public_key")
                for name in qnames
            ):
                imp_stmt = "from cryptography.hazmat.primitives.asymmetric import mldsa"
                if imp_stmt not in imp_stmts:
                    imp_stmts.append(imp_stmt)

                if updated_node.args:
                    key_arg = self.get_node_code(updated_node.args[0].value)
                    return cst.parse_expression(
                        f"mldsa.MLDSA65PublicKey.from_public_bytes({key_arg})"
                    )
                return updated_node

            if any(
                name.endswith("load_pem_private_key") or name.endswith("load_der_private_key")
                for name in qnames
            ):
                imp_stmt = "from cryptography.hazmat.primitives.asymmetric import mldsa"
                if imp_stmt not in imp_stmts:
                    imp_stmts.append(imp_stmt)
                if updated_node.args:
                    key_arg = self.get_node_code(updated_node.args[0].value)
                    return cst.parse_expression(
                        f"mldsa.MLDSA65PrivateKey.from_seed_bytes({key_arg})"
                    )
                return updated_node

            return updated_node

        def transform_assignment_value(self, value_node: cst.CSTNode) -> cst.CSTNode:
            if not isinstance(value_node, cst.Call):
                return value_node

            val_code = self.get_node_code(value_node).strip()

            if "Ed25519PublicKey.from_public_bytes" in val_code:
                key_arg = self.get_node_code(value_node.args[0].value)
                imp_stmts.append("from cryptography.hazmat.primitives.asymmetric import mldsa")
                return cst.parse_expression(f"mldsa.MLDSA65PublicKey.from_public_bytes({key_arg})")

            if "Ed25519PrivateKey.generate" in val_code:
                imp_stmts.append("from cryptography.hazmat.primitives.asymmetric import mldsa")
                return cst.parse_expression("mldsa.MLDSA65PrivateKey.generate()")

            if "Ed448PublicKey.from_public_bytes" in val_code:
                key_arg = self.get_node_code(value_node.args[0].value)
                imp_stmts.append("from cryptography.hazmat.primitives.asymmetric import mldsa")
                return cst.parse_expression(f"mldsa.MLDSA87PublicKey.from_public_bytes({key_arg})")

            if "Ed448PrivateKey.generate" in val_code:
                imp_stmts.append("from cryptography.hazmat.primitives.asymmetric import mldsa")
                return cst.parse_expression("mldsa.MLDSA87PrivateKey.generate()")

            return value_node

        def leave_AnnAssign(self, node, updated_node):
            if node.value:
                return updated_node.with_changes(value=self.transform_assignment_value(node.value))
            return updated_node

        def leave_Assign(self, node, updated_node):
            if not isinstance(node.value, cst.Call):
                return updated_node

            qualified_names = self.get_metadata(QualifiedNameProvider, node.value)
            qnames = [q.name for q in qualified_names]

            # Private key from bytes → seed
            if any(name.endswith("Ed25519PrivateKey.from_private_bytes") for name in qnames):
                target_var = self.get_target_name(node.targets[0].target)
                key_arg = self.get_node_code(node.value.args[0].value)
                imp_stmts.append("from cryptography.hazmat.primitives.asymmetric import mldsa")
                new_assign = f"{target_var} = mldsa.MLDSA65PrivateKey.from_seed_bytes({key_arg})"
                return cst.parse_statement(new_assign).body[0]

            if any(name.endswith("Ed448PrivateKey.from_private_bytes") for name in qnames):
                target_var = self.get_target_name(node.targets[0].target)
                key_arg = self.get_node_code(node.value.args[0].value)
                imp_stmts.append("from cryptography.hazmat.primitives.asymmetric import mldsa")
                new_assign = f"{target_var} = mldsa.MLDSA87PrivateKey.from_seed_bytes({key_arg})"
                return cst.parse_statement(new_assign).body[0]

            # Public key from bytes
            if any(name.endswith("Ed25519PublicKey.from_public_bytes") for name in qnames):
                target_var = self.get_target_name(node.targets[0].target)
                key_arg = self.get_node_code(node.value.args[0].value)
                imp_stmts.append("from cryptography.hazmat.primitives.asymmetric import mldsa")
                new_assign = f"{target_var} = mldsa.MLDSA65PublicKey.from_public_bytes({key_arg})"
                return cst.parse_statement(new_assign).body[0]

            if any(name.endswith("Ed448PublicKey.from_public_bytes") for name in qnames):
                target_var = self.get_target_name(node.targets[0].target)
                key_arg = self.get_node_code(node.value.args[0].value)
                imp_stmts.append("from cryptography.hazmat.primitives.asymmetric import mldsa")
                new_assign = f"{target_var} = mldsa.MLDSA87PublicKey.from_public_bytes({key_arg})"
                return cst.parse_statement(new_assign).body[0]

            # generate()
            if any(name.endswith("Ed25519PrivateKey.generate") for name in qnames):
                target_var = self.get_target_name(node.targets[0].target)
                imp_stmts.append("from cryptography.hazmat.primitives.asymmetric import mldsa")
                new_assign = f"{target_var} = mldsa.MLDSA65PrivateKey.generate()"
                return cst.parse_statement(new_assign).body[0]

            if any(name.endswith("Ed448PrivateKey.generate") for name in qnames):
                target_var = self.get_target_name(node.targets[0].target)
                imp_stmts.append("from cryptography.hazmat.primitives.asymmetric import mldsa")
                new_assign = f"{target_var} = mldsa.MLDSA87PrivateKey.generate()"
                return cst.parse_statement(new_assign).body[0]

            # EC / RSA / DSA generate → ML-DSA
            if any(name.endswith("ec.generate_private_key") for name in qnames):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(value=m.Name("ec"), attr=m.Name("generate_private_key"))))):
                    pqc_ds = mappings.get("pqc_alg", "MLDSA65PrivateKey")
                    if "ec_curve" in mappings:
                        pqc_ds = get_pqc_ds_ec_curve(mappings["ec_curve"])
                    target_var = self.get_target_name(node.targets[0].target)
                    new_assign = f"{target_var} = mldsa.{pqc_ds}.generate()"
                    imp_stmts.append("from cryptography.hazmat.primitives.asymmetric import mldsa")
                    return cst.parse_statement(new_assign).body[0]

            if any(
                name == "cryptography.hazmat.primitives.asymmetric.rsa.generate_private_key"
                or name == "cryptography.hazmat.primitives.asymmetric.dsa.generate_private_key"
                for name in qnames
            ):
                call_node = node.value
                key_size = None
                pqc_ds = "MLDSA65PrivateKey"
                target_var = self.get_target_name(node.targets[0].target)
                for arg in call_node.args:
                    if arg.keyword and arg.keyword.value == "key_size":
                        if isinstance(arg.value, cst.Integer):
                            key_size = int(arg.value.value)
                        break
                if key_size is not None:
                    pqc_ds = get_pqc_ds_with_keysize_rsa_or_dsa(key_size)
                imp_stmts.append("from cryptography.hazmat.primitives.asymmetric import mldsa")
                new_assign = f"{target_var} = mldsa.{pqc_ds}.generate()"
                return cst.parse_statement(new_assign).body[0]

            # sign() simplification (already present)
            if "private_key" in mappings:
                valid_signatures = tuple(f"{key}.sign" for key in mappings["private_key"])
                if any(name.endswith(valid_signatures) for name in qnames):
                    if isinstance(node.value, cst.Call) and isinstance(node.value.func, cst.Attribute):
                        target_var = self.get_target_name(node.targets[0].target)
                        caller_name = self.get_node_code(node.value.func.value)
                        msg_arg = self.get_node_code(node.value.args[0].value)
                        new_value = f"{target_var} = {caller_name}.sign({msg_arg})"
                        return updated_node.with_changes(
                            value=cst.parse_statement(new_value).body[0].value
                        )

            return updated_node

    wrapper = MetadataWrapper(tree)
    obj = updateSign()
    tree = wrapper.visit(obj)
    tree = update_imports(tree, imp_stmts)
    tree = remove_imports(tree)
    return tree









    


def set_verify_cryptography(tree, mappings):
    #print('verify cryptography\n')
    class updateVerify(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)
        def get_target_name(self, target):
            if isinstance(target, cst.Name):
                return target.value

            if isinstance(target, cst.Attribute):
                return cst.helpers.get_full_name_for_node(target)

            return None

        def get_node_code(self, node: cst.CSTNode) -> str:
                return cst.Module([]).code_for_node(node)

        def leave_Assign(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value)
            qnames = [q.name for q in qualified_names]

            
            if any(name.endswith("verify") for name in qnames):
                if isinstance(node.value, cst.Call) and isinstance(node.value.func, cst.Attribute):

                    target_var = self.get_target_name(node.targets[0].target)
                    sign_arg = cst.Module([]).code_for_node(node.value.args[0].value)
                    caller_name = self.get_node_code(node.value.func.value)
                    msg_arg = cst.Module([]).code_for_node(node.value.args[1].value)
                    new_value = f"{target_var} = {caller_name}.verify({sign_arg}, {msg_arg})"
                    return cst.parse_statement(new_value).body[0]
            
            return updated_node
        def leave_Expr(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value)
            qnames = [q.name for q in qualified_names]

            if any(name.endswith("verify") for name in qnames):
                if isinstance(node.value, cst.Call) and isinstance(node.value.func, cst.Attribute):
                    sign_arg = cst.Module([]).code_for_node(node.value.args[0].value)
                    msg_arg = cst.Module([]).code_for_node(node.value.args[1].value)
                    caller_name = self.get_node_code(node.value.func.value)
                    new_value = f"{caller_name}.verify({sign_arg}, {msg_arg})"
                    return cst.parse_statement(new_value).body[0]
            return updated_node
    wrapper = MetadataWrapper(tree)
    obj = updateVerify()
    tree = wrapper.visit(obj)
    return tree



def set_sign_cryptography(tree, mappings):
    #print('sign cryptography\n')
    class updateSign(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def leave_Assign(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value)
            qnames_array = [q.name for q in qualified_names]
            #print('cryptography ', qnames_array)

            
            if 'private_key' in mappings and any(name.endswith("sign") for name in qnames_array):

                target_var = node.targets[0].target.value
                pqc_ds = "MLDSA_65"
                if 'pqc_alg' in mappings:
                    pqc_ds = mappings['pqc_alg']
                msg_arg = node.value.args[0].value.value
                new_value = f"{target_var} = {pqc_ds}().sign({mappings['private_key']}, {msg_arg})"
                return cst.parse_statement(new_value).body[0]
            
            elif 'private_key' in mappings and any(name.endswith(f"{mappings['private_key']}.sign") for name in qnames_array):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("sign"))))):
                    target_var = node.targets[0].target.value
                    if mappings['algorithm'] == 'ec':
                        msg_arg = node.value.args[0].value.value
                        
                        new_value = f"{target_var} = {mappings['pqc_alg']}().sign({mappings['private_key']}, {msg_arg})"
                        return updated_node.with_changes(value=(cst.parse_statement(new_value).body[0].value))
                    else:
                        new_value = f"{target_var} = {mappings['pqc_alg']}().sign({mappings['signing_key']}, {mappings['digest_id']})"
                        return updated_node.with_changes(value=(cst.parse_statement(new_value).body[0].value))
            return updated_node

    wrapper = MetadataWrapper(tree)
    obj = updateSign()
    tree = wrapper.visit(obj)
    return tree





CURVE_TO_KEM_TIER = {
    # pyca/cryptography exposes MLKEM768 and MLKEM1024 (no MLKEM512)
    "secp192r1": "MLKEM768",
    "secp224r1": "MLKEM768",
    "sect163k1": "MLKEM768",
    "sect163r2": "MLKEM768",
    "sect233k1": "MLKEM768",
    "sect233r1": "MLKEM768",
    "secp256r1": "MLKEM768",
    "secp256k1": "MLKEM768",
    "sect283k1": "MLKEM768",
    "sect283r1": "MLKEM768",
    "secp384r1": "MLKEM1024",
    "secp521r1": "MLKEM1024",
    "sect409k1": "MLKEM1024",
    "sect409r1": "MLKEM1024",
    "sect571k1": "MLKEM1024",
    "sect571r1": "MLKEM1024",
}

CLASSICAL_PRIV_TYPES = {
    "X25519PrivateKey": "MLKEM768",
    "X448PrivateKey": "MLKEM1024",
    "EllipticCurvePrivateKey": None,  # falls back to default_tier
    "DHPrivateKey": None,
}

CLASSICAL_PUB_TYPES = {
    "X25519PublicKey": "MLKEM768",
    "X448PublicKey": "MLKEM1024",
    "EllipticCurvePublicKey": None,
    "DHPublicKey": None,
}

EC_ONLY_PUBLIC_FORMATS = {"X962", "UncompressedPoint", "CompressedPoint"}


class UpdateKEMGen(cst.CSTTransformer):
    METADATA_DEPENDENCIES = (QualifiedNameProvider,)

    def __init__(self, mappings: dict | None = None):
        super().__init__()
        self.mappings = mappings or {}
        self.default_tier = self._resolve_default_tier()

        # Lexical scope stacks (module -> class -> function)
        self.priv_scopes: list[dict[str, str]] = [{}]
        self.pub_scopes: list[dict[str, str]] = [{}]
        self.dh_param_scopes: list[set[str]] = [set()]
        self.peer_pub_raw_scopes: list[dict[str, str]] = [{}]
        self.class_scope_indices: list[int] = []

    # ---------- Scope Helpers ----------

    def _push_scope(self, is_class: bool = False) -> None:
        self.priv_scopes.append({})
        self.pub_scopes.append({})
        self.dh_param_scopes.append(set())
        self.peer_pub_raw_scopes.append({})
        if is_class:
            self.class_scope_indices.append(len(self.priv_scopes) - 1)

    def _pop_scope(self, is_class: bool = False) -> None:
        if is_class and self.class_scope_indices:
            self.class_scope_indices.pop()
        self.priv_scopes.pop()
        self.pub_scopes.pop()
        self.dh_param_scopes.pop()
        self.peer_pub_raw_scopes.pop()

    def _target_scope_idx(self, name: str) -> int:
        """Persist `self.*` attributes at the enclosing class scope so sibling methods see them."""
        if name.startswith("self.") and self.class_scope_indices:
            return self.class_scope_indices[-1]
        return -1

    def _set_priv(self, name: str, tier: str) -> None:
        self.priv_scopes[self._target_scope_idx(name)][name] = tier

    def _set_pub(self, name: str, tier: str) -> None:
        self.pub_scopes[self._target_scope_idx(name)][name] = tier

    def _set_dh_param(self, name: str) -> None:
        self.dh_param_scopes[self._target_scope_idx(name)].add(name)

    def _set_peer_raw_expr(self, name: str, raw_expr: str) -> None:
        self.peer_pub_raw_scopes[self._target_scope_idx(name)][name] = raw_expr

    def _get_priv_tier(self, name: str | None) -> str | None:
        if not name:
            return None
        for scope in reversed(self.priv_scopes):
            if name in scope:
                return scope[name]
        return None

    def _get_pub_tier(self, name: str | None) -> str | None:
        if not name:
            return None
        for scope in reversed(self.pub_scopes):
            if name in scope:
                return scope[name]
        return None

    def _is_dh_param(self, name: str | None) -> bool:
        if not name:
            return False
        return any(name in scope for scope in reversed(self.dh_param_scopes))

    def _get_peer_raw_expr(self, name: str | None) -> str | None:
        if not name:
            return None
        for scope in reversed(self.peer_pub_raw_scopes):
            if name in scope:
                return scope[name]
        return None

    # ---------- Resolution & AST Helpers ----------

    def _resolve_default_tier(self) -> str:
        ec_curve = self.mappings.get("ec_curve")
        if ec_curve:
            return CURVE_TO_KEM_TIER.get(ec_curve.lower(), "MLKEM1024")

        kem_key_size = self.mappings.get("kem_key_size")
        if kem_key_size is not None and kem_key_size > 1024:
            return "MLKEM1024"
        return "MLKEM768"

    def _get_qnames(self, node: cst.CSTNode) -> set[str]:
        qnames = self.get_metadata(QualifiedNameProvider, node, default=None)
        return {q.name for q in qnames} if qnames else set()

    def _get_node_name(self, node: cst.BaseExpression | None) -> str | None:
        if node is None:
            return None
        if isinstance(node, cst.Name):
            return node.value
        if isinstance(node, cst.Attribute):
            return cst.helpers.get_full_name_for_node(node)
        return None

    def _code(self, node: cst.CSTNode) -> str:
        return cst.Module([]).code_for_node(node)

    def _get_arg(
        self, args: tuple[cst.Arg, ...], kw_name: str, pos_index: int
    ) -> cst.Arg | None:
        for arg in args:
            if arg.keyword is not None and arg.keyword.value == kw_name:
                return arg
        pos_args = [a for a in args if a.keyword is None]
        if 0 <= pos_index < len(pos_args):
            return pos_args[pos_index]
        return None

    def _format_args(self, args: tuple[cst.Arg, ...]) -> str:
        formatted = []
        for arg in args:
            val_code = self._code(arg.value)
            if arg.keyword is not None:
                formatted.append(f"{arg.keyword.value}={val_code}")
            else:
                formatted.append(val_code)
        return ", ".join(formatted)

    def _resolve_ec_tier_from_call(self, call_node: cst.Call) -> str:
        curve_arg = self._get_arg(call_node.args, "curve", 0)
        if curve_arg is not None:
            for q in self._get_qnames(curve_arg.value):
                curve_name = q.rsplit(".", 1)[-1].lower()
                if curve_name in CURVE_TO_KEM_TIER:
                    return CURVE_TO_KEM_TIER[curve_name]
        return self.default_tier

    def _classify_annotation(
        self, annotation_expr: cst.BaseExpression
    ) -> tuple[str | None, str | None]:
        """Returns ('priv' | 'pub', tier) if annotation is a classical KEX key type."""
        candidates = {q.rsplit(".", 1)[-1] for q in self._get_qnames(annotation_expr)}
        raw_name = self._get_node_name(annotation_expr)
        if raw_name:
            candidates.add(raw_name.rsplit(".", 1)[-1])

        for name in candidates:
            if name in CLASSICAL_PRIV_TYPES:
                return "priv", CLASSICAL_PRIV_TYPES[name] or self.default_tier
            if name in CLASSICAL_PUB_TYPES:
                return "pub", CLASSICAL_PUB_TYPES[name] or self.default_tier
        return None, None

    def _extract_enum_leaf(self, expr: cst.BaseExpression) -> str | None:
        for q in self._get_qnames(expr):
            return q.rsplit(".", 1)[-1]
        name = self._get_node_name(expr)
        return name.rsplit(".", 1)[-1] if name else None

    def _replace_enum_member(
        self, expr: cst.BaseExpression, new_member: str
    ) -> cst.BaseExpression:
        """Swap enum attribute leaf while preserving import aliases (e.g. ser.Encoding.X962)."""
        if isinstance(expr, cst.Attribute):
            return expr.with_changes(attr=cst.Name(new_member))
        return expr

    # ---------- Serialization Normalizers ----------

    def _normalize_private_bytes(
        self, original_node: cst.Call, updated_node: cst.Call
    ) -> cst.Call:
        """
        ML-KEM private_bytes supports:
          - Encoding.PEM / Encoding.DER + PrivateFormat.PKCS8
          - Encoding.Raw + PrivateFormat.Raw + NoEncryption()
        """
        new_args = list(updated_node.args)
        enc_idx = fmt_idx = enc_alg_idx = None

        for i, arg in enumerate(original_node.args):
            if arg.keyword is None:
                if i == 0:
                    enc_idx = i
                elif i == 1:
                    fmt_idx = i
                elif i == 2:
                    enc_alg_idx = i
            elif arg.keyword.value == "encoding":
                enc_idx = i
            elif arg.keyword.value == "format":
                fmt_idx = i
            elif arg.keyword.value == "encryption_algorithm":
                enc_alg_idx = i

        enc_leaf = (
            self._extract_enum_leaf(original_node.args[enc_idx].value)
            if enc_idx is not None
            else None
        )
        fmt_leaf = (
            self._extract_enum_leaf(original_node.args[fmt_idx].value)
            if fmt_idx is not None
            else None
        )

        # Unsupported encoding (e.g. Encoding.OpenSSH) -> Encoding.PEM
        if enc_idx is not None and enc_leaf not in {"PEM", "DER", "Raw"}:
            new_args[enc_idx] = new_args[enc_idx].with_changes(
                value=self._replace_enum_member(updated_node.args[enc_idx].value, "PEM")
            )
            enc_leaf = "PEM"

        # Align format with encoding
        if fmt_idx is not None:
            if enc_leaf == "Raw" and fmt_leaf != "Raw":
                new_args[fmt_idx] = new_args[fmt_idx].with_changes(
                    value=self._replace_enum_member(updated_node.args[fmt_idx].value, "Raw")
                )
            elif enc_leaf in {"PEM", "DER"} and fmt_leaf != "PKCS8":
                new_args[fmt_idx] = new_args[fmt_idx].with_changes(
                    value=self._replace_enum_member(updated_node.args[fmt_idx].value, "PKCS8")
                )

        # Raw encoding strictly requires NoEncryption()
        if enc_leaf == "Raw" and enc_alg_idx is not None:
            alg_expr = updated_node.args[enc_alg_idx].value
            if isinstance(alg_expr, cst.Call):
                orig_alg = original_node.args[enc_alg_idx].value
                alg_leaf = (
                    self._extract_enum_leaf(orig_alg.func)
                    if isinstance(orig_alg, cst.Call)
                    else None
                )
                if alg_leaf != "NoEncryption":
                    new_func = (
                        alg_expr.func.with_changes(attr=cst.Name("NoEncryption"))
                        if isinstance(alg_expr.func, cst.Attribute)
                        else cst.Name("NoEncryption")
                    )
                    new_args[enc_alg_idx] = new_args[enc_alg_idx].with_changes(
                        value=alg_expr.with_changes(func=new_func, args=[])
                    )

        return updated_node.with_changes(args=new_args)

    def _normalize_public_bytes(
        self, original_node: cst.Call, updated_node: cst.Call
    ) -> cst.Call:
        """
        ML-KEM public_bytes supports:
          - Encoding.PEM / Encoding.DER + PublicFormat.SubjectPublicKeyInfo
          - Encoding.Raw + PublicFormat.Raw
        """
        new_args = list(updated_node.args)
        enc_idx = fmt_idx = None

        for i, arg in enumerate(original_node.args):
            if arg.keyword is None:
                if i == 0:
                    enc_idx = i
                elif i == 1:
                    fmt_idx = i
            elif arg.keyword.value == "encoding":
                enc_idx = i
            elif arg.keyword.value == "format":
                fmt_idx = i

        enc_leaf = (
            self._extract_enum_leaf(original_node.args[enc_idx].value)
            if enc_idx is not None
            else None
        )
        fmt_leaf = (
            self._extract_enum_leaf(original_node.args[fmt_idx].value)
            if fmt_idx is not None
            else None
        )

        # Encoding.X962 -> Encoding.Raw; Encoding.OpenSSH -> Encoding.PEM
        if enc_idx is not None and enc_leaf not in {"PEM", "DER", "Raw"}:
            target_enc = "Raw" if enc_leaf == "X962" else "PEM"
            new_args[enc_idx] = new_args[enc_idx].with_changes(
                value=self._replace_enum_member(
                    updated_node.args[enc_idx].value, target_enc
                )
            )
            enc_leaf = target_enc

        # Align format with encoding
        if fmt_idx is not None:
            if enc_leaf == "Raw" and fmt_leaf != "Raw":
                new_args[fmt_idx] = new_args[fmt_idx].with_changes(
                    value=self._replace_enum_member(updated_node.args[fmt_idx].value, "Raw")
                )
            elif enc_leaf in {"PEM", "DER"} and fmt_leaf != "SubjectPublicKeyInfo":
                new_args[fmt_idx] = new_args[fmt_idx].with_changes(
                    value=self._replace_enum_member(
                        updated_node.args[fmt_idx].value, "SubjectPublicKeyInfo"
                    )
                )

        return updated_node.with_changes(args=new_args)

    # ---------- Class, Function & Annotation Visitors ----------

    def visit_ClassDef(self, node: cst.ClassDef) -> bool:
        self._push_scope(is_class=True)
        return True

    def leave_ClassDef(
        self, original_node: cst.ClassDef, updated_node: cst.ClassDef
    ) -> cst.ClassDef:
        self._pop_scope(is_class=True)
        return updated_node

    def visit_FunctionDef(self, node: cst.FunctionDef) -> bool:
        self._push_scope(is_class=False)

        # Register typed KEX parameters before visiting the function body
        all_params = (
            list(node.params.posonly_params)
            + list(node.params.params)
            + list(node.params.kwonly_params)
        )
        for param in all_params:
            if param.annotation is not None:
                kind, tier = self._classify_annotation(param.annotation.annotation)
                if kind == "priv" and tier:
                    self._set_priv(param.name.value, tier)
                elif kind == "pub" and tier:
                    self._set_pub(param.name.value, tier)
        return True

    def leave_FunctionDef(
        self, original_node: cst.FunctionDef, updated_node: cst.FunctionDef
    ) -> cst.FunctionDef:
        self._pop_scope(is_class=False)
        return updated_node

    def leave_Annotation(
        self, original_node: cst.Annotation, updated_node: cst.Annotation
    ) -> cst.Annotation:
        kind, tier = self._classify_annotation(original_node.annotation)
        if kind == "priv" and tier:
            return updated_node.with_changes(
                annotation=cst.parse_expression(f"mlkem.{tier}PrivateKey")
            )
        if kind == "pub" and tier:
            return updated_node.with_changes(
                annotation=cst.parse_expression(f"mlkem.{tier}PublicKey")
            )
        return updated_node

    # ---------- Assignment & Statement Tracking ----------

    def _track_assignment(
        self, target: cst.BaseExpression, value: cst.BaseExpression
    ) -> None:
        target_name = self._get_node_name(target)
        if not target_name or not isinstance(value, cst.Call):
            return

        func_code = self._code(value.func)

        # Track derived public key: pub = priv.public_key()
        if isinstance(value.func, cst.Attribute) and value.func.attr.value == "public_key":
            receiver_tier = self._get_priv_tier(self._get_node_name(value.func.value))
            if receiver_tier:
                self._set_pub(target_name, receiver_tier)
                return

        # Track direct ML-KEM private/public key assignments
        for tier in ("MLKEM768", "MLKEM1024"):
            if f"mlkem.{tier}PrivateKey" in func_code:
                if func_code.endswith(".public_key"):
                    self._set_pub(target_name, tier)
                else:
                    self._set_priv(target_name, tier)
                return

            if f"mlkem.{tier}PublicKey" in func_code:
                self._set_pub(target_name, tier)
                # Remember raw bytes expression so decapsulate(peer_pub) can unwrap it
                if func_code.endswith(".from_public_bytes"):
                    data_arg = self._get_arg(value.args, "data", 0)
                    if data_arg is not None:
                        self._set_peer_raw_expr(target_name, self._code(data_arg.value))
                return

    def leave_Assign(
        self, original_node: cst.Assign, updated_node: cst.Assign
    ) -> cst.Assign:
        if len(updated_node.targets) == 1:
            self._track_assignment(updated_node.targets[0].target, updated_node.value)
        return updated_node

    def leave_AnnAssign(
        self, original_node: cst.AnnAssign, updated_node: cst.AnnAssign
    ) -> cst.AnnAssign:
        if updated_node.value is not None:
            self._track_assignment(updated_node.target, updated_node.value)
        return updated_node

    def leave_SimpleStatementLine(
        self,
        original_node: cst.SimpleStatementLine,
        updated_node: cst.SimpleStatementLine,
    ) -> cst.SimpleStatementLine | cst.RemovalSentinel:
        # Remove classical DH parameter generation statements and track variable name
        if len(original_node.body) == 1:
            orig_stmt = original_node.body[0]
            target_node = None
            value_node = None

            if isinstance(orig_stmt, cst.Assign) and len(orig_stmt.targets) == 1:
                target_node = orig_stmt.targets[0].target
                value_node = orig_stmt.value
            elif isinstance(orig_stmt, cst.AnnAssign):
                target_node = orig_stmt.target
                value_node = orig_stmt.value

            if isinstance(value_node, cst.Call):
                qnames = self._get_qnames(value_node.func)
                if any(q.endswith("dh.generate_parameters") for q in qnames):
                    target_name = self._get_node_name(target_node)
                    if target_name:
                        self._set_dh_param(target_name)
                    return cst.RemoveFromParent()

        # Add warning comment on from_seed_bytes (strictly requires 64-byte seed)
        stmt_code = self._code(updated_node)
        if ".from_seed_bytes(" in stmt_code and updated_node.trailing_whitespace.comment is None:
            updated_node = updated_node.with_changes(
                trailing_whitespace=updated_node.trailing_whitespace.with_changes(
                    whitespace=cst.SimpleWhitespace("  "),
                    comment=cst.Comment("# TODO: verify 64-byte ML-KEM seed input"),
                )
            )

        return updated_node

    # ---------- Call Rewriting ----------

    def leave_Call(
        self, original_node: cst.Call, updated_node: cst.Call
    ) -> cst.BaseExpression:
        qnames = self._get_qnames(original_node.func)

        # 1. X25519 -> ML-KEM-768
        # Note: chained .generate().public_key() is handled automatically by bottom-up traversal
        if any(q.endswith("X25519PrivateKey.generate") for q in qnames):
            return cst.parse_expression("mlkem.MLKEM768PrivateKey.generate()")

        if any(q.endswith("X25519PrivateKey.from_private_bytes") for q in qnames):
            return cst.parse_expression(
                f"mlkem.MLKEM768PrivateKey.from_seed_bytes({self._format_args(updated_node.args)})"
            )

        if any(q.endswith("X25519PublicKey.from_public_bytes") for q in qnames):
            return cst.parse_expression(
                f"mlkem.MLKEM768PublicKey.from_public_bytes({self._format_args(updated_node.args)})"
            )

        # 2. X448 -> ML-KEM-1024
        if any(q.endswith("X448PrivateKey.generate") for q in qnames):
            return cst.parse_expression("mlkem.MLKEM1024PrivateKey.generate()")

        if any(q.endswith("X448PrivateKey.from_private_bytes") for q in qnames):
            return cst.parse_expression(
                f"mlkem.MLKEM1024PrivateKey.from_seed_bytes({self._format_args(updated_node.args)})"
            )

        if any(q.endswith("X448PublicKey.from_public_bytes") for q in qnames):
            return cst.parse_expression(
                f"mlkem.MLKEM1024PublicKey.from_public_bytes({self._format_args(updated_node.args)})"
            )

        # 3. ECDH -> Curve-matched ML-KEM (avoids touching rsa/dsa.generate_private_key)
        if any(q.endswith("ec.generate_private_key") for q in qnames):
            tier = self._resolve_ec_tier_from_call(original_node)
            return cst.parse_expression(f"mlkem.{tier}PrivateKey.generate()")

        if any(q.endswith("EllipticCurvePublicKey.from_encoded_point") for q in qnames):
            tier = self._resolve_ec_tier_from_call(original_node)
            data_arg = self._get_arg(updated_node.args, "data", 1)
            if data_arg is not None:
                return cst.parse_expression(
                    f"mlkem.{tier}PublicKey.from_public_bytes({self._code(data_arg.value)})"
                )

        # 4. Inline DH chain: dh.generate_parameters(...).generate_private_key()
        if (
            isinstance(original_node.func, cst.Attribute)
            and original_node.func.attr.value == "generate_private_key"
            and isinstance(original_node.func.value, cst.Call)
        ):
            inner_qnames = self._get_qnames(original_node.func.value.func)
            if any(q.endswith("dh.generate_parameters") for q in inner_qnames):
                return cst.parse_expression(f"mlkem.{self.default_tier}PrivateKey.generate()")

        # 5. Instance & Parameter Method Calls
        if isinstance(updated_node.func, cst.Attribute):
            receiver_name = self._get_node_name(updated_node.func.value)
            method_name = updated_node.func.attr.value

            # DH parameters object -> generate private key directly
            if self._is_dh_param(receiver_name) and method_name == "generate_private_key":
                return cst.parse_expression(f"mlkem.{self.default_tier}PrivateKey.generate()")

            # Private key methods
            if self._get_priv_tier(receiver_name):
                if method_name == "exchange" and updated_node.args:
                    peer_arg = self._get_arg(
                        updated_node.args, "peer_public_key", len(updated_node.args) - 1
                    )
                    if peer_arg is not None:
                        peer_name = self._get_node_name(peer_arg.value)
                        # Unwrap deserialized PublicKey back to raw bytes to avoid TypeError
                        raw_ct_expr = self._get_peer_raw_expr(peer_name)
                        ct_expr = raw_ct_expr if raw_ct_expr else self._code(peer_arg.value)
                        return cst.parse_expression(f"{receiver_name}.decapsulate({ct_expr})")

                if method_name == "private_bytes":
                    return self._normalize_private_bytes(original_node, updated_node)

            # Public key methods (includes fallback for untyped helpers using EC-only formats)
            if method_name == "public_bytes":
                is_tracked_pub = bool(self._get_pub_tier(receiver_name))
                has_ec_only_format = any(
                    self._extract_enum_leaf(a.value) in EC_ONLY_PUBLIC_FORMATS
                    for a in original_node.args
                )
                if is_tracked_pub or has_ec_only_format:
                    return self._normalize_public_bytes(original_node, updated_node)

        return updated_node


def set_kempure_client_cryptography(tree: cst.Module, mappings: dict) -> cst.Module:
    wrapper = MetadataWrapper(tree)
    transformer = UpdateKEMGen(mappings)
    tree = wrapper.visit(transformer)

    imp_stmts = [
        "from cryptography.hazmat.primitives.asymmetric import mlkem",
    ]
    tree = update_imports(tree, imp_stmts)

    return tree


def get_pqc_kexwith_ec_curve(curve: str | None) -> str:
    if curve is None:
        return "MLKEM1024PrivateKey"
    tier = CURVE_TO_KEM_TIER.get(curve.lower(), "MLKEM1024")
    return f"{tier}PrivateKey"


def get_pqc_kexwith_ec_curve_server_public_key(curve: str | None) -> str:
    if curve is None:
        return "MLKEM1024PublicKey"
    tier = CURVE_TO_KEM_TIER.get(curve.lower(), "MLKEM1024")
    return f"{tier}PublicKey"


def get_ec_public_key_size(algorithm: str) -> int | None:
    curve_sizes = {
        "secp192r1": 49,
        "secp224r1": 57,
        "secp256r1": 65,
        "secp256k1": 65,
        "secp384r1": 97,
        "secp521r1": 133,
        "sect163k1": 43,
        "sect163r2": 43,
        "sect233k1": 61,
        "sect233r1": 61,
        "sect283k1": 73,
        "sect283r1": 73,
        "sect409k1": 105,
        "sect409r1": 105,
        "sect571k1": 145,
        "sect571r1": 145,
    }
    return curve_sizes.get(algorithm.lower())








CURVE_TO_KEM_TIER = {
    "secp192r1": "MLKEM768",
    "secp224r1": "MLKEM768",
    "sect163k1": "MLKEM768",
    "sect163r2": "MLKEM768",
    "sect233k1": "MLKEM768",
    "sect233r1": "MLKEM768",
    "secp256r1": "MLKEM768",
    "secp256k1": "MLKEM768",
    "sect283k1": "MLKEM768",
    "sect283r1": "MLKEM768",
    "secp384r1": "MLKEM1024",
    "secp521r1": "MLKEM1024",
    "sect409k1": "MLKEM1024",
    "sect409r1": "MLKEM1024",
    "sect571k1": "MLKEM1024",
    "sect571r1": "MLKEM1024",
}

MLKEM_CIPHERTEXT_SIZES = {
    "MLKEM768": 1088,
    "MLKEM1024": 1568,
}

MLKEM_SEED_SIZE = 64

EC_PUBLIC_KEY_SIZES = {
    "secp192r1": 49,
    "secp224r1": 57,
    "secp256r1": 65,
    "secp256k1": 65,
    "secp384r1": 97,
    "secp521r1": 133,
    "sect163k1": 43,
    "sect163r2": 43,
    "sect233k1": 61,
    "sect233r1": 61,
    "sect283k1": 73,
    "sect283r1": 73,
    "sect409k1": 105,
    "sect409r1": 105,
    "sect571k1": 145,
    "sect571r1": 145,
}

CLASSICAL_PRIV_ANNOTATION_ALGO = {
    "X25519PrivateKey": ("X25519", "MLKEM768", None),
    "X448PrivateKey": ("X448", "MLKEM1024", None),
    "EllipticCurvePrivateKey": ("EC", None, None),
    "DHPrivateKey": ("DH", None, None),
}

CLASSICAL_PUB_ANNOTATION_ALGO = {
    "X25519PublicKey": ("X25519", "MLKEM768", None),
    "X448PublicKey": ("X448", "MLKEM1024", None),
    "EllipticCurvePublicKey": ("EC", None, None),
    "DHPublicKey": ("DH", None, None),
}


class UpdateHybridClientKEM(cst.CSTTransformer):
    METADATA_DEPENDENCIES = (QualifiedNameProvider,)

    def __init__(self, mappings: dict | None = None):
        super().__init__()
        self.mappings = mappings or {}
        self.default_tier = self._resolve_default_tier()

        self.priv_scopes: list[dict[str, tuple[str, str, str | None]]] = [{}]
        self.pub_scopes: list[dict[str, tuple[str, str, str | None]]] = [{}]
        self.peer_pub_scopes: list[dict[str, tuple[str, str, str | None]]] = [{}]
        self.dh_param_scopes: list[set[str]] = [set()]
        self.class_scope_indices: list[int] = []

    def _push_scope(self, is_class: bool = False) -> None:
        self.priv_scopes.append({})
        self.pub_scopes.append({})
        self.peer_pub_scopes.append({})
        self.dh_param_scopes.append(set())
        if is_class:
            self.class_scope_indices.append(len(self.priv_scopes) - 1)

    def _pop_scope(self, is_class: bool = False) -> None:
        if is_class and self.class_scope_indices:
            self.class_scope_indices.pop()
        self.priv_scopes.pop()
        self.pub_scopes.pop()
        self.peer_pub_scopes.pop()
        self.dh_param_scopes.pop()

    def _target_scope_idx(self, name: str) -> int:
        if name.startswith("self.") and self.class_scope_indices:
            return self.class_scope_indices[-1]
        return -1

    def _set_priv(self, name: str, algo: str, tier: str, curve: str | None) -> None:
        self.priv_scopes[self._target_scope_idx(name)][name] = (algo, tier, curve)

    def _get_priv(self, name: str | None) -> tuple[str, str, str | None] | None:
        if not name:
            return None
        for scope in reversed(self.priv_scopes):
            if name in scope:
                return scope[name]
        return None

    def _set_pub(self, name: str, algo: str, tier: str, curve: str | None) -> None:
        self.pub_scopes[self._target_scope_idx(name)][name] = (algo, tier, curve)

    def _get_pub(self, name: str | None) -> tuple[str, str, str | None] | None:
        if not name:
            return None
        for scope in reversed(self.pub_scopes):
            if name in scope:
                return scope[name]
        return None

    def _set_peer_pub(
        self, name: str, raw_expr: str, algo: str, curve: str | None
    ) -> None:
        self.peer_pub_scopes[self._target_scope_idx(name)][name] = (
            raw_expr,
            algo,
            curve,
        )

    def _get_peer_pub(
        self, name: str | None
    ) -> tuple[str, str, str | None] | None:
        if not name:
            return None
        for scope in reversed(self.peer_pub_scopes):
            if name in scope:
                return scope[name]
        return None

    def _set_dh_param(self, name: str) -> None:
        self.dh_param_scopes[self._target_scope_idx(name)].add(name)

    def _is_dh_param(self, name: str | None) -> bool:
        if not name:
            return False
        return any(name in scope for scope in reversed(self.dh_param_scopes))

    def _resolve_default_tier(self) -> str:
        ec_curve = self.mappings.get("ec_curve")
        if ec_curve:
            return CURVE_TO_KEM_TIER.get(ec_curve.lower(), "MLKEM1024")
        kem_key_size = self.mappings.get("kem_key_size")
        if kem_key_size is not None and kem_key_size > 1024:
            return "MLKEM1024"
        return "MLKEM768"

    def _get_qnames(self, node: cst.CSTNode) -> set[str]:
        qnames = self.get_metadata(QualifiedNameProvider, node, default=None)
        return {q.name for q in qnames} if qnames else set()

    def _get_node_name(self, node: cst.BaseExpression | None) -> str | None:
        if node is None:
            return None
        if isinstance(node, cst.Name):
            return node.value
        if isinstance(node, cst.Attribute):
            return cst.helpers.get_full_name_for_node(node)
        return None

    def _code(self, node: cst.CSTNode) -> str:
        return cst.Module([]).code_for_node(node)

    def _safe_slice_base(self, expr_code: str) -> str:
        return f"({expr_code})" if any(ch in expr_code for ch in " +-*/") else expr_code

    def _get_arg_with_index(
        self, args: tuple[cst.Arg, ...], kw_name: str, pos_index: int
    ) -> tuple[int, cst.Arg] | tuple[None, None]:
        for idx, arg in enumerate(args):
            if arg.keyword is not None and arg.keyword.value == kw_name:
                return idx, arg
        pos_entries = [(idx, arg) for idx, arg in enumerate(args) if arg.keyword is None]
        if -len(pos_entries) <= pos_index < len(pos_entries):
            return pos_entries[pos_index]
        return None, None

    def _extract_curve_from_node(self, node: cst.BaseExpression) -> str | None:
        for q in self._get_qnames(node):
            leaf = q.rsplit(".", 1)[-1].lower()
            if leaf in EC_PUBLIC_KEY_SIZES:
                return leaf
        if isinstance(node, cst.Call):
            name = self._get_node_name(node.func)
            if name:
                leaf = name.rsplit(".", 1)[-1].lower()
                if leaf in EC_PUBLIC_KEY_SIZES:
                    return leaf
        return None

    def _extract_enum_leaf(self, expr: cst.BaseExpression) -> str | None:
        for q in self._get_qnames(expr):
            return q.rsplit(".", 1)[-1]
        name = self._get_node_name(expr)
        return name.rsplit(".", 1)[-1] if name else None

    def _replace_enum_member(
        self, expr: cst.BaseExpression, new_member: str
    ) -> cst.BaseExpression:
        if isinstance(expr, cst.Attribute):
            return expr.with_changes(attr=cst.Name(new_member))
        return expr

    def _resolve_hybrid_spec(
        self,
        detected_algo: str | None = None,
        detected_curve: str | None = None,
        detected_tier: str | None = None,
    ) -> dict:
        algo = (
            detected_algo
            or self.mappings.get("algorithm")
            or "X25519"
        ).upper()
        ec_curve = (
            detected_curve
            or self.mappings.get("ec_curve")
            or (algo.lower() if algo.lower() in EC_PUBLIC_KEY_SIZES else None)
        )

        if algo == "X25519":
            return {
                "algo": "X25519",
                "tier": "MLKEM768",
                "ec_curve": None,
                "order": "pqc_first",
                "ct_split": MLKEM_CIPHERTEXT_SIZES["MLKEM768"],
                "seed_split": MLKEM_SEED_SIZE,
            }

        if algo == "X448":
            return {
                "algo": "X448",
                "tier": "MLKEM1024",
                "ec_curve": None,
                "order": "pqc_first",
                "ct_split": MLKEM_CIPHERTEXT_SIZES["MLKEM1024"],
                "seed_split": MLKEM_SEED_SIZE,
            }

        if algo == "SECP256R1":
            return {
                "algo": "EC",
                "tier": "MLKEM768",
                "ec_curve": "secp256r1",
                "order": "classical_first",
                "ct_split": 65,
                "seed_split": MLKEM_SEED_SIZE,
            }

        if algo == "SECP384R1":
            return {
                "algo": "EC",
                "tier": "MLKEM1024",
                "ec_curve": "secp384r1",
                "order": "classical_first",
                "ct_split": 97,
                "seed_split": MLKEM_SEED_SIZE,
            }

        if algo == "EC" or algo.lower() in EC_PUBLIC_KEY_SIZES:
            curve = (ec_curve or "secp256r1").lower()
            tier = detected_tier or CURVE_TO_KEM_TIER.get(curve, "MLKEM1024")
            ec_size = EC_PUBLIC_KEY_SIZES.get(curve, 65)
            return {
                "algo": "EC",
                "tier": tier,
                "ec_curve": curve,
                "order": "classical_first",
                "ct_split": ec_size,
                "seed_split": MLKEM_SEED_SIZE,
            }

        tier = detected_tier or self.default_tier
        return {
            "algo": algo,
            "tier": tier,
            "ec_curve": None,
            "order": "pqc_first",
            "ct_split": MLKEM_CIPHERTEXT_SIZES[tier],
            "seed_split": MLKEM_SEED_SIZE,
        }

    def _slice_server_payload(self, raw_code: str, spec: dict) -> tuple[str, str]:
        base = self._safe_slice_base(raw_code)
        split = spec["ct_split"]
        if spec["order"] == "pqc_first":
            return f"{base}[{split}:]", f"{base}[:{split}]"
        return f"{base}[:{split}]", f"{base}[{split}:]"

    def _slice_private_bytes(self, raw_code: str, spec: dict) -> tuple[str, str]:
        base = self._safe_slice_base(raw_code)
        split = spec["seed_split"]
        return f"{base}[{split}:]", f"{base}[:{split}]"

    def _detect_peer_deserializer(
        self, call_node: cst.Call
    ) -> tuple[str | None, str | None, int | None, cst.Arg | None]:
        qnames = self._get_qnames(call_node.func)
        if any(q.endswith("X25519PublicKey.from_public_bytes") for q in qnames):
            idx, arg = self._get_arg_with_index(call_node.args, "data", 0)
            return "X25519", None, idx, arg
        if any(q.endswith("X448PublicKey.from_public_bytes") for q in qnames):
            idx, arg = self._get_arg_with_index(call_node.args, "data", 0)
            return "X448", None, idx, arg
        if any(q.endswith("EllipticCurvePublicKey.from_encoded_point") for q in qnames):
            _, curve_arg = self._get_arg_with_index(call_node.args, "curve", 0)
            idx, data_arg = self._get_arg_with_index(call_node.args, "data", 1)
            curve = (
                self._extract_curve_from_node(curve_arg.value)
                if curve_arg is not None
                else None
            )
            return "EC", curve, idx, data_arg
        return None, None, None, None

    def _detect_priv_deserializer(
        self, call_node: cst.Call
    ) -> tuple[str | None, int | None, cst.Arg | None]:
        qnames = self._get_qnames(call_node.func)
        if any(q.endswith("X25519PrivateKey.from_private_bytes") for q in qnames):
            idx, arg = self._get_arg_with_index(call_node.args, "data", 0)
            return "X25519", idx, arg
        if any(q.endswith("X448PrivateKey.from_private_bytes") for q in qnames):
            idx, arg = self._get_arg_with_index(call_node.args, "data", 0)
            return "X448", idx, arg
        return None, None, None

    def _detect_priv_generator(
        self, call_node: cst.Call
    ) -> tuple[str | None, str | None, str | None]:
        qnames = self._get_qnames(call_node.func)
        if any(q.endswith("X25519PrivateKey.generate") for q in qnames):
            return "X25519", "MLKEM768", None
        if any(q.endswith("X448PrivateKey.generate") for q in qnames):
            return "X448", "MLKEM1024", None
        if any(q.endswith("ec.generate_private_key") for q in qnames):
            _, curve_arg = self._get_arg_with_index(call_node.args, "curve", 0)
            curve = (
                self._extract_curve_from_node(curve_arg.value)
                if curve_arg is not None
                else None
            )
            spec = self._resolve_hybrid_spec(detected_algo="EC", detected_curve=curve)
            return "EC", spec["tier"], spec["ec_curve"]
        if (
            isinstance(call_node.func, cst.Attribute)
            and call_node.func.attr.value == "generate_private_key"
        ):
            receiver = self._get_node_name(call_node.func.value)
            if self._is_dh_param(receiver):
                return "DH", self.default_tier, None
            if isinstance(call_node.func.value, cst.Call):
                inner_qnames = self._get_qnames(call_node.func.value.func)
                if any(q.endswith("dh.generate_parameters") for q in inner_qnames):
                    return "DH", self.default_tier, None
        return None, None, None

    def _normalize_private_bytes(
        self, original_call: cst.Call, pqc_call: cst.Call
    ) -> tuple[cst.Call, bool]:
        new_args = list(pqc_call.args)
        enc_idx = fmt_idx = enc_alg_idx = None

        for i, arg in enumerate(original_call.args):
            if arg.keyword is None:
                if i == 0:
                    enc_idx = i
                elif i == 1:
                    fmt_idx = i
                elif i == 2:
                    enc_alg_idx = i
            elif arg.keyword.value == "encoding":
                enc_idx = i
            elif arg.keyword.value == "format":
                fmt_idx = i
            elif arg.keyword.value == "encryption_algorithm":
                enc_alg_idx = i

        enc_leaf = (
            self._extract_enum_leaf(original_call.args[enc_idx].value)
            if enc_idx is not None
            else None
        )
        fmt_leaf = (
            self._extract_enum_leaf(original_call.args[fmt_idx].value)
            if fmt_idx is not None
            else None
        )

        if enc_idx is not None and enc_leaf not in {"PEM", "DER", "Raw"}:
            new_args[enc_idx] = new_args[enc_idx].with_changes(
                value=self._replace_enum_member(pqc_call.args[enc_idx].value, "PEM")
            )
            enc_leaf = "PEM"

        if fmt_idx is not None:
            if enc_leaf == "Raw" and fmt_leaf != "Raw":
                new_args[fmt_idx] = new_args[fmt_idx].with_changes(
                    value=self._replace_enum_member(pqc_call.args[fmt_idx].value, "Raw")
                )
            elif enc_leaf in {"PEM", "DER"} and fmt_leaf != "PKCS8":
                new_args[fmt_idx] = new_args[fmt_idx].with_changes(
                    value=self._replace_enum_member(pqc_call.args[fmt_idx].value, "PKCS8")
                )

        if enc_leaf == "Raw" and enc_alg_idx is not None:
            alg_expr = pqc_call.args[enc_alg_idx].value
            if isinstance(alg_expr, cst.Call):
                orig_alg = original_call.args[enc_alg_idx].value
                alg_leaf = (
                    self._extract_enum_leaf(orig_alg.func)
                    if isinstance(orig_alg, cst.Call)
                    else None
                )
                if alg_leaf != "NoEncryption":
                    new_func = (
                        alg_expr.func.with_changes(attr=cst.Name("NoEncryption"))
                        if isinstance(alg_expr.func, cst.Attribute)
                        else cst.Name("NoEncryption")
                    )
                    new_args[enc_alg_idx] = new_args[enc_alg_idx].with_changes(
                        value=alg_expr.with_changes(func=new_func, args=[])
                    )

        return pqc_call.with_changes(args=new_args), enc_leaf == "Raw"

    def _normalize_public_bytes(
        self, original_call: cst.Call, pqc_call: cst.Call
    ) -> tuple[cst.Call, bool]:
        new_args = list(pqc_call.args)
        enc_idx = fmt_idx = None

        for i, arg in enumerate(original_call.args):
            if arg.keyword is None:
                if i == 0:
                    enc_idx = i
                elif i == 1:
                    fmt_idx = i
            elif arg.keyword.value == "encoding":
                enc_idx = i
            elif arg.keyword.value == "format":
                fmt_idx = i

        enc_leaf = (
            self._extract_enum_leaf(original_call.args[enc_idx].value)
            if enc_idx is not None
            else None
        )
        fmt_leaf = (
            self._extract_enum_leaf(original_call.args[fmt_idx].value)
            if fmt_idx is not None
            else None
        )

        is_raw_wire = enc_leaf in {"Raw", "X962"}

        if enc_idx is not None and enc_leaf not in {"PEM", "DER", "Raw"}:
            target_enc = "Raw" if enc_leaf == "X962" else "PEM"
            new_args[enc_idx] = new_args[enc_idx].with_changes(
                value=self._replace_enum_member(pqc_call.args[enc_idx].value, target_enc)
            )
            enc_leaf = target_enc

        if fmt_idx is not None:
            if enc_leaf == "Raw" and fmt_leaf != "Raw":
                new_args[fmt_idx] = new_args[fmt_idx].with_changes(
                    value=self._replace_enum_member(pqc_call.args[fmt_idx].value, "Raw")
                )
            elif enc_leaf in {"PEM", "DER"} and fmt_leaf != "SubjectPublicKeyInfo":
                new_args[fmt_idx] = new_args[fmt_idx].with_changes(
                    value=self._replace_enum_member(
                        pqc_call.args[fmt_idx].value, "SubjectPublicKeyInfo"
                    )
                )

        return pqc_call.with_changes(args=new_args), is_raw_wire

    def _is_kex_exchange_call(
        self, original_call: cst.Call, updated_call: cst.Call
    ) -> bool:
        if not isinstance(updated_call.func, cst.Attribute):
            return False
        if updated_call.func.attr.value != "exchange" or not updated_call.args:
            return False

        if self._get_priv(self._get_node_name(updated_call.func.value)):
            return True

        _, peer_arg = self._get_arg_with_index(original_call.args, "peer_public_key", -1)
        if peer_arg is not None:
            if self._get_peer_pub(self._get_node_name(peer_arg.value)):
                return True
            if isinstance(peer_arg.value, cst.Call):
                if self._detect_peer_deserializer(peer_arg.value)[0]:
                    return True

        for arg in original_call.args:
            if any(q.endswith("ECDH") for q in self._get_qnames(arg.value)):
                return True

        orig_qnames = self._get_qnames(original_call.func)
        return any(
            q.endswith((
                "X25519PrivateKey.exchange",
                "X448PrivateKey.exchange",
                "EllipticCurvePrivateKey.exchange",
                "DHPrivateKey.exchange",
            ))
            for q in orig_qnames
        )

    def visit_ClassDef(self, node: cst.ClassDef) -> bool:
        self._push_scope(is_class=True)
        return True

    def leave_ClassDef(
        self, original_node: cst.ClassDef, updated_node: cst.ClassDef
    ) -> cst.ClassDef:
        self._pop_scope(is_class=True)
        return updated_node

    def visit_FunctionDef(self, node: cst.FunctionDef) -> bool:
        self._push_scope(is_class=False)
        all_params = (
            list(node.params.posonly_params)
            + list(node.params.params)
            + list(node.params.kwonly_params)
        )
        for param in all_params:
            if param.annotation is not None:
                ann_expr = param.annotation.annotation
                candidates = {q.rsplit(".", 1)[-1] for q in self._get_qnames(ann_expr)}
                raw_name = self._get_node_name(ann_expr)
                if raw_name:
                    candidates.add(raw_name.rsplit(".", 1)[-1])
                for name in candidates:
                    if name in CLASSICAL_PRIV_ANNOTATION_ALGO:
                        algo, tier, curve = CLASSICAL_PRIV_ANNOTATION_ALGO[name]
                        spec = self._resolve_hybrid_spec(algo, curve, tier)
                        self._set_priv(param.name.value, spec["algo"], spec["tier"], spec["ec_curve"])
                        break
                    if name in CLASSICAL_PUB_ANNOTATION_ALGO:
                        algo, tier, curve = CLASSICAL_PUB_ANNOTATION_ALGO[name]
                        spec = self._resolve_hybrid_spec(algo, curve, tier)
                        self._set_pub(param.name.value, spec["algo"], spec["tier"], spec["ec_curve"])
                        break
        return True

    def leave_FunctionDef(
        self, original_node: cst.FunctionDef, updated_node: cst.FunctionDef
    ) -> cst.FunctionDef:
        self._pop_scope(is_class=False)
        return updated_node

    def leave_Call(
        self, original_node: cst.Call, updated_node: cst.Call
    ) -> cst.BaseExpression:
        peer_algo, peer_curve, peer_idx, peer_data_arg = self._detect_peer_deserializer(
            original_node
        )
        if peer_algo and peer_idx is not None and peer_data_arg is not None:
            spec = self._resolve_hybrid_spec(detected_algo=peer_algo, detected_curve=peer_curve)
            classical_slice, _ = self._slice_server_payload(self._code(peer_data_arg.value), spec)
            new_args = list(updated_node.args)
            new_args[peer_idx] = new_args[peer_idx].with_changes(
                value=cst.parse_expression(classical_slice)
            )
            return updated_node.with_changes(args=new_args)

        priv_algo, priv_idx, priv_data_arg = self._detect_priv_deserializer(original_node)
        if priv_algo and priv_idx is not None and priv_data_arg is not None:
            spec = self._resolve_hybrid_spec(detected_algo=priv_algo)
            classical_slice, _ = self._slice_private_bytes(self._code(priv_data_arg.value), spec)
            new_args = list(updated_node.args)
            new_args[priv_idx] = new_args[priv_idx].with_changes(
                value=cst.parse_expression(classical_slice)
            )
            return updated_node.with_changes(args=new_args)

        return updated_node

    def leave_SimpleStatementLine(
        self,
        original_node: cst.SimpleStatementLine,
        updated_node: cst.SimpleStatementLine,
    ) -> cst.SimpleStatementLine | cst.FlattenSentinel[cst.SimpleStatementLine]:
        if len(original_node.body) != 1:
            return updated_node

        orig_stmt = original_node.body[0]
        upd_stmt = updated_node.body[0]

        is_assign = isinstance(orig_stmt, (cst.Assign, cst.AnnAssign)) and isinstance(
            upd_stmt, (cst.Assign, cst.AnnAssign)
        )
        is_return = isinstance(orig_stmt, cst.Return) and isinstance(upd_stmt, cst.Return)

        if not (is_assign or is_return):
            return updated_node
        if not (isinstance(orig_stmt.value, cst.Call) and isinstance(upd_stmt.value, cst.Call)):
            return updated_node

        if is_assign:
            if isinstance(orig_stmt, cst.Assign) and len(orig_stmt.targets) != 1:
                return updated_node
            target_node = (
                orig_stmt.targets[0].target
                if isinstance(orig_stmt, cst.Assign)
                else orig_stmt.target
            )
            target_var = self._get_node_name(target_node)

            orig_call = orig_stmt.value
            upd_call = upd_stmt.value
            qnames = self._get_qnames(orig_call.func)

            if any(q.endswith("dh.generate_parameters") for q in qnames):
                if target_var:
                    self._set_dh_param(target_var)
                return updated_node

            if target_var:
                gen_algo, gen_tier, gen_curve = self._detect_priv_generator(orig_call)
                if gen_algo and gen_tier:
                    self._set_priv(target_var, gen_algo, gen_tier, gen_curve)
                    pqc_stmt = cst.parse_statement(
                        f"{target_var}_pqc = mlkem.{gen_tier}PrivateKey.generate()\n"
                    )
                    return cst.FlattenSentinel([updated_node, pqc_stmt])

                priv_algo, _, priv_data_arg = self._detect_priv_deserializer(orig_call)
                if priv_algo and priv_data_arg is not None:
                    spec = self._resolve_hybrid_spec(detected_algo=priv_algo)
                    _, seed_slice = self._slice_private_bytes(
                        self._code(priv_data_arg.value), spec
                    )
                    self._set_priv(target_var, spec["algo"], spec["tier"], spec["ec_curve"])
                    pqc_stmt = cst.parse_statement(
                        f"{target_var}_pqc = mlkem.{spec['tier']}PrivateKey.from_seed_bytes({seed_slice})\n"
                    )
                    return cst.FlattenSentinel([updated_node, pqc_stmt])

                peer_algo, peer_curve, _, peer_data_arg = self._detect_peer_deserializer(
                    orig_call
                )
                if peer_algo and peer_data_arg is not None:
                    self._set_peer_pub(
                        target_var, self._code(peer_data_arg.value), peer_algo, peer_curve
                    )
                    return updated_node

                if (
                    isinstance(orig_call.func, cst.Attribute)
                    and orig_call.func.attr.value == "public_key"
                ):
                    if isinstance(orig_call.func.value, cst.Call):
                        chain_algo, chain_tier, chain_curve = self._detect_priv_generator(
                            orig_call.func.value
                        )
                        if chain_algo and chain_tier:
                            self._set_pub(target_var, chain_algo, chain_tier, chain_curve)
                            pqc_stmt = cst.parse_statement(
                                f"{target_var}_pqc = mlkem.{chain_tier}PrivateKey.generate().public_key()\n"
                            )
                            return cst.FlattenSentinel([updated_node, pqc_stmt])

                    receiver_name = self._get_node_name(orig_call.func.value)
                    priv_info = self._get_priv(receiver_name)
                    if priv_info and receiver_name:
                        p_algo, p_tier, p_curve = priv_info
                        self._set_pub(target_var, p_algo, p_tier, p_curve)
                        pqc_stmt = cst.parse_statement(
                            f"{target_var}_pqc = {receiver_name}_pqc.public_key()\n"
                        )
                        return cst.FlattenSentinel([updated_node, pqc_stmt])

                if isinstance(upd_call.func, cst.Attribute):
                    receiver_name = self._get_node_name(upd_call.func.value)
                    method_name = upd_call.func.attr.value

                    if method_name == "private_bytes":
                        priv_info = self._get_priv(receiver_name)
                        if priv_info and receiver_name:
                            p_algo, p_tier, p_curve = priv_info
                            spec = self._resolve_hybrid_spec(p_algo, p_curve, p_tier)
                            pqc_call = upd_call.with_changes(
                                func=upd_call.func.with_changes(
                                    value=cst.parse_expression(f"{receiver_name}_pqc")
                                )
                            )
                            pqc_call, is_raw = self._normalize_private_bytes(orig_call, pqc_call)
                            stmts = [
                                updated_node,
                                cst.parse_statement(
                                    f"{target_var}_pqc = {self._code(pqc_call)}\n"
                                ),
                            ]
                            if is_raw:
                                combined = (
                                    f"{target_var}_pqc + {target_var}"
                                    if spec["order"] == "pqc_first"
                                    else f"{target_var} + {target_var}_pqc"
                                )
                                stmts.append(cst.parse_statement(f"{target_var} = {combined}\n"))
                            return cst.FlattenSentinel(stmts)

                    if method_name == "public_bytes":
                        pub_info = self._get_pub(receiver_name)
                        if pub_info and receiver_name:
                            p_algo, p_tier, p_curve = pub_info
                            spec = self._resolve_hybrid_spec(p_algo, p_curve, p_tier)
                            pqc_call = upd_call.with_changes(
                                func=upd_call.func.with_changes(
                                    value=cst.parse_expression(f"{receiver_name}_pqc")
                                )
                            )
                            pqc_call, is_raw_wire = self._normalize_public_bytes(
                                orig_call, pqc_call
                            )
                            stmts = [
                                updated_node,
                                cst.parse_statement(
                                    f"{target_var}_pqc = {self._code(pqc_call)}\n"
                                ),
                            ]
                            if is_raw_wire:
                                combined = (
                                    f"{target_var}_pqc + {target_var}"
                                    if spec["order"] == "pqc_first"
                                    else f"{target_var} + {target_var}_pqc"
                                )
                                stmts.append(cst.parse_statement(f"{target_var} = {combined}\n"))
                            return cst.FlattenSentinel(stmts)

        if not self._is_kex_exchange_call(orig_stmt.value, upd_stmt.value):
            return updated_node

        priv_name = self._get_node_name(upd_stmt.value.func.value)
        if not priv_name:
            return updated_node

        priv_info = self._get_priv(priv_name)
        _, orig_peer_arg = self._get_arg_with_index(
            orig_stmt.value.args, "peer_public_key", -1
        )
        if orig_peer_arg is None:
            return updated_node

        ct_expr = "ct_pqc"
        peer_name = self._get_node_name(orig_peer_arg.value)
        tracked_peer = self._get_peer_pub(peer_name)

        if tracked_peer is not None:
            raw_bytes_code, peer_algo, peer_curve = tracked_peer
            spec = self._resolve_hybrid_spec(
                detected_algo=peer_algo or (priv_info[0] if priv_info else None),
                detected_curve=peer_curve or (priv_info[2] if priv_info else None),
                detected_tier=priv_info[1] if priv_info else None,
            )
            _, ct_expr = self._slice_server_payload(raw_bytes_code, spec)
        elif isinstance(orig_peer_arg.value, cst.Call):
            peer_algo, peer_curve, _, peer_data_arg = self._detect_peer_deserializer(
                orig_peer_arg.value
            )
            if peer_algo and peer_data_arg is not None:
                spec = self._resolve_hybrid_spec(
                    detected_algo=peer_algo,
                    detected_curve=peer_curve,
                    detected_tier=priv_info[1] if priv_info else None,
                )
                _, ct_expr = self._slice_server_payload(
                    self._code(peer_data_arg.value), spec
                )

        if is_assign:
            target_node = (
                upd_stmt.targets[0].target
                if isinstance(upd_stmt, cst.Assign)
                else upd_stmt.target
            )
            target_str = self._code(target_node)
            decap_stmt = cst.parse_statement(
                f"pqc_shared_secret = {priv_name}_pqc.decapsulate({ct_expr})\n"
            )
            combine_stmt = cst.parse_statement(
                f"{target_str} = {target_str} + pqc_shared_secret\n"
            )
            return cst.FlattenSentinel([updated_node, decap_stmt, combine_stmt])

        classical_stmt = cst.parse_statement(
            f"shared_secret = {self._code(upd_stmt.value)}\n"
        ).with_changes(leading_lines=updated_node.leading_lines)
        decap_stmt = cst.parse_statement(
            f"pqc_shared_secret = {priv_name}_pqc.decapsulate({ct_expr})\n"
        )
        ret_stmt = cst.parse_statement("return shared_secret + pqc_shared_secret\n")
        return cst.FlattenSentinel([classical_stmt, decap_stmt, ret_stmt])


def set_kemhybrid_client_cryptography(tree: cst.Module, mappings: dict) -> cst.Module:
    wrapper = MetadataWrapper(tree)
    transformer = UpdateHybridClientKEM(mappings)
    tree = wrapper.visit(transformer)

    imp_stmts = [
        "from cryptography.hazmat.primitives.asymmetric import mlkem",
    ]
    tree = update_imports(tree, imp_stmts)
    return tree























CURVE_TO_KEM_TIER = {
    # Shared with client so ML-KEM key & ciphertext sizes always match
    # pyca/cryptography exposes MLKEM768 and MLKEM1024 (no MLKEM512)
    "secp192r1": "MLKEM768",
    "secp224r1": "MLKEM768",
    "sect163k1": "MLKEM768",
    "sect163r2": "MLKEM768",
    "sect233k1": "MLKEM768",
    "sect233r1": "MLKEM768",
    "secp256r1": "MLKEM768",
    "secp256k1": "MLKEM768",
    "sect283k1": "MLKEM768",
    "sect283r1": "MLKEM768",
    "secp384r1": "MLKEM1024",
    "secp521r1": "MLKEM1024",
    "sect409k1": "MLKEM1024",
    "sect409r1": "MLKEM1024",
    "sect571k1": "MLKEM1024",
    "sect571r1": "MLKEM1024",
}

CLASSICAL_PRIV_TYPES = {
    "X25519PrivateKey": "MLKEM768",
    "X448PrivateKey": "MLKEM1024",
    "EllipticCurvePrivateKey": None,  # falls back to default_tier
    "DHPrivateKey": None,
}

CLASSICAL_PUB_TYPES = {
    "X25519PublicKey": "MLKEM768",
    "X448PublicKey": "MLKEM1024",
    "EllipticCurvePublicKey": None,
    "DHPublicKey": None,
}

EC_ONLY_PUBLIC_FORMATS = {"X962", "UncompressedPoint", "CompressedPoint"}


class UpdateKEMServerGen(cst.CSTTransformer):
    METADATA_DEPENDENCIES = (QualifiedNameProvider,)

    def __init__(self, mappings: dict | None = None):
        super().__init__()
        self.mappings = mappings or {}
        self.default_tier = self._resolve_default_tier()

        # Lexical scope stacks (module -> class -> function)
        self.priv_scopes: list[dict[str, str]] = [{}]
        self.pub_scopes: list[dict[str, str]] = [{}]
        self.dh_param_scopes: list[set[str]] = [set()]
        self.class_scope_indices: list[int] = []

    # ---------- Scope Helpers ----------

    def _push_scope(self, is_class: bool = False) -> None:
        self.priv_scopes.append({})
        self.pub_scopes.append({})
        self.dh_param_scopes.append(set())
        if is_class:
            self.class_scope_indices.append(len(self.priv_scopes) - 1)

    def _pop_scope(self, is_class: bool = False) -> None:
        if is_class and self.class_scope_indices:
            self.class_scope_indices.pop()
        self.priv_scopes.pop()
        self.pub_scopes.pop()
        self.dh_param_scopes.pop()

    def _target_scope_idx(self, name: str) -> int:
        """Persist `self.*` attributes at the enclosing class scope so sibling methods see them."""
        if name.startswith("self.") and self.class_scope_indices:
            return self.class_scope_indices[-1]
        return -1

    def _set_priv(self, name: str, tier: str) -> None:
        self.priv_scopes[self._target_scope_idx(name)][name] = tier

    def _set_pub(self, name: str, tier: str) -> None:
        self.pub_scopes[self._target_scope_idx(name)][name] = tier

    def _set_dh_param(self, name: str) -> None:
        self.dh_param_scopes[self._target_scope_idx(name)].add(name)

    def _get_priv_tier(self, name: str | None) -> str | None:
        if not name:
            return None
        for scope in reversed(self.priv_scopes):
            if name in scope:
                return scope[name]
        return None

    def _get_pub_tier(self, name: str | None) -> str | None:
        if not name:
            return None
        for scope in reversed(self.pub_scopes):
            if name in scope:
                return scope[name]
        return None

    def _is_dh_param(self, name: str | None) -> bool:
        if not name:
            return False
        return any(name in scope for scope in reversed(self.dh_param_scopes))

    # ---------- Resolution & AST Helpers ----------

    def _resolve_default_tier(self) -> str:
        ec_curve = self.mappings.get("ec_curve")
        if ec_curve:
            return CURVE_TO_KEM_TIER.get(ec_curve.lower(), "MLKEM1024")

        kem_key_size = self.mappings.get("kem_key_size")
        if kem_key_size is not None and kem_key_size > 1024:
            return "MLKEM1024"
        return "MLKEM768"

    def _get_qnames(self, node: cst.CSTNode) -> set[str]:
        qnames = self.get_metadata(QualifiedNameProvider, node, default=None)
        return {q.name for q in qnames} if qnames else set()

    def _get_node_name(self, node: cst.BaseExpression | None) -> str | None:
        if node is None:
            return None
        if isinstance(node, cst.Name):
            return node.value
        if isinstance(node, cst.Attribute):
            return cst.helpers.get_full_name_for_node(node)
        return None

    def _code(self, node: cst.CSTNode) -> str:
        return cst.Module([]).code_for_node(node)

    def _get_arg(
        self, args: tuple[cst.Arg, ...], kw_name: str, pos_index: int
    ) -> cst.Arg | None:
        for arg in args:
            if arg.keyword is not None and arg.keyword.value == kw_name:
                return arg
        pos_args = [a for a in args if a.keyword is None]
        if -len(pos_args) <= pos_index < len(pos_args):
            return pos_args[pos_index]
        return None

    def _format_args(self, args: tuple[cst.Arg, ...]) -> str:
        formatted = []
        for arg in args:
            val_code = self._code(arg.value)
            if arg.keyword is not None:
                formatted.append(f"{arg.keyword.value}={val_code}")
            else:
                formatted.append(val_code)
        return ", ".join(formatted)

    def _resolve_ec_tier_from_call(self, call_node: cst.Call) -> str:
        curve_arg = self._get_arg(call_node.args, "curve", 0)
        if curve_arg is not None:
            for q in self._get_qnames(curve_arg.value):
                curve_name = q.rsplit(".", 1)[-1].lower()
                if curve_name in CURVE_TO_KEM_TIER:
                    return CURVE_TO_KEM_TIER[curve_name]
        return self.default_tier

    def _classify_annotation(
        self, annotation_expr: cst.BaseExpression
    ) -> tuple[str | None, str | None]:
        """Returns ('priv' | 'pub', tier) if annotation is a classical KEX key type."""
        candidates = {q.rsplit(".", 1)[-1] for q in self._get_qnames(annotation_expr)}
        raw_name = self._get_node_name(annotation_expr)
        if raw_name:
            candidates.add(raw_name.rsplit(".", 1)[-1])

        for name in candidates:
            if name in CLASSICAL_PRIV_TYPES:
                return "priv", CLASSICAL_PRIV_TYPES[name] or self.default_tier
            if name in CLASSICAL_PUB_TYPES:
                return "pub", CLASSICAL_PUB_TYPES[name] or self.default_tier
        return None, None

    def _extract_enum_leaf(self, expr: cst.BaseExpression) -> str | None:
        for q in self._get_qnames(expr):
            return q.rsplit(".", 1)[-1]
        name = self._get_node_name(expr)
        return name.rsplit(".", 1)[-1] if name else None

    def _replace_enum_member(
        self, expr: cst.BaseExpression, new_member: str
    ) -> cst.BaseExpression:
        """Swap enum leaf while preserving import aliases (e.g. ser.Encoding.X962)."""
        if isinstance(expr, cst.Attribute):
            return expr.with_changes(attr=cst.Name(new_member))
        return expr

    def _is_kex_exchange_call(
        self, original_call: cst.Call, updated_call: cst.Call
    ) -> bool:
        """Determine whether a `.exchange(...)` call belongs to classical KEX."""
        if not isinstance(updated_call.func, cst.Attribute):
            return False
        if updated_call.func.attr.value != "exchange" or not updated_call.args:
            return False

        # 1. Receiver is a tracked KEX private key
        receiver_name = self._get_node_name(updated_call.func.value)
        if self._get_priv_tier(receiver_name):
            return True

        # 2. Peer argument is a tracked KEX/ML-KEM public key
        peer_arg = self._get_arg(updated_call.args, "peer_public_key", -1)
        if peer_arg is not None:
            peer_name = self._get_node_name(peer_arg.value)
            if self._get_pub_tier(peer_name):
                return True
            if "mlkem.MLKEM" in self._code(peer_arg.value):
                return True

        # 3. Classical ECDH signature: priv.exchange(ec.ECDH(), peer_pub)
        for arg in original_call.args:
            if any(q.endswith("ECDH") for q in self._get_qnames(arg.value)):
                return True

        # 4. Static qualified name fallback
        orig_qnames = self._get_qnames(original_call.func)
        if any(
            q.endswith(("X25519PrivateKey.exchange", "X448PrivateKey.exchange", "EllipticCurvePrivateKey.exchange", "DHPrivateKey.exchange"))
            for q in orig_qnames
        ):
            return True

        return False

    def _format_encapsulate_receiver(self, expr: cst.BaseExpression) -> str:
        code = self._code(expr)
        if isinstance(expr, (cst.Name, cst.Attribute, cst.Call, cst.Subscript)):
            return code
        return f"({code})"

    

    def _normalize_private_bytes(
        self, original_node: cst.Call, updated_node: cst.Call
    ) -> cst.Call:
        new_args = list(updated_node.args)
        enc_idx = fmt_idx = enc_alg_idx = None

        for i, arg in enumerate(original_node.args):
            if arg.keyword is None:
                if i == 0:
                    enc_idx = i
                elif i == 1:
                    fmt_idx = i
                elif i == 2:
                    enc_alg_idx = i
            elif arg.keyword.value == "encoding":
                enc_idx = i
            elif arg.keyword.value == "format":
                fmt_idx = i
            elif arg.keyword.value == "encryption_algorithm":
                enc_alg_idx = i

        enc_leaf = (
            self._extract_enum_leaf(original_node.args[enc_idx].value)
            if enc_idx is not None
            else None
        )
        fmt_leaf = (
            self._extract_enum_leaf(original_node.args[fmt_idx].value)
            if fmt_idx is not None
            else None
        )

        if enc_idx is not None and enc_leaf not in {"PEM", "DER", "Raw"}:
            new_args[enc_idx] = new_args[enc_idx].with_changes(
                value=self._replace_enum_member(updated_node.args[enc_idx].value, "PEM")
            )
            enc_leaf = "PEM"

        if fmt_idx is not None:
            if enc_leaf == "Raw" and fmt_leaf != "Raw":
                new_args[fmt_idx] = new_args[fmt_idx].with_changes(
                    value=self._replace_enum_member(updated_node.args[fmt_idx].value, "Raw")
                )
            elif enc_leaf in {"PEM", "DER"} and fmt_leaf != "PKCS8":
                new_args[fmt_idx] = new_args[fmt_idx].with_changes(
                    value=self._replace_enum_member(updated_node.args[fmt_idx].value, "PKCS8")
                )

        if enc_leaf == "Raw" and enc_alg_idx is not None:
            alg_expr = updated_node.args[enc_alg_idx].value
            if isinstance(alg_expr, cst.Call):
                orig_alg = original_node.args[enc_alg_idx].value
                alg_leaf = (
                    self._extract_enum_leaf(orig_alg.func)
                    if isinstance(orig_alg, cst.Call)
                    else None
                )
                if alg_leaf != "NoEncryption":
                    new_func = (
                        alg_expr.func.with_changes(attr=cst.Name("NoEncryption"))
                        if isinstance(alg_expr.func, cst.Attribute)
                        else cst.Name("NoEncryption")
                    )
                    new_args[enc_alg_idx] = new_args[enc_alg_idx].with_changes(
                        value=alg_expr.with_changes(func=new_func, args=[])
                    )

        return updated_node.with_changes(args=new_args)

    def _normalize_public_bytes(
        self, original_node: cst.Call, updated_node: cst.Call
    ) -> cst.Call:
        new_args = list(updated_node.args)
        enc_idx = fmt_idx = None

        for i, arg in enumerate(original_node.args):
            if arg.keyword is None:
                if i == 0:
                    enc_idx = i
                elif i == 1:
                    fmt_idx = i
            elif arg.keyword.value == "encoding":
                enc_idx = i
            elif arg.keyword.value == "format":
                fmt_idx = i

        enc_leaf = (
            self._extract_enum_leaf(original_node.args[enc_idx].value)
            if enc_idx is not None
            else None
        )
        fmt_leaf = (
            self._extract_enum_leaf(original_node.args[fmt_idx].value)
            if fmt_idx is not None
            else None
        )

        if enc_idx is not None and enc_leaf not in {"PEM", "DER", "Raw"}:
            target_enc = "Raw" if enc_leaf == "X962" else "PEM"
            new_args[enc_idx] = new_args[enc_idx].with_changes(
                value=self._replace_enum_member(
                    updated_node.args[enc_idx].value, target_enc
                )
            )
            enc_leaf = target_enc

        if fmt_idx is not None:
            if enc_leaf == "Raw" and fmt_leaf != "Raw":
                new_args[fmt_idx] = new_args[fmt_idx].with_changes(
                    value=self._replace_enum_member(updated_node.args[fmt_idx].value, "Raw")
                )
            elif enc_leaf in {"PEM", "DER"} and fmt_leaf != "SubjectPublicKeyInfo":
                new_args[fmt_idx] = new_args[fmt_idx].with_changes(
                    value=self._replace_enum_member(
                        updated_node.args[fmt_idx].value, "SubjectPublicKeyInfo"
                    )
                )

        return updated_node.with_changes(args=new_args)

    

    def visit_ClassDef(self, node: cst.ClassDef) -> bool:
        self._push_scope(is_class=True)
        return True

    def leave_ClassDef(
        self, original_node: cst.ClassDef, updated_node: cst.ClassDef
    ) -> cst.ClassDef:
        self._pop_scope(is_class=True)
        return updated_node

    def visit_FunctionDef(self, node: cst.FunctionDef) -> bool:
        self._push_scope(is_class=False)

        all_params = (
            list(node.params.posonly_params)
            + list(node.params.params)
            + list(node.params.kwonly_params)
        )
        for param in all_params:
            if param.annotation is not None:
                kind, tier = self._classify_annotation(param.annotation.annotation)
                if kind == "priv" and tier:
                    self._set_priv(param.name.value, tier)
                elif kind == "pub" and tier:
                    self._set_pub(param.name.value, tier)
        return True

    def leave_FunctionDef(
        self, original_node: cst.FunctionDef, updated_node: cst.FunctionDef
    ) -> cst.FunctionDef:
        self._pop_scope(is_class=False)
        return updated_node

    def leave_Annotation(
        self, original_node: cst.Annotation, updated_node: cst.Annotation
    ) -> cst.Annotation:
        kind, tier = self._classify_annotation(original_node.annotation)
        if kind == "priv" and tier:
            return updated_node.with_changes(
                annotation=cst.parse_expression(f"mlkem.{tier}PrivateKey")
            )
        if kind == "pub" and tier:
            return updated_node.with_changes(
                annotation=cst.parse_expression(f"mlkem.{tier}PublicKey")
            )
        return updated_node

    

    def _track_assignment(
        self,
        target: cst.BaseExpression,
        original_value: cst.BaseExpression | None,
        updated_value: cst.BaseExpression,
    ) -> None:
        target_name = self._get_node_name(target)
        if not target_name or not isinstance(updated_value, cst.Call):
            return

        func_code = self._code(updated_value.func)

        # Track PEM/DER loaded public keys (ML-KEM SPKI loads natively via load_*_public_key)
        if isinstance(original_value, cst.Call):
            orig_qnames = self._get_qnames(original_value.func)
            if any(
                q.endswith(("load_pem_public_key", "load_der_public_key"))
                for q in orig_qnames
            ):
                self._set_pub(target_name, self.default_tier)
                return

        # Track derived public key: pub = priv.public_key()
        if (
            isinstance(updated_value.func, cst.Attribute)
            and updated_value.func.attr.value == "public_key"
        ):
            receiver_tier = self._get_priv_tier(
                self._get_node_name(updated_value.func.value)
            )
            if receiver_tier:
                self._set_pub(target_name, receiver_tier)
                return

        # Track ML-KEM private/public key assignments
        for tier in ("MLKEM768", "MLKEM1024"):
            if f"mlkem.{tier}PrivateKey" in func_code:
                if func_code.endswith(".public_key"):
                    self._set_pub(target_name, tier)
                else:
                    self._set_priv(target_name, tier)
                return
            if f"mlkem.{tier}PublicKey" in func_code:
                self._set_pub(target_name, tier)
                return

    def leave_Assign(
        self, original_node: cst.Assign, updated_node: cst.Assign
    ) -> cst.Assign:
        if len(updated_node.targets) == 1:
            self._track_assignment(
                updated_node.targets[0].target, original_node.value, updated_node.value
            )
        return updated_node

    def leave_AnnAssign(
        self, original_node: cst.AnnAssign, updated_node: cst.AnnAssign
    ) -> cst.AnnAssign:
        if updated_node.value is not None:
            self._track_assignment(
                updated_node.target, original_node.value, updated_node.value
            )
        return updated_node

    

    def leave_SimpleStatementLine(
        self,
        original_node: cst.SimpleStatementLine,
        updated_node: cst.SimpleStatementLine,
    ) -> cst.SimpleStatementLine | cst.FlattenSentinel[cst.SimpleStatementLine] | cst.RemovalSentinel:
        if len(original_node.body) == 1:
            orig_stmt = original_node.body[0]
            upd_stmt = updated_node.body[0]

            # 1. Remove classical DH parameter generation statements and track variable name
            dh_target = None
            dh_value = None
            if isinstance(orig_stmt, cst.Assign) and len(orig_stmt.targets) == 1:
                dh_target = orig_stmt.targets[0].target
                dh_value = orig_stmt.value
            elif isinstance(orig_stmt, cst.AnnAssign):
                dh_target = orig_stmt.target
                dh_value = orig_stmt.value

            if isinstance(dh_value, cst.Call):
                qnames = self._get_qnames(dh_value.func)
                if any(q.endswith("dh.generate_parameters") for q in qnames):
                    target_name = self._get_node_name(dh_target)
                    if target_name:
                        self._set_dh_param(target_name)
                    return cst.RemoveFromParent()

            # 2. Rewrite server `shared = priv.exchange(..., client_pub)` -> `shared, ct_pqc = client_pub.encapsulate()`
            if (
                isinstance(orig_stmt, (cst.Assign, cst.AnnAssign))
                and isinstance(upd_stmt, (cst.Assign, cst.AnnAssign))
                and isinstance(orig_stmt.value, cst.Call)
                and isinstance(upd_stmt.value, cst.Call)
                and self._is_kex_exchange_call(orig_stmt.value, upd_stmt.value)
            ):
                target_node = (
                    upd_stmt.targets[0].target
                    if isinstance(upd_stmt, cst.Assign)
                    else upd_stmt.target
                )
                target_str = self._code(target_node)
                peer_arg = self._get_arg(upd_stmt.value.args, "peer_public_key", -1)

                if peer_arg is not None:
                    peer_receiver = self._format_encapsulate_receiver(peer_arg.value)
                    new_stmt = cst.parse_statement(
                        f"{target_str}, ct_pqc = {peer_receiver}.encapsulate()"
                    )
                    return updated_node.with_changes(
                        body=new_stmt.body,
                        trailing_whitespace=updated_node.trailing_whitespace.with_changes(
                            whitespace=cst.SimpleWhitespace("  "),
                            comment=cst.Comment(
                                "# TODO: send/return ct_pqc to client for decapsulation"
                            ),
                        ),
                    )

            
            if (
                isinstance(orig_stmt, cst.Return)
                and isinstance(upd_stmt, cst.Return)
                and isinstance(orig_stmt.value, cst.Call)
                and isinstance(upd_stmt.value, cst.Call)
                and self._is_kex_exchange_call(orig_stmt.value, upd_stmt.value)
            ):
                peer_arg = self._get_arg(upd_stmt.value.args, "peer_public_key", -1)
                if peer_arg is not None:
                    peer_receiver = self._format_encapsulate_receiver(peer_arg.value)
                    encap_stmt = cst.parse_statement(
                        f"shared_secret, ct_pqc = {peer_receiver}.encapsulate()  "
                        "# TODO: send/return ct_pqc to client for decapsulation\n"
                    ).with_changes(leading_lines=updated_node.leading_lines)
                    ret_stmt = cst.parse_statement("return shared_secret, ct_pqc\n")
                    return cst.FlattenSentinel([encap_stmt, ret_stmt])

        # Flag from_seed_bytes calls (strictly requires 64-byte ML-KEM seed)
        stmt_code = self._code(updated_node)
        if ".from_seed_bytes(" in stmt_code and updated_node.trailing_whitespace.comment is None:
            updated_node = updated_node.with_changes(
                trailing_whitespace=updated_node.trailing_whitespace.with_changes(
                    whitespace=cst.SimpleWhitespace("  "),
                    comment=cst.Comment("# TODO: verify 64-byte ML-KEM seed input"),
                )
            )

        return updated_node

    # ---------- Call Rewriting ----------

    def leave_Call(
        self, original_node: cst.Call, updated_node: cst.Call
    ) -> cst.BaseExpression:
        qnames = self._get_qnames(original_node.func)

        # 1. X25519 -> ML-KEM-768
        if any(q.endswith("X25519PrivateKey.generate") for q in qnames):
            return cst.parse_expression("mlkem.MLKEM768PrivateKey.generate()")

        if any(q.endswith("X25519PrivateKey.from_private_bytes") for q in qnames):
            return cst.parse_expression(
                f"mlkem.MLKEM768PrivateKey.from_seed_bytes({self._format_args(updated_node.args)})"
            )

        if any(q.endswith("X25519PublicKey.from_public_bytes") for q in qnames):
            return cst.parse_expression(
                f"mlkem.MLKEM768PublicKey.from_public_bytes({self._format_args(updated_node.args)})"
            )

        # 2. X448 -> ML-KEM-1024
        if any(q.endswith("X448PrivateKey.generate") for q in qnames):
            return cst.parse_expression("mlkem.MLKEM1024PrivateKey.generate()")

        if any(q.endswith("X448PrivateKey.from_private_bytes") for q in qnames):
            return cst.parse_expression(
                f"mlkem.MLKEM1024PrivateKey.from_seed_bytes({self._format_args(updated_node.args)})"
            )

        if any(q.endswith("X448PublicKey.from_public_bytes") for q in qnames):
            return cst.parse_expression(
                f"mlkem.MLKEM1024PublicKey.from_public_bytes({self._format_args(updated_node.args)})"
            )

        # 3. ECDH -> Curve-matched ML-KEM (avoids touching rsa/dsa.generate_private_key)
        if any(q.endswith("ec.generate_private_key") for q in qnames):
            tier = self._resolve_ec_tier_from_call(original_node)
            return cst.parse_expression(f"mlkem.{tier}PrivateKey.generate()")

        if any(q.endswith("EllipticCurvePublicKey.from_encoded_point") for q in qnames):
            tier = self._resolve_ec_tier_from_call(original_node)
            data_arg = self._get_arg(updated_node.args, "data", 1)
            if data_arg is not None:
                return cst.parse_expression(
                    f"mlkem.{tier}PublicKey.from_public_bytes({self._code(data_arg.value)})"
                )

        # 4. Inline DH chain: dh.generate_parameters(...).generate_private_key()
        if (
            isinstance(original_node.func, cst.Attribute)
            and original_node.func.attr.value == "generate_private_key"
            and isinstance(original_node.func.value, cst.Call)
        ):
            inner_qnames = self._get_qnames(original_node.func.value.func)
            if any(q.endswith("dh.generate_parameters") for q in inner_qnames):
                return cst.parse_expression(f"mlkem.{self.default_tier}PrivateKey.generate()")

        # 5. Instance & Parameter Method Calls
        if isinstance(updated_node.func, cst.Attribute):
            receiver_name = self._get_node_name(updated_node.func.value)
            method_name = updated_node.func.attr.value

            if self._is_dh_param(receiver_name) and method_name == "generate_private_key":
                return cst.parse_expression(f"mlkem.{self.default_tier}PrivateKey.generate()")

            if self._get_priv_tier(receiver_name) and method_name == "private_bytes":
                return self._normalize_private_bytes(original_node, updated_node)

            if method_name == "public_bytes":
                is_tracked_pub = bool(self._get_pub_tier(receiver_name))
                has_ec_only_format = any(
                    self._extract_enum_leaf(a.value) in EC_ONLY_PUBLIC_FORMATS
                    for a in original_node.args
                )
                if is_tracked_pub or has_ec_only_format:
                    return self._normalize_public_bytes(original_node, updated_node)

        return updated_node


def set_kempqc_cryptography(tree: cst.Module, mappings: dict) -> cst.Module:
    wrapper = MetadataWrapper(tree)
    transformer = UpdateKEMServerGen(mappings)
    tree = wrapper.visit(transformer)

    imp_stmts = [
        "from cryptography.hazmat.primitives.asymmetric import mlkem",
    ]
    tree = update_imports(tree, imp_stmts)

    return tree






CURVE_TO_KEM_TIER = {
    # pyca/cryptography exposes MLKEM768 and MLKEM1024 (no MLKEM512)
    "secp192r1": "MLKEM768",
    "secp224r1": "MLKEM768",
    "sect163k1": "MLKEM768",
    "sect163r2": "MLKEM768",
    "sect233k1": "MLKEM768",
    "sect233r1": "MLKEM768",
    "secp256r1": "MLKEM768",
    "secp256k1": "MLKEM768",
    "sect283k1": "MLKEM768",
    "sect283r1": "MLKEM768",
    "secp384r1": "MLKEM1024",
    "secp521r1": "MLKEM1024",
    "sect409k1": "MLKEM1024",
    "sect409r1": "MLKEM1024",
    "sect571k1": "MLKEM1024",
    "sect571r1": "MLKEM1024",
}

MLKEM_PUBLIC_KEY_SIZES = {
    "MLKEM768": 1184,
    "MLKEM1024": 1568,
}

EC_PUBLIC_KEY_SIZES = {
    "secp192r1": 49,
    "secp224r1": 57,
    "secp256r1": 65,
    "secp256k1": 65,
    "secp384r1": 97,
    "secp521r1": 133,
    "sect163k1": 43,
    "sect163r2": 43,
    "sect233k1": 61,
    "sect233r1": 61,
    "sect283k1": 73,
    "sect283r1": 73,
    "sect409k1": 105,
    "sect409r1": 105,
    "sect571k1": 145,
    "sect571r1": 145,
}

CLASSICAL_PRIV_ANNOTATION_ALGO = {
    "X25519PrivateKey": "X25519",
    "X448PrivateKey": "X448",
    "EllipticCurvePrivateKey": "EC",
    "DHPrivateKey": "DH",
}


class UpdateHybridServerKEM(cst.CSTTransformer):
    METADATA_DEPENDENCIES = (QualifiedNameProvider,)

    def __init__(self, mappings: dict | None = None):
        super().__init__()
        self.mappings = mappings or {}
        self.default_tier = self._resolve_default_tier()

        # priv_scopes: var_name -> detected classical algo ("X25519", "X448", "SECP256R1", "EC", "DH")
        self.priv_scopes: list[dict[str, str]] = [{}]
        # peer_pub_scopes: var_name -> (unsliced_raw_bytes_code, detected_algo, detected_ec_curve)
        self.peer_pub_scopes: list[dict[str, tuple[str, str, str | None]]] = [{}]
        self.class_scope_indices: list[int] = []

        # Extra classical imports needed only if wrapping raw bytes directly inside .exchange()
        self.extra_imports: set[str] = set()

    

    def _push_scope(self, is_class: bool = False) -> None:
        self.priv_scopes.append({})
        self.peer_pub_scopes.append({})
        if is_class:
            self.class_scope_indices.append(len(self.priv_scopes) - 1)

    def _pop_scope(self, is_class: bool = False) -> None:
        if is_class and self.class_scope_indices:
            self.class_scope_indices.pop()
        self.priv_scopes.pop()
        self.peer_pub_scopes.pop()

    def _target_scope_idx(self, name: str) -> int:
        if name.startswith("self.") and self.class_scope_indices:
            return self.class_scope_indices[-1]
        return -1

    def _set_priv(self, name: str, algo: str) -> None:
        self.priv_scopes[self._target_scope_idx(name)][name] = algo

    def _get_priv_algo(self, name: str | None) -> str | None:
        if not name:
            return None
        for scope in reversed(self.priv_scopes):
            if name in scope:
                return scope[name]
        return None

    def _set_peer_pub(
        self, name: str, raw_expr: str, algo: str, ec_curve: str | None
    ) -> None:
        self.peer_pub_scopes[self._target_scope_idx(name)][name] = (
            raw_expr,
            algo,
            ec_curve,
        )

    def _get_peer_pub(
        self, name: str | None
    ) -> tuple[str, str, str | None] | None:
        if not name:
            return None
        for scope in reversed(self.peer_pub_scopes):
            if name in scope:
                return scope[name]
        return None

    

    def _resolve_default_tier(self) -> str:
        ec_curve = self.mappings.get("ec_curve")
        if ec_curve:
            return CURVE_TO_KEM_TIER.get(ec_curve.lower(), "MLKEM1024")
        kem_key_size = self.mappings.get("kem_key_size")
        if kem_key_size is not None and kem_key_size > 1024:
            return "MLKEM1024"
        return "MLKEM768"

    def _get_qnames(self, node: cst.CSTNode) -> set[str]:
        qnames = self.get_metadata(QualifiedNameProvider, node, default=None)
        return {q.name for q in qnames} if qnames else set()

    def _get_node_name(self, node: cst.BaseExpression | None) -> str | None:
        if node is None:
            return None
        if isinstance(node, cst.Name):
            return node.value
        if isinstance(node, cst.Attribute):
            return cst.helpers.get_full_name_for_node(node)
        return None

    def _code(self, node: cst.CSTNode) -> str:
        return cst.Module([]).code_for_node(node)

    def _safe_slice_target(self, expr_code: str, expr_node: cst.BaseExpression | None = None) -> str:
        if expr_node is not None and isinstance(
            expr_node, (cst.Name, cst.Attribute, cst.Call, cst.Subscript)
        ):
            return expr_code
        return f"({expr_code})" if any(ch in expr_code for ch in " +-*/") else expr_code

    def _get_arg(
        self, args: tuple[cst.Arg, ...], kw_name: str, pos_index: int
    ) -> cst.Arg | None:
        for arg in args:
            if arg.keyword is not None and arg.keyword.value == kw_name:
                return arg
        pos_args = [a for a in args if a.keyword is None]
        if -len(pos_args) <= pos_index < len(pos_args):
            return pos_args[pos_index]
        return None

    def _extract_curve_from_node(self, node: cst.BaseExpression) -> str | None:
        for q in self._get_qnames(node):
            leaf = q.rsplit(".", 1)[-1].lower()
            if leaf in EC_PUBLIC_KEY_SIZES:
                return leaf
        if isinstance(node, cst.Call):
            name = self._get_node_name(node.func)
            if name:
                leaf = name.rsplit(".", 1)[-1].lower()
                if leaf in EC_PUBLIC_KEY_SIZES:
                    return leaf
        return None

    def _detect_deserializer_call(
        self, call_node: cst.Call
    ) -> tuple[str | None, str | None, cst.Arg | None]:
        """
        Returns (algo, ec_curve, data_arg) if call_node loads a classical KEX public key.
        """
        qnames = self._get_qnames(call_node.func)
        if any(q.endswith("X25519PublicKey.from_public_bytes") for q in qnames):
            return "X25519", None, self._get_arg(call_node.args, "data", 0)
        if any(q.endswith("X448PublicKey.from_public_bytes") for q in qnames):
            return "X448", None, self._get_arg(call_node.args, "data", 0)
        if any(q.endswith("EllipticCurvePublicKey.from_encoded_point") for q in qnames):
            curve_arg = self._get_arg(call_node.args, "curve", 0)
            data_arg = self._get_arg(call_node.args, "data", 1)
            curve = (
                self._extract_curve_from_node(curve_arg.value)
                if curve_arg is not None
                else None
            )
            return "EC", curve, data_arg
        return None, None, None

    def _resolve_hybrid_spec(
        self, detected_algo: str | None = None, detected_curve: str | None = None
    ) -> dict:
        """
        Returns exact slicing & ML-KEM parameters following the requested wire key order:
          - X25519:     [PQC (1184B MLKEM768)  || Classical]
          - X448:       [PQC (1568B MLKEM1024) || Classical]
          - SECP256R1:  [Classical (65B)       || PQC (MLKEM768)]
          - SECP384R1:  [Classical (97B)       || PQC (MLKEM1024)]
          - EC (other): [Classical (ec_size)   || PQC (curve-matched MLKEM)]
          - Fallback:   [Classical             || PQC] if ec_curve given, else [PQC || Classical]
        """
        algo = (
            self.mappings.get("algorithm")
            or detected_algo
            or "X25519"
        ).upper()
        ec_curve = (
            self.mappings.get("ec_curve")
            or detected_curve
            or (algo.lower() if algo.lower() in EC_PUBLIC_KEY_SIZES else None)
        )

        if algo == "X25519":
            return {
                "algo": "X25519",
                "ec_curve": None,
                "order": "pqc_first",
                "split": MLKEM_PUBLIC_KEY_SIZES["MLKEM768"],  # 1184
                "mlkem_pub_cls": "MLKEM768PublicKey",
            }

        if algo == "X448":
            return {
                "algo": "X448",
                "ec_curve": None,
                "order": "pqc_first",
                "split": MLKEM_PUBLIC_KEY_SIZES["MLKEM1024"],  # 1568
                "mlkem_pub_cls": "MLKEM1024PublicKey",
            }

        if algo == "SECP256R1":
            return {
                "algo": "EC",
                "ec_curve": "secp256r1",
                "order": "classical_first",
                "split": 65,
                "mlkem_pub_cls": "MLKEM768PublicKey",
            }

        if algo == "SECP384R1":
            return {
                "algo": "EC",
                "ec_curve": "secp384r1",
                "order": "classical_first",
                "split": 97,
                "mlkem_pub_cls": "MLKEM1024PublicKey",
            }

        if algo == "EC" or algo.lower() in EC_PUBLIC_KEY_SIZES:
            curve = (ec_curve or "secp256r1").lower()
            ec_size = get_ec_public_key_size(curve) or 65
            pub_cls = get_pqc_kexwith_ec_curve_server_public_key(curve)
            return {
                "algo": "EC",
                "ec_curve": curve,
                "order": "classical_first",
                "split": ec_size,
                "mlkem_pub_cls": pub_cls,
            }

        # Fallback (matches original else branch using cryptography mlkem)
        tier = self.default_tier
        return {
            "algo": algo,
            "ec_curve": None,
            "order": "pqc_first",
            "split": MLKEM_PUBLIC_KEY_SIZES[tier],
            "mlkem_pub_cls": f"{tier}PublicKey",
        }

    def _slice_exprs(self, raw_code: str, spec: dict) -> tuple[str, str]:
        """Returns (classical_slice_code, pqc_slice_code)."""
        base = self._safe_slice_target(raw_code)
        split = spec["split"]
        if spec["order"] == "pqc_first":
            return f"{base}[{split}:]", f"{base}[:{split}]"
        return f"{base}[:{split}]", f"{base}[{split}:]"

    def _wrap_raw_classical_arg(self, classical_slice: str, spec: dict) -> cst.BaseExpression:
        """
        Wrap a raw classical key slice in the appropriate cryptography PublicKey loader
        when .exchange() was given a raw bytes buffer directly.
        """
        algo = spec["algo"]
        if algo == "X25519":
            self.extra_imports.add("from cryptography.hazmat.primitives.asymmetric import x25519")
            return cst.parse_expression(
                f"x25519.X25519PublicKey.from_public_bytes({classical_slice})"
            )
        if algo == "X448":
            self.extra_imports.add("from cryptography.hazmat.primitives.asymmetric import x448")
            return cst.parse_expression(
                f"x448.X448PublicKey.from_public_bytes({classical_slice})"
            )
        if algo == "EC" and spec["ec_curve"]:
            self.extra_imports.add("from cryptography.hazmat.primitives.asymmetric import ec")
            curve_cls = spec["ec_curve"].upper()
            return cst.parse_expression(
                f"ec.EllipticCurvePublicKey.from_encoded_point(ec.{curve_cls}(), {classical_slice})"
            )
        return cst.parse_expression(classical_slice)

    def _is_kex_exchange_call(
        self, original_call: cst.Call, updated_call: cst.Call
    ) -> bool:
        if not isinstance(updated_call.func, cst.Attribute):
            return False
        if updated_call.func.attr.value != "exchange" or not updated_call.args:
            return False

        receiver_name = self._get_node_name(updated_call.func.value)
        if self._get_priv_algo(receiver_name):
            return True

        peer_arg = self._get_arg(original_call.args, "peer_public_key", -1)
        if peer_arg is not None:
            if self._get_peer_pub(self._get_node_name(peer_arg.value)):
                return True
            if isinstance(peer_arg.value, cst.Call):
                algo, _, _ = self._detect_deserializer_call(peer_arg.value)
                if algo:
                    return True

        for arg in original_call.args:
            if any(q.endswith("ECDH") for q in self._get_qnames(arg.value)):
                return True

        orig_qnames = self._get_qnames(original_call.func)
        if any(
            q.endswith((
                "X25519PrivateKey.exchange",
                "X448PrivateKey.exchange",
                "EllipticCurvePrivateKey.exchange",
                "DHPrivateKey.exchange",
            ))
            for q in orig_qnames
        ):
            return True

        return False

    

    def visit_ClassDef(self, node: cst.ClassDef) -> bool:
        self._push_scope(is_class=True)
        return True

    def leave_ClassDef(
        self, original_node: cst.ClassDef, updated_node: cst.ClassDef
    ) -> cst.ClassDef:
        self._pop_scope(is_class=True)
        return updated_node

    def visit_FunctionDef(self, node: cst.FunctionDef) -> bool:
        self._push_scope(is_class=False)
        all_params = (
            list(node.params.posonly_params)
            + list(node.params.params)
            + list(node.params.kwonly_params)
        )
        for param in all_params:
            if param.annotation is not None:
                ann_expr = param.annotation.annotation
                candidates = {q.rsplit(".", 1)[-1] for q in self._get_qnames(ann_expr)}
                raw_name = self._get_node_name(ann_expr)
                if raw_name:
                    candidates.add(raw_name.rsplit(".", 1)[-1])
                for name in candidates:
                    if name in CLASSICAL_PRIV_ANNOTATION_ALGO:
                        self._set_priv(param.name.value, CLASSICAL_PRIV_ANNOTATION_ALGO[name])
                        break
        return True

    def leave_FunctionDef(
        self, original_node: cst.FunctionDef, updated_node: cst.FunctionDef
    ) -> cst.FunctionDef:
        self._pop_scope(is_class=False)
        return updated_node

    

    def leave_Call(
        self, original_node: cst.Call, updated_node: cst.Call
    ) -> cst.BaseExpression:
        # Slice classical bytes inside peer public key loaders so they accept concatenated hybrid bytes
        algo, curve, orig_data_arg = self._detect_deserializer_call(original_node)
        if algo and orig_data_arg is not None:
            spec = self._resolve_hybrid_spec(detected_algo=algo, detected_curve=curve)
            raw_code = self._code(orig_data_arg.value)
            classical_slice, _ = self._slice_exprs(raw_code, spec)

            # Replace the data argument in updated_node.args
            new_args = list(updated_node.args)
            target_idx = original_node.args.index(orig_data_arg)
            new_args[target_idx] = new_args[target_idx].with_changes(
                value=cst.parse_expression(classical_slice)
            )
            return updated_node.with_changes(args=new_args)

        return updated_node

    def _track_assignment(
        self, target: cst.BaseExpression, original_value: cst.BaseExpression | None
    ) -> None:
        target_name = self._get_node_name(target)
        if not target_name or not isinstance(original_value, cst.Call):
            return

        # 1. Track classical private keys (kept intact for hybrid exchange)
        qnames = self._get_qnames(original_value.func)
        if any(q.endswith(("X25519PrivateKey.generate", "X25519PrivateKey.from_private_bytes")) for q in qnames):
            self._set_priv(target_name, "X25519")
            return
        if any(q.endswith(("X448PrivateKey.generate", "X448PrivateKey.from_private_bytes")) for q in qnames):
            self._set_priv(target_name, "X448")
            return
        if any(q.endswith("ec.generate_private_key") for q in qnames):
            curve_arg = self._get_arg(original_value.args, "curve", 0)
            curve = (
                self._extract_curve_from_node(curve_arg.value)
                if curve_arg is not None
                else None
            )
            self._set_priv(target_name, curve.upper() if curve else "EC")
            return
        if isinstance(original_value.func, cst.Attribute) and original_value.func.attr.value == "generate_private_key":
            self._set_priv(target_name, "DH")
            return

        # 2. Track deserialized peer public keys and their original unsliced raw bytes expression
        algo, curve, data_arg = self._detect_deserializer_call(original_value)
        if algo and data_arg is not None:
            self._set_peer_pub(target_name, self._code(data_arg.value), algo, curve)

    def leave_Assign(
        self, original_node: cst.Assign, updated_node: cst.Assign
    ) -> cst.Assign:
        if len(original_node.targets) == 1:
            self._track_assignment(original_node.targets[0].target, original_node.value)
        return updated_node

    def leave_AnnAssign(
        self, original_node: cst.AnnAssign, updated_node: cst.AnnAssign
    ) -> cst.AnnAssign:
        if original_node.value is not None:
            self._track_assignment(original_node.target, original_node.value)
        return updated_node

    

    def leave_SimpleStatementLine(
        self,
        original_node: cst.SimpleStatementLine,
        updated_node: cst.SimpleStatementLine,
    ) -> cst.SimpleStatementLine | cst.FlattenSentinel[cst.SimpleStatementLine]:
        if len(original_node.body) != 1:
            return updated_node

        orig_stmt = original_node.body[0]
        upd_stmt = updated_node.body[0]

        is_assign = isinstance(orig_stmt, (cst.Assign, cst.AnnAssign)) and isinstance(
            upd_stmt, (cst.Assign, cst.AnnAssign)
        )
        is_return = isinstance(orig_stmt, cst.Return) and isinstance(upd_stmt, cst.Return)

        if not (is_assign or is_return):
            return updated_node
        if not (isinstance(orig_stmt.value, cst.Call) and isinstance(upd_stmt.value, cst.Call)):
            return updated_node
        if not self._is_kex_exchange_call(orig_stmt.value, upd_stmt.value):
            return updated_node

        orig_peer_arg = self._get_arg(orig_stmt.value.args, "peer_public_key", -1)
        upd_peer_arg = self._get_arg(upd_stmt.value.args, "peer_public_key", -1)
        if orig_peer_arg is None or upd_peer_arg is None:
            return updated_node

        priv_algo = self._get_priv_algo(self._get_node_name(upd_stmt.value.func.value))
        peer_name = self._get_node_name(orig_peer_arg.value)
        tracked_peer = self._get_peer_pub(peer_name)

        # Case A: peer_pub was deserialized on an earlier line (already sliced in leave_Call)
        if tracked_peer is not None:
            raw_bytes_code, detected_algo, detected_curve = tracked_peer
            spec = self._resolve_hybrid_spec(
                detected_algo=detected_algo or priv_algo,
                detected_curve=detected_curve,
            )
            _, pqc_slice = self._slice_exprs(raw_bytes_code, spec)
            classical_call = upd_stmt.value

        # Case B: inline deserializer inside exchange (already sliced in leave_Call)
        elif isinstance(orig_peer_arg.value, cst.Call) and self._detect_deserializer_call(orig_peer_arg.value)[0]:
            detected_algo, detected_curve, orig_data_arg = self._detect_deserializer_call(
                orig_peer_arg.value
            )
            spec = self._resolve_hybrid_spec(
                detected_algo=detected_algo or priv_algo,
                detected_curve=detected_curve,
            )
            raw_bytes_code = self._code(orig_data_arg.value)
            _, pqc_slice = self._slice_exprs(raw_bytes_code, spec)
            classical_call = upd_stmt.value

        # Case C: raw hybrid bytes variable passed directly to exchange(...)
        else:
            spec = self._resolve_hybrid_spec(detected_algo=priv_algo)
            raw_bytes_code = self._code(orig_peer_arg.value)
            classical_slice, pqc_slice = self._slice_exprs(raw_bytes_code, spec)

            new_args = list(upd_stmt.value.args)
            peer_idx = upd_stmt.value.args.index(upd_peer_arg)
            new_args[peer_idx] = new_args[peer_idx].with_changes(
                value=self._wrap_raw_classical_arg(classical_slice, spec)
            )
            classical_call = upd_stmt.value.with_changes(args=new_args)

        mlkem_pub_cls = spec["mlkem_pub_cls"]

        if is_assign:
            target_node = (
                upd_stmt.targets[0].target
                if isinstance(upd_stmt, cst.Assign)
                else upd_stmt.target
            )
            target_var = self._code(target_node)

            classical_stmt = updated_node.with_changes(
                body=[upd_stmt.with_changes(value=classical_call)]
            )
            encap_stmt = cst.parse_statement(
                f"pqc_shared_secret, ct_pqc = mlkem.{mlkem_pub_cls}.from_public_bytes({pqc_slice}).encapsulate()  "
                "# TODO: send/return ct_pqc alongside server public key\n"
            )
            combine_stmt = cst.parse_statement(
                f"{target_var} = {target_var} + pqc_shared_secret\n"
            )
            return cst.FlattenSentinel([classical_stmt, encap_stmt, combine_stmt])

        # is_return: `return priv.exchange(..., peer_pub)`
        classical_stmt = cst.parse_statement(
            f"shared_secret = {self._code(classical_call)}\n"
        ).with_changes(leading_lines=updated_node.leading_lines)
        encap_stmt = cst.parse_statement(
            f"pqc_shared_secret, ct_pqc = mlkem.{mlkem_pub_cls}.from_public_bytes({pqc_slice}).encapsulate()  "
            "# TODO: send/return ct_pqc alongside server public key\n"
        )
        ret_stmt = cst.parse_statement(
            "return shared_secret + pqc_shared_secret\n"
        )
        return cst.FlattenSentinel([classical_stmt, encap_stmt, ret_stmt])


def set_kemhybrid_server_cryptography(tree: cst.Module, mappings: dict) -> cst.Module:
    wrapper = MetadataWrapper(tree)
    transformer = UpdateHybridServerKEM(mappings)
    tree = wrapper.visit(transformer)

    imp_stmts = [
        "from cryptography.hazmat.primitives.asymmetric import mlkem",
        *sorted(transformer.extra_imports),
    ]
    tree = update_imports(tree, imp_stmts)
    return tree




















def set_sign_nacl(tree, mappings):
    imp_stmts = []

    class UpdateSignNaCl(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def leave_Assign(self, node, updated_node):
            if m.matches(node, m.Assign(value=m.Call())):
                qualified_names = self.get_metadata(
                    QualifiedNameProvider, node.value.func, default=None
                )
                qnames_array = [q.name for q in qualified_names] if qualified_names else []
                print('qnames ', qnames_array)

                if any(name.endswith("sign") for name in qnames_array):
                    if "signing_key" not in mappings or "message" not in mappings:
                        return updated_node

                    new_value = f"MLDSA_65().sign({mappings['signing_key']}, {mappings['message']})"
                    try:
                        new_node = updated_node.with_changes(
                            value=cst.parse_statement(new_value).body[0].value
                        )
                        return new_node
                    except Exception as e:
                        print("Error parsing new sign call:", e)
                        return updated_node

            
            if m.matches(node, m.Assign(value=m.Attribute(attr=m.Name("verify_key")))):
                rhs = node.value
                if isinstance(rhs, cst.Attribute) and isinstance(rhs.value, cst.Name):
                    rhs_var = rhs.value.value  

                    if rhs_var == mappings.get("private_key"):
                        if "public_key" not in mappings:
                            return updated_node

                        target = node.targets[0].target
                        if isinstance(target, cst.Name):
                            target_var = target.value
                        else:
                            return updated_node

                        new_assign = f"{target_var} = {mappings['public_key']}\n"
                        try:
                            return cst.parse_statement(new_assign).body[0]
                        except Exception as e:
                            print("Error parsing new verify_key assignment:", e)
                            return updated_node

                return updated_node

            return updated_node

    wrapper = MetadataWrapper(tree)
    obj = UpdateSignNaCl()
    tree = wrapper.visit(obj)

    imp_stmts = ['from quantcrypt.dss import MLDSA_65']
    tree = update_imports(tree, imp_stmts)

    return tree

def set_kemgen_node_cryptodome(tree, mappings):
    imp_stmts = []
    class UpdateKeygen(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider, ScopeProvider)

        def _extract_name(self, node):
            if isinstance(node, cst.Name):
                scope = self.get_metadata(ScopeProvider, node, default=None)
                if scope:
                    assignments = scope.assignments[node.value] if node.value in scope.assignments else set()
                    for assignment in assignments:
                        if isinstance(assignment, cst.metadata.Assignment):
                            if isinstance(assignment.node, (cst.Assign, cst.AnnAssign)):
                                return self._extract_name(assignment.node.value)
                return node.value
            elif isinstance(node, cst.Attribute):
                return f"{self._extract_name(node.value)}.{node.attr.value}"
            elif isinstance(node, cst.SimpleString):
                return node.evaluated_value  
            else:
                return None

        def leave_Assign(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value, default=None)
            qnames_array = [q.name for q in qualified_names] if qualified_names else []
            
            
            
            if any(name.endswith("ECC.generate") for name in qnames_array):
                if m.matches(node,m.Assign(value=m.Call(func=m.Attribute(value=m.Name("ECC"),attr=m.Name("generate"))))):
                    target_var = node.targets[0].target.value  

                    pub_var = f"{target_var}_pub"  
                    call_node = node.value
                    curve = None
                    pqc_ds = "MLKEM_512"
                    for arg in call_node.args:
                        if arg.keyword and arg.keyword.value == "curve":
                            curve = self._extract_name(arg.value)
                            break
                    if curve is not None:
                        pqc_ds = get_ec_curve_kem_alternate(curve)
                    new_assign = f"{pub_var} , {target_var} = {pqc_ds}().keygen()\n"
                    return cst.parse_statement(new_assign).body[0]
            elif any(name.endswith("ECC.generate.public_key") for name in qnames_array):
                target_var = node.targets[0].target.value  

                priv_var = f"{target_var}_priv"  
                call_node = node.value
                curve = None
                pqc_ds = "MLKEM_512"
                for arg in call_node.args:
                    if arg.keyword and arg.keyword.value == "curve":
                        curve = self._extract_name(arg.value)
                        break
                if curve is not None:
                    pqc_ds = get_ec_curve_kem_alternate(curve)
                new_assign = f"{target_var} , {priv_var} = {pqc_ds}().keygen()\n"
                return cst.parse_statement(new_assign).body[0]
            elif any(name.endswith("key_agreement") for name in qnames_array):
                target_var = node.targets[0].target.value  
                call_node = node.value
                curve = None
                kdf = None
                pqc_ds = "MLKEM_512"
                for arg in call_node.args:
                    if arg.keyword and arg.keyword.value == "static_pub":
                        curve = self._extract_name(arg.value)
                    if arg.keyword and arg.keyword.value == "kdf":
                        kdf = self._extract_name(arg.value)
                if kdf is None:
                    print("kdf is not present")
                    kdf = "KDF"

                
                new_assign = f"cipher_text_kem, shared_key  = {pqc_ds}().encaps({curve})"
                second_assign = f"{target_var} = {kdf}(shared_key)"
                statement_1 = cst.parse_statement(new_assign)
                statement_2 = cst.parse_statement(second_assign)
                return cst.FlattenSentinel([cst.parse_statement(new_assign).body[0],
                cst.parse_statement(second_assign).body[0]])
                
            return updated_node


        

    wrapper = MetadataWrapper(tree)
    obj = UpdateKeygen()
    
    tree = wrapper.visit(obj)
    tree = update_imports(tree, imp_stmts)
    return tree
        

def set_verify_cryptodome(tree, mappings):

    imp_stmts = []
    class UpdateKeygen(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def leave_Assign(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value, default=None)
            qnames = [q.name for q in qualified_names] if qualified_names else []
            
            
            if any(name.endswith("pkcs1_15.new.verify") for name in qnames):
                target_var = node.targets[0].target.value
                arg_var = node.value.args[1].value.value
                pqc_ds = "MLDSA_65"
                if "pqc_ds" in mappings:
                    pqc_ds = mappings['pqc_ds']
                priv = mappings['private_key']
                    
                new_assign = f"{target_var} = {pqc_ds}().verify({priv}_pub, {mappings['message']}, {arg_var})"
                return cst.parse_statement(new_assign).body[0]
            elif any(name.endswith("verify") for name in qnames):
                arg_var = node.value.args[1].value.value
                target_var = node.targets[0].target.value
                pqc_ds = "MLDSA_65"
                if "pqc_ds" in mappings:
                    pqc_ds = mappings['pqc_ds']
                priv = mappings['private_key']
                    
                new_assign = f"{target_var} = {pqc_ds}().verify({priv}_pub, {mappings['message']}, {arg_var})"
                return cst.parse_statement(new_assign).body[0]
            return updated_node
        
        def leave_Expr(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value, default=None)
            qnames = [q.name for q in qualified_names] if qualified_names else []
            
            
            if any(name.endswith("pkcs1_15.new.verify") for name in qnames):
                arg_var = node.value.args[1].value.value
                pqc_ds = "MLDSA_65"
                if "pqc_ds" in mappings:
                    pqc_ds = mappings['pqc_ds']
                priv = mappings['private_key']
                    
                new_assign = f"{pqc_ds}().verify({priv}_pub, {mappings['message']}, {arg_var})"
                return cst.parse_statement(new_assign).body[0]
            elif any(name.endswith("verify") for name in qnames):
                arg_var = node.value.args[1].value.value
                pqc_ds = "MLDSA_65"
                if "pqc_ds" in mappings:
                    pqc_ds = mappings['pqc_ds']
                priv = mappings['private_key']
                    
                new_assign = f"{pqc_ds}().verify({priv}_pub, {mappings['message']}, {arg_var})"
                return cst.parse_statement(new_assign).body[0]
               
            return updated_node
    wrapper = MetadataWrapper(tree)
    obj = UpdateKeygen()
    
    tree = wrapper.visit(obj)
    tree = update_imports(tree, imp_stmts)
    return tree


def set_sign_cryptodome(tree, mappings):

    imp_stmts = []
    class UpdateKeygen(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def leave_Assign(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value, default=None)
            qnames = [q.name for q in qualified_names] if qualified_names else []
            
            #print(qnames, "\n")
            if (any(name.endswith("DSS.new") for name in qnames)) or any(name.endswith("ECC.new") for name in qnames) or any(name.endswith("eddsa.new") for name in qnames):
                #remove node
                return cst.RemoveFromParent()

            if ('private_key' not in mappings and 'message' not in mappings):
                return updated_node
            

            if any(name.endswith("pkcs1_15.new.sign") for name in qnames):
                target_var = node.targets[0].target.value
                pqc_ds = "MLDSA_65"
                if "pqc_ds" in mappings:
                    pqc_ds = mappings['pqc_ds']
                priv = mappings['private_key']
                    
                new_assign = f"{target_var} = {pqc_ds}().sign({priv}, {mappings['message']})"
                return cst.parse_statement(new_assign).body[0]
            elif any(name.endswith("pss.new.sign") for name in qnames):
                target_var = node.targets[0].target.value
                pqc_ds = "MLDSA_65"
                if "pqc_ds" in mappings:
                    pqc_ds = mappings['pqc_ds']
                priv = mappings['private_key']
                    
                new_assign = f"{target_var} = {pqc_ds}().sign({priv}, {mappings['message']})"
                return cst.parse_statement(new_assign).body[0]
            elif any(name.endswith("sign") for name in qnames):
                target_var = node.targets[0].target.value
                pqc_ds = "MLDSA_65"
                if "pqc_ds" in mappings:
                    pqc_ds = mappings['pqc_ds']
                priv = mappings['private_key']
                    
                new_assign = f"{target_var} = {pqc_ds}().sign({priv}, {mappings['message']})"
                return cst.parse_statement(new_assign).body[0]
               
            return updated_node
    wrapper = MetadataWrapper(tree)
    obj = UpdateKeygen()
    
    tree = wrapper.visit(obj)
    tree = update_imports(tree, imp_stmts)
    return tree


def transform_ds_cryptodome(tree, mappings, library):
    imp_stmts = []
    class UpdateKeygen(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def leave_Assign(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value, default=None)
            qnames = [q.name for q in qualified_names] if qualified_names else []

            if any(name.endswith("import_key") for name in qnames):
                target_var = node.targets[0].target.value
                new_assign = f"{target_var} = load_pqc_key()"
                return cst.parse_statement(new_assign).body[0]
            
            if any(name.endswith("RSA.generate") for name in qnames):
                target_var = node.targets[0].target.value
                arg_key = node.value.args[0].value.value
                pqc_ds = "MLDSA_65"
                class_alg = f"RSA-{arg_key}"
                pqc_ds = get_pqc_sign(class_alg)
                new_assign = f"{target_var}_pub, {target_var} = {pqc_ds}().keygen()"
                return cst.parse_statement(new_assign).body[0]
            if any(name.endswith("DSA.generate") for name in qnames):
                target_var = node.targets[0].target.value
                arg_key = node.value.args[0].value.value
                pqc_ds = "MLDSA_65"
                class_alg = f"DSA-{arg_key}"
                pqc_ds = get_pqc_sign(class_alg)
                new_assign = f"{target_var}_pub, {target_var} = {pqc_ds}().keygen()"
                return cst.parse_statement(new_assign).body[0]        
            if "private_key" in mappings and any(name.endswith("publickey") for name in qnames):
                target_var = node.targets[0].target.value
                new_assign = f"{target_var} = {mappings['private_key']}_pub"
                return cst.parse_statement(new_assign).body[0]
                
            if any(name.endswith("ECC.generate") for name in qnames):
                if m.matches(node,m.Assign(value=m.Call(func=m.Attribute(value=m.Name("ECC"),attr=m.Name("generate"))))):
                    target_var = node.targets[0].target.value  

                    pub_var = f"{target_var}_pub"  
                    call_node = node.value
                    curve = None
                    pqc_ds = "MLDSA_65"
                    for arg in call_node.args:
                        if arg.keyword and arg.keyword.value == "curve":
                            curve = self._extract_name(arg.value)
                            break
                    if curve is not None:
                        pqc_ds = get_ec_curve_ds_alternate(curve)
                    new_assign = f"{pub_var} , {target_var} = {pqc_ds}().keygen()\n"
                    return cst.parse_statement(new_assign).body[0]
            if any(name.endswith("ECC.generate.publickey") for name in qnames):
                target_var = node.targets[0].target.value  

                priv_var = f"{target_var}_priv"  
                call_node = node.value
                curve = None
                pqc_ds = "MLDSA_65"
                for arg in call_node.args:
                    if arg.keyword and arg.keyword.value == "curve":
                        curve = self._extract_name(arg.value)
                        break
                if curve is not None:
                    pqc_ds = get_ec_curve_ds_alternate(curve)
                new_assign = f"{target_var} , {priv_var} = {pqc_ds}().keygen()\n"
                return cst.parse_statement(new_assign).body[0]

            return updated_node
    wrapper = MetadataWrapper(tree)
    obj = UpdateKeygen()
    
    tree = wrapper.visit(obj)
    tree = update_imports(tree, imp_stmts)
    return tree
      
        
def set_keygen_node_cryptography(tree, mappings, library):
    print('keygen cryptography\n')
    imp_stmts = []
    class UpdateKeygen(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def leave_Assign(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value, default=None)
            qnames_array = [q.name for q in qualified_names] if qualified_names else []
            
            if "public_key" not in mappings or "private_key" not in mappings:
                print('public_key or private_key is missing\n')
                return updated_node
            
            if any(name.endswith("ec.generate_private_key") for name in qnames_array):
                if m.matches(node,m.Assign(value=m.Call(func=m.Attribute(value=m.Name("ec"),attr=m.Name("generate_private_key"))))):
                    call_node = node.value
                    key_size = None
                    pqc_ds = mappings['pqc_alg']
                        
                    new_assign = f"{mappings['public_key']}, {mappings['private_key']} = {pqc_ds}().keygen()\n"
                    imp_stmts.append(f"from quantcrypt.dss import {pqc_ds}")
    
                    return cst.parse_statement(new_assign).body[0]


            # Handle RSA keygen

            if any(name == "cryptography.hazmat.primitives.asymmetric.rsa.generate_private_key" for name in qnames_array):
                if m.matches(
                    node,
                    m.Assign(
                        value=m.Call(
                            func=m.Attribute(
                                value=m.Name("rsa"),
                                attr=m.Name("generate_private_key")
                            )
                        )
                    )
                ):
                    call_node = node.value
                    key_size = None
                    pqc_ds = "MLDSA_65"
                    for arg in call_node.args:
                        if arg.keyword and arg.keyword.value == "key_size":
                            key_size = arg.value.evaluated_value
                            break
                    if key_size is not None:
                        alg = "RSA-"+str(key_size)
                        pqc_ds = get_pqc_sign(alg)
                        
                    new_assign = f"{mappings['public_key']}, {mappings['private_key']} = {pqc_ds}().keygen()\n"
    
                    return cst.parse_statement(new_assign).body[0]
            if any(name == "cryptography.hazmat.primitives.asymmetric.dsa.generate_private_key" for name in qnames_array):
                if m.matches(
                    node,
                    m.Assign(
                        value=m.Call(
                            func=m.Attribute(
                                value=m.Name("dsa"),
                                attr=m.Name("generate_private_key")
                            )
                        )
                    )
                ):
                    call_node = node.value
                    key_size = None
                    pqc_ds = "MLDSA_65"
                    for arg in call_node.args:
                        if arg.keyword and arg.keyword.value == "key_size":
                            key_size = arg.value.evaluated_value
                            break
                    if key_size is not None:
                        alg = "DSA-"+str(key_size)
                        pqc_ds = get_pqc_sign(alg)


                    imp_stmt = f"from quantcrypt.dss import {pqc_ds}"
                    imp_stmts.append(imp_stmt)
                        
                    new_assign = f"{mappings['public_key']}, {mappings['private_key']} = {pqc_ds}().keygen()\n"
    
                    return cst.parse_statement(new_assign).body[0]
            # Handle Ed25519 keygen

            if any(name == "cryptography.hazmat.primitives.asymmetric.ed25519.Ed25519PrivateKey.generate" for name in qnames_array):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("generate"))))):
                    imp_stmt = "from quantcrypt.dss import MLDSA_65"
                    imp_stmts.append(imp_stmt)
                    new_assign = f"{mappings['public_key']}, {mappings['private_key']} = MLDSA_65().keygen()\n"
                    return cst.parse_statement(new_assign).body[0]

            # Handle Ed448 keygen
            if any(name == "cryptography.hazmat.primitives.asymmetric.ed448.Ed448PrivateKey.generate" for name in qnames_array):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("generate"))))):
                    imp_stmt = "from quantcrypt.dss import MLDSA_65"
                    imp_stmts.append(imp_stmt)
                    new_assign = f"{mappings['public_key']}, {mappings['private_key']} = MLDSA_65().keygen()\n"
                    return cst.parse_statement(new_assign).body[0]
            return updated_node

    wrapper = MetadataWrapper(tree)
    obj = UpdateKeygen()
    
    tree = wrapper.visit(obj)
    tree = update_imports(tree, imp_stmts)
    return tree



def set_keygen_node_nacl(tree, mappings, library):
    print('in action keygne nacl\n')
    imp_stmts = []
    class UpdateKeygenNaCl(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def __init__(self):
            super().__init__()
            self.import_updated = False  # Track if import has been updated to avoid duplicates

        def leave_Assign(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value, default=None)
            qnames_array = [q.name for q in qualified_names] if qualified_names else []

            if any(name == "nacl.signing.SigningKey.generate" for name in qnames_array):
                if "public_key" not in mappings or "private_key" not in mappings:
                    print("Both 'public_key' and 'private_key' must be present in mappings")
                    return updated_node

                if m.matches(
                    node,
                    m.Assign(
                        value=m.Call(
                            func=m.Attribute(
                                value=m.Name("SigningKey"),
                                attr=m.Name("generate")
                            )
                        )
                    )
                ):
                    imp_stmt = f"from quantcrypt.dss import MLDSA_65"
                    imp_stmts.append(imp_stmt)
                    new_assign = f"{mappings['public_key']}, {mappings['private_key']} = MLDSA_65().keygen()"
                    return cst.parse_statement(new_assign).body[0]

            return updated_node

    wrapper = MetadataWrapper(tree)
    obj = UpdateKeygenNaCl()
    tree = wrapper.visit(obj)
    tree = update_imports(tree, imp_stmts)
    return tree





def set_verify_nacl(tree, mappings):
    print('in verify nacl')
    class UpdateVerify(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def leave_Assign(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value)
            qnames_array = [q.name for q in qualified_names]

            if any(mappings['private_key'] + '.verify_key' in name for name in qnames_array):
                new_assign = f"{node.targets[0].target.value} = {mappings.get('public_key')}"
                return cst.parse_statement(new_assign).body[0]

            if any(mappings['private_key'] + '.verify_key' in name for name in qnames_array):
                call = node.value
                args = call.args
                print("mappings, ", call, " \n", args)
                if len(args) == 1:
                    new_assign = f"{node.targets[0].target.value} = Dilithium().verify({mappings['public_key']}, {args[0].value}, None)"
                else:
                    new_assign = f"{node.targets[0].target.value} = Dilithium().verify({mappings['public_key']}, {args[0].value}, {args[1].value})"
                return cst.parse_statement(new_assign).body[0]

            return updated_node

        def leave_Expr(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value)
            qnames_array = [q.name for q in qualified_names]

            if any(mappings.get('verifying_key', '') + '.verify' in name for name in qnames_array):
                call = node.value
                args = call.args
                if len(args) == 1:
                    new_expr = f"MLDSA_65().verify({mappings.get('verifying_key')}, {args[0].value}, None)"
                else:
                    new_expr = f"Dilithium().verify({mappings.get('verifying_key')}, {args[0].value}, {args[1].value})"
                return cst.parse_statement(new_expr).body[0]

            return updated_node

    wrapper = MetadataWrapper(tree)
    obj = UpdateVerify()
    tree = wrapper.visit(obj)
    return tree




def transform_kem_nacl(tree, mappings):
    imp_stmts = ["from Crypto.Cipher import AES","from Crypto.Random import get_random_bytes", "from quantcrypt.kem import MLKEM_512",
                 "from cryptography.hazmat.primitives import hashes","from cryptography.hazmat.primitives.kdf.hkdf import HKDF"]
    class UpdateKemgen(cst.CSTTransformer):
        
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)
        
        def __init__(self):
            self.to_insert = False
        def leave_Assign(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value)
            qnames = [q.name for q in qualified_names]
            if any(name.endswith("PrivateKey.generate") for name in qnames):
                target_node = node.targets[0].target.value
                new_assign = f"{target_node}_pub, {target_node} = MLKEM_512.keygen()"
                return cst.parse_statement(new_assign).body[0]

            if any(name.endswith("public_key") for name in qnames):
                priv_var = node.value.value.value
                target_node = node.targets[0].target.value

                new_assign = f"{target_node} = {priv_var}_pub"

                return cst.parse_statement(new_assign).body[0]
            #nacl pk encrpt aes-128
            if any(name.endswith("Box") for name in qnames) and m.matches(node.value, m.Call()):
                args = node.value.args
                if len(args) >= 2:
                    arg1 = args[0].value
                    arg2 = args[1].value
                    arg1_val = cst.Module([]).code_for_node(arg1)
                    arg2_val = cst.Module([]).code_for_node(arg2)
                    new_assign = f"cipher_text, shared_key = MLKEM_512.encaps({arg2_val})"
                    second_assign = "session_key = HKDF(algorithm=hashes.SHA256(),length=32,salt=None,).derive(shared_key)"
                    statement_1 = cst.parse_statement(new_assign)
                    statement_2 = cst.parse_statement(second_assign)
                    
                    return cst.FlattenSentinel([cst.parse_statement(new_assign).body[0],
                    cst.parse_statement(second_assign).body[0]])

                elif len(args) > 0:
                    arg1 = cst.Module([]).code_for_node(args[0].value)
                    new_assign = f"shared_key = MLKEM_512.decaps({arg1_val}, ciphertext)"
                    second_assign = "session_key = HKDF(algorithm=hashes.SHA256(),length=32,salt=None,).derive(shared_key)"
                    statement_1 = cst.parse_statement(new_assign)
                    statement_2 = cst.parse_statement(second_assign)
                    return cst.FlattenSentinel([cst.parse_statement(new_assign).body[0],
                    cst.parse_statement(second_assign).body[0]])
                    
                    




            if any(name.endswith("encrypt") for name in qnames) and m.matches(node.value, m.Call()):
                call_node = node.value
                self.to_insert = True
                target_node = node.targets[0].target.value
                args = call_node.args
                if len(args) > 0:
                    arg1 = args[0].value
                    arg1_val = cst.Module([]).code_for_node(arg1)
                    new_assign = f"{target_node} = aes_encrypt(session_key, plaintext)"
                    return cst.parse_statement(new_assign).body[0]
                            
                            

            if any(name.endswith("decrypt") for name in qnames) and m.matches(node.value, m.Call()):
                call_node = node.value
                self.to_insert = True
                target_node = node.targets[0].target.value
                
                args = call_node.args
                if len(args) > 0:
                    arg1 = args[0].value
                    arg1_val = cst.Module([]).code_for_node(arg1)
                    
                    new_assign = f"{target_node} = aes_decrypt(session_key, nonce, {arg1_val}, tag)"
                    return cst.parse_statement(new_assign).body[0]

                

            return updated_node
        def update_tree_body(self, tree, code):
            parsed_body = cst.parse_module(code).body
            new_imports = [item for item in parsed_body if isinstance(item, (cst.Import, cst.ImportFrom))]
            new_non_imports = [item for item in parsed_body if not isinstance(item, (cst.Import, cst.ImportFrom))]

            insert_index = 0
            for i, item in enumerate(tree.body):
                if isinstance(item, (cst.Import, cst.ImportFrom)):
                    insert_index = i + 1
                elif isinstance(item, cst.SimpleStatementLine) and \
                     len(item.body) > 0 and \
                     isinstance(item.body[0], cst.Expr) and \
                     isinstance(item.body[0].value, cst.SimpleString):
                    insert_index = i + 1
                else:
                    break

            new_body = list(tree.body)
            new_body[insert_index:insert_index] = new_imports
            new_body[insert_index + len(new_imports):insert_index + len(new_imports)] = new_non_imports

            return tree.with_changes(body=new_body)

        
        
    wrapper = MetadataWrapper(tree)
    obj = UpdateKemgen()
    tree = wrapper.visit(obj)
    #tree = update_imports(tree, imp_stmts)
    if obj.to_insert is True:
        print('to insert\n')
        code = """
from Crypto.Cipher import AES
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
def aes_encrypt(session_key, plaintext):
    cipher = AES.new(session_key, AES.MODE_GCM)
    nonce = cipher.nonce
    ciphertext, tag = cipher.encrypt_and_digest(plaintext)
    return ciphertext, nonce, tag
def aes_decrypt(session_key, ciphertext, nonce, tag):
    cipher = AES.new(session_key, AES.MODE_GCM, nonce=nonce)
    plaintext = cipher.decrypt_and_verify(ciphertext, tag)
    return plaintext
"""
        tree = obj.update_tree_body(tree, code)
    return tree


