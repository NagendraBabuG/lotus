def keygen():
    key = RSA.generate(bits=1024)
    public_key = key.public_key()
    return key, public_key


def sign(key, msg):
    signer= pkcs1_15.new(key)
    signature = signer.sign(msg)
    b64_signature = base64.b64encode(signature)
    return b64_signature

def verify(public_key, message, signature):
    decoded_message = base64.b64decode(message)
    verifier = PKCS1.new(public_key)

    try:
        verifier.verify(decoded_message, signature)
        print(f"{signature} VALID")

    except Exception as e:
        print(e)

Signature = sing(key, message)
is_valid = verify(public_key, message, signature)