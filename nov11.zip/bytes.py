import ast
import re

HEX_PATTERN = re.compile(r"0x[0-9A-Fa-f]+")

def get_refactored_code(source_code):
    hex_literals = HEX_PATTERN.findall(source_code)
    print(hex_literals, '\n')
    try:
        tree = ast.parse(source_code)
        result = ast.unparse(tree)
    except SyntaxError as e:
        raise ValueError(f"Syntax error in source code: {e}")

    for hx in hex_literals:
        dec = str(int(hx, 16))
        result = result.replace(dec, hx)

    return result


source = """ 
def creat_cipher(v):
    v_int = bytes_to_long(v)
    q = v_int & 0xFFFFFFFFFFFFFFFF7FFFFFFF7FFFFFFF

"""

print(get_refactored_code(source))