import ast
from collections import defaultdict


class HardcodedValues(ast.NodeTransformer):
    

    def _collect_from_call(self, call, collected):
        for arg in call.args:
            if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                collected["p"].add(arg.value)

        for kw in call.keywords:
            if isinstance(kw.value, ast.Constant) and isinstance(kw.value.value, str):
                base = kw.arg or "p"
                collected[base].add(kw.value.value)

    def _build_vars_and_map(self, func_node):
        raw = defaultdict(set)

        for sub in ast.walk(func_node):
            if isinstance(sub, ast.Call):
                self._collect_from_call(sub, raw)

        var_list: list[tuple[str, str]] = []
        counters: dict[str, int] = defaultdict(int)

        for base, literals in list(raw.items()):
            if base != "p":
                for lit in literals:
                    var_list.append((base, lit))
                del raw[base]

        for lit in raw["p"]:
            idx = counters["p"]
            counters["p"] += 1
            var_list.append((f"var{idx}", lit))

        literal_to_var: dict[str, str] = {lit: name for name, lit in var_list}

        assignments: list[ast.Assign] = [
            ast.Assign(
                targets=[ast.Name(id=name, ctx=ast.Store())],
                value=ast.Constant(value=lit)
            )
            for name, lit in var_list
        ]
        for a in assignments:
            ast.fix_missing_locations(a)

        return assignments, literal_to_var

    class _Replacer(ast.NodeTransformer):
        def __init__(self, literal_to_var):
            self.l2v = literal_to_var

        def visit_Call(self, node):
            self.generic_visit(node)          

            new_args = []
            for arg in node.args:
                if (isinstance(arg, ast.Constant) and
                        isinstance(arg.value, str) and
                        arg.value in self.l2v):
                    new_args.append(ast.Name(id=self.l2v[arg.value], ctx=ast.Load()))
                else:
                    new_args.append(arg)

            new_kw = []
            for kw in node.keywords:
                if (isinstance(kw.value, ast.Constant) and
                        isinstance(kw.value.value, str) and
                        kw.value.value in self.l2v):
                    new_args.append(ast.Name(id=self.l2v[kw.value.value], ctx=ast.Load()))
                else:
                    new_kw.append(kw)

            node.args = new_args
            node.keywords = new_kw
            return node

    def _inject_into_function(self, func):
        assignments, literal_to_var = self._build_vars_and_map(func)

        if assignments:
            func.body[0:0] = assignments

        if literal_to_var:
            self._Replacer(literal_to_var).visit(func)

    def assign_var_to_hardcoded_values(self, tree):
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                self._inject_into_function(node)
        return ast.unparse(tree)

    def get_refactored_code(self, source_code):
        try:
            tree = ast.parse(source_code)
            return self.assign_var_to_hardcoded_values(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")


if __name__ == "__main__":
    src = """
import encrypter

def f1():
    encrypter.encrypt('text').encode('utf8')

def f2():
    if True:
        encrypter.encrypt('hello')
    else:
        encrypter.decrypt('world').upper()

def f3():
    var0 = 'deep'
    x = encrypter.encrypt(text=var0)
"""

    transformer = HardcodedValues()
    print(transformer.get_refactored_code(src))