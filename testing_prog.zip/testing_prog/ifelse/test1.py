def test1(score):
    grade = "A" if score >= 90 else "B" if score >= 80 else "C"
    return grade
#below ternary didn't work
x = 5
print("negative") if x < 0 else print("positive") if x > 0 else print("zero") if not x else print("Fin")