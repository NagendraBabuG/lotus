from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric.x448 import X448PrivateKey
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from quantcrypt.kem import MLKEM_768

# Generate a private key for use in the exchange.
private_key = X448PrivateKey.generate()
# In a real handshake the peer_public_key will be received from the
# other party. For this example we'll generate another private key and
# get a public key from that. Note that in a DH handshake both peers
# must agree on a common set of parameters.
peer_public_key = X448PrivateKey.generate().public_key()
shared_key = private_key.exchange(peer_public_key)
mlkem = MLKEM_768()

mlkem_public_key, mlkem_secret_key = mlkem.keygen()

# The ciphertext is assumed to be received here.
ciphertext_var = "ciphertext"

pqc_shared_secret = mlkem.decaps(
    mlkem_secret_key,
    ciphertext_var
)

# Combine classical and PQC shared secrets
shared_key = shared_key + pqc_shared_secret
# Perform key derivation.
derived_key = HKDF(
    algorithm=hashes.SHA256(),
    length=32,
    salt=None,
    info=b'handshake data',
).derive(shared_key)
# For the next handshake we MUST generate another private key.
private_key_2 = X448PrivateKey.generate()
peer_public_key_2 = X448PrivateKey.generate().public_key()
shared_key_2 = private_key_2.exchange(peer_public_key_2)
mlkem = MLKEM_768()

mlkem_public_key, mlkem_secret_key = mlkem.keygen()

# The ciphertext is assumed to be received here.
ciphertext_var = "ciphertext"

pqc_shared_secret = mlkem.decaps(
    mlkem_secret_key,
    ciphertext_var
)

# Combine classical and PQC shared secrets
shared_key_2 = shared_key_2 + pqc_shared_secret
derived_key_2 = HKDF(
    algorithm=hashes.SHA256(),
    length=32,
    salt=None,
    info=b'handshake data',
).derive(shared_key_2)