import os
"""

#parameters passed should be not modified , a new varialbe will be delcraed so original values remains uncahnged
class ParameterRefactor(ast.NodeTransformer):
    def repeated_check(self, node, par_var_map):
        if isinstance(node.func, ast.Attribute):

            if isinstance(node.func.value, ast.Call):
                node.func.value = self._repeated_check(node.func.value, par_var_map)
                for arg in node.args:
                    if arg.id in par_var_map:
                        arg.id = par_var_map[arg.id]
            else:
                for arg in node.args:
                    if arg.id in par_var_map:
                        arg.id = par_var_map[arg.id]

        elif isinstance(node.func, ast.Name):
            for arg in node.args:
                    if arg.id in par_var_map:
                        arg.id = par_var_map[arg.id]
        return node

    def remove_parameter_assign(self, tree):
        par_var_map = {}

        for node in ast.walk(tree):
            par_list = []
            par_var_map = {}

            if isinstance(node, ast.FunctionDef):
                var_idx = 0

                for elem in node.args.args:
                    par_list.append(elem.arg)

                # Update assignments
                for idx, node2 in enumerate(node.body):
                    if isinstance(node2.value, ast.Call):
                        node.body[idx].value = self.repeated_check(node2.value, par_var_map)
                        if isinstance(node2, ast.Assign):

                            for target in node2.targets:
                                if target.id in par_list:
                                    var_name = f"var{var_idx}"
                                    var_idx += 1
                                    par_var_map[target.id] = var_name
                                    target.id = var_name

                for node2 in ast.walk(node):
                    if isinstance(node2, ast.Return):
                        if isinstance(node2.value, ast.Tuple):

                            for obj in node2.value.elts:
                                if obj.id in par_var_map:
                                   obj.id=self.par_var_map[obj.id]

                        elif node2.value.id in par_var_map:
                            node2.value.id = par_var_map[node2.value.id]
            ast.fix_missing_locations(node)

        return tree

    def refactor_parameters(self, tree):
        tree = self.remove_parameter_assign(tree)
        ast.fix_missing_locations(tree)
        return ast.unparse(tree)

    def get_refactored_code(self, source_code):
        try:
            tree = ast.parse(source_code)
            return self.refactor_parameters(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")
"""


#parameters passed should be not modified , a new varialbe will be delcraed so original values remains uncahnged
import ast

class ParameterRefactor(ast.NodeTransformer):
    def visit_FunctionDef(self, node):
        
        param_names = [arg.arg for arg in node.args.args]

        init_assignments = []
        for param in param_names:
            copy_name = f"{param}_copy"
            self.par_var_map[param] = copy_name
            init_assignments.append(ast.Assign(
                targets=[ast.Name(id=copy_name, ctx=ast.Store())],
                value=ast.Name(id=param, ctx=ast.Load())
            ))

        new_body = init_assignments + [self.visit(stmt) for stmt in node.body]
        node.body = new_body
        return node

    def visit_Name(self, node):
        if isinstance(node.ctx, (ast.Load, ast.Store, ast.Del)):
            if node.id in self.par_var_map:
                return ast.copy_location(
                    ast.Name(id=self.par_var_map[node.id], ctx=node.ctx),
                    node
                )
        return node
     
    
    """
    def visit_FunctionDef(self, node):
        self.par_var_map = {}
        param_names = [arg.arg for arg in node.args.args]

        init_assignments = []
        for param in param_names:
            copy_name = f"{param}_copy"
            self.par_var_map[param] = copy_name
            init_assignments.append(ast.Assign(
                targets=[ast.Name(id=copy_name, ctx=ast.Store())],
                value=ast.Name(id=param, ctx=ast.Load())
            ))

        new_body = init_assignments + [self.visit(stmt) for stmt in node.body]
        node.body = new_body
        return node

    def visit_Name(self, node):
        if isinstance(node.ctx, (ast.Load, ast.Store, ast.Del)):
            if node.id in self.par_var_map:
                return ast.copy_location(
                    ast.Name(id=self.par_var_map[node.id], ctx=node.ctx),
                    node
                )
        return node
    """
    def refactor_parameters(self, tree):
        self.par_var_map = {}
        return ast.fix_missing_locations(self.visit(tree))

    def get_refactored_code(self, source_code):
        try:
            tree = ast.parse(source_code)
            modified_tree = self.refactor_parameters(tree)
            return ast.unparse(modified_tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")
