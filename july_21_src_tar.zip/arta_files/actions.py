import libcst as cst
import libcst.matchers as m

from libcst.metadata import FullyQualifiedNameProvider, FullRepoManager, QualifiedNameProvider, MetadataWrapper, ScopeProvider
from libcst import FlattenSentinel
import textwrap

def update_imports(tree, import_statements):
    class UpdateImportsNacl(cst.CSTTransformer):
        def __init__(self, new_imports):
            self.new_imports = [cst.parse_statement(stmt).body[0] for stmt in new_imports]


        def leave_Module(self, original_node, updated_node) -> cst.Module:
            imports = [
                stmt for stmt in updated_node.body
                if isinstance(stmt, cst.SimpleStatementLine)
                and any(isinstance(el, (cst.Import, cst.ImportFrom)) for el in stmt.body)
            ]

            all_imports = imports + self.new_imports

            seen = set()
            unique_imports = []
            for stmt in all_imports:
                if not isinstance(stmt, cst.SimpleStatementLine):
                    stmt = cst.SimpleStatementLine(body=[stmt])
                code = updated_node.code_for_node(stmt).strip()
                if code not in seen:
                    seen.add(code)
                    unique_imports.append(stmt)

            non_imports = [
                stmt for stmt in updated_node.body
                if not (
                    isinstance(stmt, cst.SimpleStatementLine)
                    and any(isinstance(el, (cst.Import, cst.ImportFrom)) for el in stmt.body)
                )
            ]

            if unique_imports and non_imports:
                unique_imports.append(cst.EmptyLine())

            return updated_node.with_changes(body=unique_imports + non_imports)

    transformer = UpdateImportsNacl(import_statements)
    return tree.visit(transformer)

def remove_imports(tree):
    class UpdateImports(cst.CSTTransformer):
        def leave_Import(self, original_node, updated_node) -> cst.CSTNode:
            filtered_names = [
                name for name in updated_node.names
                if not (
                    name.name.value.startswith("nacl") or
                    name.name.value.startswith("cryptography")
                )
            ]
            if not filtered_names:
                return cst.RemoveFromParent()
            return updated_node.with_changes(names=filtered_names)

        def leave_ImportFrom(self, original_node, updated_node):
            if not updated_node.module:
                return updated_node

            module_str = None
            if isinstance(updated_node.module, cst.Name):
                module_str = updated_node.module.value
            elif isinstance(updated_node.module, cst.Attribute):
                parts = []
                node = updated_node.module
                while isinstance(node, cst.Attribute):
                    parts.append(node.attr.value)
                    node = node.value
                if isinstance(node, cst.Name):
                    parts.append(node.value)
                module_str = ".".join(reversed(parts))

            if module_str and (
                module_str.startswith("nacl") or
                module_str.startswith("cryptography.hazmat.primitives.asymmetric")
            ):
                return cst.RemoveFromParent()

            return updated_node

        

    transformer = UpdateImports()
    return tree.visit(transformer)

temp_map = {}

def get_pqc_sign(key):
    class_to_pqc_ds = {
        "ECC-256": "MLDSA_44",
        "ECC-1024": "MLDSA_65",
        "ECC-2048": "MLDSA_87",
        "RSA-256": "MLDSA_44",
        "RSA-1024": "MLDSA_65",
        "RSA-2048": "MLDSA_87",
        "DSA-256": "MLDSA_44",
        "DSA-1024": "MLDSA_65",
        "DSA-2048": "MLDSA_87"}
    if key not in class_to_pqc_ds: return "MLDSA_65"
     
    return class_to_pqc_ds[key]
    
def get_ec_curve_ds_alternate(curve):
    #mldsa 44 < 128  65 < 256  87 >=256
    if curve == "secp256r1" or curve == "secp384r1" or curve == "secp256k1" or curve == "sect409k1" or curve == "sect409r1" or curve == "sect283k1" or curve == "sect283r1":
        return "MLDSA_65"
    elif curve == "secp521r1" or curve == "sect571k1" or curve == "sect571r1": return "MLDSA_87"
    elif curve == "secp224r1" or curve == "secp192r1" or curve == "sect233k1" or curve == "sect163k1" or curve == "sect233r1"or curve == "sect163r2":
        return "MLDSA_44"
    elif curve == "ECDH" or curve == "ECDSA":
        return "MLDSA_65"
    else:
        return "MLDSA_65"

def get_ec_curve_kem_alternate(curve):
    if curve == "p256":
        return "MLKEM_768"
    if curve == "secp256r1" or curve == "secp384r1" or curve == "secp256k1" or curve == "sect409k1" or curve == "sect409r1" or curve == "sect283k1" or curve == "sect283r1":
        return "MLKEM_768"
    elif curve == "secp521r1" or curve == "sect571k1" or curve == "sect571r1": return "MLKEM_1024"
    elif curve == "secp224r1" or curve == "secp192r1" or curve == "sect233k1" or curve == "sect163k1" or curve == "sect233r1"or curve == "sect163r2":
        return "MLKEM_512"
    elif curve == "ECDH" or curve == "ECDSA":
        return "MLKEM_768"
    else:
        return "MLKEM_768"

def return_empty_list(tree):
    return []

def return_tree(tree, **args):
    return tree
def set_primitive(tree):
    #needs to add
    return tree

def add_hash_nodes(tree):
    #needse to add
    return tree

def remove_public_key(tree, mappings):
    #needs to add
    return tree

def update_imports_cryptography(tree):


    return tree


def record_keypair_ids_pycryptodome(tree):
    mappings = {}
    class CheckCryptographyImport(cst.CSTVisitor):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def __init__(self, metadata_wrapper):
            super().__init__()
            self.metadata_wrapper = metadata_wrapper

        def visit_Assign(self, node):
            if not m.matches(node, m.Assign(value=m.Call())):
                return

            qualified_names = self.get_metadata(QualifiedNameProvider, node.value.func, default=None)
            if not qualified_names:
                return

            qualified_names = [q.name for q in qualified_names]

            #print("names ", qualified_names)
            
            if any(name.endswith("RSA.generate") for name in qualified_names):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("generate"))))):
                    mappings["private_key"] = node.targets[0].target.value
                    mappings['algorithm'] = 'RSA'
            elif any(name.endswith("DSA.generate") for name in qualified_names):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("generate"))))):
                    mappings["private_key"] = node.targets[0].target.value
                    mappings['algorithm'] = 'DSA'
            elif any(name.endswith("ECC.generate") for name in qualified_names):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("generate"))))):
                    mappings["private_key"] = node.targets[0].target.value
                    mappings['algorithm'] = 'ECC'
            elif any(name.endswith("sign") for name in qualified_names):
                    mappings["signature"] = node.targets[0].target.value
                    mappings["signing_key"] = node.value.func.value.args[0].value.value
            elif  any(name.endswith("sign") for name in qualified_names):
                if "signature" not in mappings.keys():
                    mappings["signature"] = node.targets[1].target.value
                    mappings["verifying_key"] = node.value.func.args[0].value.value
            if any(name.endswith("SHA256.new") for name in qualified_names):
                arg_key = node.value.args[0].value.value
                mappings["message"] = arg_key
    wrapper = MetadataWrapper(tree)
    mappings['algorithm'] = 'na'
    visitor = CheckCryptographyImport(wrapper)
    wrapper.visit(visitor)
    return mappings


def record_keypair_ids_nacl(tree):
    mappings = {}

    class CheckNaClImport(cst.CSTVisitor):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def __init__(self, metadata_wrapper):
            super().__init__()
            self.metadata_wrapper = metadata_wrapper
            self.key_ind = 0
            self.pk_ind = 0
        def visit_Assign(self, node):
            if not m.matches(node, m.Assign(value=m.Call())) and not m.matches(node, m.Assign(value=m.Attribute())):
                return

            qualified_names = self.get_metadata(QualifiedNameProvider, node.value.func if m.matches(node, m.Assign(value=m.Call())) else node.value, default=None)
            if not qualified_names:
                return

            qualified_names = [q.name for q in qualified_names]
            if any(name.endswith("public_key") for name in qualified_names):
                if isinstance(node.targets[0].target, cst.Name):
                    pkname = f"pub_key_{self.pk_ind}"
                    mappings[pkname] = node.targets[0].target.value
            if any(name == "nacl.signing.SigningKey.generate" for name in qualified_names):
                if isinstance(node.targets[0].target, cst.Name):
                    mappings["private_key"] = node.targets[0].target.value

            elif any(name == "nacl.signing.SigningKey.verify_key" for name in qualified_names):
                if isinstance(node.targets[0].target, cst.Name):
                    mappings["public_key"] = node.targets[0].target.value

        def visit_Call(self, node):
            if not isinstance(node.func, cst.Attribute):
                return

            qualified_names = self.get_metadata(QualifiedNameProvider, node.func, default=None)
            if not qualified_names:
                return

            qualified_names = [q.name for q in qualified_names]

            if any(name.endswith("PrivateKey.generate") for name in qualified_names):
                keyname = f"priv_key_{self.key_ind}"
                self.key_ind += 1
                if hasattr(node, "_parent_node") and m.matches(node._parent_node, m.Assign()):
                    for target in node._parent_node.targets:
                        if isinstance(target.target, cst.Name):
                            mappings[keyname] = target.target.value

            

            if any(name.endswith("sign") for name in qualified_names):
                if node.args:
                    arg = node.args[0]
                    mappings["message"] = arg.value.value
                   
                if isinstance(node.func.value, cst.Name):
                    mappings["signing_key"] = node.func.value.value

                if hasattr(node, "_parent_node") and m.matches(node._parent_node, m.Assign()):
                    for target in node._parent_node.targets:
                        if isinstance(target.target, cst.Name):
                            mappings["signature"] = target.target.value

            elif any(name == "nacl.signing.VerifyKey.encode" for name in qualified_names):
               
                if hasattr(node, "_parent_node") and m.matches(node._parent_node, m.Assign()):
                    for target in node._parent_node.targets:
                        if isinstance(target.target, cst.Name):
                            mappings["verifying_key"] = target.target.value

    wrapper = MetadataWrapper(tree)
    visitor = CheckNaClImport(wrapper)
    wrapper.visit(visitor)
    return mappings





def record_keypair_ids_cryptography(tree):
    mappings = {}
    
    class CheckCryptographyImport(cst.CSTVisitor):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def __init__(self, metadata_wrapper):
            super().__init__()
            self.metadata_wrapper = metadata_wrapper
        def leave_Assign(self, node):
            #qualified nodes are some missing
            if not m.matches(node, m.Assign(value=m.Call())):
                return

            qualified_names = self.get_metadata(QualifiedNameProvider, node.value.func, default=None)
            
            if not qualified_names:
                return

            qualified_names = [q.name for q in qualified_names]
            
            if any(name == "cryptography.hazmat.primitives.asymmetric.rsa.generate_private_key" for name in qualified_names):
                mappings["private_key"] = node.targets[0].target.value
                mappings['algorithm'] = 'rsa'
                mappings["pqc_alg"] = "MLDSA_65"
                key_size = 256
                for arg in node.value.args:
                    if arg.keyword and arg.keyword.value == "key_size":
                        key_size = arg.value.evaluated_value
                        break
                if key_size < 1024:
                    mappings["pqc_alg"] = "MLDSA_44"
                elif key_size == 1024:
                    mappings["pqc_alg"] = "MLDSA_65"
                else: mappings["pqc_alg"] = "MLDSA_87"
            elif any(name == "cryptography.hazmat.primitives.asymmetric.dsa.generate_private_key" for name in qualified_names):
                if isinstance(node.targets[0].target, cst.Name):
                    mappings["private_key"] = node.targets[0].target.value
                    mappings['algorithm'] = 'dsa'
            
            elif any(name == "cryptography.hazmat.primitives.asymmetric.rsa.RSAPrivateKey.public_key" for name in qualified_names):
                mappings["public_key"] = node.targets[0].target.value
                mappings['algorithm'] = 'rsa' 
            elif any(name == "cryptography.hazmat.primitives.asymmetric.ec.ECPrivateKey.public_key" for name in qualified_names):
                if isinstance(node.targets[0].target, cst.Name):
                    mappings["public_key"] = node.targets[0].target.value
                    mappings['algorithm']='ec'
            elif any(name.endswith("X25519PrivateKey.generate") for name in qualified_names):
                mappings["kem_private_generate"] = node.targets[0].target.value
                mappings['algorithm']='x25519'
                mappings['private_key'] = node.targets[0].target.value
                mappings[node.targets[0].target.value] = f"{node.targets[0].target.value}_pub"
            elif any(name.endswith("Ed25519PrivateKey.generate") for name in qualified_names):
                mappings["kem_private_generate"] = node.targets[0].target.value
                mappings['algorithm']='Ed25519'
                mappings['pqc_alg'] = 'MLDSA_65'
                mappings[node.targets[0].target.value] = f"{node.targets[0].target.value}_pub"
                mappings['private_key'] = node.targets[0].target.value
            elif any(name.endswith("Ed448PrivateKey.generate") for name in qualified_names):
                mappings['algorithm']='Ed448'
                mappings['pqc_alg'] = 'MLDSA_87'
                mappings[node.targets[0].target.value] = f"{node.targets[0].target.value}_pub"
                mappings['private_key'] = node.targets[0].target.value
            elif any(name.endswith("ec.generate_private_key") for name in qualified_names):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("generate_private_key"))))):
                    mappings['algorithm'] = 'ec'
                    mappings["kem_private_generate"] = node.targets[0].target.value
                    target_var = node.targets[0].target.value
                    mappings["private_key"] = target_var
                    mappings["public_key"] = f"{target_var}_pub"
                    #ec_curve = node.value.args[0].value.func.attr.value
                    arg = node.value.args[0].value
                    ec_curve = None

                    if isinstance(arg, cst.Call):

                        if isinstance(arg.func, cst.Attribute):
                            ec_curve = arg.func.attr.value

                        elif isinstance(arg.func, cst.Name):
                            ec_curve = arg.func.value

                    elif isinstance(arg, cst.Attribute):
                        ec_curve = arg.attr.value

                    elif isinstance(arg, cst.Name):
                        ec_curve = arg.value
                    if ec_curve is None: mappings['pqc_alg'] = 'MLDSA_65'
                    else: mappings['pqc_alg'] = get_ec_curve_kem_alternate(ec_curve)
                    if ec_curve is not None: mappings['ec_curve'] = ec_curve

            #kem 
            elif any(name.endswith("X25519PrivateKey.generate.public_key") for name in qualified_names):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("public_key"))))):
                    target_var = node.targets[0].target.value  # e.g., peer_public_key
                    mappings['peer_public_key'] = target_var
                    mappings['algorithm'] = 'x25519'
            if any(name.endswith("X448PrivateKey.generate.public_key") for name in qualified_names):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("public_key"))))):
                    target_var = node.targets[0].target.value  # e.g., peer_public_key
                    mappings['peer_public_key'] = target_var
                    mappings['algorithm'] = 'x448'
            if any(name.endswith("X25519PrivateKey.from_private_bytes") for name in qualified_names):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("from_private_bytes"))))):
                    arg_key = node.value.args[0].value.value
                    target_var = node.targets[0].target.value 
                    mappings['private_key'] = target_var
                    mappings['priv_key_bytes'] = arg_key
                    mappings['algorithm'] = 'x25519'
            if any(name.endswith("X25519PublicKey.from_public_bytes") for name in qualified_names):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("from_public_bytes"))))):
                    arg_key = node.value.args[0].value.value
                    target_var = node.targets[0].target.value 
                    mappings['public_key'] = target_var
                    mappings['pub_key_bytes'] = arg_key
                    mappings['algorithm'] = 'x448'
            if any(name.endswith("exchange") for name in qualified_names):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("exchange"))))):
                    arg = node.value.args[0].value  
                    arg_in_exchange = None
                    if (isinstance(arg, cst.Call) and 
                        isinstance(arg.func, cst.Attribute) and 
                        isinstance(arg.func.value, cst.Name)):
                        arg_in_exchange = arg.func.value.value
                          
                    elif isinstance(arg, cst.Name):
                        arg_in_exchange = arg.value
                    if arg_in_exchange:
                        if 'peer_public_key' in mappings:
                            if isinstance(mappings['peer_public_key'], list):
                                mappings['peer_public_key'].append(arg_in_exchange)
                            else:
                                ls = [mappings['peer_public_key']]
                                ls.append(arg_in_exchange)
                                mappings['peer_public_key'] = ls

                        else:
                            mappings['peer_public_key'] = arg_in_exchange
            if any(name.endswith("dh.generate_parameters") for name in qualified_names):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("generate_parameters"))))):
                
                    target_var = node.targets[0].target.value  
                    try:
                        call_node = node.value
                        key_size = None
                        for arg in call_node.args:
                            if arg.keyword and arg.keyword.value == "key_size":
                                key_size = arg.value.evaluated_value
                                break
                        mappings['kem_param'] = target_var
                        mappings['kem_key_size'] = key_size
                        mappings['algorithm'] = 'dh'
                    except Exception as e:
                        print('dh error', e)
            if any(name.endswith("dh.generate_parameters.parameter_bytes") for name in qualified_names):
                print('in param call dh param bytes\n')
                target_var = node.targets[0].target.value  
                target = node.targets[0].target
                if isinstance(target, cst.Attribute):
                    base = cst.helpers.get_full_name_for_node(target.value)
                    attr = target.attr.value
                    target_var = f"{base}.{attr}"
                elif isinstance(target, cst.Name):
                    target_var = target.value
                
                try:
                    call_node = node.value          
                    generate_call = call_node.func.value 
                    key_size = None
                    for arg in generate_call.args:
                        if arg.keyword and arg.keyword.value == "key_size":
                            key_size = arg.value.evaluated_value
                            break
                    mappings['kem_param'] = target_var
                    mappings['kem_key_size'] = key_size
                    mappings['algorithm'] = 'dh'
                except Exception as e:
                    print('dh error', e)
            if "kem_param" in mappings and any(name.endswith(f"{mappings['kem_param']}.generate_private_key") for name in qualified_names):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("generate_private_key"))))):
                    target_var = node.targets[0].target.value  
                    target = node.targets[0].target
                    if isinstance(target, cst.Attribute):
                        base = cst.helpers.get_full_name_for_node(target.value)
                        attr = target.attr.value
                        target_var = f"{base}.{attr}"
                    elif isinstance(target, cst.Name):
                        target_var = target.value
                    
                    mappings['kem_private_generate'] = target_var
            if any(name.endswith("load_der_parameters.generate_private_key") for name in qualified_names):
                target_var = node.targets[0].target.value  
                target = node.targets[0].target
                if isinstance(target, cst.Attribute):
                    base = cst.helpers.get_full_name_for_node(target.value)
                    attr = target.attr.value
                    target_var = f"{base}.{attr}"
                elif isinstance(target, cst.Name):
                    target_var = target.value
                mappings['kem_private_generate'] = target_var
            
            if any(name.endswith("public_key.public_bytes") for name in qualified_names):
                target_var = node.targets[0].target.value  
                target = node.targets[0].target
                if isinstance(target, cst.Attribute):
                    base = cst.helpers.get_full_name_for_node(target.value)
                    attr = target.attr.value
                    target_var = f"{base}.{attr}"
                elif isinstance(target, cst.Name):
                    target_var = target.value
                mappings['peer_public_key'] = target_var
            
            
        def visit_Call(self, node):
            if not isinstance(node.func, cst.Attribute):
                return

            qualified_names = self.get_metadata(QualifiedNameProvider, node.func, default=None)
            if not qualified_names:
                return

            qualified_names = [q.name for q in qualified_names]

            if any(name.endswith("sign") for name in qualified_names) and \
               any(name.startswith("cryptography.hazmat.primitives.asymmetric") for name in qualified_names):
                if node.args:
                    mappings["message"] = node.args[0].value.value
                if isinstance(node.func.value, cst.Name):
                    mappings["signing_key"] = node.func.value.value
                if hasattr(node, "_parent_node") and m.matches(node._parent_node, m.Assign()):
                    for target in node._parent_node.targets:
                        if isinstance(target.target, cst.Name):
                            mappings["signature"] = target.target.value

            elif any(name.endswith("verify") for name in qualified_names) and \
                 any(name.startswith("cryptography.hazmat.primitives.asymmetric") for name in qualified_names):
                if node.args:
                    mappings["signature"] = node.args[0].value.value
                if isinstance(node.func.value, cst.Name):
                    mappings["verifying_key"] = node.func.value.value

            elif any(name.startswith("cryptography.hazmat.primitives.hashes") for name in qualified_names):
                mappings["hash_algo"] = node.func.attr.value
                mappings["digest_id"] = "digest"
            

    wrapper = MetadataWrapper(tree)
    mappings['algorithm'] = 'na'
    visitor = CheckCryptographyImport(wrapper)
    wrapper.visit(visitor)
    return mappings





def remove_publickey(tree, mappings):


    class RemovePublicKey(cst.CSTTransformer):
        def leave_Assign(self, original_node, updated_node):
            if isinstance(updated_node.value, cst.Call):
                if isinstance(updated_node.value.func, cst.Attribute) and updated_node.value.func.attr.value == "publickey":
                    return cst.RemoveFromParent()
            return updated_node

    transformer = RemovePublicKey()
    tree = tree.visit(transformer)
    #tree.validate()
    return tree



def has_generate_cryptography(tree):
    class keywordChecker(cst.CSTVisitor):
        value = False
        def visit_Assign(self, node):
            if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name(value="generate"))))) or \
               m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name(value="generate_private_key"))))):
                self.value = True

    obj = keywordChecker()
    tree.visit(obj)
    return obj.value


def has_publickey(tree):
    class pkeyChecker(cst.CSTVisitor):
        value = False
        def visit_Assign(self, node):
            if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name(value="publicKey"))))):
                self.value = True

    obj = pkeyChecker()
    tree.visit(obj)
    return obj.value


def transform_ds_cryptography(tree, mappings, library):
    imp_stmts = []
    class updateSign(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def leave_Assign(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value)
            qnames= [q.name for q in qualified_names]
            if any(name.endswith('public_key') for name in qnames):
                target_var = node.targets[0].target.value
                new_assign = f"{target_var} = {mappings['private_key']}_pub"
                return cst.parse_statement(new_assign).body[0]

            if any(name.endswith("serialization.load_pem_private_key") for name in qnames):
                target_var = node.targets[0].target.value
                new_assign = f"{target_var} = load_pqc_private_key() # replace place holder function with appropriate key loading function"
                return cst.parse_statement(new_assign).body[0]
            

            

            if any(name.endswith("Ed25519PrivateKey.generate") for name in qnames):
                target_var = node.targets[0].target.value
                pqc_ds = "MLDSA_65"
                
                if "pqc_alg" in mappings: 
                    print('pqc alg\n')
                    pqc_ds = mappings["pqc_alg"]
                imp_stmt = f"from quantcrypt.dss import {pqc_ds}"
                imp_stmts.append(imp_stmt)
                new_assign = f"{target_var}_pub, {target_var} = {pqc_ds}().keygen()"
                return cst.parse_statement(new_assign).body[0]
            if any(name.endswith("Ed448PrivateKey.generate") for name in qnames):
                target_var = node.targets[0].target.value
                pqc_ds = "MLDSA_65"
                
                if "pqc_alg" in mappings: 
                    #print('pqc alg\n')
                    pqc_ds = mappings["pqc_alg"]
                imp_stmt = f"from quantcrypt.dss import {pqc_ds}"
                imp_stmts.append(imp_stmt)
                new_assign = f"{target_var}_pub, {target_var} = {pqc_ds}().keygen()"
                return cst.parse_statement(new_assign).body[0]


            if any(name.endswith("ec.generate_private_key") for name in qnames):
                if m.matches(node,m.Assign(value=m.Call(func=m.Attribute(value=m.Name("ec"),attr=m.Name("generate_private_key"))))):
                    call_node = node.value
                    key_size = None
                    pqc_ds = mappings['pqc_alg']
                    target_var = node.targets[0].target.value
                    new_assign = f"{target_var}_pub, {target_var} = {pqc_ds}().keygen()"
                    imp_stmts.append(f"from quantcrypt.dss import {pqc_ds}")
                    return cst.parse_statement(new_assign).body[0]

            # Handle RSA keygen

            if any(name == "cryptography.hazmat.primitives.asymmetric.rsa.generate_private_key" for name in qnames):
                if m.matches(
                    node,
                    m.Assign(
                        value=m.Call(
                            func=m.Attribute(
                                value=m.Name("rsa"),
                                attr=m.Name("generate_private_key")
                            )
                        )
                    )
                ):
                    call_node = node.value
                    key_size = None
                    pqc_ds = "MLDSA_65"
                    target_var = node.targets[0].target.value
                    for arg in call_node.args:
                        if arg.keyword and arg.keyword.value == "key_size":
                            key_size = arg.value.evaluated_value
                            break
                    if key_size is not None:
                        alg = "RSA-"+str(key_size)
                        pqc_ds = get_pqc_sign(alg)
                    imp_stmt = f"from quantcrypt.dss import {pqc_ds}"
                    imp_stmts.append(imp_stmt)
                    new_assign = f"{target_var}_pub, {target_var} = {pqc_ds}().keygen()"
                    return cst.parse_statement(new_assign).body[0]
            if any(name == "cryptography.hazmat.primitives.asymmetric.dsa.generate_private_key" for name in qnames):
                if m.matches(
                    node,
                    m.Assign(
                        value=m.Call(
                            func=m.Attribute(
                                value=m.Name("dsa"),
                                attr=m.Name("generate_private_key")
                            )
                        )
                    )
                ):
                    target_var = node.targets[0].target.value
                    call_node = node.value
                    key_size = None
                    pqc_ds = "MLDSA_65"
                    for arg in call_node.args:
                        if arg.keyword and arg.keyword.value == "key_size":
                            key_size = arg.value.evaluated_value
                            break
                    if key_size is not None:
                        alg = "DSA-"+str(key_size)
                        pqc_ds = get_pqc_sign(alg)

                    imp_stmt = f"from quantcrypt.dss import {pqc_ds}"
                    imp_stmts.append(imp_stmt)    
                    new_assign = f"{target_var}_pub, {target_var} = {pqc_ds}().keygen()\n"
    
                    return cst.parse_statement(new_assign).body[0]
                
            
        
            

            return updated_node


    wrapper = MetadataWrapper(tree)
    obj = updateSign()
    tree = wrapper.visit(obj)
    #tree = update_imports(tree, imp_stmts)
    return tree
    


def set_verify_cryptography(tree, mappings):
    #print('verify cryptography\n')
    class updateVerify(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def leave_Assign(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value)
            qnames = [q.name for q in qualified_names]

            
            if any(name.endswith("verify") for name in qnames):

                target_var = node.targets[0].target.value
                pqc_ds = "MLDSA_65"
                if 'pqc_alg' in mappings:
                    pqc_ds = mappings['pqc_alg']
                sign_arg = node.value.args[0].value.value
                msg_arg = node.value.args[1].value.value
                new_value = f"{target_var} = {pqc_ds}().verify({mappings['private_key']}_pub, {msg_arg},{sign_arg})"
                return cst.parse_statement(new_value).body[0]
            return updated_node
        def leave_Expr(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value)
            qnames = [q.name for q in qualified_names]

            
            if any(name.endswith("verify") for name in qnames):

                pqc_ds = "MLDSA_65"
                if 'pqc_alg' in mappings:
                    pqc_ds = mappings['pqc_alg']
                sign_arg = node.value.args[0].value.value
                msg_arg = node.value.args[1].value.value
                new_value = f"{pqc_ds}().verify({mappings['private_key']}_pub ,{msg_arg},{sign_arg})"
                return cst.parse_statement(new_value).body[0]
            return updated_node
    wrapper = MetadataWrapper(tree)
    obj = updateVerify()
    tree = wrapper.visit(obj)
    return tree



def set_sign_cryptography(tree, mappings):
    #print('sign cryptography\n')
    class updateSign(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def leave_Assign(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value)
            qnames_array = [q.name for q in qualified_names]
            #print('cryptography ', qnames_array)

            
            if 'private_key' in mappings and any(name.endswith("sign") for name in qnames_array):

                target_var = node.targets[0].target.value
                pqc_ds = "MLDSA_65"
                if 'pqc_alg' in mappings:
                    pqc_ds = mappings['pqc_alg']
                msg_arg = node.value.args[0].value.value
                new_value = f"{target_var} = {pqc_ds}().sign({mappings['private_key']}, {msg_arg})"
                return cst.parse_statement(new_value).body[0]
            
            elif 'private_key' in mappings and any(name.endswith(f"{mappings['private_key']}.sign") for name in qnames_array):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("sign"))))):
                    target_var = node.targets[0].target.value
                    if mappings['algorithm'] == 'ec':
                        msg_arg = node.value.args[0].value.value
                        
                        new_value = f"{target_var} = {mappings['pqc_alg']}().sign({mappings['private_key']}, {msg_arg})"
                        return updated_node.with_changes(value=(cst.parse_statement(new_value).body[0].value))
                    else:
                        new_value = f"{target_var} = {mappings['pqc_alg']}().sign({mappings['signing_key']}, {mappings['digest_id']})"
                        return updated_node.with_changes(value=(cst.parse_statement(new_value).body[0].value))
            return updated_node

    wrapper = MetadataWrapper(tree)
    obj = updateSign()
    tree = wrapper.visit(obj)
    return tree




def set_kemgen_cryptography(tree, mappings):
    imp_stmts = []
    kem_size = 'MLKEM_768'
    


    class UpdateKEMGen(cst.CSTTransformer):

        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        

        def leave_SimpleStatementLine(self, node, updated_node):

            if len(node.body) != 1:
                return updated_node

            assign = node.body[0]

            if not isinstance(assign, cst.Assign):
                return updated_node

            if not isinstance(assign.value, cst.Call):
                return updated_node

            qualified_names = self.get_metadata(
                QualifiedNameProvider,
                assign.value.func,
                default=None,
            )

            if not qualified_names:
                return updated_node

            qnames = [q.name for q in qualified_names]

            if not any(name.endswith("exchange") for name in qnames):
                return updated_node

            print("MATCHED EXCHANGE")

            # Shared secret variable
            target_node = assign.targets[0].target

            if isinstance(target_node, cst.Attribute):
                target_var = (
                    cst.helpers.get_full_name_for_node(target_node)
                    or target_node.attr.value
                )
            elif isinstance(target_node, cst.Name):
                target_var = target_node.value
            else:
                target_var = "shared_secret"

            # Get exchange arguments
            args = list(assign.value.args)

            if not args:
                return updated_node

            # Last argument is always the peer public key
            peer_pub_arg = args[-1]

            peer_pub_str = (
                cst.helpers.get_full_name_for_node(peer_pub_arg.value)
                or getattr(peer_pub_arg.value, "value", "peer_public_key")
            )

            algo = mappings.get("algorithm", "X25519").upper()


            if algo == "X448":
                kem_algo = "MLKEM_768"
                key_size = 1184

                # Replace last argument with peer_public_key[:key_size]
                args[-1] = args[-1].with_changes(
                    value=cst.Subscript(
                        value=peer_pub_arg.value,
                        slice=[
                            cst.SubscriptElement(
                                slice=cst.Slice(
                                    lower=cst.Integer(str(key_size)),
                                    upper=None,
                                )
                            )
                        ],
                    )
                )

                new_call = assign.value.with_changes(args=args)

                new_assign = assign.with_changes(value=new_call)

                new_stmt = updated_node.with_changes(
                    body=[new_assign]
                )

                hybrid_code = textwrap.dedent(f"""
                    mlkem = {kem_algo}()

                    ct_pqc, pqc_shared_secret = mlkem.encaps({peer_pub_str}[:{key_size}])

                    {target_var} = {target_var} + pqc_shared_secret
                """)



            elif algo == "X25519" or algo == 'ec':
                kem_algo = "MLKEM_768"
                key_size = 1184

                # Replace last argument with peer_public_key[:key_size]
                args[-1] = args[-1].with_changes(
                    value=cst.Subscript(
                        value=peer_pub_arg.value,
                        slice=[
                            cst.SubscriptElement(
                                slice=cst.Slice(
                                    lower=cst.Integer(str(key_size)),
                                    upper=None,
                                )
                            )
                        ],
                    )
                )

                new_call = assign.value.with_changes(args=args)

                new_assign = assign.with_changes(value=new_call)

                new_stmt = updated_node.with_changes(
                    body=[new_assign]
                )

                hybrid_code = textwrap.dedent(f"""
                    mlkem = {kem_algo}()

                    ct_pqc, pqc_shared_secret = mlkem.encaps({peer_pub_str}[:{key_size}])

                    {target_var} = {target_var} + pqc_shared_secret
                """)
            elif algo == "SECP384R1":
                kem_algo = "MLKEM_1024"
                key_size = 97

                # Replace last argument with peer_public_key[:key_size]
                args[-1] = args[-1].with_changes(
                    value=cst.Subscript(
                        value=peer_pub_arg.value,
                        slice=[
                            cst.SubscriptElement(
                                slice=cst.Slice(
                                    lower=None,
                                    upper=cst.Integer(str(key_size)),
                                )
                            )
                        ],
                    )
                )

                new_call = assign.value.with_changes(args=args)

                new_assign = assign.with_changes(value=new_call)

                new_stmt = updated_node.with_changes(
                    body=[new_assign]
                )

                hybrid_code = textwrap.dedent(f"""
                    mlkem = {kem_algo}()

                    ct_pqc, pqc_shared_secret = mlkem.encaps({peer_pub_str}[{key_size}:])

                    {target_var} = {target_var} + pqc_shared_secret
                """)
            elif algo == "SECP256R1":
                kem_algo = "MLKEM_768"
                key_size = 65

                # Replace last argument with peer_public_key[:key_size]
                args[-1] = args[-1].with_changes(
                    value=cst.Subscript(
                        value=peer_pub_arg.value,
                        slice=[
                            cst.SubscriptElement(
                                slice=cst.Slice(
                                    lower=None,
                                    upper=cst.Integer(str(key_size)),
                                )
                            )
                        ],
                    )
                )

                new_call = assign.value.with_changes(args=args)

                new_assign = assign.with_changes(value=new_call)

                new_stmt = updated_node.with_changes(
                    body=[new_assign]
                )

                hybrid_code = textwrap.dedent(f"""
                    mlkem = {kem_algo}()

                    ct_pqc, pqc_shared_secret = mlkem.encaps({peer_pub_str}[{key_size}:])

                    {target_var} = {target_var} + pqc_shared_secret
                """)
            
            else:

                kem_algo = "MLKEM_768"
                key_size = 1184
                
                args[-1] = args[-1].with_changes(
                    value=cst.Subscript(
                        value=peer_pub_arg.value,
                        slice=[
                            cst.SubscriptElement(
                                slice=cst.Slice(
                                    lower=cst.Integer(str(key_size)),
                                    upper=None,
                                )
                            )
                        ],
                    )
                )

                new_call = assign.value.with_changes(args=args)

                new_assign = assign.with_changes(value=new_call)

                new_stmt = updated_node.with_changes(
                    body=[new_assign]
                )

                hybrid_code = textwrap.dedent(f"""
                    mlkem = {kem_algo}()

                    ct_pqc, pqc_shared_secret = mlkem.encaps({peer_pub_str}[:{key_size}])

                    {target_var} = {target_var} + pqc_shared_secret
                """)


            try:
                module = cst.parse_module(hybrid_code)
    
                return cst.FlattenSentinel(
                    [
                        new_stmt,
                        *module.body,
                    ]
                )

            except Exception as e:
                print(f"Hybrid transform error: {e}")
                return updated_node



    wrapper = MetadataWrapper(tree)
    obj = UpdateKEMGen()
    tree = wrapper.visit(obj)

    if 'kem_key_size' in mappings:
        if mappings['kem_key_size'] > 1024:
            kem_size = 'MLKEM_1024'
        elif mappings['kem_key_size'] == 1024:
            kem_size = 'MLKEM_768'
        else:
            kem_size = 'MLKEM_512'

    imp_stmts = [f"from quantcrypt.kem import {kem_size}"]
    tree = update_imports(tree, imp_stmts)
    return tree





























def set_sign_nacl(tree, mappings):
    imp_stmts = []

    class UpdateSignNaCl(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def leave_Assign(self, node, updated_node):
            if m.matches(node, m.Assign(value=m.Call())):
                qualified_names = self.get_metadata(
                    QualifiedNameProvider, node.value.func, default=None
                )
                qnames_array = [q.name for q in qualified_names] if qualified_names else []
                print('qnames ', qnames_array)

                if any(name.endswith("sign") for name in qnames_array):
                    if "signing_key" not in mappings or "message" not in mappings:
                        return updated_node

                    new_value = f"MLDSA_65().sign({mappings['signing_key']}, {mappings['message']})"
                    try:
                        new_node = updated_node.with_changes(
                            value=cst.parse_statement(new_value).body[0].value
                        )
                        return new_node
                    except Exception as e:
                        print("Error parsing new sign call:", e)
                        return updated_node

            
            if m.matches(node, m.Assign(value=m.Attribute(attr=m.Name("verify_key")))):
                rhs = node.value
                if isinstance(rhs, cst.Attribute) and isinstance(rhs.value, cst.Name):
                    rhs_var = rhs.value.value  

                    if rhs_var == mappings.get("private_key"):
                        if "public_key" not in mappings:
                            return updated_node

                        target = node.targets[0].target
                        if isinstance(target, cst.Name):
                            target_var = target.value
                        else:
                            return updated_node

                        new_assign = f"{target_var} = {mappings['public_key']}\n"
                        try:
                            return cst.parse_statement(new_assign).body[0]
                        except Exception as e:
                            print("Error parsing new verify_key assignment:", e)
                            return updated_node

                return updated_node

            return updated_node

    wrapper = MetadataWrapper(tree)
    obj = UpdateSignNaCl()
    tree = wrapper.visit(obj)

    imp_stmts = ['from quantcrypt.dss import MLDSA_65']
    tree = update_imports(tree, imp_stmts)

    return tree

def set_kemgen_node_cryptodome(tree, mappings):
    imp_stmts = []
    class UpdateKeygen(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider, ScopeProvider)

        def _extract_name(self, node):
            if isinstance(node, cst.Name):
                scope = self.get_metadata(ScopeProvider, node, default=None)
                if scope:
                    assignments = scope.assignments[node.value] if node.value in scope.assignments else set()
                    for assignment in assignments:
                        if isinstance(assignment, cst.metadata.Assignment):
                            if isinstance(assignment.node, (cst.Assign, cst.AnnAssign)):
                                return self._extract_name(assignment.node.value)
                return node.value
            elif isinstance(node, cst.Attribute):
                return f"{self._extract_name(node.value)}.{node.attr.value}"
            elif isinstance(node, cst.SimpleString):
                return node.evaluated_value  
            else:
                return None

        def leave_Assign(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value, default=None)
            qnames_array = [q.name for q in qualified_names] if qualified_names else []
            
            
            
            if any(name.endswith("ECC.generate") for name in qnames_array):
                if m.matches(node,m.Assign(value=m.Call(func=m.Attribute(value=m.Name("ECC"),attr=m.Name("generate"))))):
                    target_var = node.targets[0].target.value  

                    pub_var = f"{target_var}_pub"  
                    call_node = node.value
                    curve = None
                    pqc_ds = "MLKEM_512"
                    for arg in call_node.args:
                        if arg.keyword and arg.keyword.value == "curve":
                            curve = self._extract_name(arg.value)
                            break
                    if curve is not None:
                        pqc_ds = get_ec_curve_kem_alternate(curve)
                    new_assign = f"{pub_var} , {target_var} = {pqc_ds}().keygen()\n"
                    return cst.parse_statement(new_assign).body[0]
            elif any(name.endswith("ECC.generate.public_key") for name in qnames_array):
                target_var = node.targets[0].target.value  

                priv_var = f"{target_var}_priv"  
                call_node = node.value
                curve = None
                pqc_ds = "MLKEM_512"
                for arg in call_node.args:
                    if arg.keyword and arg.keyword.value == "curve":
                        curve = self._extract_name(arg.value)
                        break
                if curve is not None:
                    pqc_ds = get_ec_curve_kem_alternate(curve)
                new_assign = f"{target_var} , {priv_var} = {pqc_ds}().keygen()\n"
                return cst.parse_statement(new_assign).body[0]
            elif any(name.endswith("key_agreement") for name in qnames_array):
                target_var = node.targets[0].target.value  
                call_node = node.value
                curve = None
                kdf = None
                pqc_ds = "MLKEM_512"
                for arg in call_node.args:
                    if arg.keyword and arg.keyword.value == "static_pub":
                        curve = self._extract_name(arg.value)
                    if arg.keyword and arg.keyword.value == "kdf":
                        kdf = self._extract_name(arg.value)
                if kdf is None:
                    print("kdf is not present")
                    kdf = "KDF"

                
                new_assign = f"cipher_text_kem, shared_key  = {pqc_ds}().encaps({curve})"
                second_assign = f"{target_var} = {kdf}(shared_key)"
                statement_1 = cst.parse_statement(new_assign)
                statement_2 = cst.parse_statement(second_assign)
                return cst.FlattenSentinel([cst.parse_statement(new_assign).body[0],
                cst.parse_statement(second_assign).body[0]])
                
            return updated_node


        

    wrapper = MetadataWrapper(tree)
    obj = UpdateKeygen()
    
    tree = wrapper.visit(obj)
    tree = update_imports(tree, imp_stmts)
    return tree
        

def set_verify_cryptodome(tree, mappings):

    imp_stmts = []
    class UpdateKeygen(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def leave_Assign(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value, default=None)
            qnames = [q.name for q in qualified_names] if qualified_names else []
            
            
            if any(name.endswith("pkcs1_15.new.verify") for name in qnames):
                target_var = node.targets[0].target.value
                arg_var = node.value.args[1].value.value
                pqc_ds = "MLDSA_65"
                if "pqc_ds" in mappings:
                    pqc_ds = mappings['pqc_ds']
                priv = mappings['private_key']
                    
                new_assign = f"{target_var} = {pqc_ds}().verify({priv}_pub, {mappings['message']}, {arg_var})"
                return cst.parse_statement(new_assign).body[0]
            elif any(name.endswith("verify") for name in qnames):
                arg_var = node.value.args[1].value.value
                target_var = node.targets[0].target.value
                pqc_ds = "MLDSA_65"
                if "pqc_ds" in mappings:
                    pqc_ds = mappings['pqc_ds']
                priv = mappings['private_key']
                    
                new_assign = f"{target_var} = {pqc_ds}().verify({priv}_pub, {mappings['message']}, {arg_var})"
                return cst.parse_statement(new_assign).body[0]
            return updated_node
        
        def leave_Expr(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value, default=None)
            qnames = [q.name for q in qualified_names] if qualified_names else []
            
            
            if any(name.endswith("pkcs1_15.new.verify") for name in qnames):
                arg_var = node.value.args[1].value.value
                pqc_ds = "MLDSA_65"
                if "pqc_ds" in mappings:
                    pqc_ds = mappings['pqc_ds']
                priv = mappings['private_key']
                    
                new_assign = f"{pqc_ds}().verify({priv}_pub, {mappings['message']}, {arg_var})"
                return cst.parse_statement(new_assign).body[0]
            elif any(name.endswith("verify") for name in qnames):
                arg_var = node.value.args[1].value.value
                pqc_ds = "MLDSA_65"
                if "pqc_ds" in mappings:
                    pqc_ds = mappings['pqc_ds']
                priv = mappings['private_key']
                    
                new_assign = f"{pqc_ds}().verify({priv}_pub, {mappings['message']}, {arg_var})"
                return cst.parse_statement(new_assign).body[0]
               
            return updated_node
    wrapper = MetadataWrapper(tree)
    obj = UpdateKeygen()
    
    tree = wrapper.visit(obj)
    tree = update_imports(tree, imp_stmts)
    return tree


def set_sign_cryptodome(tree, mappings):

    imp_stmts = []
    class UpdateKeygen(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def leave_Assign(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value, default=None)
            qnames = [q.name for q in qualified_names] if qualified_names else []
            
            #print(qnames, "\n")
            if (any(name.endswith("DSS.new") for name in qnames)) or any(name.endswith("ECC.new") for name in qnames) or any(name.endswith("eddsa.new") for name in qnames):
                #remove node
                return cst.RemoveFromParent()

            if ('private_key' not in mappings and 'message' not in mappings):
                return updated_node
            

            if any(name.endswith("pkcs1_15.new.sign") for name in qnames):
                target_var = node.targets[0].target.value
                pqc_ds = "MLDSA_65"
                if "pqc_ds" in mappings:
                    pqc_ds = mappings['pqc_ds']
                priv = mappings['private_key']
                    
                new_assign = f"{target_var} = {pqc_ds}().sign({priv}, {mappings['message']})"
                return cst.parse_statement(new_assign).body[0]
            elif any(name.endswith("pss.new.sign") for name in qnames):
                target_var = node.targets[0].target.value
                pqc_ds = "MLDSA_65"
                if "pqc_ds" in mappings:
                    pqc_ds = mappings['pqc_ds']
                priv = mappings['private_key']
                    
                new_assign = f"{target_var} = {pqc_ds}().sign({priv}, {mappings['message']})"
                return cst.parse_statement(new_assign).body[0]
            elif any(name.endswith("sign") for name in qnames):
                target_var = node.targets[0].target.value
                pqc_ds = "MLDSA_65"
                if "pqc_ds" in mappings:
                    pqc_ds = mappings['pqc_ds']
                priv = mappings['private_key']
                    
                new_assign = f"{target_var} = {pqc_ds}().sign({priv}, {mappings['message']})"
                return cst.parse_statement(new_assign).body[0]
               
            return updated_node
    wrapper = MetadataWrapper(tree)
    obj = UpdateKeygen()
    
    tree = wrapper.visit(obj)
    tree = update_imports(tree, imp_stmts)
    return tree


def transform_ds_cryptodome(tree, mappings, library):
    imp_stmts = []
    class UpdateKeygen(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def leave_Assign(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value, default=None)
            qnames = [q.name for q in qualified_names] if qualified_names else []

            if any(name.endswith("import_key") for name in qnames):
                target_var = node.targets[0].target.value
                new_assign = f"{target_var} = load_pqc_key()"
                return cst.parse_statement(new_assign).body[0]
            
            if any(name.endswith("RSA.generate") for name in qnames):
                target_var = node.targets[0].target.value
                arg_key = node.value.args[0].value.value
                pqc_ds = "MLDSA_65"
                class_alg = f"RSA-{arg_key}"
                pqc_ds = get_pqc_sign(class_alg)
                new_assign = f"{target_var}_pub, {target_var} = {pqc_ds}().keygen()"
                return cst.parse_statement(new_assign).body[0]
            if any(name.endswith("DSA.generate") for name in qnames):
                target_var = node.targets[0].target.value
                arg_key = node.value.args[0].value.value
                pqc_ds = "MLDSA_65"
                class_alg = f"DSA-{arg_key}"
                pqc_ds = get_pqc_sign(class_alg)
                new_assign = f"{target_var}_pub, {target_var} = {pqc_ds}().keygen()"
                return cst.parse_statement(new_assign).body[0]        
            if "private_key" in mappings and any(name.endswith("publickey") for name in qnames):
                target_var = node.targets[0].target.value
                new_assign = f"{target_var} = {mappings['private_key']}_pub"
                return cst.parse_statement(new_assign).body[0]
                
            if any(name.endswith("ECC.generate") for name in qnames):
                if m.matches(node,m.Assign(value=m.Call(func=m.Attribute(value=m.Name("ECC"),attr=m.Name("generate"))))):
                    target_var = node.targets[0].target.value  

                    pub_var = f"{target_var}_pub"  
                    call_node = node.value
                    curve = None
                    pqc_ds = "MLDSA_65"
                    for arg in call_node.args:
                        if arg.keyword and arg.keyword.value == "curve":
                            curve = self._extract_name(arg.value)
                            break
                    if curve is not None:
                        pqc_ds = get_ec_curve_ds_alternate(curve)
                    new_assign = f"{pub_var} , {target_var} = {pqc_ds}().keygen()\n"
                    return cst.parse_statement(new_assign).body[0]
            if any(name.endswith("ECC.generate.publickey") for name in qnames):
                target_var = node.targets[0].target.value  

                priv_var = f"{target_var}_priv"  
                call_node = node.value
                curve = None
                pqc_ds = "MLDSA_65"
                for arg in call_node.args:
                    if arg.keyword and arg.keyword.value == "curve":
                        curve = self._extract_name(arg.value)
                        break
                if curve is not None:
                    pqc_ds = get_ec_curve_ds_alternate(curve)
                new_assign = f"{target_var} , {priv_var} = {pqc_ds}().keygen()\n"
                return cst.parse_statement(new_assign).body[0]

            return updated_node
    wrapper = MetadataWrapper(tree)
    obj = UpdateKeygen()
    
    tree = wrapper.visit(obj)
    tree = update_imports(tree, imp_stmts)
    return tree
      
        
def set_keygen_node_cryptography(tree, mappings, library):
    print('keygen cryptography\n')
    imp_stmts = []
    class UpdateKeygen(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def leave_Assign(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value, default=None)
            qnames_array = [q.name for q in qualified_names] if qualified_names else []
            
            if "public_key" not in mappings or "private_key" not in mappings:
                print('public_key or private_key is missing\n')
                return updated_node
            
            if any(name.endswith("ec.generate_private_key") for name in qnames_array):
                if m.matches(node,m.Assign(value=m.Call(func=m.Attribute(value=m.Name("ec"),attr=m.Name("generate_private_key"))))):
                    call_node = node.value
                    key_size = None
                    pqc_ds = mappings['pqc_alg']
                        
                    new_assign = f"{mappings['public_key']}, {mappings['private_key']} = {pqc_ds}().keygen()\n"
                    imp_stmts.append(f"from quantcrypt.dss import {pqc_ds}")
    
                    return cst.parse_statement(new_assign).body[0]


            # Handle RSA keygen

            if any(name == "cryptography.hazmat.primitives.asymmetric.rsa.generate_private_key" for name in qnames_array):
                if m.matches(
                    node,
                    m.Assign(
                        value=m.Call(
                            func=m.Attribute(
                                value=m.Name("rsa"),
                                attr=m.Name("generate_private_key")
                            )
                        )
                    )
                ):
                    call_node = node.value
                    key_size = None
                    pqc_ds = "MLDSA_65"
                    for arg in call_node.args:
                        if arg.keyword and arg.keyword.value == "key_size":
                            key_size = arg.value.evaluated_value
                            break
                    if key_size is not None:
                        alg = "RSA-"+str(key_size)
                        pqc_ds = get_pqc_sign(alg)
                        
                    new_assign = f"{mappings['public_key']}, {mappings['private_key']} = {pqc_ds}().keygen()\n"
    
                    return cst.parse_statement(new_assign).body[0]
            if any(name == "cryptography.hazmat.primitives.asymmetric.dsa.generate_private_key" for name in qnames_array):
                if m.matches(
                    node,
                    m.Assign(
                        value=m.Call(
                            func=m.Attribute(
                                value=m.Name("dsa"),
                                attr=m.Name("generate_private_key")
                            )
                        )
                    )
                ):
                    call_node = node.value
                    key_size = None
                    pqc_ds = "MLDSA_65"
                    for arg in call_node.args:
                        if arg.keyword and arg.keyword.value == "key_size":
                            key_size = arg.value.evaluated_value
                            break
                    if key_size is not None:
                        alg = "DSA-"+str(key_size)
                        pqc_ds = get_pqc_sign(alg)


                    imp_stmt = f"from quantcrypt.dss import {pqc_ds}"
                    imp_stmts.append(imp_stmt)
                        
                    new_assign = f"{mappings['public_key']}, {mappings['private_key']} = {pqc_ds}().keygen()\n"
    
                    return cst.parse_statement(new_assign).body[0]
            # Handle Ed25519 keygen

            if any(name == "cryptography.hazmat.primitives.asymmetric.ed25519.Ed25519PrivateKey.generate" for name in qnames_array):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("generate"))))):
                    imp_stmt = "from quantcrypt.dss import MLDSA_65"
                    imp_stmts.append(imp_stmt)
                    new_assign = f"{mappings['public_key']}, {mappings['private_key']} = MLDSA_65().keygen()\n"
                    return cst.parse_statement(new_assign).body[0]

            # Handle Ed448 keygen
            if any(name == "cryptography.hazmat.primitives.asymmetric.ed448.Ed448PrivateKey.generate" for name in qnames_array):
                if m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name("generate"))))):
                    imp_stmt = "from quantcrypt.dss import MLDSA_65"
                    imp_stmts.append(imp_stmt)
                    new_assign = f"{mappings['public_key']}, {mappings['private_key']} = MLDSA_65().keygen()\n"
                    return cst.parse_statement(new_assign).body[0]
            return updated_node

    wrapper = MetadataWrapper(tree)
    obj = UpdateKeygen()
    
    tree = wrapper.visit(obj)
    tree = update_imports(tree, imp_stmts)
    return tree



def set_keygen_node_nacl(tree, mappings, library):
    print('in action keygne nacl\n')
    imp_stmts = []
    class UpdateKeygenNaCl(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def __init__(self):
            super().__init__()
            self.import_updated = False  # Track if import has been updated to avoid duplicates

        def leave_Assign(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value, default=None)
            qnames_array = [q.name for q in qualified_names] if qualified_names else []

            if any(name == "nacl.signing.SigningKey.generate" for name in qnames_array):
                if "public_key" not in mappings or "private_key" not in mappings:
                    print("Both 'public_key' and 'private_key' must be present in mappings")
                    return updated_node

                if m.matches(
                    node,
                    m.Assign(
                        value=m.Call(
                            func=m.Attribute(
                                value=m.Name("SigningKey"),
                                attr=m.Name("generate")
                            )
                        )
                    )
                ):
                    imp_stmt = f"from quantcrypt.dss import MLDSA_65"
                    imp_stmts.append(imp_stmt)
                    new_assign = f"{mappings['public_key']}, {mappings['private_key']} = MLDSA_65().keygen()"
                    return cst.parse_statement(new_assign).body[0]

            return updated_node

    wrapper = MetadataWrapper(tree)
    obj = UpdateKeygenNaCl()
    tree = wrapper.visit(obj)
    tree = update_imports(tree, imp_stmts)
    return tree

"""
def set_verify_cryptography(tree, mappings):
    class updateVerify(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def leave_Assign(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value)
            qnames_array = [q.name for q in qualified_names]

            if any(mappings['verifying_key']+'.verify' for name in qnames_array) \
            or m.matches(node, m.Assign(value=m.Call(func=m.Attribute(attr=m.Name(value="verify"))))):
                new_assign = [node.targets[0].target.value + " = Dilithium().verify(mappings['verifying_key'], mappings['digest_id'], mappings['signature'])"]
                return cst.parse_statement(new_assign).body[0]
            return updated_node

        def leave_Expr(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value)
            qnames_array = [q.name for q in qualified_names]

            if any(mappings['verifying_key']+'.verify' for name in qnames_array) \
            or m.matches(node, m.Expr(value=m.Call(func=m.Attribute(attr=m.Name(value="verify"))))):
                new_expr = "Dilithium().verify(mappings['verifying_key'], mappings['digest_id'], mappings['signature'])"
                return cst.parse_statement(new_expr).body[0]
            return updated_node

    wrapper = MetadataWrapper(tree)
    obj = updateVerify()
    tree = wrapper.visit(obj)
    return tree
"""



def set_verify_nacl(tree, mappings):
    print('in verify nacl')
    class UpdateVerify(cst.CSTTransformer):
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)

        def leave_Assign(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value)
            qnames_array = [q.name for q in qualified_names]

            if any(mappings['private_key'] + '.verify_key' in name for name in qnames_array):
                new_assign = f"{node.targets[0].target.value} = {mappings.get('public_key')}"
                return cst.parse_statement(new_assign).body[0]

            if any(mappings['private_key'] + '.verify_key' in name for name in qnames_array):
                call = node.value
                args = call.args
                print("mappings, ", call, " \n", args)
                if len(args) == 1:
                    new_assign = f"{node.targets[0].target.value} = Dilithium().verify({mappings['public_key']}, {args[0].value}, None)"
                else:
                    new_assign = f"{node.targets[0].target.value} = Dilithium().verify({mappings['public_key']}, {args[0].value}, {args[1].value})"
                return cst.parse_statement(new_assign).body[0]

            return updated_node

        def leave_Expr(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value)
            qnames_array = [q.name for q in qualified_names]

            if any(mappings.get('verifying_key', '') + '.verify' in name for name in qnames_array):
                call = node.value
                args = call.args
                if len(args) == 1:
                    new_expr = f"MLDSA_65().verify({mappings.get('verifying_key')}, {args[0].value}, None)"
                else:
                    new_expr = f"Dilithium().verify({mappings.get('verifying_key')}, {args[0].value}, {args[1].value})"
                return cst.parse_statement(new_expr).body[0]

            return updated_node

    wrapper = MetadataWrapper(tree)
    obj = UpdateVerify()
    tree = wrapper.visit(obj)
    return tree




def transform_kem_nacl(tree, mappings):
    imp_stmts = ["from Crypto.Cipher import AES","from Crypto.Random import get_random_bytes", "from quantcrypt.kem import MLKEM_512",
                 "from cryptography.hazmat.primitives import hashes","from cryptography.hazmat.primitives.kdf.hkdf import HKDF"]
    class UpdateKemgen(cst.CSTTransformer):
        
        METADATA_DEPENDENCIES = (QualifiedNameProvider,)
        
        def __init__(self):
            self.to_insert = False
        def leave_Assign(self, node, updated_node):
            qualified_names = self.get_metadata(QualifiedNameProvider, node.value)
            qnames = [q.name for q in qualified_names]
            if any(name.endswith("PrivateKey.generate") for name in qnames):
                target_node = node.targets[0].target.value
                new_assign = f"{target_node}_pub, {target_node} = MLKEM_512.keygen()"
                return cst.parse_statement(new_assign).body[0]

            if any(name.endswith("public_key") for name in qnames):
                priv_var = node.value.value.value
                target_node = node.targets[0].target.value

                new_assign = f"{target_node} = {priv_var}_pub"

                return cst.parse_statement(new_assign).body[0]
            #nacl pk encrpt aes-128
            if any(name.endswith("Box") for name in qnames) and m.matches(node.value, m.Call()):
                args = node.value.args
                if len(args) >= 2:
                    arg1 = args[0].value
                    arg2 = args[1].value
                    arg1_val = cst.Module([]).code_for_node(arg1)
                    arg2_val = cst.Module([]).code_for_node(arg2)
                    new_assign = f"cipher_text, shared_key = MLKEM_512.encaps({arg2_val})"
                    second_assign = "session_key = HKDF(algorithm=hashes.SHA256(),length=32,salt=None,).derive(shared_key)"
                    statement_1 = cst.parse_statement(new_assign)
                    statement_2 = cst.parse_statement(second_assign)
                    
                    return cst.FlattenSentinel([cst.parse_statement(new_assign).body[0],
                    cst.parse_statement(second_assign).body[0]])

                elif len(args) > 0:
                    arg1 = cst.Module([]).code_for_node(args[0].value)
                    new_assign = f"shared_key = MLKEM_512.decaps({arg1_val}, ciphertext)"
                    second_assign = "session_key = HKDF(algorithm=hashes.SHA256(),length=32,salt=None,).derive(shared_key)"
                    statement_1 = cst.parse_statement(new_assign)
                    statement_2 = cst.parse_statement(second_assign)
                    return cst.FlattenSentinel([cst.parse_statement(new_assign).body[0],
                    cst.parse_statement(second_assign).body[0]])
                    
                    




            if any(name.endswith("encrypt") for name in qnames) and m.matches(node.value, m.Call()):
                call_node = node.value
                self.to_insert = True
                target_node = node.targets[0].target.value
                args = call_node.args
                if len(args) > 0:
                    arg1 = args[0].value
                    arg1_val = cst.Module([]).code_for_node(arg1)
                    new_assign = f"{target_node} = aes_encrypt(session_key, plaintext)"
                    return cst.parse_statement(new_assign).body[0]
                            
                            

            if any(name.endswith("decrypt") for name in qnames) and m.matches(node.value, m.Call()):
                call_node = node.value
                self.to_insert = True
                target_node = node.targets[0].target.value
                
                args = call_node.args
                if len(args) > 0:
                    arg1 = args[0].value
                    arg1_val = cst.Module([]).code_for_node(arg1)
                    
                    new_assign = f"{target_node} = aes_decrypt(session_key, nonce, {arg1_val}, tag)"
                    return cst.parse_statement(new_assign).body[0]

                

            return updated_node
        def update_tree_body(self, tree, code):
            parsed_body = cst.parse_module(code).body
            new_imports = [item for item in parsed_body if isinstance(item, (cst.Import, cst.ImportFrom))]
            new_non_imports = [item for item in parsed_body if not isinstance(item, (cst.Import, cst.ImportFrom))]

            insert_index = 0
            for i, item in enumerate(tree.body):
                if isinstance(item, (cst.Import, cst.ImportFrom)):
                    insert_index = i + 1
                elif isinstance(item, cst.SimpleStatementLine) and \
                     len(item.body) > 0 and \
                     isinstance(item.body[0], cst.Expr) and \
                     isinstance(item.body[0].value, cst.SimpleString):
                    insert_index = i + 1
                else:
                    break

            new_body = list(tree.body)
            new_body[insert_index:insert_index] = new_imports
            new_body[insert_index + len(new_imports):insert_index + len(new_imports)] = new_non_imports

            return tree.with_changes(body=new_body)

        
        
    wrapper = MetadataWrapper(tree)
    obj = UpdateKemgen()
    tree = wrapper.visit(obj)
    #tree = update_imports(tree, imp_stmts)
    if obj.to_insert is True:
        print('to insert\n')
        code = """
from Crypto.Cipher import AES
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
def aes_encrypt(session_key, plaintext):
    cipher = AES.new(session_key, AES.MODE_GCM)
    nonce = cipher.nonce
    ciphertext, tag = cipher.encrypt_and_digest(plaintext)
    return ciphertext, nonce, tag
def aes_decrypt(session_key, ciphertext, nonce, tag):
    cipher = AES.new(session_key, AES.MODE_GCM, nonce=nonce)
    plaintext = cipher.decrypt_and_verify(ciphertext, tag)
    return plaintext
"""
        tree = obj.update_tree_body(tree, code)
    return tree


