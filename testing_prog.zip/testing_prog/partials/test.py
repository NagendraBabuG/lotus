def send_message(user, message):
    print(f"Sending '{message}' to {user}")

def notify_all(users):
    for u in users:
        send_message(u, "Welcome!")
        send_message(u, "Please verify your email.")



def log(level, msg):
    print(f"[{level}] {msg}")

def process():
    info = lambda msg: log("INFO", msg)
    error = lambda msg: log("ERROR", msg)
    info("Starting process")
    error("Something went wrong")


def sign(key, msg):
    signer= pkcs1_15.new(key)
    signature = signer.sign(msg)
    return signature

key = keygen(1024)
msg = b'hello'

signed = sign(key, msg)
signed2 = sign(key, msg=b'bye')