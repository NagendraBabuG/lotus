from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

class SourceAdapter:

    def generate_private_key(self):
        return ed25519.Ed25519PrivateKey.generate()

    def get_public_key(self, private_key):
        return private_key.public_key()

    def serialize_public_key(self, public_key):
        return public_key.public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)

    def load_public_key(self, public_bytes):
        return ed25519.Ed25519PublicKey.from_public_bytes(public_bytes)

