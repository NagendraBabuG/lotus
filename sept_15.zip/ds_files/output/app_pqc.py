
from flask import Flask, render_template, request, jsonify
from flask_socketio import SocketIO, emit, join_room
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import hmac as hmac_mod
import hashlib, os, json, base64, struct, time
from datetime import datetime
import sys
from cryptography.hazmat.primitives.asymmetric import mldsa

"""
UAV ↔ Ground Station — Communication Sécurisée
================================================
Stack cryptographique :
  1. ECDH (Curve25519)     → échange de clés (shared secret)
  2. Ed25519               → signature / authentification de l'émetteur
  3. AES-256-GCM           → chiffrement symétrique authentifié
  4. HMAC-SHA256           → intégrité des messages
  5. (Bonus pédagogique)   → visualisation Feistel simplifiée pour démonstration
"""
sys.stdout.reconfigure(encoding='utf-8')

app = Flask(__name__)
app.secret_key = os.urandom(32)
socketio = SocketIO(app, cors_allowed_origins="*")

# ─── État de la session cryptographique ─────────────────────────────────────
class CryptoSession:
    def __init__(self):
        self.reset()

    def reset(self):
        # Clés ECDH
        self.uav_ecdh_private = None
        self.uav_ecdh_public  = None
        self.gcs_ecdh_private = None
        self.gcs_ecdh_public  = None
        self.shared_secret    = None
        self.session_key      = None  # dérivé via HKDF

        # Clés Ed25519 (signature)
        self.uav_sign_private = None
        self.uav_sign_public  = None
        self.gcs_sign_private = None
        self.gcs_sign_public  = None

        self.handshake_done   = False
        self.message_counter  = 0

session = CryptoSession()

# ─── Fonctions utilitaires ────────────────────────────────────────────────
def b64(data: bytes) -> str:
    return base64.b64encode(data).decode()

def hex_block(data: bytes, cols=16) -> str:
    """Formatte des bytes en hexdump lisible."""
    lines = []
    for i in range(0, len(data), cols):
        chunk = data[i:i+cols]
        hex_part  = ' '.join(f'{b:02x}' for b in chunk)
        ascii_part = ''.join(chr(b) if 32 <= b < 127 else '.' for b in chunk)
        lines.append(f'{i:04x}:  {hex_part:<{cols*3}}  |{ascii_part}|')
    return '\n'.join(lines)

# ─── Feistel Network (démonstration pédagogique) ──────────────────────────
def feistel_round_function(half: bytes, subkey: bytes) -> bytes:
    """Fonction F du réseau Feistel : XOR + rotation + hash."""
    mixed = bytes(a ^ b for a, b in zip(half, subkey[:len(half)]))
    return hashlib.sha256(mixed).digest()[:len(half)]

def feistel_encrypt_demo(plaintext: bytes, key: bytes, rounds: int = 4) -> tuple:
    """
    Chiffrement Feistel 4 rounds (démonstration pédagogique).
    Retourne (ciphertext, trace_des_rounds).
    """
    # Padding pour longueur paire
    if len(plaintext) % 2 != 0:
        plaintext += b'\x00'
    mid = len(plaintext) // 2
    L, R = plaintext[:mid], plaintext[mid:]

    # Génération des sous-clés
    subkeys = []
    for i in range(rounds):
        sk = hashlib.sha256(key + i.to_bytes(4, 'big')).digest()[:mid]
        subkeys.append(sk)

    trace = [{'round': 0, 'L': L.hex(), 'R': R.hex(), 'subkey': '—'}]

    for i in range(rounds):
        F_out = feistel_round_function(R, subkeys[i])
        new_L = bytes(a ^ b for a, b in zip(L, F_out))
        L, R  = R, new_L
        trace.append({
            'round': i + 1,
            'L': L.hex(),
            'R': R.hex(),
            'subkey': subkeys[i].hex()[:16] + '...'
        })

    return L + R, trace

def feistel_decrypt_demo(ciphertext: bytes, key: bytes, rounds: int = 4) -> bytes:
    mid = len(ciphertext) // 2
    L, R = ciphertext[:mid], ciphertext[mid:]

    subkeys = []
    for i in range(rounds):
        sk = hashlib.sha256(key + i.to_bytes(4, 'big')).digest()[:mid]
        subkeys.append(sk)

    for i in range(rounds - 1, -1, -1):
        F_out = feistel_round_function(L, subkeys[i])
        new_R = bytes(a ^ b for a, b in zip(R, F_out))
        L, R  = new_R, L

    return L + R

# ─── Routes HTTP ─────────────────────────────────────────────────────────────
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/uav')
def uav_panel():
    return render_template('uav.html')

@app.route('/gcs')
def gcs_panel():
    return render_template('gcs.html')

@app.route('/api/handshake/init', methods=['POST'])
def handshake_init():
    """
    Étape 1 : Génération des clés ECDH et Ed25519 pour UAV et GCS.
    Simule les deux côtés pour la démonstration.
    """
    session.reset()

    # Générer clés ECDH
    session.uav_ecdh_private = X25519PrivateKey.generate()
    session.uav_ecdh_public  = session.uav_ecdh_private.public_key()
    session.gcs_ecdh_private = X25519PrivateKey.generate()
    session.gcs_ecdh_public  = session.gcs_ecdh_private.public_key()

    # Générer clés de signature Ed25519
    session.uav_sign_private = mldsa.MLDSA65PrivateKey.generate()
    session.uav_sign_public  = session.uav_sign_private.public_key()
    session.gcs_sign_private = mldsa.MLDSA65PrivateKey.generate()
    session.gcs_sign_public  = session.gcs_sign_private.public_key()

    uav_pub_bytes = session.uav_ecdh_public.public_bytes(
        serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    gcs_pub_bytes = session.gcs_ecdh_public.public_bytes(
        serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    uav_sign_pub  = session.uav_sign_public.public_bytes(
        serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    gcs_sign_pub  = session.gcs_sign_public.public_bytes(
        serialization.Encoding.Raw, serialization.PublicFormat.Raw)

    return jsonify({
        'success': True,
        'uav': {
            'ecdh_public_key': uav_pub_bytes.hex(),
            'sign_public_key': uav_sign_pub.hex(),
        },
        'gcs': {
            'ecdh_public_key': gcs_pub_bytes.hex(),
            'sign_public_key': gcs_sign_pub.hex(),
        },
        'step': 'Clés générées — Échange ECDH en attente'
    })

@app.route('/api/handshake/exchange', methods=['POST'])
def handshake_exchange():
    """
    Étape 2 : Échange de clés publiques ECDH → calcul du secret partagé.
    Dérivation de la clé de session via HKDF-SHA256.
    """
    if not session.uav_ecdh_private:
        return jsonify({'success': False, 'message': "Initialiser d'abord le handshake."}), 400

    # Calcul du secret partagé (les deux côtés obtiennent le même résultat)
    shared_secret_uav = session.uav_ecdh_private.exchange(session.gcs_ecdh_public)
    shared_secret_gcs = session.gcs_ecdh_private.exchange(session.uav_ecdh_public)

    # Les deux secrets sont identiques (propriété ECDH)
    assert shared_secret_uav == shared_secret_gcs
    session.shared_secret = shared_secret_uav

    # Dérivation HKDF → clé AES-256
    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=b'UAV-GCS-SALT-2025',
        info=b'uav-gcs-session-key'
    )
    session.session_key = hkdf.derive(session.shared_secret)
    session.handshake_done = True

    return jsonify({
        'success': True,
        'shared_secret': session.shared_secret.hex(),
        'shared_secret_hex_dump': hex_block(session.shared_secret),
        'session_key': session.session_key.hex(),
        'session_key_hex_dump': hex_block(session.session_key),
        'derivation': 'HKDF-SHA256(shared_secret, salt="UAV-GCS-SALT-2025")',
        'key_size': '256 bits (AES-256)',
        'step': 'Secret partagé établi — Canal sécurisé prêt'
    })

@app.route('/api/send', methods=['POST'])
def send_message():
    """
    Envoi d'un message chiffré.
    1. Signer avec Ed25519 (authentification)
    2. Chiffrer avec AES-256-GCM (confidentialité + intégrité)
    3. Calculer HMAC-SHA256 (intégrité supplémentaire du paquet)
    4. Démonstration Feistel optionnelle
    """
    if not session.handshake_done:
        return jsonify({'success': False, 'message': "Handshake requis avant d'envoyer."}), 400

    data      = request.get_json()
    plaintext = data.get('message', '').strip()
    sender    = data.get('sender', 'UAV')  # 'UAV' ou 'GCS'

    if not plaintext:
        return jsonify({'success': False, 'message': "Message vide."}), 400

    plaintext_bytes = plaintext.encode('utf-8')
    session.message_counter += 1

    # ── Sélection des clés selon l'émetteur ──────────────────────────────────
    if sender == 'UAV':
        sign_private = session.uav_sign_private
        sign_pub     = session.uav_sign_public.public_bytes(
            serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    else:
        sign_private = session.gcs_sign_private
        sign_pub     = session.gcs_sign_public.public_bytes(
            serialization.Encoding.Raw, serialization.PublicFormat.Raw)

    # ── Étape 1 : Signature Ed25519 ──────────────────────────────────────────
    signature = sign_private.sign(plaintext_bytes)

    # ── Étape 2 : Chiffrement AES-256-GCM ────────────────────────────────────
    nonce = os.urandom(12)  # 96 bits, unique par message
    aesgcm = AESGCM(session.session_key)

    # Additional Authenticated Data (non chiffré mais authentifié)
    aad = f"UAV-GCS-MSG-{session.message_counter:04d}".encode()
    ciphertext_gcm = aesgcm.encrypt(nonce, plaintext_bytes, aad)

    # ── Étape 3 : HMAC-SHA256 du paquet complet ───────────────────────────────
    packet = nonce + ciphertext_gcm
    hmac_value = hmac_mod.new(session.session_key, packet, hashlib.sha256).hexdigest()

    # ── Étape 4 : Feistel (démonstration) ────────────────────────────────────
    feistel_key = session.session_key[:16]
    feistel_ct, feistel_trace = feistel_encrypt_demo(
        plaintext_bytes[:16] if len(plaintext_bytes) >= 2 else b'demo',
        feistel_key
    )

    # ── Construction du paquet final ─────────────────────────────────────────
    result = {
        'success': True,
        'sender': sender,
        'timestamp': datetime.now().isoformat(),
        'counter': session.message_counter,

        # CLAIR
        'plaintext': plaintext,
        'plaintext_hex': plaintext_bytes.hex(),
        'plaintext_hex_dump': hex_block(plaintext_bytes),

        # SIGNATURE
        'signature': signature.hex(),
        'signature_algorithm': 'Ed25519',
        'signer_public_key': sign_pub.hex(),

        # CHIFFRÉ
        'nonce': nonce.hex(),
        'nonce_hex_dump': hex_block(nonce),
        'aad': aad.decode(),
        'ciphertext_gcm': ciphertext_gcm.hex(),
        'ciphertext_hex_dump': hex_block(ciphertext_gcm),
        'encryption_algorithm': 'AES-256-GCM',

        # HMAC
        'hmac': hmac_value,
        'hmac_algorithm': 'HMAC-SHA256',

        # FEISTEL DEMO
        'feistel_demo': {
            'input': (plaintext_bytes[:16] if len(plaintext_bytes) >= 2 else b'demo').hex(),
            'output': feistel_ct.hex(),
            'rounds': feistel_trace
        },

        # PAQUET FINAL (ce qui transite sur le canal)
        'wire_packet': {
            'nonce': nonce.hex(),
            'ciphertext': ciphertext_gcm.hex(),
            'signature': signature.hex(),
            'hmac': hmac_value,
            'aad': aad.decode(),
            'counter': session.message_counter
        }
    }

    # Émettre via SocketIO aux deux panneaux
    socketio.emit('new_message', result, room='secure_channel')

    return jsonify(result)

@app.route('/api/decrypt', methods=['POST'])
def decrypt_message():
    """Déchiffrement d'un paquet reçu (démonstration côté récepteur)."""
    if not session.handshake_done:
        return jsonify({'success': False, 'message': "Handshake requis."}), 400

    data = request.get_json()
    try:
        nonce          = bytes.fromhex(data['nonce'])
        ciphertext_gcm = bytes.fromhex(data['ciphertext'])
        signature_hex  = data['signature']
        aad_str        = data['aad']
        sender         = data.get('sender', 'UAV')
        counter        = data.get('counter', 0)

        # ── Vérifier HMAC ────────────────────────────────────────────────────
        packet     = nonce + ciphertext_gcm
        hmac_check = hmac_mod.new(session.session_key, packet, hashlib.sha256).hexdigest()
        hmac_valid = hmac_mod.compare_digest(hmac_check, data['hmac'])

        # ── Déchiffrer AES-256-GCM ────────────────────────────────────────────
        aesgcm    = AESGCM(session.session_key)
        plaintext = aesgcm.decrypt(nonce, ciphertext_gcm, aad_str.encode())

        # ── Vérifier signature Ed25519 ────────────────────────────────────────
        if sender == 'UAV':
            verify_key = session.uav_sign_public
        else:
            verify_key = session.gcs_sign_public

        signature = bytes.fromhex(signature_hex)
        verify_key.verify(signature ,plaintext)
        sig_valid = True

        return jsonify({
            'success': True,
            'decrypted': plaintext.decode('utf-8'),
            'decrypted_hex': plaintext.hex(),
            'hmac_valid': hmac_valid,
            'signature_valid': sig_valid,
            'aes_tag_valid': True,  # GCM vérifie automatiquement
            'all_checks_passed': hmac_valid and sig_valid
        })

    except Exception as e:
        return jsonify({'success': False, 'error': str(e), 'tampered': True})

@app.route('/api/status', methods=['GET'])
def status():
    return jsonify({
        'handshake_done': session.handshake_done,
        'messages_sent': session.message_counter,
        'session_key_ready': session.session_key is not None
    })

# ─── SocketIO ─────────────────────────────────────────────────────────────────
@socketio.on('join')
def on_join(data):
    join_room('secure_channel')
    emit('status', {'connected': True, 'room': 'secure_channel'})

if __name__ == '__main__':
    print("=" * 60)
    print("  UAV ↔ Ground Station — Secure Comms")
    print("  UAV Panel : http://localhost:5001/uav")
    print("  GCS Panel : http://localhost:5001/gcs")
    print("=" * 60)
    socketio.run(app, debug=True, port=5001, allow_unsafe_werkzeug=True)
