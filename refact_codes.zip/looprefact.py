import ast
import os

class LoopRefactor(ast.NodeTransformer):

    def traverse_tree(self, tree):
        self.while_id_map = {}        
        self.while_nested_dict = {}   # Maps bounds to while loop bodies
        self.for_id_map = {}          # Maps for iterators to their bounds
        self.for_nested_dict = {}     # Maps bounds to for loop bodies
        self.init_statements = []     # Maps loop indices to initialization statements
        self.statement = None
        self.index = []  # Variable to keep track of the line number of the while statement
        for node in ast.walk(tree):
            if isinstance(node, ast.While) and isinstance(node.test, ast.Compare):
                while_body = []
                for elem in node.body:
                    if not isinstance(elem, ast.AugAssign):
                        while_body.append(elem)
                    else:
                        constant_iterator = elem.value
                
                while_iterator = node.test.left.id

                if len(node.test.comparators) == 1 and isinstance(node.test.comparators[0], ast.Call):
                    while_extracted_args = node.test.comparators[0].args[0].id
                self.while_id_map[while_iterator] = while_extracted_args
                self.while_nested_dict[self.while_id_map[while_iterator]] = while_body

            # Extracting arguments from the for block
            if isinstance(node, ast.For):
                for_body = node.body
                for_iterator = node.target.id
                """for_extracted_args = node.iter.args[1].args[0].id
                self.for_id_map[for_iterator] = for_extracted_args
                self.for_nested_dict[self.for_id_map[for_iterator]] = for_body
                """
                # Check if node.iter is a Call node (e.g., range(len(s)))
                if isinstance(node.iter, ast.Call) and node.iter.func.id == 'range':
                    # Handle range calls like range(len(s)) or range(0, len(s))
                    if len(node.iter.args) >= 1:
                        # Extract the upper bound (e.g., len(s))
                        if isinstance(node.iter.args[-1], ast.Call) and node.iter.args[-1].func.id == 'len':
                            for_extracted_args = node.iter.args[-1].args[0].id
                            self.for_id_map[for_iterator] = for_extracted_args
                            self.for_nested_dict[self.for_id_map[for_iterator]] = for_body
                        else:
                            # Skip if the upper bound is not a len() call
                            continue
                    else:
                        # Skip if range has no arguments
                        continue
                else:
                    # Skip non-range iterables (e.g., lists, tuples)
                    continue
        
        print(self.for_id_map)
        print("\n")
        print(self.for_nested_dict)
                
        self.statement = None
        self.index = []

        # Second walk to convert the for/while statements and to use the corresponding extracted identifiers
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                # Iterate over the FunctionDef body to find the while/for statement
                for idx, node_elem in enumerate(node.body):
                    # Modify the statement only if the identifiers match // NOTE: Only iterator is considered for now
                    if isinstance(node_elem, ast.While) and isinstance(node_elem.test, ast.Compare):
                        # Define the 'for' statement to replace the while statement using the extracted dictionary mappings
                        node.body[idx] = ast.For(
                            target=ast.Name(id=node_elem.test.left.id, ctx=ast.Store()),
                            iter=ast.Call(
                                func=ast.Name(id='range', ctx=ast.Load()),
                                args=[
                                    ast.Constant(value=0),
                                    ast.Call(
                                    func=ast.Name(id='len', ctx=ast.Load()),
                                    args=[ast.Name(id=self.while_id_map[node_elem.test.left.id], ctx=ast.Load())],
                                    keywords=[]), constant_iterator], keywords=[]),
                                body=self.while_nested_dict[self.while_id_map[node_elem.test.left.id]],
                                orelse=[])
                        ast.fix_missing_locations(node.body[idx])

                    if isinstance(node_elem, ast.For):
                        self.index.append(idx)

                        # Initialize the iterator to be used for the while statement
                        self.init_statements.append(ast.Assign(
                        targets=[ast.Name(id=node_elem.target.id, ctx=ast.Store())], value=ast.Constant(value=0)))
                        

                        self.for_nested_dict[self.for_id_map[node_elem.target.id]].append(ast.Augassign(
                            target=ast.Name(id=node_elem.target.id, ctx=ast.Store()),
                            op=ast.Add(),
                            value=ast.Constant(value=1)))
                        # Define the 'while' statement to replace the while statement using the extracted dictionary mappings
                        # Define the 'while' statement to replace the while statement using the extracted dictionary mappings
                        node.body[idx] = ast.While(
                            test=ast.Compare(
                                left=ast.Name(id=node_elem.target.id, ctx=ast.Load()),
                                ops=[
                                    ast.Lt()
                                ],
                                comparators=[
                                    ast.Name(id=self.for_id_map[node_elem.target.id], ctx=ast.Load())
                                ]
                            ),
                            body=self.for_nested_dict[self.for_id_map[node_elem.target.id]],
                            orelse=[]
                        )
                        ast.fix_missing_locations(node.body[idx])


        count = 0
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                for obj in node.body:
                    if isinstance(obj, ast.While):
                        if count >= len(self.index):
                            break
                        node.body.insert(self.index[count], self.init_statements[0])
                        ast.fix_missing_locations(node.body[self.index[count]])
                        count += 1
        return tree
    
    def refactor_loops(self, tree):
        self.while_id_map = {}        
        self.while_nested_dict = {}   # Maps bounds to while loop bodies
        self.for_id_map = {}          # Maps for iterators to their bounds
        self.for_nested_dict = {}     # Maps bounds to for loop bodies
        self.init_statements = []     # Maps loop indices to initialization statements
        self.loop_indices = []
        self.statement = None
        self.index = []
        tree = self.traverse_tree(tree)
        return ast.unparse(tree)

    def get_refactored_code(self, source_code):
        try:
            tree = ast.parse(source_code)
            return self.refactor_loops(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")

