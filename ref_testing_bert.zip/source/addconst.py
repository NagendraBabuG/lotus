def prints(msg):
    return msg
def greet():
    prefix = "Hello"
    message =prints("hello") 
    print(message)