def add(a):
    return a + 10

def multiply(x, y):
    return x * y

def greet(greeting):
    print('Hello')