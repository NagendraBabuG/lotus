def keygen():
    key = RSA.generate(key_size=2048)
    return key

def sign(key):
    signer = pkcs1_15.new(key)
    signature = signer.sign("this is a message")
    return signature

k = ECC.generate('ed448')
k2 = ECC.generate(curve='p521')