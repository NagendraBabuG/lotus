#parameters passed should be not modified , a new varialbe will be delcraed so original values remains uncahnged
import ast

class ParameterRefactor(ast.NodeTransformer):
    def visit_FunctionDef(self, node):
        par_var_map = {}
        param_names = [arg.arg for arg in node.args.args]

        init_assignments = []

        for param in param_names:
            if param in ('self', 'cls'):
                continue  
            copy_name = f"{param}_copy"
            par_var_map[param] = copy_name
            init_assignments.append(ast.Assign(
                targets=[ast.Name(id=copy_name, ctx=ast.Store())],
                value=ast.Name(id=param, ctx=ast.Load()),
                lineno=0, col_offset=0
            ))

        old_map = getattr(self, '_current_par_map', None)
        self._current_par_map = par_var_map

        new_body = init_assignments + [self.visit(stmt) for stmt in node.body]

        if old_map is None:
            del self._current_par_map
        else:
            self._current_par_map = old_map

        node.body = new_body
        return node

    def visit_Name(self, node):
        if hasattr(self, '_current_par_map'):
            map_ = self._current_par_map
            if node.id in map_:
                return ast.copy_location(
                    ast.Name(id=map_[node.id], ctx=node.ctx),
                    node
                )
        return node

    def refactor_parameters(self, tree):
        return ast.fix_missing_locations(self.visit(tree))

    def get_refactored_code(self, source_code):
        try:
            tree = ast.parse(source_code)
            modified_tree = self.refactor_parameters(tree)
            return ast.unparse(modified_tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")
        
wrapper = ParameterRefactor()

source = """  
class f1:
    x = 2
    def f2(self, pas):
        self.x = self.x + 2
        return 2
    def f3(self, p2):
        return p2
def func2(x):
    x = x.upper()
    return x
"""

target = wrapper.get_refactored_code(source)

print(target)