def test2(x):
    result = even_handler(x) if x % 2 == 0 else odd_handler(x)
    return result

def even_handler(n):
    return f'{n} is even'

def odd_handler(n):
    return f'{n} is odd'