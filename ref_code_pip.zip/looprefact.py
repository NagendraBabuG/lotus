import ast
#working on only fewcases

class ForWhileRefact(ast.NodeTransformer):
    
    def visit_FunctionDef(self, node):
        
        self.init_statements = []
        self.index = []
        self.for_id_map = {}
        self.for_nested_dict = {}
        self.while_id_map = {}
        self.while_nested_dict = {}

        
        for n in ast.walk(node):
            if isinstance(n, ast.While) and isinstance(n.test, ast.Compare):
                if (len(n.test.ops) == 1 and isinstance(n.test.ops[0], ast.Lt) and
                    len(n.test.comparators) == 1 and isinstance(n.test.comparators[0], ast.Call) and
                    n.test.comparators[0].func.id == 'len'):
                    while_iterator = n.test.left.id
                    while_extracted_args = n.test.comparators[0].args[0].id
                    self.while_id_map[while_iterator] = while_extracted_args
                    self.while_nested_dict[while_extracted_args] = n.body

            if isinstance(n, ast.For) and isinstance(n.iter, ast.Call) and n.iter.func.id == 'range':
                if len(n.iter.args) >= 1 and isinstance(n.iter.args[-1], ast.Call) and n.iter.args[-1].func.id == 'len':
                    for_iterator = n.target.id
                    for_extracted_args = n.iter.args[-1].args[0].id
                    self.for_id_map[for_iterator] = for_extracted_args
                    self.for_nested_dict[for_extracted_args] = n.body

        
        new_body = []
        for idx, node_elem in enumerate(node.body):
            if isinstance(node_elem, ast.While) and isinstance(node_elem.test, ast.Compare):
                if node_elem.test.left.id in self.while_id_map:
                    # Convert while to for
                    constant_iterator = None
                    for stmt in node_elem.body:
                        if isinstance(stmt, ast.AugAssign) and isinstance(stmt.op, ast.Add) and isinstance(stmt.value, ast.Constant) and stmt.value.value == 1:
                            constant_iterator = stmt.value
                            break
                    if constant_iterator is None:
                        new_body.append(node_elem)
                        continue

                    new_for = ast.For(
                        target=ast.Name(id=node_elem.test.left.id, ctx=ast.Store()),
                        iter=ast.Call(
                            func=ast.Name(id='range', ctx=ast.Load()),
                            args=[
                                ast.Constant(value=0),
                                ast.Call(
                                    func=ast.Name(id='len', ctx=ast.Load()),
                                    args=[ast.Name(id=self.while_id_map[node_elem.test.left.id], ctx=ast.Load())],
                                    keywords=[]
                                )
                            ],
                            keywords=[]
                        ),
                        body=self.while_nested_dict[self.while_id_map[node_elem.test.left.id]],
                        orelse=[]
                    )
                    ast.fix_missing_locations(new_for)
                    new_body.append(new_for)
                else:
                    new_body.append(node_elem)
            elif isinstance(node_elem, ast.For) and node_elem.target.id in self.for_id_map:
                # Convert for to while
                iterator = node_elem.target.id
                self.index.append(len(new_body))
                self.init_statements.append(ast.Assign(
                    targets=[ast.Name(id=iterator, ctx=ast.Store())],
                    value=ast.Constant(value=0)
                ))
                new_body.append(ast.While(
                    test=ast.Compare(
                        left=ast.Name(id=iterator, ctx=ast.Load()),
                        ops=[ast.Lt()],
                        comparators=[
                            ast.Call(
                                func=ast.Name(id='len', ctx=ast.Load()),
                                args=[ast.Name(id=self.for_id_map[iterator], ctx=ast.Load())],
                                keywords=[]
                            )
                        ]
                    ),
                    body=node_elem.body + [ast.AugAssign(
                        target=ast.Name(id=iterator, ctx=ast.Store()),
                        op=ast.Add(),
                        value=ast.Constant(value=1)
                    )],
                    orelse=[]
                ))
                ast.fix_missing_locations(new_body[-1])
            else:
                new_body.append(node_elem)

        for i, idx in enumerate(self.index):
            new_body.insert(idx + i, self.init_statements[i])
            ast.fix_missing_locations(new_body[idx + i])

        node.body = new_body
        return node

    def get_refactored_code(self, source_code):
        try:
            tree = ast.parse(source_code)
            transformed_tree = self.visit(tree)
            ast.fix_missing_locations(transformed_tree)
            return ast.unparse(transformed_tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")