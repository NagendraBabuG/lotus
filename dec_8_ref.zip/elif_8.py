import libcst as cst

class ElIfConverter(cst.CSTTransformer):
    def leave_If(
        self,
        original_node: cst.If,
        updated_node: cst.If
    ) -> cst.If:
        
        if updated_node.orelse is None:
            return updated_node

        if not isinstance(updated_node.orelse, cst.Else):
            return updated_node

        else_body = updated_node.orelse.body.body

        if len(else_body) != 1 or not isinstance(else_body[0], cst.If):
            return updated_node

        nested_if: cst.If = else_body[0]

        

        new_elif = nested_if.with_changes(
            leading_lines=[]   
        )

        return updated_node.with_changes(
            orelse=new_elif
        )

    def get_refactored_code(self, source_code: str) -> str:
        module = cst.parse_module(source_code)
        wrapper = cst.MetadataWrapper(module)
        modified = wrapper.visit(self)
        return modified.code

