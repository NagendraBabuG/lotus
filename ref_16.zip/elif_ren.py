import libcst as cst

class ElIfConverter(cst.CSTTransformer):
    def leave_If(self, original_node: cst.If, updated_node: cst.If):

        if updated_node.orelse is None:
            return updated_node

        if isinstance(updated_node.orelse, cst.Else):
            body = updated_node.orelse.body.body

            if len(body) == 1 and isinstance(body[0], cst.If):
                nested_if = body[0]

                return updated_node.with_changes(
                    orelse=nested_if
                )

        return updated_node
    def get_refactored_code(self, source_code):
        module = cst.parse_module(source_code)
        wrapper = cst.MetadataWrapper(module)
        return wrapper.visit(self).code
