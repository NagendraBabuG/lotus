from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey,
    X25519PublicKey,
)

class X25519Adapter:

    def load_private_key(self, seed):
        return X25519PrivateKey.from_private_bytes(seed)

    def serialize_public_key(self, public_key):
        return public_key.public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)

    def get_public_key(self, private_key):
        return private_key.public_key()

    def load_public_key(self, client_pub_key):
        return X25519PublicKey.from_public_bytes(client_pub_key)

