import ast
import random
import re

HEX_PATTERN = re.compile(r"0x[0-9A-Fa-f]+")

class AugAssignRefactor(ast.NodeTransformer):
    
    def visit_AugAssign(self, node):
        new_assign = ast.Assign(targets=[node.target], value=ast.BinOp(left=ast.Name(id=node.target.id, ctx=ast.Load()), op=node.op,
                                                                       right=node.value))
        ast.fix_missing_locations(new_assign)
        return new_assign
    
    def visit_Assign(self, node):
        if len(node.targets) == 1 and isinstance(node.value, ast.BinOp) and node.targets[0].id == node.value.left.id:
            new_aug = ast.AugAssign(
                target=node.targets[0],op=node.value.op,
                vlaue=node.value.right
            )
            ast.fix_missing_locations(new_aug)
            return new_aug
        return node
    
    def get_refactored_code(self, source_code):
        hex_literals = HEX_PATTERN.findall(source_code)
        try:
            tree = ast.parse(source_code)
            tree = self.visit(tree)
            result = ast.unparse(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")

        for hx in hex_literals:
            dec = str(int(hx, 16))
            result = result.replace(dec, hx)

        return result
    
wrapper = AugAssignRefactor() 

source = """  
class f1:
    x = 2
    def f2(self, pas):
        self.x = self.x + 2
        return 2
    def f3(self, p2):
        return p2
    def f4(self, a, b, c):
        a = a + 1
        b = b.upper()
        return a, b, c

def func2(x):
    x = x.upper()
    return x

def many(p1, p2, p3, p4):
    p1 += 1
    p2 = p2.strip()
    return p1, p2
def verify_sign(msg, sing, pub_key):
    key = RSA.import_key(pub_key)
def create_siv_cipher(factory, **kwargs):
    key_copy = kwargs.pop()
def creat_cipher(v):
    v_int = bytes_to_long(v)
    q = v_int & 0xFFFFFFFFFFFFFFFF7FFFFFFF7FFFFFFF
"""

target = wrapper.get_refactored_code(source)
print(target)