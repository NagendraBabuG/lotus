import os
import itertools

from addconstasparam import AddDefaultArgValue
from addexception import AddTryExceptRefactor
from errorcode import ExceptionRefactor
from funcommonparams import CommonParamters
from funcvaridentifier import FuncVarNameRefactator
from hardcode import HardcodedValues
from looprefact import ForWhileRefact
from mapfilter import MapFilterRefactor
from newlambda import LambdaRefactor
from optimizeassertions import AddAssertions
from partials import PartialsRefactor
from remunusedparam import RemoveUnusedParameter
from remvarassign import ParameterRefactor
from shufflefuncs import ShuffleFunctions
from ternary import TernaryRefactor
from tryexcept import ErrorHandlerRefactor

output_base_path = "./ref_output/"

refactor_classes = {
    "add_default_arg": AddDefaultArgValue(),
    "hardcoded_values": HardcodedValues(),
    "add_try_except": AddTryExceptRefactor(),
    "try_except": ErrorHandlerRefactor(),
    "exception_code": ExceptionRefactor(),
    "common_params": CommonParamters(),
    "var_rename": FuncVarNameRefactator(),
    "loops": ForWhileRefact(),
    "map_filter": MapFilterRefactor(),
    "lambda_refactor": LambdaRefactor(),
    "assertions": AddAssertions(),
    "partials": PartialsRefactor(),
    "remove_unused_param": RemoveUnusedParameter(),
    "param_refactor": ParameterRefactor(),
    "shuffle_funcs": ShuffleFunctions(),
    "ternary": TernaryRefactor()
}

technique_groups = {
    1: ["add_default_arg", "hardcoded_values"],
    2: ["add_try_except", "try_except", "exception_code"],
    3: ["ternary"],
    4: ["common_params"],
    5: ["var_rename"],
    6: ["loops"],
    7: ["map_filter"],
    8: ["lambda_refactor"],
    9: ["assertions"],
    10: ["partials"],
    11: ["remove_unused_param"],#deadcode
    12: ["param_refactor"],
    13: ["shuffle_funcs"],
    
}

pipelines = []

def generate_sequences(index, cur_pipeline, threshold=11, max_groups=13):
    if index > len(technique_groups):
        if len(cur_pipeline) >= threshold:
            pipelines.append(cur_pipeline[:])
        return
    #seq = random.randint(0, len(technique_groups[index]))
    for technique in technique_groups[index]:
        cur_pipeline.append(technique)
        generate_sequences(index + 1, cur_pipeline, threshold, max_groups)
        cur_pipeline.pop()
    generate_sequences(index + 1, cur_pipeline, threshold, max_groups)



def apply_pipeline(code: str, techniques: list):
    for name in techniques:
        refactor = refactor_classes[name]
        code = refactor.get_refactored_code(code)
    return code

def process_files(input_dir):
    os.makedirs(output_base_path, exist_ok=True)
    cur_pip = []
    generate_sequences(1, cur_pip)
    pip_no = -1
    for pipeline in pipelines:
        print(f"Applied techniques: {pipeline} -> no_{pip_no}/")
        pip_no += 1
        subset_output_path = os.path.join(output_base_path, f"pip_{pip_no}")
        os.makedirs(subset_output_path, exist_ok=True)

        for filename in os.listdir(input_dir):
            if filename.endswith(".py"):
                file_path = os.path.join(input_dir, filename)
                with open(file_path, "r", encoding="utf-8") as f:
                    source_code = f.read()

                refactored_code = apply_pipeline(source_code, pipeline)

                result_file = os.path.join(subset_output_path, f"{filename}_${pip_no}")
                with open(result_file, "w", encoding="utf-8") as f:
                    f.write(refactored_code)


if __name__ == "__main__":
    process_files("./ref_input/")
