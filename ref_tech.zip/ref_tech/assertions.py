import ast
import random



class AddAssertions(ast.NodeTransformer):
    def visit_FunctionDef(self, node):
        args = node.args.args
        defaults = node.args.defaults
        offset = len(args) - len(defaults)

        params_to_assert = []

        for i, arg in enumerate(args):
            if arg.arg == 'self':
                continue

            default = None
            if i >= offset:
                default = defaults[i - offset]

            if not (isinstance(default, ast.Constant) and default.value is None):
                params_to_assert.append(arg.arg)

        if params_to_assert:
            conds = [
                ast.Compare(
                    left=ast.Name(id=p, ctx=ast.Load()),
                    ops=[ast.NotEq()],
                    comparators=[ast.Constant(None)]
                )
                for p in params_to_assert
            ]
            test = conds[0] if len(conds) == 1 else ast.BoolOp(op=ast.And(), values=conds)
            node.body.insert(0, ast.Assert(test=test))

        return self.generic_visit(node)

    def get_refactored_code(self, source_code):
        try:
            tree = ast.parse(source_code)
            tree = self.visit(tree)
            result = ast.unparse(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")

        

        return result
