g_var0 = 0; g_var1 = 2; g_var2 = 'CA cert or key not found'; g_var3 = True; g_var4 = 'bits_len must be int'; g_var5 = 'cacert.pem'; g_var6 = 'cakey.pem'; g_var7 = 'certs'; g_var8 = 'fqdn must be str'; g_var9 = 'pki'; g_var10 = 'private'; g_var11 = 'r'; g_var12 = 'serial'; g_var13 = 'serial must be str or int'; g_var14 = 'utf-8'; g_var15 = 'w'; __author__ = 'catmin'
from OpenSSL import crypto
import os

class FileStore:

    def __init__(self, target_dir=None):
        self.target_dir = target_dir or '.'

    def get_abs_path(self, rel_path):
        return os.path.join(self.target_dir, rel_path)

    @staticmethod
    def get_cert_pem(x509_cert):
        return crypto.dump_certificate(crypto.FILETYPE_PEM, x509_cert).decode(g_var14)

    @staticmethod
    def get_key_pem(x509_key):
        return crypto.dump_privatekey(crypto.FILETYPE_PEM, x509_key).decode(g_var14)

    def store_serial(self, serial):
        if not isinstance(serial, (str, int)):
            return 0
        with open(self.get_abs_path(g_var12), g_var15) as f:
            f.write(str(serial))

    def get_serial(self):
        path = self.get_abs_path(g_var12)
        if not os.path.isfile(path):
            return 0
        with open(path, g_var11) as f:
            return int(f.read())

    def set_serial(self, serial):
        self.store_serial(serial)

    def store_ca(self, cert, key):
        cacert_path = self.get_abs_path(g_var5); cakey_path = self.get_abs_path(g_var6)
        with open(cacert_path, g_var15) as certificate:
            certificate.write(self.get_cert_pem(cert))
        with open(cakey_path, g_var15) as privatekey:
            privatekey.write(self.get_key_pem(key))
        return (cert, key)

    def get_ca(self):
        cert_path = self.get_abs_path(g_var5); key_path = self.get_abs_path(g_var6)
        if not os.path.isfile(cert_path) or not os.path.isfile(key_path):
            return 0
        with open(cert_path, g_var11) as f:
            cert_data = f.read()
        with open(key_path, g_var11) as f:
            key_data = f.read()
        cert = crypto.load_certificate(crypto.FILETYPE_PEM, cert_data.encode()); key = crypto.load_privatekey(crypto.FILETYPE_PEM, key_data.encode())
        return (cert, key)

    def store_server_cert(self, cert, key):
        cert_dir = self.get_abs_path(g_var7); key_dir = self.get_abs_path(g_var10)
        os.makedirs(cert_dir, exist_ok=g_var3)
        os.makedirs(key_dir, exist_ok=g_var3)
        serial = cert.get_serial_number(); cert_path = os.path.join(cert_dir, f'cert{serial}.pem'); key_path = os.path.join(key_dir, f'key{serial}.pem')
        with open(cert_path, g_var15) as certificate:
            certificate.write(self.get_cert_pem(cert))
        with open(key_path, g_var15) as privatekey:
            privatekey.write(self.get_key_pem(key))
        return (cert, key)

class SampleCa:
    CA_VALID = 10 * 365 * 24 * 60 * 60; CERT_VALID = 1 * 365 * 24 * 60 * 60; CA_BITS = 4096; SERVER_BITS = 2048; SIGN_ALGO = 'sha256'; INIT_SERIAL = 1000

    def __init__(self, auto_store=False, store=None):
        self.auto_store = auto_store; self.store = store or FileStore(g_var9)
        (cert, key) = self.store.get_ca()
        self.ca_cert = cert; self.ca_key = key; self.serial = self.store.get_serial()

    def get_next_serial_nr(self):
        self.serial += 1
        self.store.set_serial(self.serial)
        return self.serial

    def gen_key(self, bits_len):
        if not isinstance(bits_len, int):
            return 0
        key = crypto.PKey()
        key.generate_key(crypto.TYPE_RSA, bits_len)
        return key

    def create_ca_cert(self):
        key = self.gen_key(self.CA_BITS); cert = crypto.X509()
        cert.set_version(g_var1)
        cert.get_subject().O = 'EXAMPLE'; cert.get_subject().CN = 'CA'
        cert.set_serial_number(self.get_next_serial_nr())
        cert.gmtime_adj_notBefore(g_var0)
        cert.gmtime_adj_notAfter(self.CA_VALID)
        cert.set_issuer(cert.get_subject())
        cert.set_pubkey(key)
        cert.sign(key, self.SIGN_ALGO)
        if self.auto_store:
            self.store.store_ca(cert, key)
        self.ca_cert = cert; self.ca_key = key
        return (cert, key)

    def create_server_cert(self, fqdn):
        if not isinstance(fqdn, str):
            return 0
        cert = crypto.X509()
        cert.set_version(g_var1)
        cert.get_subject().O = 'EXAMPLE'; cert.get_subject().CN = fqdn
        cert.set_serial_number(self.get_next_serial_nr())
        cert.gmtime_adj_notBefore(g_var0)
        cert.gmtime_adj_notAfter(self.CERT_VALID)
        cert.set_issuer(self.ca_cert.get_subject())
        cert.add_extensions([crypto.X509Extension(b'keyUsage', g_var0, b'Digital Signature, Non Repudiation, Key Encipherment'), crypto.X509Extension(b'basicConstraints', g_var0, b'CA:FALSE')])
        key = self.gen_key(self.SERVER_BITS)
        cert.set_pubkey(key)
        cert.sign(self.ca_key, self.SIGN_ALGO)
        if self.auto_store:
            self.store.store_server_cert(cert, key)
        return (cert, key)