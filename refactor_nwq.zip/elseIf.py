import libcst as cst
from libcst.display import dump

class ElseIfConverter(cst.CSTTransformer):
    def leave_If(self, node, updated_node):
        if isinstance(updated_node, cst.Else):
            return updated_node
        if isinstance(updated_node.orelse, cst.If):
            new_orelse = cst.Else(
                body=cst.IndentedBlock(body=[self.leave_If(node.orelse, updated_node.orelse)])
            )
            return updated_node.with_changes(orelse=new_orelse)
        return updated_node
    def get_refactored_code(self, source_code):
        try:
            module = cst.parse_module(source_code)
            wrapper = cst.MetadataWrapper(module)
            modified_tree = wrapper.visit(self)
            return modified_tree.code
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")


wrapper = ElseIfConverter()
source = """ 
def des_if(num):
    if num==4:
        return "Four"
    elif num==5: return "Five"
    elif num==3:
        return "Three"
    else: return "None"
"""

target = wrapper.get_refactored_code(source)
print(target)