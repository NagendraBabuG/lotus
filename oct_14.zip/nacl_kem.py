
from quantcrypt.kem import MLKEM_512
import nacl.utils
from nacl.public import PrivateKey, Box
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

# Generate Bob's private key, which must be kept secret
skbob_pub, skbob = MLKEM_512().keygen()

# Bob's public key can be given to anyone wishing to send
#   Bob an encrypted message
pkbob = skbob_pub

# Alice does the same and then Alice and Bob exchange public keys
skalice_pub, skalice = MLKEM_512().keygen()
pkalice = skalice_pub

# This is our message to send, it must be a bytestring as Box will treat it
#   as just a binary blob of data.
message = b"Kill all humans"

# Encrypt our message, it will be exactly 40 bytes longer than the
#   original message as it stores authentication information and the
#   nonce alongside it.

cipher_text, sender_shared_key = MLKEM_512().encaps(pkalice)

reciever_shared_key = MLKEM_512().decaps(skalice, cipher_text)

assert sender_shared_key == reciever_shared_key
print(sender_shared_key == reciever_shared_key, "\n")
session_key = HKDF(
    algorithm=hashes.SHA256(),
    length=32,
    salt=None,
    info=b'handshake info'
).derive(sender_shared_key)

print(session_key)

print(len(session_key))
