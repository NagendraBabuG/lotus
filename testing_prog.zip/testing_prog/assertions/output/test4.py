def test4():
    a = 5
    b = 5
    c = 5
    assert a == b
    assert b == a
    assert a == b
    assert b == c
    assert a == c
test4()