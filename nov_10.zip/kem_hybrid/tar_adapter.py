
from pathlib import Path

import libcst as cst


CLASSICAL_ALGORITHMS = {
    "X25519PrivateKey",
    "X25519PublicKey",
    "X448PrivateKey",
    "X448PublicKey",
    "EllipticCurvePrivateKey",
    "EllipticCurvePublicKey",
    "DHPrivateKey",
    "DHPublicKey",
    "DHParameters",
}

CLASSICAL_MODULES = {"x25519", "x448", "ec", "dh"}

PQC_ALGORITHMS = {"MLKEM512", "MLKEM768", "MLKEM1024"}

PQC_CLASSES = {
    f"{algorithm}{suffix}"
    for algorithm in PQC_ALGORITHMS
    for suffix in ("PrivateKey", "PublicKey")
}

MODULE_CLASS_MAP = {
    "x25519": {"X25519PrivateKey", "X25519PublicKey"},
    "x448": {"X448PrivateKey", "X448PublicKey"},
    "ec": {"EllipticCurvePrivateKey", "EllipticCurvePublicKey"},
    "dh": {"DHPrivateKey", "DHPublicKey", "DHParameters"},
    "mlkem": PQC_CLASSES,
}

MODULE_PATHS = {
    "x25519": "cryptography.hazmat.primitives.asymmetric.x25519",
    "x448": "cryptography.hazmat.primitives.asymmetric.x448",
    "ec": "cryptography.hazmat.primitives.asymmetric.ec",
    "dh": "cryptography.hazmat.primitives.asymmetric.dh",
    "mlkem": "cryptography.hazmat.primitives.asymmetric.mlkem",
}

METHOD_NAME_MAP = {
    "generate": "generate_private_key",
    "generate_private_key": "generate_private_key",
    "from_private_bytes": "load_private_key",
    "from_public_bytes": "load_public_key",
    "from_seed_bytes": "load_private_key",
    "private_bytes": "serialize_private_key",
    "public_bytes": "serialize_public_key",
    "private_bytes_raw": "serialize_private_key_raw",
    "public_bytes_raw": "serialize_public_key_raw",
    "public_key": "get_public_key",
    "exchange": "exchange",
    "encapsulate": "encapsulate",
    "decapsulate": "decapsulate",
    "sign": "sign",
    "verify": "verify",
}

METHOD_TEMPLATES = {
    "from_private_bytes": (
        "seed",
        "{class_name}.from_private_bytes(seed)",
    ),
    "from_seed_bytes": (
        "seed",
        "{class_name}.from_seed_bytes(seed)",
    ),
    "from_public_bytes": (
        "public_bytes",
        "{class_name}.from_public_bytes(public_bytes)",
    ),
    "generate": (
        "",
        "{class_name}.generate()",
    ),
    "generate_private_key": (
        "",
        "{class_name}.generate()",
    ),
    "public_key": (
        "private_key",
        "private_key.public_key()",
    ),
    "exchange": (
        "private_key, peer_public_key",
        "private_key.exchange(peer_public_key)",
    ),
    "encapsulate": (
        "public_key",
        "public_key.encapsulate()",
    ),
    "decapsulate": (
        "private_key, ciphertext",
        "private_key.decapsulate(ciphertext)",
    ),
    "private_bytes": (
        "private_key, encoding, format, encryption_algorithm",
        "private_key.private_bytes("
        "encoding=encoding, format=format, "
        "encryption_algorithm=encryption_algorithm)",
    ),
    "public_bytes": (
        "public_key, encoding, format",
        "public_key.public_bytes(encoding=encoding, format=format)",
    ),
    "private_bytes_raw": (
        "private_key",
        "private_key.private_bytes_raw()",
    ),
    "public_bytes_raw": (
        "public_key",
        "public_key.public_bytes_raw()",
    ),
    "sign": (
        "private_key, data",
        "private_key.sign(data)",
    ),
    "verify": (
        "public_key, signature, data",
        "public_key.verify(signature, data)",
    ),
}


class CryptoCall:

    def __init__(
        self,
        name,
        receiver,
        arguments,
        keywords,
        receiver_type=None,
        is_class_method=False,
        is_pqc=False,
        algorithm=None,
    ):
        self.name = name
        self.receiver = receiver
        self.arguments = arguments
        self.keywords = keywords
        self.receiver_type = receiver_type
        self.is_class_method = is_class_method
        self.is_pqc = is_pqc
        self.algorithm = algorithm


class HybridCallExtractor(cst.CSTVisitor):

    def __init__(self):
        self.crypto_calls = []
        self.variables = {}
        self.import_aliases = {}
        self.module_aliases = {}

    def _code(self, node):
        return cst.Module([]).code_for_node(node)

    def _resolve_name(self, name):
        return self.import_aliases.get(name, name)

    def _get_algorithm(self, class_name):
        for algorithm in PQC_ALGORITHMS:
            if algorithm in class_name:
                return algorithm

        return class_name

    def _get_class_info(self, func):
        if not isinstance(func, cst.Attribute):
            return None

        owner = func.value

        # Imported class:
        # X448PrivateKey.generate()
        # MLKEM768PrivateKey.generate()
        if isinstance(owner, cst.Name):
            class_name = self._resolve_name(owner.value)

            if class_name in CLASSICAL_ALGORITHMS:
                return class_name, False, class_name

            if class_name in PQC_CLASSES:
                return class_name, True, self._get_algorithm(class_name)

        # Module-qualified class:
        # x448.X448PrivateKey.generate()
        # mlkem.MLKEM768PrivateKey.generate()
        if isinstance(owner, cst.Attribute):
            if isinstance(owner.value, cst.Name):
                module_alias = owner.value.value
                module_name = self.module_aliases.get(
                    module_alias,
                    module_alias,
                )

                class_name = owner.attr.value

                if class_name in MODULE_CLASS_MAP.get(module_name, set()):
                    is_pqc = module_name == "mlkem"

                    return (
                        class_name,
                        is_pqc,
                        self._get_algorithm(class_name),
                    )

        return None

    def _get_receiver_info(self, receiver):
        receiver_name = self._code(receiver)

        if receiver_name in self.variables:
            return self.variables[receiver_name]

        if isinstance(receiver, cst.Name):
            return self.variables.get(receiver.value)

        return None

    def _extract_args(self, args):
        positional = []
        keywords = {}

        for arg in args:
            value = self._code(arg.value)

            if arg.keyword:
                keywords[arg.keyword.value] = value
            else:
                positional.append(value)

        return positional, keywords

    def _get_target_names(self, target):
        if isinstance(target, cst.Name):
            return [target.value]

        if isinstance(target, cst.Attribute):
            return [self._code(target)]

        return []

    def _get_module_name(self, module_name):
        parts = module_name.split(".")
        return parts[-1]

    def _track_assignment(self, target, value):
        if not isinstance(value, cst.Call):
            return

        info = self._get_class_info(value.func)

        # EC key generation:
        # private_key = ec.generate_private_key(ec.SECP384R1())
        if (
            not info
            and isinstance(value.func, cst.Attribute)
            and value.func.attr.value == "generate_private_key"
            and isinstance(value.func.value, cst.Name)
        ):
            module_name = self.module_aliases.get(
                value.func.value.value,
                value.func.value.value,
            )

            if module_name == "ec":
                info = (
                    "EllipticCurvePrivateKey",
                    False,
                    "ECCurve",
                )

        # Track returned public keys:
        # public_key = private_key.public_key()
        if not info and isinstance(value.func, cst.Attribute):
            receiver_info = self._get_receiver_info(value.func.value)

            if receiver_info and value.func.attr.value == "public_key":
                private_type, is_pqc, algorithm = receiver_info

                public_type = private_type.replace(
                    "PrivateKey",
                    "PublicKey",
                )

                info = (
                    public_type,
                    is_pqc,
                    algorithm,
                )

        if not info:
            return

        for target_name in self._get_target_names(target):
            self.variables[target_name] = info

    def visit_ImportFrom(self, node):
        if not node.module:
            return

        module_name = self._code(node.module)
        module_short_name = self._get_module_name(module_name)

        for item in node.names:
            if isinstance(item, cst.ImportStar):
                continue

            imported_name = item.name.value

            alias = (
                item.asname.name.value
                if item.asname
                else imported_name
            )

            self.import_aliases[alias] = imported_name

            if imported_name in MODULE_CLASS_MAP:
                self.module_aliases[alias] = imported_name

            if imported_name in CLASSICAL_MODULES:
                self.module_aliases[alias] = imported_name

            if module_short_name in MODULE_CLASS_MAP:
                if imported_name in MODULE_CLASS_MAP[module_short_name]:
                    self.import_aliases[alias] = imported_name

    def visit_Import(self, node):
        for item in node.names:
            module_name = self._code(item.name)
            short_name = self._get_module_name(module_name)

            alias = (
                item.asname.name.value
                if item.asname
                else short_name
            )

            if short_name in MODULE_CLASS_MAP:
                self.module_aliases[alias] = short_name

    def visit_Assign(self, node):
        for assignment_target in node.targets:
            self._track_assignment(
                assignment_target.target,
                node.value,
            )

    def visit_AnnAssign(self, node):
        if node.value is not None:
            self._track_assignment(
                node.target,
                node.value,
            )

    def visit_Call(self, node):
        if not isinstance(node.func, cst.Attribute):
            return

        method_name = node.func.attr.value
        receiver = node.func.value

        # Module-level EC key generation:
        # ec.generate_private_key(ec.SECP384R1())
        if (
            method_name == "generate_private_key"
            and isinstance(receiver, cst.Name)
        ):
            module_name = self.module_aliases.get(
                receiver.value,
                receiver.value,
            )

            if module_name == "ec":
                positional, keywords = self._extract_args(node.args)

                self.crypto_calls.append(
                    CryptoCall(
                        name=method_name,
                        receiver=self._code(receiver),
                        arguments=positional,
                        keywords=keywords,
                        receiver_type="ec",
                        is_class_method=True,
                        is_pqc=False,
                        algorithm="ECCurve",
                    )
                )
                return

        class_info = self._get_class_info(node.func)

        if class_info:
            class_name, is_pqc, algorithm = class_info

            positional, keywords = self._extract_args(node.args)

            self.crypto_calls.append(
                CryptoCall(
                    name=method_name,
                    receiver=self._code(receiver),
                    arguments=positional,
                    keywords=keywords,
                    receiver_type=class_name,
                    is_class_method=True,
                    is_pqc=is_pqc,
                    algorithm=algorithm,
                )
            )
            return

        receiver_info = self._get_receiver_info(receiver)

        if not receiver_info:
            return

        class_name, is_pqc, algorithm = receiver_info

        positional, keywords = self._extract_args(node.args)

        self.crypto_calls.append(
            CryptoCall(
                name=method_name,
                receiver=self._code(receiver),
                arguments=positional,
                keywords=keywords,
                receiver_type=class_name,
                is_class_method=False,
                is_pqc=is_pqc,
                algorithm=algorithm,
            )
        )


def get_algorithm(crypto_calls, is_pqc):
    for call in crypto_calls:
        if call.is_pqc == is_pqc and call.algorithm:
            return call.algorithm

    return None


def get_adapter_name(crypto_calls):
    classical_algorithm = get_algorithm(crypto_calls, False)
    pqc_algorithm = get_algorithm(crypto_calls, True)

    if classical_algorithm and pqc_algorithm:
        classical_name = classical_algorithm.replace("PrivateKey", "")
        return f"Hybrid{classical_name}{pqc_algorithm}Adapter"

    if pqc_algorithm:
        return f"{pqc_algorithm}Adapter"

    if classical_algorithm == "ECCurve":
        return "ECCurveAdapter"

    if classical_algorithm:
        return (
            f"{classical_algorithm.replace('PrivateKey', '')}Adapter"
        )

    return "CryptoAdapter"


def get_adapter_method_name(call):
    method = METHOD_NAME_MAP.get(call.name)

    if not method:
        return None

    prefix = "pqc" if call.is_pqc else "classical"

    return f"{prefix}_{method}"


def get_required_imports(crypto_calls):
    required_classes = {
        call.receiver_type
        for call in crypto_calls
        if call.receiver_type
    }

    imports = {}

    for class_name in required_classes:
        if class_name == "ec":
            imports.setdefault("ec", set())
            continue

        if class_name == "EllipticCurvePrivateKey":
            imports.setdefault("ec", set())
            continue

        if class_name == "EllipticCurvePublicKey":
            imports.setdefault("ec", set())
            continue

        for module_name, classes in MODULE_CLASS_MAP.items():
            if class_name in classes:
                imports.setdefault(module_name, set()).add(class_name)
                break

    import_lines = []

    for module_name in sorted(imports):
        if module_name == "ec":
            import_lines.append(
                "from cryptography.hazmat.primitives.asymmetric import ec"
            )
            continue

        class_names = sorted(imports[module_name])
        import_path = MODULE_PATHS[module_name]

        import_lines.append(
            f"from {import_path} import {', '.join(class_names)}"
        )

    return import_lines


def get_method_definition(call):
    method_name = get_adapter_method_name(call)

    if not method_name:
        return None

    # EC key generation:
    # ec.generate_private_key(ec.SECP384R1())
    if (
        call.receiver_type == "ec"
        and call.name == "generate_private_key"
    ):
        return (
            f"    def {method_name}(self, curve):\n"
            "        return ec.generate_private_key(curve)\n"
        )

    # EC exchange requires an exchange algorithm such as ec.ECDH().
    if (
        call.name == "exchange"
        and call.receiver_type == "EllipticCurvePrivateKey"
    ):
        return (
            f"    def {method_name}("
            "self, private_key, algorithm, peer_public_key):\n"
            "        return private_key.exchange("
            "algorithm, peer_public_key)\n"
        )

    template = METHOD_TEMPLATES.get(call.name)

    if not template:
        return None

    parameters, implementation = template

    if call.is_class_method:
        implementation = implementation.format(
            class_name=call.receiver_type
        )

    signature = ", ".join(
        ["self"] + ([parameters] if parameters else [])
    )

    return (
        f"    def {method_name}({signature}):\n"
        f"        return {implementation}\n"
    )


def generate_hybrid_target_adapter(crypto_calls, output_file):
    adapter_name = get_adapter_name(crypto_calls)

    imports = get_required_imports(crypto_calls)

    methods = {}

    for call in crypto_calls:
        method_name = get_adapter_method_name(call)

        if not method_name or method_name in methods:
            continue

        method_code = get_method_definition(call)

        if method_code:
            methods[method_name] = method_code

    code = ""

    if imports:
        code += "\n".join(imports) + "\n\n"

    code += f"class {adapter_name}:\n"

    if not methods:
        code += "    pass\n"
    else:
        code += "\n".join(methods.values())

    compile(code, str(output_file), "exec")

    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(code, encoding="utf-8")

    return adapter_name


def process_file(source_file, target_file):
    source_code = source_file.read_text(encoding="utf-8")
    module = cst.parse_module(source_code)

    extractor = HybridCallExtractor()
    module.visit(extractor)

    if not extractor.crypto_calls:
        return None

    return generate_hybrid_target_adapter(
        extractor.crypto_calls,
        target_file,
    )


def process_files(source_dir, target_dir):
    source_dir = Path(source_dir)
    target_dir = Path(target_dir)

    target_dir.mkdir(parents=True, exist_ok=True)

    for source_file in source_dir.rglob("*.py"):
        relative_path = source_file.relative_to(source_dir)
        target_file = target_dir / relative_path

        try:
            adapter_name = process_file(
                source_file,
                target_file,
            )

            if adapter_name:
                print(
                    f"Generated {adapter_name}: {target_file}"
                )
            else:
                print(
                    f"No crypto operations found: {source_file}"
                )

        except Exception as error:
            print(
                f"ERROR processing {source_file.name}: {error}"
            )



if __name__ == "__main__":
    process_files(
        "../kem_files/hybrid",
        "./adapter/target",
    )
