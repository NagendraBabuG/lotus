from cryptography.hazmat.primitives.asymmetric import ec

class ECAdapter:

    def generate_private_key(self, curve, backend):
        return ec.generate_private_key(curve, backend)

    def get_public_key(self, alice_private):
        return alice_private.public_key()

    def serialize_public_key(self, alice_public, ser_encoding, pub_format):
        return alice_public.public_bytes(ser_encoding, pub_format)

    def get_public_key(self, bob_private):
        return bob_private.public_key()

    def serialize_public_key(self, bob_public, ser_encoding, pub_format):
        return bob_public.public_bytes(ser_encoding, pub_format)

    def exchange(self, alice_private, algorithm, alice_copy_bob_public):
        return alice_private.exchange(algorithm, alice_copy_bob_public)

    def exchange(self, bob_private, algorithm, bob_copy_alice_public):
        return bob_private.exchange(algorithm, bob_copy_alice_public)

    def serialize_private_key(self, alice_private, ser_encoding, pri_format, pri_encrypt):
        return alice_private.private_bytes(ser_encoding, pri_format, pri_encrypt)

    def serialize_private_key(self, bob_private, ser_encoding, pri_format, pri_encrypt):
        return bob_private.private_bytes(ser_encoding, pri_format, pri_encrypt)

    def hex(self, alice_shared):
        return alice_shared.hex()

    def hex(self, bob_shared):
        return bob_shared.hex()

