def test1():
    x = 100
    y = 100
    z = 100

    assert x == y
    assert y == z
    assert z == x 
test1()