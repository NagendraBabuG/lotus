def test3():
    a = 10
    b = 10
    c = 20
    assert a != b
    assert b != c
    assert a != b and b != c
test3()