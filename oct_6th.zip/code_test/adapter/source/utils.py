import json
import requests
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.serialization import PrivateFormat, Encoding, NoEncryption, load_pem_public_key

class RSAAdapter:

    def generate_private_key(self):
        return rsa.generate_private_key(public_exponent=65537, key_size=2048, backend=default_backend())

    def serialize_private_key(self, sk):
        return sk.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption())

    def decrypt(self, sk, key, mgf, algorithm, label):
        return sk.decrypt(key, padding.OAEP(
        mgf=padding.MGF1(algorithm=hashes.SHA256()),
        algorithm=hashes.SHA256(),
        label=None
    ))

