def rsa_long_encrypt(message, my_rsa_public):
    try:
        if not message:
            return ""

        msg = message.encode('utf-8')
        length = len(msg)
        default_length = 245

        my_rsa_public = add_start_end(
            my_rsa_public,
            "-----BEGIN PUBLIC KEY-----\n",
            "\n-----END PUBLIC KEY-----"
        )

        pubobj = PKCS1_v1_5.new(RSA.importKey(my_rsa_public))

        if length < default_length:
            return base64.b64encode(pubobj.encrypt(msg)).decode("utf-8")

        offset = 0
        res = []

        while length - offset > 0:
            if length - offset > default_length:
                res.append(
                    pubobj.encrypt(msg[offset:offset + default_length])
                )
            else:
                res.append(
                    pubobj.encrypt(msg[offset:])
                )
            offset += default_length

        byte_data = b''.join(res)
        return base64.b64encode(byte_data).decode("utf-8")

    except Exception as ex:
        return str(ex)