x = 10
print('x') if x > 5 else print('y') if x >= 2 else print('z')
y = 20
y = y + 1 if y % 2 == 0 else y + 2
print(y)