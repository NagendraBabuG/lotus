import ast


class CommonParamters(ast.NodeTransformer):
    def getCommonParams(self, tree):
        param_list = []

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                param_list.append([arg.arg for arg in node.args.args])

        if len(param_list) < 2:
            return tree

        common_param = list(set(param_list[0]).intersection(*param_list[1:]))
        if not common_param:
            return tree

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                current_args = [arg.arg for arg in node.args.args]
                if set(common_param).issubset(current_args):
                    new_args = [arg for arg in current_args if arg not in common_param]
                    new_args.insert(0, 'mergedParam')
                    node.args.args = [ast.arg(arg=arg) for arg in new_args]

            elif isinstance(node, ast.Call):
                for idx, elem in enumerate(node.args):
                    if isinstance(elem, ast.Name) and elem.id in common_param:
                        node.args[idx] = ast.Attribute(
                            value=ast.Name(id='mergedParam', ctx=ast.Load()),
                            attr=elem.id,
                            ctx=ast.Load()
                        )

        new_stmts = [
            ast.Assign(
                targets=[ast.Name(id='mergedParam', ctx=ast.Store())],
                value=ast.Call(
                    func=ast.Call(
                        func=ast.Name(id='type', ctx=ast.Load()),
                        args=[
                            ast.Constant(value='MergedParam'),
                            ast.Tuple(elts=[], ctx=ast.Load()),
                            ast.Dict(keys=[], values=[])
                        ],
                        keywords=[]
                    ),
                    args=[],
                    keywords=[]
                )
            )
        ]

        for param in common_param:
            new_stmts.append(
                ast.Assign(
                    targets=[ast.Attribute(
                        value=ast.Name(id='mergedParam', ctx=ast.Load()),
                        attr=param,
                        ctx=ast.Store()
                    )],
                    value=ast.Name(id=param, ctx=ast.Load())
                )
            )

        if isinstance(tree, ast.Module):
            insertion_index = 0
            for i, stmt in enumerate(tree.body):
                if isinstance(stmt, ast.Assign):
                    insertion_index = i + 1
            tree.body[insertion_index:insertion_index] = new_stmts

        
        ast.fix_missing_locations(tree)

        return tree

    def get_refactored_code(self, source_code):
        try:
            tree = ast.parse(source_code)
            tree = self.getCommonParams(tree)
            return ast.unparse(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")
