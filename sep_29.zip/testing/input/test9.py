from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey, Ed25519PrivateKey

def ed_pub_from_bytes(raw: bytes) -> Ed25519PublicKey:
    pub_key: Ed25519PublicKey = Ed25519PublicKey.from_public_bytes(raw)
    return pub_key

def ed_priv_gen() -> Ed25519PrivateKey:
    priv_key: Ed25519PrivateKey = Ed25519PrivateKey.generate()
    return priv_key
