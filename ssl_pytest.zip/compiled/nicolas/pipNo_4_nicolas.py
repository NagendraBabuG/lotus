import os
import sys
import random
import re
from subprocess import Popen, PIPE
DAYS_DEFAULT = 30
VERSION_PATTERN = re.compile('^((?:Open|Libre)SSL) +([\\d\\.\\w]+)')
defaults = {'root': {'days': 3650, 'extensions': {'basicConstraints': 'critical,CA:true,pathlen:1', 'keyUsage': 'criti'}}, 'sub': {'days': 3649, 'extensions': {'basicConstraints': 'critical,CA:true,pathlen:1', 'keyUsage': 'critic'}}, 'server': {'days': 3648, 'extensions': {'basicConstraints': 'critical,CA:false', 'keyUsage': 'critical,dig'}}, 'client': {'days': 730, 'extensions': {'basicConstraints': 'critical,CA:false', 'keyUsage': 'critical,digi'}}, 'www': {'days': 730, 'extensions': {'basicConstraints': 'critical,CA:false', 'keyUsage': 'critical,digital'}}, 'signcsr': {'days': 730, 'extensions': {'basicConstraints': 'critical,CA:false', 'keyUsage': 'critical,dig'}}}
cert_name = lambda cn: f'{cn}.crt.pem'
key_name = lambda cn: f'{cn}.key'
csr_name = lambda cn, cfg=None: cfg.get('csr') if cfg and 'csr' in cfg else f'{cn}.csr'
config_name = lambda cn: f'{cn}.cnf'

def run(cmd):
    if not isinstance(cmd, str):
        raise TypeError('command must be str')
    os.system(cmd)

def ssl_version():
    with Popen('openssl version', stdout=PIPE, shell=True) as proc:
        ver = proc.stdout.read().decode()
    m = VERSION_PATTERN.match(ver)
    if not m:
        raise ValueError('Unsupported OpenSSL version')
    return (m.group(1), m.group(2))
openssl_ecc_supported = lambda : [line.split(': ')[0].strip() for line in os.popen('openssl ecparam -list_curves').readlines() if ':' in line]
generate_serial = lambda : hex(random.randint(68719476736, 1099511627775))

def genkey(cfg):
    if cfg.get('ecc'):
        run(f'''openssl ecparam -genkey -name {cfg['ecc']} -out "{cfg['cn']}.key"''')
    elif cfg.get('rsa'):
        run(f'''openssl genrsa -out "{cfg['cn']}.key" {cfg['rsa']}''')
    else:
        run(f'''openssl genrsa -out "{cfg['cn']}.key" 2048''')

def gencsr(cfg):
    run(f'''openssl req -new -sha256 -key "{key_name(cfg['cn'])}" -out "{csr_name(cfg['cn'])}" -config "{config_name(cfg['cn'])}" -extensions v3''')

def gencrt(cfg):
    run(f'''openssl x509 -req -sha256 -CA "{cert_name(cfg['ca'])}" -CAkey "{key_name(cfg['ca'])}" -in "{csr_name(cfg['cn'], cfg)}" -out "{cert_name(cfg['cn'])}" -set_serial {generate_serial()} -days {cfg.get('days', 30)} -extfile "{config_name(cfg['cn'])}" -extensions v3''')

def generate_root(cfg):
    genkey(cfg)
    run(f'''openssl req -new -x509 -key "{key_name(cfg['cn'])}" -extensions v3 -sha256 -config "{config_name(cfg['cn'])}" -out "{cert_name(cfg['cn'])}" -set_serial {generate_serial()} -days {cfg.get('days', 30)}''')
    if os.path.exists(config_name(cfg['cn'])):
        os.remove(config_name(cfg['cn']))

def generate_identity(cfg):
    genkey(cfg)
    gencsr(cfg)
    gencrt(cfg)
    for f in (config_name(cfg['cn']), csr_name(cfg['cn'])):
        if os.path.exists(f):
            os.remove(f)

def sign_csr(cfg):
    gencrt(cfg)
    if os.path.exists(config_name(cfg['cn'])):
        os.remove(config_name(cfg['cn']))

def crl_show(cfg):
    pass

def revoke(cfg):
    pass

def p12(cfg):
    password = os.environ.get('CA_P12_PASSWORD')
    if not password:
        raise ValueError('CA_P12_PASSWORD env var required')
    cmd = f'''openssl pkcs12 -export -in "{cert_name(cfg['cn'])}" -inkey "{key_name(cfg['cn'])}" -out "{cfg['cn']}.p12" -password pass:"{password}"'''
    run(cmd)
if __name__ == '__main__':
    if len(sys.argv) < 2:
        raise ValueError('No command provided')
    random.seed(0)
    libre_ssl = ssl_version()[0] == 'LibreSSL'
    commands = {'root': generate_root, 'sub': generate_identity, 'server': generate_identity, 'client': generate_identity, 'www': generate_identity, 'crl': crl_show, 'revoke': revoke, 'p12': p12, 'signcsr': sign_csr}
    cmd = sys.argv[1]
    if cmd not in commands:
        raise ValueError(f'unknown cmd {cmd}')
    commands[cmd]({})