from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey

class X25519Adapter:

    def load_private_key(self, bytes, private_key_text):
        return X25519PrivateKey.from_private_bytes(bytes.fromhex(private_key_text))

    def generate_private_key(self):
        return X25519PrivateKey.generate()

    def get_public_key(self, private_key):
        return private_key.public_key()

