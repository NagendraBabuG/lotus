from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric.x448 import X448PrivateKey
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.asymmetric import mlkem

# Generate a private key for use in the exchange.
private_key= mlkem.MLKEM1024PrivateKey.generate()
peer_public_key = mlkem.MLKEM1024PrivateKey.generate().public_key()
shared_key, ct_pqc = peer_public_key.encapsulate()
# Perform key derivation.
derived_key = HKDF(
    algorithm=hashes.SHA256(),
    length=32,
    salt=None,
    info=b'handshake data',
).derive(shared_key)
# For the next handshake we MUST generate another private key.
private_key_2= mlkem.MLKEM1024PrivateKey.generate()
peer_public_key_2 = mlkem.MLKEM1024PrivateKey.generate().public_key()
shared_key_2, ct_pqc = peer_public_key_2.encapsulate()
derived_key_2 = HKDF(
    algorithm=hashes.SHA256(),
    length=32,
    salt=None,
    info=b'handshake data',
).derive(shared_key_2)