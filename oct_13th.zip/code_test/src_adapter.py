import libcst as cst
from libcst.metadata import MetadataWrapper
from pathlib import Path


CLASSICAL_ALGORITHMS = {
    "Ed25519PrivateKey",
    "Ed25519PublicKey",
    "Ed448PrivateKey",
    "Ed448PublicKey",
    "RSAPrivateKey",
    "RSAPublicKey",
    "EllipticCurvePrivateKey",
    "EllipticCurvePublicKey",
    "DSAPrivateKey",
    "DSAPublicKey",
}

PQC_ALGORITHMS = {
    "MLDSA44PrivateKey",
    "MLDSA44PublicKey",
    "MLDSA65PrivateKey",
    "MLDSA65PublicKey",
    "MLDSA87PrivateKey",
    "MLDSA87PublicKey",
}

CRYPTO_MODULES = {
    "ed25519",
    "ed448",
    "rsa",
    "ec",
    "dsa",
}

PQC_MODULES = {
    "mldsa",
}

MODULE_GENERATORS = {
    "rsa": "RSAPrivateKey",
    "dsa": "DSAPrivateKey",
    "ec": "EllipticCurvePrivateKey",
}

METHOD_NAME_MAP = {
    "generate": "generate_private_key",
    "generate_private_key": "generate_private_key",
    "from_private_bytes": "load_private_key",
    "from_seed_bytes": "load_private_key_from_seed",
    "from_public_bytes": "load_public_key",
    "private_bytes": "serialize_private_key",
    "public_bytes": "serialize_public_key",
    "private_bytes_raw": "serialize_private_key_raw",
    "public_bytes_raw": "serialize_public_key_raw",
    "public_key": "get_public_key",
    "sign": "sign",
    "verify": "verify",
    "private_numbers": "get_private_numbers",
    "public_numbers": "get_public_numbers",
    "encrypt": "encrypt",
    "decrypt": "decrypt",
}


class CryptoCall:

    def __init__(
        self,
        name,
        receiver,
        arguments,
        keywords,
        receiver_type=None,
        is_class_method=False,
        module_name=None,
        source_expression=None,
    ):
        self.name = name
        self.receiver = receiver
        self.arguments = arguments
        self.keywords = keywords
        self.receiver_type = receiver_type
        self.is_class_method = is_class_method
        self.module_name = module_name
        self.source_expression = source_expression


class CryptoCallExtractor(cst.CSTVisitor):

    def __init__(self):
        self.crypto_module_aliases = set()
        self.pqc_module_aliases = set()

        self.crypto_class_aliases = {}
        self.pqc_class_aliases = {}

        self.crypto_variables = {}
        self.pqc_variables = {}

        self.calls = []
        self.imports = []
        self.imported_names = set()

    def visit_ImportFrom(self, node):

        if node.module is None:
            return

        module_name = cst.Module([]).code_for_node(node.module)
        import_code = cst.Module([]).code_for_node(node)

        if import_code not in self.imports:
            self.imports.append(import_code)

        for imported in node.names:

            if isinstance(imported, cst.ImportStar):
                continue

            imported_name = imported.name.value
            alias = (
                imported.asname.name.value
                if imported.asname
                else imported_name
            )

            self.imported_names.add(imported_name)
            self.imported_names.add(alias)

            if imported_name in CLASSICAL_ALGORITHMS:
                self.crypto_class_aliases[alias] = imported_name

            if imported_name in PQC_ALGORITHMS:
                self.pqc_class_aliases[alias] = imported_name

            if not module_name.startswith("cryptography"):
                continue

            if imported_name in CRYPTO_MODULES:
                self.crypto_module_aliases.add(alias)

            if imported_name in PQC_MODULES:
                self.pqc_module_aliases.add(alias)

    def visit_Import(self, node):

        for imported in node.names:

            module_name = cst.Module([]).code_for_node(imported.name)
            import_code = cst.Module([]).code_for_node(node)

            if import_code not in self.imports:
                self.imports.append(import_code)

            if imported.asname:
                alias = imported.asname.name.value
            else:
                alias = module_name.split(".")[0]

            self.imported_names.add(alias)

            if not module_name.startswith("cryptography"):
                continue

            module_leaf = module_name.split(".")[-1]

            if module_leaf in PQC_MODULES:
                self.pqc_module_aliases.add(alias)

            elif module_leaf in CRYPTO_MODULES:
                self.crypto_module_aliases.add(alias)

    def _get_arguments(self, node):

        positional = []
        keywords = []

        for arg in node.args:
            value = cst.Module([]).code_for_node(arg.value)

            if arg.keyword is not None:
                keywords.append((arg.keyword.value, value))
            else:
                positional.append(value)

        return positional, keywords

    def _get_class_call(self, node):

        function = node.func

        if not isinstance(function, cst.Attribute):
            return None

        method_name = function.attr.value
        value = function.value

        if isinstance(value, cst.Attribute):
            class_name = value.attr.value
            module = value.value

            if isinstance(module, cst.Name):
                module_name = module.value

                if (
                    module_name in self.pqc_module_aliases
                    and class_name in PQC_ALGORITHMS
                ):
                    return {
                        "receiver": class_name,
                        "method": method_name,
                        "receiver_type": class_name,
                        "module_name": module_name,
                        "source_expression": cst.Module([]).code_for_node(node),
                        "pqc": True,
                    }

                if (
                    module_name in self.crypto_module_aliases
                    and class_name in CLASSICAL_ALGORITHMS
                ):
                    return {
                        "receiver": class_name,
                        "method": method_name,
                        "receiver_type": class_name,
                        "module_name": module_name,
                        "source_expression": cst.Module([]).code_for_node(node),
                        "pqc": False,
                    }

        if isinstance(value, cst.Name):
            class_name = value.value

            if class_name in self.pqc_class_aliases:
                return {
                    "receiver": class_name,
                    "method": method_name,
                    "receiver_type": self.pqc_class_aliases[class_name],
                    "module_name": None,
                    "source_expression": cst.Module([]).code_for_node(node),
                    "pqc": True,
                }

            if class_name in self.crypto_class_aliases:
                return {
                    "receiver": class_name,
                    "method": method_name,
                    "receiver_type": self.crypto_class_aliases[class_name],
                    "module_name": None,
                    "source_expression": cst.Module([]).code_for_node(node),
                    "pqc": False,
                }

            if (
                class_name in MODULE_GENERATORS
                and method_name == "generate_private_key"
            ):
                return {
                    "receiver": class_name,
                    "method": method_name,
                    "receiver_type": MODULE_GENERATORS[class_name],
                    "module_name": class_name,
                    "source_expression": cst.Module([]).code_for_node(node),
                    "pqc": False,
                }

        return None

    def _get_instance_call(self, node):

        function = node.func

        if not isinstance(function, cst.Attribute):
            return None

        receiver = function.value

        if not isinstance(receiver, cst.Name):
            return None

        receiver_name = receiver.value

        if receiver_name in self.pqc_variables:
            return {
                "receiver": receiver_name,
                "method": function.attr.value,
                "receiver_type": self.pqc_variables[receiver_name],
                "module_name": None,
                "source_expression": cst.Module([]).code_for_node(node),
                "pqc": True,
            }

        if receiver_name in self.crypto_variables:
            return {
                "receiver": receiver_name,
                "method": function.attr.value,
                "receiver_type": self.crypto_variables[receiver_name],
                "module_name": None,
                "source_expression": cst.Module([]).code_for_node(node),
                "pqc": False,
            }

        return None

    def visit_Assign(self, node):

        if not isinstance(node.value, cst.Call):
            return

        class_call = self._get_class_call(node.value)

        if class_call:
            crypto_type = class_call["receiver_type"]
            is_pqc = class_call["pqc"]
        else:
            instance_call = self._get_instance_call(node.value)

            if not instance_call:
                return

            crypto_type = instance_call["receiver_type"]
            is_pqc = instance_call["pqc"]

        for target in node.targets:
            target_node = target.target

            if not isinstance(target_node, cst.Name):
                continue

            if is_pqc:
                self.pqc_variables[target_node.value] = crypto_type
            else:
                self.crypto_variables[target_node.value] = crypto_type

    def visit_Call(self, node):

        class_call = self._get_class_call(node)

        if class_call:
            arguments, keywords = self._get_arguments(node)

            self.calls.append(
                CryptoCall(
                    name=class_call["method"],
                    receiver=class_call["receiver"],
                    arguments=arguments,
                    keywords=keywords,
                    receiver_type=class_call["receiver_type"],
                    is_class_method=True,
                    module_name=class_call["module_name"],
                    source_expression=class_call["source_expression"],
                )
            )
            return

        instance_call = self._get_instance_call(node)

        if instance_call:
            arguments, keywords = self._get_arguments(node)

            self.calls.append(
                CryptoCall(
                    name=instance_call["method"],
                    receiver=instance_call["receiver"],
                    arguments=arguments,
                    keywords=keywords,
                    receiver_type=instance_call["receiver_type"],
                    is_class_method=False,
                    module_name=instance_call["module_name"],
                    source_expression=instance_call["source_expression"],
                )
            )


class SubscriptStripper(cst.CSTTransformer):

    def leave_Subscript(self, original_node, updated_node):
        return updated_node.value


def clean_argument(argument_str):
    try:
        expr = cst.parse_expression(argument_str)
        stripped = expr.visit(SubscriptStripper())
        return cst.Module([]).code_for_node(stripped)
    except Exception:
        return argument_str


def get_parameter_names(arguments, ignored_names=None):

    if ignored_names is None:
        ignored_names = set()

    ignored_names = set(ignored_names)
    parameters = []

    class VariableExtractor(cst.CSTVisitor):

        def visit_Subscript(self, node):
            node.value.visit(self)
            return False

        def visit_Attribute(self, node):
            node.value.visit(self)
            return False

        def visit_Name(self, node):
            name = node.value

            if name in {"None", "True", "False"}:
                return

            if name in ignored_names:
                return

            if name not in parameters:
                parameters.append(name)

    for argument in arguments:
        try:
            expression = cst.parse_expression(argument)
            extractor = VariableExtractor()
            expression.visit(extractor)
        except Exception:
            continue

    return parameters


def get_method_name(call):
    return METHOD_NAME_MAP.get(call.name, call.name)


def create_class_method(call, imported_names):

    method_name = get_method_name(call)

    argument_expressions = list(call.arguments)
    argument_expressions.extend(value for _, value in call.keywords)

    parameters = get_parameter_names(
        argument_expressions,
        imported_names
    )

    parameter_text = ""

    if parameters:
        parameter_text = ", " + ", ".join(parameters)

    call_arguments = [
        clean_argument(arg)
        for arg in call.arguments
    ]

    for keyword, value in call.keywords:
        cleaned_val = clean_argument(value)
        call_arguments.append(f"{keyword}={cleaned_val}")

    arguments_text = ", ".join(call_arguments)

    if call.module_name:
        if call.receiver == call.module_name:
            function_call = f"{call.module_name}.{call.name}"
        else:
            function_call = (
                f"{call.module_name}.{call.receiver}.{call.name}"
            )

        return (
            f"    def {method_name}(self{parameter_text}):\n"
            f"        return {function_call}({arguments_text})\n"
        )

    return (
        f"    def {method_name}(self{parameter_text}):\n"
        f"        return {call.receiver}.{call.name}({arguments_text})\n"
    )
def create_instance_method(call, imported_names):

    method_name = get_method_name(call)
    argument_expressions = list(call.arguments)
    argument_expressions.extend(value for _, value in call.keywords)

    parameters = get_parameter_names(argument_expressions, imported_names)
    parameter_text = ""

    if parameters:
        parameter_text = ", " + ", ".join(parameters)

    call_arguments = [clean_argument(arg) for arg in call.arguments]

    for keyword, value in call.keywords:
        cleaned_val = clean_argument(value)
        call_arguments.append(f"{keyword}={cleaned_val}")

    arguments_text = ", ".join(call_arguments)

    return (
        f"    def {method_name}(self, {call.receiver}{parameter_text}):\n"
        f"        return {call.receiver}.{call.name}({arguments_text})\n"
    )


def get_algorithm_prefix(receiver_type):
    if not receiver_type:
        return "Source"
    for alg in [
        "Ed25519", "Ed448", "RSA", "EllipticCurve", "DSA",
        "MLDSA44", "MLDSA65", "MLDSA87"
    ]:
        if alg.lower() in receiver_type.lower():
            if alg == "EllipticCurve":
                return "EC"
            return alg
    return "Source"


def generate_adapter_code(extractor):

    all_calls = extractor.calls

    if not all_calls:
        return ""

    unique_calls = []
    seen = set()

    for call in all_calls:
        key = (
            call.receiver,
            call.name,
            tuple(call.arguments),
            tuple(call.keywords),
            call.module_name,
            call.receiver_type,
        )

        if key in seen:
            continue

        seen.add(key)
        unique_calls.append(call)

    variant_calls = {}
    for call in unique_calls:
        prefix = get_algorithm_prefix(call.receiver_type)
        variant_calls.setdefault(prefix, []).append(call)

    code = ""
    used_imports = []

    generated_code_tokens = ""
    for call in unique_calls:
        if call.source_expression:
            generated_code_tokens += call.source_expression + " "
        for arg in call.arguments:
            generated_code_tokens += str(arg) + " "
        for k, v in call.keywords:
            generated_code_tokens += f"{k}={v} "
        generated_code_tokens += f"{call.name} {call.receiver} "
        if call.receiver_type:
            generated_code_tokens += call.receiver_type + " "

    for import_statement in extractor.imports:
        lower_import = import_statement.lower()
        should_include = False

        for name in extractor.imported_names:
            if name.lower() in lower_import and name.lower() in generated_code_tokens.lower():
                should_include = True
                break

        for kw in [
            "serialization", "hashes", "padding", "encoding", "privateformat",
            "noencryption", "ed25519", "ed448", "mldsa", "rsa", "ec", "dsa"
        ]:
            if kw in lower_import and kw in generated_code_tokens.lower():
                should_include = True
                break

        if should_include and import_statement not in used_imports:
            used_imports.append(import_statement)

    for import_statement in used_imports:
        code += import_statement
        code += "\n"

    if used_imports:
        code += "\n"

    # Generate unified adapter classes containing all methods (including signing & verifying)
    for prefix, calls in variant_calls.items():
        class_name = f"{prefix}Adapter"
        code += f"class {class_name}:\n\n"

        for call in calls:
            if call.is_class_method:
                method = create_class_method(call, extractor.imported_names)
            else:
                method = create_instance_method(call, extractor.imported_names)

            code += method
            code += "\n"

    return code


def generate_adapter(source_code):
    module = cst.parse_module(source_code)
    wrapper = MetadataWrapper(module)
    extractor = CryptoCallExtractor()
    wrapper.visit(extractor)
    return generate_adapter_code(extractor)


def process_files(input_folder, output_folder):
    input_folder = Path(input_folder)
    output_folder = Path(output_folder)

    output_folder.mkdir(parents=True, exist_ok=True)

    for file_path in input_folder.glob("*.py"):
        print(f"\nProcessing: {file_path.name}")

        try:
            with open(file_path, "r", encoding="utf-8") as f:
                src = f.read()

            modified_code = generate_adapter(src)

            if not modified_code:
                print("  No crypto usage found - adapter classes not created")
                continue

            base_name = file_path.stem
            output_file = output_folder / f"{base_name}.py"

            with open(output_file, "w", encoding="utf-8") as f:
                f.write(modified_code)

            print(f"  Created: {output_file}")

        except Exception as e:
            print(f"  ERROR processing {file_path.name}: {e}")


if __name__ == "__main__":
    process_files("../testing/input", "./adapter/source")