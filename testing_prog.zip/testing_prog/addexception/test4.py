def bad_index():
    lst = []
    return lst[1]
