import ast

class ForWhile(ast.NodeTransformer):
    def __init__(self):
        self.iterator = ""
        self.iter_id = ""
        self.range_flag = False

    def visit_For(self, node):
        if isinstance(node.iter, ast.Call) and isinstance(node.iter.func, ast.Name) and node.iter.func.id == "range":
            iterator = node.target.id
            args = node.iter.args

            if len(args) == 1:
                start = ast.Constant(value=0)
                stop = args[0]
                step = ast.Constant(value=1)
            elif len(args) == 2:
                start, stop = args
                step = ast.Constant(value=1)
            else:
                start, stop, step = args

            assign_init = ast.Assign(
                targets=[ast.Name(id=iterator, ctx=ast.Store())],
                value=start
            )

            new_test = ast.Compare(
                left=ast.Name(id=iterator, ctx=ast.Load()),
                ops=[ast.Lt()],
                comparators=[stop]
            )

            self.generic_visit(node)
            node.body.append(
                ast.AugAssign(
                    target=ast.Name(id=iterator, ctx=ast.Store()),
                    op=ast.Add(),
                    value=step
                )
            )

            new_while = ast.While(
                test=new_test,
                body=node.body,
                orelse=node.orelse
            )

            ast.fix_missing_locations(assign_init)
            ast.fix_missing_locations(new_while)
            return [assign_init, new_while]

        elif isinstance(node.iter, ast.Name):
            local_iterator = node.target.id
            self.iterator = node.target.id
            self.iter_id = node.iter.id

            assign_init = ast.Assign(
                targets=[ast.Name(id=local_iterator, ctx=ast.Store())],
                value=ast.Constant(value=0)
            )

            new_while = ast.While(
                test=ast.Compare(
                    left=ast.Name(id=local_iterator, ctx=ast.Load()),
                    ops=[ast.Lt()],
                    comparators=[ast.Call(
                        func=ast.Name(id="len", ctx=ast.Load()),
                        args=[ast.Name(id=self.iter_id, ctx=ast.Load())],
                        keywords=[]
                    )]
                ),
                body=node.body,
                orelse=[]
            )

            self.generic_visit(node)
            node.body.append(
                ast.AugAssign(
                    target=ast.Name(id=local_iterator, ctx=ast.Store()),
                    op=ast.Add(),
                    value=ast.Constant(value=1)
                )
            )

            ast.fix_missing_locations(assign_init)
            ast.fix_missing_locations(new_while)
            return [assign_init, new_while]

        return node

    def visit_Subscript(self, node):
        if isinstance(node.slice, ast.Name) and node.slice.id == self.iterator:
            return ast.Subscript(
                value=ast.Name(id=self.iter_id, ctx=ast.Load()),
                slice=ast.Name(id=self.iterator, ctx=ast.Load()),
                ctx=node.ctx
            )
        return node

    def visit_Name(self, node):
        if node.id == self.iterator:
            return ast.Subscript(
                value=ast.Name(id=self.iter_id, ctx=ast.Load()),
                slice=ast.Name(id=self.iterator, ctx=ast.Load()),
                ctx=ast.Load()
            )
        return node

    def visit_While(self, node):
        if not isinstance(node.test, ast.Compare):
            return node
        comp = node.test
        if not (isinstance(comp.left, ast.Name) and isinstance(comp.comparators[0], ast.Call)):
            return node

        iterator = comp.left.id
        call = comp.comparators[0]
        if call.func.id != "len":
            return node

        iter_id = call.args[0].id
        self.iterator = iterator
        self.iter_id = iter_id

        step = ast.Constant(value=1)
        for stmt in node.body:
            if isinstance(stmt, ast.AugAssign) and stmt.target.id == iterator:
                step = stmt.value
                break

        new_for = ast.For(
            target=ast.Name(id=iterator, ctx=ast.Store()),
            iter=ast.Call(
                func=ast.Name(id="range", ctx=ast.Load()),
                args=[ast.Constant(value=0),
                      ast.Call(
                          func=ast.Name(id="len", ctx=ast.Load()),
                          args=[ast.Name(id=iter_id, ctx=ast.Load())],
                          keywords=[]
                      ),
                      step],
                keywords=[]
            ),
            body=[s for s in node.body if not (isinstance(s, ast.AugAssign) and s.target.id == iterator)],
            orelse=node.orelse
        )

        ast.fix_missing_locations(new_for)
        return new_for

    def get_refactored_code(self, source_code):
        tree = ast.parse(source_code)
        tree = self.visit(tree)
        return ast.unparse(tree)


source = """
def fun1(a, b):
    for id in a:
        print(id)
    i = 0 
    while i < len(b):
        print(b[i])
        i = i + 1
"""

wrapper = ForWhile()
target = wrapper.get_refactored_code(source)
print(target)
