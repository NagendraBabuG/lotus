import ast


#it throws error codes (0 or 1) instead of exceptions
# need to check usage
# 
#   
import ast

class ExceptionRefactor(ast.NodeTransformer):
    def __init__(self):
        self.current_function = None  # Track if we're inside a function

    def visit_FunctionDef(self, node):
        # Set flag to indicate we're inside a function
        self.current_function = node
        self.generic_visit(node)
        self.current_function = None  # Reset after leaving function
        return node

    def visit_Try(self, node):
        # Visit all child nodes first
        self.generic_visit(node)

        # Only add return statements if not inside a function
        if self.current_function is None:
            # Ensure try block ends with return 1 (if no return exists)
            if not node.body or not isinstance(node.body[-1], ast.Return):
                node.body.append(
                    ast.Return(value=ast.Constant(value=1))
                )

            # Process each except handler
            for handler in node.handlers:
                if isinstance(handler, ast.ExceptHandler):
                    # Replace Raise with return 0
                    for idx, stmt in enumerate(handler.body):
                        if isinstance(stmt, ast.Raise):
                            handler.body[idx] = ast.Return(
                                value=ast.Constant(value=0)
                            )
                        elif isinstance(stmt, ast.Return):
                            # Replace return statements in except block with return 0
                            handler.body[idx] = ast.Return(
                                value=ast.Constant(value=0)
                            )

                    # Ensure except block ends with return 0 (if no return exists)
                    if not handler.body or not isinstance(handler.body[-1], ast.Return):
                        handler.body.append(
                            ast.Return(value=ast.Constant(value=0))
                        )

        return node

    def visit_If(self, node):
        # Visit child nodes first
        self.generic_visit(node)

        # Process the if body
        for idx, stmt in enumerate(node.body):
            if isinstance(stmt, ast.Raise):
                node.body[idx] = ast.Return(
                    value=ast.Constant(value=1)
                )
            elif isinstance(stmt, ast.Return) and isinstance(stmt.value, ast.Constant):
                if isinstance(stmt.value.value, int):
                    node.body[idx] = ast.Raise(
                        exc=ast.Call(
                            func=ast.Name(id='Exception', ctx=ast.Load()),
                            args=[ast.Constant(value="Operation Failed")],
                            keywords=[]
                        )
                    )

        # Process the else (orelse) body
        for idx, stmt in enumerate(node.orelse):
            if isinstance(stmt, ast.Return) and isinstance(stmt.value, ast.Constant):
                if isinstance(stmt.value.value, int):
                    node.orelse[idx] = ast.Raise(
                        exc=ast.Call(
                            func=ast.Name(id='Exception', ctx=ast.Load()),
                            args=[ast.Constant(value="Operation Failed")],
                            keywords=[]
                        )
                    )
            elif isinstance(stmt, ast.Return):
                node.orelse[idx] = ast.Return(
                    value=ast.Constant(value=0)
                )

        return node

    def refactor_exceptions(self, tree):
        tree = self.visit(tree)
        ast.fix_missing_locations(tree)
        return ast.unparse(tree)

    def get_refactored_code(self, source_code):
        try:
            tree = ast.parse(source_code)
            return self.refactor_exceptions(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")