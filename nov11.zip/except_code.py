import ast

class ExceptionRefactor(ast.NodeTransformer):
    def __init__(self):
        self.in_function = False
        self.in_try = False
        self.in_except = False

    def visit_FunctionDef(self, node):
        self.in_function = True
        self.generic_visit(node)
        self.in_function = False
        return node

    def visit_Try(self, node):
        if not self.in_function:
            return node

        old_try, old_except = self.in_try, self.in_except
        self.in_try = True
        node.body = self._process_block(node.body)
        self.in_try = False

        for h in node.handlers:
            self.in_except = True
            h.body = self._process_block(h.body)
            self.in_except = False

        if not any(isinstance(s, ast.Return) for s in node.body):
            node.body.append(ast.Return(value=ast.Constant(value=1)))

        for h in node.handlers:
            if not any(isinstance(s, ast.Return) for s in h.body):
                h.body.append(ast.Return(value=ast.Constant(value=0)))

        self.in_try, self.in_except = old_try, old_except
        return node

    def _process_block(self, stmts):
        new_stmts = []
        for s in stmts:
            if isinstance(s, ast.Raise):
                s = ast.Return(value=ast.Constant(value=0))
            else:
                s = self.visit(s)
            new_stmts.append(s)
        return new_stmts

    def visit_If(self, node):
        if not self.in_function:
            return node
        node.body = self._process_block(node.body)
        node.orelse = self._process_block(node.orelse)
        return node

    def refactor_exceptions(self, tree):
        self.visit(tree)
        ast.fix_missing_locations(tree)
        return tree

    def get_refactored_code(self, source_code):
        tree = ast.parse(source_code)
        return ast.unparse(self.refactor_exceptions(tree))


wrapper = ExceptionRefactor()

source = """    
def test_password(word):
    try:
        word_copy = word
        key = word_copy.decode('utf-8')
        if len(word_copy) == len(key):
            raise Exception("Operation Failed")
        else:
            raise Exception("OPeration Failed")

    except Exception as exception:
        print(f"operation failed: {exception}")
"""

print(wrapper.get_refactored_code(source))