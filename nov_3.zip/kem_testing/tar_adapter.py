
import libcst as cst
from pathlib import Path


PQC_ALGORITHMS = {
    "MLKEM512",
    "MLKEM768",
    "MLKEM1024",
}

PQC_CLASSES = {
    f"{algorithm}{key_type}"
    for algorithm in PQC_ALGORITHMS
    for key_type in ("PrivateKey", "PublicKey")
}

METHOD_NAME_MAP = {
    "generate": "generate_private_key",
    "from_seed_bytes": "load_private_key",
    "from_private_bytes": "load_private_key",
    "from_public_bytes": "load_public_key",
    "public_key": "get_public_key",
    "private_bytes_raw": "serialize_private_key",
    "private_bytes": "serialize_private_key",
    "public_bytes_raw": "serialize_public_key",
    "public_bytes": "serialize_public_key",
    "encapsulate": "encapsulate",
    "decapsulate": "decapsulate",
}


class PQCCallExtractor(cst.CSTVisitor):

    def __init__(self):
        self.pqc_classes = set(PQC_CLASSES)
        self.pqc_variables = {}
        self.operations = {}
        self.algorithms = set()

    def get_name(self, node):
        try:
            return cst.helpers.get_full_name_for_node(node)
        except Exception:
            return None

    def get_class_info(self, function):

        if not isinstance(function, cst.Attribute):
            return None

        class_node = function.value

        if isinstance(class_node, cst.Name):
            class_name = class_node.value

            if class_name in self.pqc_classes:
                return class_name

        if isinstance(class_node, cst.Attribute):
            class_name = class_node.attr.value

            if class_name in self.pqc_classes:
                return class_name

        return None

    def get_arguments(self, node):

        positional = []
        keywords = []

        for arg in node.args:
            value = cst.Module([]).code_for_node(arg.value)

            if arg.keyword:
                keywords.append(
                    (arg.keyword.value, value)
                )
            else:
                positional.append(value)

        return positional, keywords

    def get_algorithm(self, class_name):

        for algorithm in PQC_ALGORITHMS:
            if class_name.startswith(algorithm):
                return algorithm

        return None

    def add_operation(
        self,
        algorithm,
        method,
        positional=None,
        keywords=None,
        receiver_type=None,
        class_method=False
    ):

        if algorithm not in PQC_ALGORITHMS:
            return

        self.algorithms.add(algorithm)

        operation = {
            "method": method,
            "positional": positional or [],
            "keywords": keywords or [],
            "receiver_type": receiver_type,
            "class_method": class_method,
        }

        operations = self.operations.setdefault(
            algorithm, []
        )

        if operation not in operations:
            operations.append(operation)

    def get_receiver_type(self, receiver):

        receiver_name = self.get_name(receiver)

        if receiver_name in self.pqc_variables:
            return self.pqc_variables[receiver_name]

        # Handle attributes such as self.keys.verify_pub
        if receiver_name and receiver_name.endswith(".verify_pub"):
            if self.algorithms:
                algorithm = next(iter(self.algorithms))
                return algorithm + "PublicKey"

        return None

    def visit_Assign(self, node):

        if not isinstance(node.value, cst.Call):
            return

        function = node.value.func

        if not isinstance(function, cst.Attribute):
            return

        class_name = self.get_class_info(function)

        if class_name:

            for target in node.targets:
                if isinstance(target.target, cst.Name):
                    self.pqc_variables[
                        target.target.value
                    ] = class_name

    def visit_Call(self, node):

        function = node.func

        if not isinstance(function, cst.Attribute):
            return

        method = function.attr.value

        if method not in METHOD_NAME_MAP:
            return

        positional, keywords = self.get_arguments(node)

        # Detect calls such as mlkem.MLKEM768PrivateKey.from_seed_bytes()
        class_name = self.get_class_info(function)

        if class_name:

            algorithm = self.get_algorithm(class_name)

            self.add_operation(
                algorithm,
                method,
                positional,
                keywords,
                receiver_type=class_name,
                class_method=True
            )

            return

        receiver_type = self.get_receiver_type(
            function.value
        )

        # Detect instance methods on known PQC objects
        if receiver_type:

            algorithm = self.get_algorithm(receiver_type)

            self.add_operation(
                algorithm,
                method,
                positional,
                keywords,
                receiver_type=receiver_type
            )

            return

        # Encapsulation is performed using the peer's public key.
        # The receiver may be passed into the function as an argument.
        if method == "encapsulate" and self.algorithms:

            algorithm = next(iter(self.algorithms))

            self.add_operation(
                algorithm,
                method,
                positional,
                keywords,
                receiver_type=algorithm + "PublicKey"
            )

        # Handle decapsulation when the private-key receiver
        # is supplied through a function argument.
        elif method == "decapsulate" and self.algorithms:

            algorithm = next(iter(self.algorithms))

            self.add_operation(
                algorithm,
                method,
                positional,
                keywords,
                receiver_type=algorithm + "PrivateKey"
            )


def generate_method(algorithm, operation):

    method = operation["method"]
    positional = operation["positional"]
    keywords = operation["keywords"]
    class_method = operation["class_method"]

    method_name = METHOD_NAME_MAP.get(method)

    if not method_name:
        return ""

    private_class = f"mlkem.{algorithm}PrivateKey"
    public_class = f"mlkem.{algorithm}PublicKey"

    if class_method:

        if method == "generate":
            parameters = []
            call = f"{private_class}.generate()"

        elif method in {"from_seed_bytes", "from_private_bytes"}:
            parameters = ["seed"]
            call = f"{private_class}.{method}(seed)"

        elif method == "from_public_bytes":
            parameters = ["key_data"]
            call = f"{public_class}.from_public_bytes(key_data)"

        else:
            return ""

    else:

        if method == "public_key":
            parameters = ["private_key"]
            call = "private_key.public_key()"

        elif method in {"private_bytes", "private_bytes_raw"}:

            parameters = ["private_key"]

            if method == "private_bytes":
                parameters.extend(
                    keyword for keyword, _ in keywords
                )

                arguments = [
                    f"{keyword}={keyword}"
                    for keyword, _ in keywords
                ]

                call = (
                    "private_key.private_bytes("
                    + ", ".join(arguments)
                    + ")"
                )
            else:
                call = "private_key.private_bytes_raw()"

        elif method in {"public_bytes", "public_bytes_raw"}:

            parameters = ["public_key"]

            if method == "public_bytes":
                parameters.extend(
                    keyword for keyword, _ in keywords
                )

                arguments = [
                    f"{keyword}={keyword}"
                    for keyword, _ in keywords
                ]

                call = (
                    "public_key.public_bytes("
                    + ", ".join(arguments)
                    + ")"
                )
            else:
                call = "public_key.public_bytes_raw()"

        elif method == "encapsulate":
            parameters = ["peer_public_key"]
            call = "peer_public_key.encapsulate()"

        elif method == "decapsulate":
            parameters = ["private_key", "ciphertext"]
            call = "private_key.decapsulate(ciphertext)"

        else:
            return ""

    return (
        "    @staticmethod\n"
        f"    def {method_name}({', '.join(parameters)}):\n"
        f"        return {call}\n\n"
    )


def generate_target_adapter(source_code):

    module = cst.parse_module(source_code)

    extractor = PQCCallExtractor()
    module.visit(extractor)

    if not extractor.operations:
        return ""

    generated_classes = []

    for algorithm, operations in extractor.operations.items():

        class_name = algorithm + "Adapter"

        code = (
            "from cryptography.hazmat.primitives.asymmetric "
            "import mlkem\n\n\n"
            f"class {class_name}:\n\n"
        )

        generated_methods = set()

        for operation in operations:

            method_name = METHOD_NAME_MAP.get(
                operation["method"]
            )

            if not method_name or method_name in generated_methods:
                continue

            method_code = generate_method(
                algorithm,
                operation
            )

            if method_code:
                code += method_code
                generated_methods.add(method_name)

        if generated_methods:
            generated_classes.append(code)

    return "\n".join(generated_classes)


def process_files(input_folder, output_folder):

    input_folder = Path(input_folder)
    output_folder = Path(output_folder)

    output_folder.mkdir(
        parents=True,
        exist_ok=True
    )

    for file_path in input_folder.glob("*.py"):

        print(f"Processing: {file_path.name}")

        try:
            source_code = file_path.read_text(
                encoding="utf-8"
            )

            target_code = generate_target_adapter(
                source_code
            )

            if not target_code:
                print("No PQC operations found")
                continue

            output_file = (
                output_folder /
                f"{file_path.stem}_target.py"
            )

            output_file.write_text(
                target_code,
                encoding="utf-8"
            )

            print(f"Created: {output_file}")

        except Exception as error:
            print(
                f"ERROR processing {file_path.name}: {error}"
            )


if __name__ == "__main__":

    process_files(
        "../kem_files/output",
        "./adapter/target"
    )
