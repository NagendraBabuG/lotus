
from __future__ import annotations

import os
import struct
from dataclasses import dataclass

from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey,
    X25519PublicKey,
)
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.asymmetric import mldsa

"""
Cryptographic primitives for end-to-end encrypted chat.

Primitives used:
  X25519          — Elliptic-curve Diffie-Hellman key agreement
  HKDF-SHA256     — Key derivation
  ChaCha20-Poly1305 — Authenticated encryption (AEAD)
  Ed25519         — Digital signatures for identity keys
"""


# ─────────────────────────────────────────────────────────────────────────────
# Key generation
# ─────────────────────────────────────────────────────────────────────────────

def generate_dh_keypair() -> tuple[X25519PrivateKey, X25519PublicKey]:
    """Generate an X25519 Diffie-Hellman key pair."""
    private = X25519PrivateKey.generate()
    public = private.public_key()
    return private, public


def generate_identity_keypair() -> tuple[Ed25519PrivateKey, Ed25519PublicKey]:
    """Generate an Ed25519 identity key pair (for signing)."""
    private = mldsa.MLDSA65PrivateKey.generate()
    public = private.public_key()
    return private, public


# ─────────────────────────────────────────────────────────────────────────────
# Key serialisation helpers
# ─────────────────────────────────────────────────────────────────────────────

def pub_to_bytes(key: X25519PublicKey) -> bytes:
    return key.public_bytes(
        serialization.Encoding.Raw,
        serialization.PublicFormat.Raw,
    )


def pub_from_bytes(raw: bytes) -> X25519PublicKey:
    return X25519PublicKey.from_public_bytes(raw)


def ed_pub_to_bytes(key: Ed25519PublicKey) -> bytes:
    return key.public_bytes(
        serialization.Encoding.Raw,
        serialization.PublicFormat.Raw,
    )


def ed_pub_from_bytes(raw: bytes) -> Ed25519PublicKey:
    return Ed25519PublicKey.from_public_bytes(raw)


# ─────────────────────────────────────────────────────────────────────────────
# Diffie-Hellman
# ─────────────────────────────────────────────────────────────────────────────

def dh(private: X25519PrivateKey, public: X25519PublicKey) -> bytes:
    """Perform X25519 DH and return the 32-byte shared secret."""
    return private.exchange(public)


# ─────────────────────────────────────────────────────────────────────────────
# HKDF
# ─────────────────────────────────────────────────────────────────────────────

def hkdf(
    input_key_material: bytes,
    length: int = 32,
    salt: bytes | None = None,
    info: bytes = b"",
) -> bytes:
    """Derive *length* bytes using HKDF-SHA256."""
    h = HKDF(
        algorithm=hashes.SHA256(),
        length=length,
        salt=salt,
        info=info,
    )
    return h.derive(input_key_material)


def hkdf_chain(chain_key: bytes) -> tuple[bytes, bytes]:
    """
    Derive a (new_chain_key, message_key) pair from *chain_key*.

    Uses two different `info` labels so the outputs are independent.
    """
    new_chain_key = hkdf(chain_key, info=b"chain-key")
    message_key = hkdf(chain_key, info=b"message-key")
    return new_chain_key, message_key


# ─────────────────────────────────────────────────────────────────────────────
# AEAD — ChaCha20-Poly1305
# ─────────────────────────────────────────────────────────────────────────────

NONCE_SIZE = 12  # bytes (96-bit nonce for ChaCha20-Poly1305)


def encrypt(key: bytes, plaintext: bytes, associated_data: bytes = b"") -> bytes:
    """
    Encrypt *plaintext* with ChaCha20-Poly1305.

    Returns  nonce (12 bytes) || ciphertext+tag.
    """
    if len(key) != 32:
        raise ValueError(f"Key must be 32 bytes, got {len(key)}")
    nonce = os.urandom(NONCE_SIZE)
    aead = ChaCha20Poly1305(key)
    ct = aead.encrypt(nonce, plaintext, associated_data or None)
    return nonce + ct


def decrypt(key: bytes, ciphertext: bytes, associated_data: bytes = b"") -> bytes:
    """
    Decrypt a message produced by :func:`encrypt`.

    Raises :class:`cryptography.exceptions.InvalidTag` on authentication failure.
    """
    if len(key) != 32:
        raise ValueError(f"Key must be 32 bytes, got {len(key)}")
    if len(ciphertext) < NONCE_SIZE:
        raise ValueError("Ciphertext too short")
    nonce = ciphertext[:NONCE_SIZE]
    ct = ciphertext[NONCE_SIZE:]
    aead = ChaCha20Poly1305(key)
    return aead.decrypt(nonce, ct, associated_data or None)


# ─────────────────────────────────────────────────────────────────────────────
# Ed25519 signatures
# ─────────────────────────────────────────────────────────────────────────────

def sign(private: Ed25519PrivateKey, message: bytes) -> bytes:
    """Sign *message* and return the 64-byte signature."""
    return private.sign(message)


def verify(public: Ed25519PublicKey, message: bytes, signature: bytes) -> bool:
    """
    Verify *signature* over *message*. Returns True on success, False on failure.
    """
    try:
        public.verify(signature ,message)
        return True
    except Exception:
        return False
