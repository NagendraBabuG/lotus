def greet():
    print("Hello!")

def main():
    greet()

main()
