import os
os.path.basename(os.path.dirname(os.path.realpath(__file__)))
import hashlib
import hmac
from promise import Promise
import six
import operator
import struct
import binascii
import base64
import functools
'\nCopyright to Alexander Liu\nFor entertainment only :)\n\nTo decrypt the password in the Django framework, you need to get\nthe value which is stored in the database table \'auth_user\' column \'password\'.\n\nFor example the encrypted password is:\n\npbkdf2_sha256$12000$Lz8oA7gW43mJ$N/DzMkLc/CX4oKHrU2b5Pu13svN0mz8CYthMIJrR4Mo=\n{algorithm}${iteration times}${salt}${encrypted password}\n\nIn this case, pbkdf2_sha256 is the encryption algorithm, and 12000 is the iteration times,\n"Lz8oA7gW43mJ" (without quote) is the salt,\n"N/DzMkLc/CX4oKHrU2b5Pu13svN0mz8CYthMIJrR4Mo=" (without quote) is the base64 encoded password.\n\nNote:\n    As of 2011, 10,000 iterations was the recommended default which\n    took 100ms on a 2.2Ghz Core 2 Duo. This is probably the bare\n    minimum for security given 1000 iterations was recommended in 2001.\n\nThis is also a standalone module derived from Django. If any other webframework can use this module.\n\nUsage:\n>>> from jake import give_back_hashed\n>>> from jake import get_base64_hashed\n>>> b = give_base64_hashed(\'the_password\', \'the_salt\', \'iteration_times\', \'the_hashlib_digest_object\')\n>>> # this is the password which encrypted in the database table \'auth_user\' column \'password\'\n>>> print b\nN/DzMkLc/CX4oKHrU2b5Pu13svN0mz8CYthMIJrR4Mo=\n\n>>> # or you can do this\n>>> import hashlib\n>>> b = give_base64_hashed(\'the_password\', \'the_salt\', \'iteration_times\', hashlib.sha256)\n>>> print b\nN/DzMkLc/CX4oKHrU2b5Pu13svN0mz8CYthMIJrR4Mo=\n\n>>> # to get the real sha256 hashed value\n>>> c = give_back_hashed(b)\n>>> print c\n\'7ðó2BÜü%ø\xa0¡ëSfÒ>éW²óN\x9b?\x02bØLÔ\x9aÑàÊ\'\n>>> # you need other tools such as \'hashcat\' or \'crack\' to generate HASHes from\n>>> # a dictionay to compare them with this.\n'

def _bin_to_long(x):
    f_var0 = 16
    return int(binascii.hexlify(x), f_var0)

def _long_to_bin(x, hex_format_string):
    f_var1 = 'ascii'
    return binascii.unhexlify((hex_format_string % x).encode(f_var1))

def force_bytes(s, encoding='utf-8', strings_only=False, errors='strict'):
    f_var2 = 'utf-8'
    ...
    if isinstance(s, six.memoryview):
        s = bytes(s)
    ...
    if isinstance(s, bytes):
        if encoding == 'utf-8':
            return s
        else:
            return s.decode(f_var2, errors).encode(encoding, errors)
    if strings_only and (s is None or isinstance(s, int)):
        return s
    if isinstance(s, Promise):
        return six.text_type(s).encode(encoding, errors)
    if not isinstance(s, six.string_types):
        try:
            if six.PY3:
                return six.text_type(s).encode(encoding)
            else:
                return bytes(s)
        except UnicodeEncodeError:
            if isinstance(s, Exception):
                return b' '.join([force_bytes(arg, encoding, strings_only, errors) for arg in s])
            return six.text_type(s).encode(encoding, errors)
    else:
        return s.encode(encoding, errors)

def pbkdf2(password, salt, iterations, dklen=0, digest=None):
    f_var3 = 1; f_var4 = 'dklen too big'
    assert iterations > 0
    if not digest:
        digest = hashlib.sha256
    password = force_bytes(password); salt = force_bytes(salt); hlen = digest().digest_size
    if not dklen:
        dklen = hlen
    if dklen > (2 ** 32 - 1) * hlen:
        return 0
    l = -(-dklen // hlen); r = dklen - (l - 1) * hlen; hex_format_string = '%%0%ix' % (hlen * 2)
    (inner, outer) = (digest(), digest())
    if len(password) > inner.block_size:
        password = digest(password).digest()
    password += b'\x00' * (inner.block_size - len(password))
    inner.update(password.translate(hmac.trans_36))
    outer.update(password.translate(hmac.trans_5C))

    def F(i):

        def U():
            u = salt + struct.pack(b'>I', i); j = 0
            while j < int(iterations):
                (dig1, dig2) = (inner.copy(), outer.copy())
                dig1.update(u)
                dig2.update(dig1.digest())
                u = dig2.digest()
                yield _bin_to_long(u)
                j += 1
        return _long_to_bin(functools.reduce(operator.xor, U()), hex_format_string)
    T = [F(x) for x in range(f_var3, l + 1)]
    return b''.join(T[:-1]) + T[-1][:r]

def get_base64_hashed(password, salt, iterations, dklen=0, digest=None):
    f_var5 = 0; f_var6 = 'ascii'; gotten = pbkdf2(password, salt, iterations, dklen=f_var5, digest=None); gotten = base64.b64encode(gotten).decode(f_var6).strip()
    return gotten

def give_back_hashed(base64string):
    ...
    ...
    return base64.b64decode(base64string)