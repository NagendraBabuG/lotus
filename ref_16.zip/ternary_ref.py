import ast
import random
import re

HEX_PATTERN = re.compile(r"0x[0-9A-Fa-f]+")

class TernaryRefactor(ast.NodeTransformer):
    def visit_If(self, node):
        self.generic_visit(node)

        if (len(node.body) == 1 and isinstance(node.body[0], ast.Expr) and
            len(node.orelse) == 1 and isinstance(node.orelse[0], ast.Expr)):

            return ast.Expr(
                value=ast.IfExp(
                    test=node.test,
                    body=node.body[0].value,
                    orelse=node.orelse[0].value
                )
            )
        elif (len(node.body) == 1 and isinstance(node.body[0], ast.Assign) and
              len(node.orelse) == 1 and isinstance(node.orelse[0], ast.Assign)):
            body_assign = node.body[0]
            else_assign = node.orelse[0]
            if len(body_assign.targets) == 1 and len(else_assign.targets) == 1:
                if ast.dump(body_assign.targets[0]) == ast.dump(else_assign.targets[0]):
                    return ast.Assign(
                        targets=body_assign.targets,
                        value=ast.IfExp(
                            test=node.test,
                            body=body_assign.value,
                            orelse=else_assign.value
                        )
                    )
        return node

    def visit_Assign(self, node):
        self.generic_visit(node)

        if isinstance(node.value, ast.IfExp):
            return ast.If(
                test=node.value.test,
                body=[ast.Assign(targets=node.targets, value=node.value.body)],
                orelse=[ast.Assign(targets=node.targets, value=node.value.orelse)]
            )
        return node

    def visit_Expr(self, node):
        self.generic_visit(node)

        if isinstance(node.value, ast.IfExp):
            return ast.If(
                test=node.value.test,
                body=[ast.Expr(value=node.value.body)],
                orelse=[self.visit_Expr(ast.Expr(value=node.value.orelse))]
            )
        return node

    def get_refactored_code(self, source_code):
        hex_literals = HEX_PATTERN.findall(source_code)
        try:
            tree = ast.parse(source_code)
            tree = self.visit(tree)
            ast.fix_missing_locations(tree)
            result = ast.unparse(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")

        for hx in hex_literals:
            dec = str(int(hx, 16))
            result = result.replace(dec, hx)

        return result
   