from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives.asymmetric import ed448


class Ed25519Adapter:

    def generate_private_key(self):
        return ed25519.Ed25519PrivateKey.generate()


class Ed448Adapter:

    def generate_private_key(self):
        return ed448.Ed448PrivateKey.generate()

    def sign(self, private_key, data):
        return private_key.sign(data)

    def get_public_key(self, private_key):
        return private_key.public_key()

    def verify(self, public_key, signature, data):
        return public_key.verify(signature, data)
