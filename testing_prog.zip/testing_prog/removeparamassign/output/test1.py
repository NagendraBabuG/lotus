def update(x):
    x_copy = x
    x_copy += 1
    return x_copy

def mutate_list(items):
    items_copy = items
    for i in range(len(items_copy)):
        items_copy[i] += 1