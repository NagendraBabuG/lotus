import builtins
import sys
import libcst as cst
from pathlib import Path


_EMPTY_MODULE = cst.Module([])

BUILTIN_NAMES = set(dir(builtins))
LITERAL_NAMES = {"None", "True", "False", "Ellipsis", "NotImplemented"}

PQC_ALGORITHMS = (
    "MLKEM1024",
    "MLKEM768",
    "MLKEM512",
)

PQC_ALGORITHM_SET = set(PQC_ALGORITHMS)

PQC_CLASSES = {
    f"{algorithm}{key_type}"
    for algorithm in PQC_ALGORITHMS
    for key_type in ("PrivateKey", "PublicKey")
}

METHOD_NAME_MAP = {
    "generate": "generate_private_key",
    "from_seed_bytes": "load_private_key",
    "from_private_bytes": "load_private_key",
    "from_public_bytes": "load_public_key",
    "public_key": "get_public_key",
    "private_bytes_raw": "serialize_private_key",
    "private_bytes": "serialize_private_key",
    "public_bytes_raw": "serialize_public_key",
    "public_bytes": "serialize_public_key",
    "encapsulate": "encapsulate",
    "decapsulate": "decapsulate",
}

SERIALIZATION_PARAM_ORDER = {
    "private_bytes": ("encoding", "format", "encryption_algorithm"),
    "public_bytes": ("encoding", "format"),
}

PRIVATE_KEY_OPERATIONS = {
    "generate",
    "from_seed_bytes",
    "from_private_bytes",
    "private_bytes",
    "private_bytes_raw",
    "decapsulate",
}


def _code_for(node):
    return _EMPTY_MODULE.code_for_node(node)


def _uses_bytes_fromhex(expr_str):
    try:
        tree = cst.parse_expression(expr_str)
    except Exception:
        return "bytes.fromhex" in expr_str

    found = False

    class FromHexFinder(cst.CSTVisitor):
        def visit_Call(self, node):
            nonlocal found
            func = node.func
            if (
                isinstance(func, cst.Attribute)
                and func.attr.value == "fromhex"
                and isinstance(func.value, cst.Name)
                and func.value.value == "bytes"
            ):
                found = True

    tree.visit(FromHexFinder())
    return found


def _collect_free_names(expr_str):
    """Return root identifier names referenced by an expression string."""
    try:
        tree = cst.parse_expression(expr_str)
    except Exception:
        return None

    names = set()

    class FreeNameCollector(cst.CSTVisitor):
        def visit_Arg(self, node):
            node.value.visit(self)
            return False

        def visit_Attribute(self, node):
            node.value.visit(self)
            return False

        def visit_Name(self, node):
            names.add(node.value)

    tree.visit(FreeNameCollector())
    return names


class PQCCallExtractor(cst.CSTVisitor):

    def __init__(self):
        self.pqc_class_aliases = {cls: cls for cls in PQC_CLASSES}
        self.pqc_module_aliases = {"mlkem"}
        self.pqc_variables = {}
        self.operations = {}
        self.algorithms_order = []
        self.last_algorithm = None
        self.unresolved_calls = []

        # (import_code, bound_names_set)
        self.imports = []
        self._seen_import_codes = set()
        self.imported_names = set()

    def _record_import(self, import_code, bound_names):
        if import_code not in self._seen_import_codes:
            self._seen_import_codes.add(import_code)
            self.imports.append((import_code, set(bound_names)))

    def _register_algorithm(self, algorithm):
        if algorithm not in PQC_ALGORITHM_SET:
            return
        if algorithm not in self.algorithms_order:
            self.algorithms_order.append(algorithm)
        self.last_algorithm = algorithm

    def visit_ImportFrom(self, node):
        if node.module is None:
            return

        module_name = _code_for(node.module)
        import_code = _code_for(node)

        if isinstance(node.names, cst.ImportStar):
            self._record_import(import_code, set())
            return

        bound_names = set()

        for imported in node.names:
            imported_name = imported.name.value
            alias = (
                imported.asname.name.value
                if imported.asname
                else imported_name
            )
            bound_names.add(alias)
            self.imported_names.add(alias)

            if imported_name in PQC_CLASSES:
                self.pqc_class_aliases[alias] = imported_name

            if (
                module_name.startswith("cryptography")
                and imported_name == "mlkem"
            ):
                self.pqc_module_aliases.add(alias)

        self._record_import(import_code, bound_names)

    def visit_Import(self, node):
        import_code = _code_for(node)
        bound_names = set()

        for imported in node.names:
            module_name = _code_for(imported.name)
            alias = (
                imported.asname.name.value
                if imported.asname
                else module_name.split(".")[0]
            )
            bound_names.add(alias)
            self.imported_names.add(alias)

            if (
                module_name.startswith("cryptography")
                and module_name.split(".")[-1] == "mlkem"
            ):
                self.pqc_module_aliases.add(alias)

        self._record_import(import_code, bound_names)

    def get_name(self, node):
        try:
            return cst.helpers.get_full_name_for_node(node)
        except Exception:
            return None

    def get_class_info(self, function):
        if not isinstance(function, cst.Attribute):
            return None

        class_node = function.value

        if isinstance(class_node, cst.Name):
            return self.pqc_class_aliases.get(class_node.value)

        if isinstance(class_node, cst.Attribute):
            class_name = class_node.attr.value
            if class_name in PQC_CLASSES:
                if (
                    isinstance(class_node.value, cst.Name)
                    and class_node.value.value in self.pqc_module_aliases
                ):
                    return class_name
                # Also accept deeper qualified paths ending in mlkem.MLKEM*
                full_mod = self.get_name(class_node.value)
                if full_mod and full_mod.split(".")[-1] in self.pqc_module_aliases:
                    return class_name
                return class_name

        return None

    def get_arguments(self, node):
        positional = []
        keywords = []

        for arg in node.args:
            value = _code_for(arg.value)

            if arg.keyword:
                keywords.append((arg.keyword.value, value))
            else:
                positional.append(value)

        return positional, keywords

    def get_algorithm(self, class_name):
        if not class_name:
            return None

        for algorithm in PQC_ALGORITHMS:
            if class_name.startswith(algorithm):
                return algorithm

        return None

    def add_operation(
        self,
        algorithm,
        method,
        positional=None,
        keywords=None,
        receiver_type=None,
        class_method=False,
    ):
        if algorithm not in PQC_ALGORITHM_SET:
            return

        self._register_algorithm(algorithm)

        operation = {
            "method": method,
            "positional": positional or [],
            "keywords": keywords or [],
            "receiver_type": receiver_type,
            "class_method": class_method,
        }

        operations = self.operations.setdefault(algorithm, [])

        if operation not in operations:
            operations.append(operation)

    def _infer_call_result_type(self, call_node):
        """Infer PQC key type returned by a cst.Call expression."""
        function = call_node.func

        if not isinstance(function, cst.Attribute):
            return None

        class_name = self.get_class_info(function)
        if class_name:
            return class_name

        method = function.attr.value
        if method == "public_key":
            receiver_type = self.get_receiver_type(function.value)
            if receiver_type and receiver_type.endswith("PrivateKey"):
                return receiver_type.replace("PrivateKey", "PublicKey")

        return None

    def get_receiver_type(self, receiver):
        if isinstance(receiver, cst.Call):
            return self._infer_call_result_type(receiver)

        receiver_name = self.get_name(receiver)
        if receiver_name in self.pqc_variables:
            return self.pqc_variables[receiver_name]

        return None

    def _update_variable_binding(self, target_node, value_node, annotation_node=None):
        target_name = self.get_name(target_node)
        if not target_name:
            return

        inferred_type = None

        if isinstance(value_node, cst.Call):
            inferred_type = self._infer_call_result_type(value_node)
        elif value_node is not None:
            src_name = self.get_name(value_node)
            if src_name in self.pqc_variables:
                inferred_type = self.pqc_variables[src_name]

        # Fallback to explicit type annotation (e.g., priv: MLKEM768PrivateKey = ...)
        if inferred_type is None and annotation_node is not None:
            ann_expr = annotation_node.annotation
            ann_name = None
            if isinstance(ann_expr, cst.Name):
                ann_name = ann_expr.value
            elif isinstance(ann_expr, cst.Attribute):
                ann_name = ann_expr.attr.value

            if ann_name in self.pqc_class_aliases:
                inferred_type = self.pqc_class_aliases[ann_name]

        if inferred_type:
            self.pqc_variables[target_name] = inferred_type
            alg = self.get_algorithm(inferred_type)
            if alg:
                self._register_algorithm(alg)
        else:
            # Clear stale type if reassigned to bytes / non-key value
            self.pqc_variables.pop(target_name, None)

    def leave_Assign(self, original_node):
        for target in original_node.targets:
            self._update_variable_binding(target.target, original_node.value)

    def leave_AnnAssign(self, original_node):
        self._update_variable_binding(
            original_node.target,
            original_node.value,
            annotation_node=original_node.annotation,
        )

    def visit_Call(self, node):
        function = node.func

        if not isinstance(function, cst.Attribute):
            return

        method = function.attr.value

        if method not in METHOD_NAME_MAP:
            return

        positional, keywords = self.get_arguments(node)

        class_name = self.get_class_info(function)

        if class_name:
            algorithm = self.get_algorithm(class_name)
            self.add_operation(
                algorithm,
                method,
                positional,
                keywords,
                receiver_type=class_name,
                class_method=True,
            )
            return

        receiver_type = self.get_receiver_type(function.value)

        if receiver_type:
            algorithm = self.get_algorithm(receiver_type)
            self.add_operation(
                algorithm,
                method,
                positional,
                keywords,
                receiver_type=receiver_type,
            )
            return

        # Untracked receiver fallback for uniquely KEM operations
        if method in {"encapsulate", "decapsulate"}:
            if self.last_algorithm:
                algorithm = self.last_algorithm
                suffix = "PublicKey" if method == "encapsulate" else "PrivateKey"
                self.add_operation(
                    algorithm,
                    method,
                    positional,
                    keywords,
                    receiver_type=algorithm + suffix,
                )
            else:
                # Defer until end of module (e.g., helper defined above main)
                self.unresolved_calls.append((method, positional, keywords))

    def leave_Module(self, original_node):
        if not self.unresolved_calls or not self.algorithms_order:
            return

        fallback_algorithm = self.algorithms_order[0]
        for method, positional, keywords in self.unresolved_calls:
            suffix = "PublicKey" if method == "encapsulate" else "PrivateKey"
            self.add_operation(
                fallback_algorithm,
                method,
                positional,
                keywords,
                receiver_type=fallback_algorithm + suffix,
            )


def _build_serialization_args(method, positional, keywords, imported_names):
    """
    Build parameter declarations and call arguments for private_bytes / public_bytes.
    Supports both positional and keyword calls in the source file.
    """
    canonical_order = SERIALIZATION_PARAM_ORDER[method]
    bound = []
    seen = set()

    # Map positional args onto canonical cryptography parameter names
    for idx, val in enumerate(positional):
        if idx < len(canonical_order):
            name = canonical_order[idx]
        else:
            name = f"arg{idx}"
        bound.append((name, val))
        seen.add(name)

    for key, val in keywords:
        if key not in seen:
            bound.append((key, val))
            seen.add(key)

    if not bound:
        # Fallback to canonical parameter names if called via *args/**kwargs
        params = list(canonical_order)
        call_args = [f"{name}={name}" for name in canonical_order]
        return params, call_args, set()

    # Use source expressions as default values only if all of them are self-contained
    # (no unresolved local variables that would raise NameError at import time).
    allowed_names = set(imported_names) | BUILTIN_NAMES | LITERAL_NAMES
    referenced_imports = set()
    all_self_contained = True

    for _, expr in bound:
        free = _collect_free_names(expr)
        if free is None or not free.issubset(allowed_names):
            all_self_contained = False
            break
        referenced_imports.update(free & set(imported_names))

    if all_self_contained:
        params = [f"{name}={expr}" for name, expr in bound]
        call_args = [f"{name}={name}" for name, _ in bound]
        return params, call_args, referenced_imports

    params = [name for name, _ in bound]
    call_args = [f"{name}={name}" for name, _ in bound]
    return params, call_args, set()


def generate_method(algorithm, operation, imported_names):

    method = operation["method"]
    positional = operation["positional"]
    keywords = operation["keywords"]
    class_method = operation["class_method"]

    method_name = METHOD_NAME_MAP.get(method)

    if not method_name:
        return "", set()

    private_class = f"mlkem.{algorithm}PrivateKey"
    public_class = f"mlkem.{algorithm}PublicKey"
    used_imports = set()

    if class_method:

        if method == "generate":
            parameters = []
            call = f"{private_class}.generate()"

        elif method in {"from_seed_bytes", "from_private_bytes"}:
            parameters = ["seed"]
            all_args = positional + [v for _, v in keywords]
            if any(_uses_bytes_fromhex(a) for a in all_args):
                arg_expr = "(seed if isinstance(seed, bytes) else bytes.fromhex(seed))"
            else:
                arg_expr = "seed"
            call = f"{private_class}.{method}({arg_expr})"

        elif method == "from_public_bytes":
            parameters = ["key_data"]
            all_args = positional + [v for _, v in keywords]
            if any(_uses_bytes_fromhex(a) for a in all_args):
                arg_expr = (
                    "(key_data if isinstance(key_data, bytes) "
                    "else bytes.fromhex(key_data))"
                )
            else:
                arg_expr = "key_data"
            call = f"{public_class}.from_public_bytes({arg_expr})"

        else:
            return "", set()

    else:

        if method == "public_key":
            parameters = ["private_key"]
            call = "private_key.public_key()"

        elif method in {"private_bytes", "private_bytes_raw"}:
            parameters = ["private_key"]

            if method == "private_bytes":
                extra_params, call_args, extra_imports = _build_serialization_args(
                    method,
                    positional,
                    keywords,
                    imported_names,
                )
                parameters.extend(extra_params)
                used_imports.update(extra_imports)
                call = "private_key.private_bytes(" + ", ".join(call_args) + ")"
            else:
                call = "private_key.private_bytes_raw()"

        elif method in {"public_bytes", "public_bytes_raw"}:
            parameters = ["public_key"]

            if method == "public_bytes":
                extra_params, call_args, extra_imports = _build_serialization_args(
                    method,
                    positional,
                    keywords,
                    imported_names,
                )
                parameters.extend(extra_params)
                used_imports.update(extra_imports)
                call = "public_key.public_bytes(" + ", ".join(call_args) + ")"
            else:
                call = "public_key.public_bytes_raw()"

        elif method == "encapsulate":
            parameters = ["peer_public_key"]
            call = "peer_public_key.encapsulate()"

        elif method == "decapsulate":
            parameters = ["private_key", "ciphertext"]
            call = "private_key.decapsulate(ciphertext)"

        else:
            return "", set()

    method_parameters = ["self"] + parameters

    method_code = (
        f"    def {method_name}({', '.join(method_parameters)}):\n"
        f"        return {call}\n\n"
    )
    return method_code, used_imports


def generate_target_adapter(source_code):

    module = cst.parse_module(source_code)

    extractor = PQCCallExtractor()
    module.visit(extractor)

    if not extractor.operations:
        return ""

    generated_classes = []
    extra_referenced_names = set()

    for algorithm in extractor.algorithms_order:
        operations = extractor.operations.get(algorithm)
        if not operations:
            continue

        class_name = f"{algorithm}Adapter"
        class_code = f"class {class_name}:\n\n"

        generated_methods = set()

        for operation in operations:
            method_name = METHOD_NAME_MAP.get(operation["method"])

            if not method_name or method_name in generated_methods:
                continue

            method_code, method_imports = generate_method(
                algorithm,
                operation,
                extractor.imported_names,
            )

            if method_code:
                class_code += method_code
                generated_methods.add(method_name)
                extra_referenced_names.update(method_imports)

        # Generate get_public_key whenever a PQC private-key
        # operation is detected, even if the source does not
        # explicitly call public_key().
        has_private_key_operation = any(
            operation["method"] in PRIVATE_KEY_OPERATIONS
            or (
                operation["receiver_type"]
                and operation["receiver_type"].endswith("PrivateKey")
            )
            for operation in operations
        )

        if (
            has_private_key_operation
            and "get_public_key" not in generated_methods
        ):
            class_code += (
                "    def get_public_key(self, private_key):\n"
                "        return private_key.public_key()\n\n"
            )

        if generated_methods or has_private_key_operation:
            generated_classes.append(class_code)

    if not generated_classes:
        return ""

    # Emit required imports once at the top of the file
    header_imports = []
    for import_code, bound_names in extractor.imports:
        if bound_names & extra_referenced_names:
            if import_code not in header_imports:
                header_imports.append(import_code)

    mlkem_import = "from cryptography.hazmat.primitives.asymmetric import mlkem"
    if mlkem_import not in header_imports:
        header_imports.append(mlkem_import)

    return "\n".join(header_imports) + "\n\n\n" + "\n".join(generated_classes)


def process_files(input_folder, output_folder):

    input_folder = Path(input_folder)
    output_folder = Path(output_folder)

    output_folder.mkdir(
        parents=True,
        exist_ok=True,
    )

    for file_path in sorted(input_folder.glob("*.py")):

        print(f"Processing: {file_path.name}")

        try:
            source_code = file_path.read_text(encoding="utf-8")

            target_code = generate_target_adapter(source_code)

            if not target_code:
                print("No PQC operations found")
                continue

            output_file = output_folder / f"{file_path.stem}.py"

            output_file.write_text(target_code, encoding="utf-8")

            print(f"Created: {output_file}")

        except Exception as error:
            print(f"ERROR processing {file_path.name}: {error}")


if __name__ == "__main__":
    in_dir = sys.argv[1] if len(sys.argv) > 1 else "../kem_files/output"
    out_dir = sys.argv[2] if len(sys.argv) > 2 else "./adapter/target"
    process_files(in_dir, out_dir)