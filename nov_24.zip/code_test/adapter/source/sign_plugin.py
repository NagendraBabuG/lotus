from cryptography.hazmat.primitives import serialization


class Ed25519Adapter:

    def load_private_key_pem(self, data):
        return serialization.load_pem_private_key(data, password=None)

    def sign(self, private_key, data):
        return private_key.sign(data)

    def serialize_public_key(self, public_key):
        return public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )

    def get_public_key(self, private_key):
        return private_key.public_key()
