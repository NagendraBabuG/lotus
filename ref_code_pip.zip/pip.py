import os

from addconstasparam import AddDefaultArgValue
from addexception import AddTryExceptRefactor
from errorcode import ExceptionRefactor
from funcommonparams import CommonParamters
from funcvaridentifier import FuncVarNameRefactator
from hardcode import HardcodedValues
from looprefact import ForWhileRefact
from mapfilter import MapFilterRefactor
from newlambda import LambdaRefactor
from optimizeassertions import AddAssertions
from partials import PartialsRefactor
from remunusedparam import RemoveUnusedParameter
from remvarassign import ParameterRefactor
from shufflefuncs import ShuffleFunctions
from ternary import TernaryRefactor
from tryexcept import ErrorHandlerRefactor


path = "./ref_input/"


add_const_as_param = AddDefaultArgValue()
add_exception = AddTryExceptRefactor()
error_code = ExceptionRefactor()
func_common_params = CommonParamters()
func_var_rename = FuncVarNameRefactator()
hard_code = HardcodedValues()
loop_refact = ForWhileRefact()
map_filter = MapFilterRefactor()
lambda_refact = LambdaRefactor()
assertions = AddAssertions()
partials_refact = PartialsRefactor()
rem_unused_param = RemoveUnusedParameter()
rem_var_assign = ParameterRefactor()
shuffle_funcs = ShuffleFunctions()
ternary = TernaryRefactor()
tryexcept = ErrorHandlerRefactor()


def process_files(dir_path):
    os.makedirs(f"{path}", exist_ok=True)
    for filename in os.listdir(dir_path):
        if filename.endswith(".py"):
            file_path = os.path.join(dir_path, filename)
            with open(file_path, "r", encoding="utf-8") as f:
                source_code = f.read()


            refactored_code = add_assert.get_refactored_code(source_code)
            #refactored_code = shuffle_funcs.get_refactored_code(source_code)
            #refactored_code = ifelse_ternary.get_refactored_code(source_code)
            #refactored_code = partials.get_refactored_code(source_code)
            
            res_file_path = os.path.join(f"{path}", filename)
            with open(res_file_path, "w", encoding="utf-8") as f:
                f.write(refactored_code)

if __name__ == "__main__":
    process_files(f"./testing_prog/{path}/")
