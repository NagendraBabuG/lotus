#extend for classes also
#converts single line funcs to lambda and also added conditon for not refactoring decorator methods
import ast

class LambdaRefactor(ast.NodeTransformer):
    
    @staticmethod
    def has_decorators(func_def: ast.FunctionDef) -> bool:
        return bool(func_def.decorator_list)

    def _refactor_function(self, func_def: ast.FunctionDef, target_name: str):
        if len(func_def.body) != 1:
            return None
        
        ret_stmt = func_def.body[0]
        if not isinstance(ret_stmt, ast.Return) or ret_stmt.value is None:
            return None
        
        if self.has_decorators(func_def):
            return None 

        lambda_assign = ast.Assign(
            targets=[ast.Name(id=target_name, ctx=ast.Store())],
            value=ast.Lambda(
                args=func_def.args,
                body=ret_stmt.value
            )
        )
        return lambda_assign

    def visit_Module(self, node: ast.Module):
        new_body = []
        for stmt in node.body:
            if isinstance(stmt, ast.FunctionDef):
                refactored = self._refactor_function(stmt, stmt.name)
                if refactored:
                    new_body.append(refactored)
                    continue
            
            new_body.append(self.visit(stmt))
        node.body = new_body
        return node

    def visit_ClassDef(self, node: ast.ClassDef):
        new_body = []
        for stmt in node.body:
            if isinstance(stmt, ast.FunctionDef):
                refactored = self._refactor_function(stmt, stmt.name)
                if refactored:
                    new_body.append(refactored)
                    continue
            new_body.append(self.visit(stmt))
        node.body = new_body
        return node

    def visit_FunctionDef(self, node: ast.FunctionDef):
        node.body = [self.visit(stmt) for stmt in node.body]
        return node 

    def get_refactored_code(self, source_code: str) -> str:
        try:
            tree = ast.parse(source_code)
            tree = self.visit(tree)
            ast.fix_missing_locations(tree)
            return ast.unparse(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")

l_refact = LambdaRefactor()
code = """ 
class Calculator:
    def add(a, b):
        return a + b

    def mul(a, b):
        return a * b

    @staticmethod
    def static_method(x):
        return x * 2

    def ignored(self, x):
        print("hello")
        return x*2

def global_func(x):
    return x + 1
"""

tar = l_refact.get_refactored_code(code)

print(tar)