def handled():
    try:
        x = 1 / 0
    except:
        print('Handled')

def validate(x):
    try:
        if x < 0:
            raise ValueError('x must be non-negative')
    except Exception as error:
        print(f'Operation Failed: {error}')