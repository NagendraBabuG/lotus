import ast


class CryptoVarExtractor(ast.NodeTransformer):
    def __init__(self):
        self.next_var_id = 0
        self.pending_assigns: list[ast.stmt] = []

    def _new_var(self) -> str:
        name = f"cond_{self.next_var_id}"
        self.next_var_id += 1
        return name

    def _extract_expr(self, node: ast.expr) -> ast.Name:
        var_name = self._new_var()

        assign = ast.Assign(
            targets=[ast.Name(id=var_name, ctx=ast.Store())],
            value=node,
        )
        ast.fix_missing_locations(assign)
        self.pending_assigns.append(assign)

        return ast.Name(id=var_name, ctx=ast.Load())

    def visit_Compare(self, node: ast.Compare):
        self.generic_visit(node)
        return self._extract_expr(node)

    def visit_BoolOp(self, node: ast.BoolOp):
        self.generic_visit(node)
        return self._extract_expr(node)

    def visit_Assert(self, node: ast.Assert):
        self.generic_visit(node)
        if isinstance(node.test, (ast.Compare, ast.BoolOp)):
            test_var = self._extract_expr(node.test)
            return [
                *self.pending_assigns,
                ast.Assert(test=test_var, msg=node.msg)
            ]
        return node

    def _visit_body(self, body: list[ast.stmt]) -> list[ast.stmt]:
        new_body = []
        for stmt in body:
            result = self.visit(stmt)
            if isinstance(result, list):
                new_body.extend(result)
            else:
                new_body.append(result)
        return new_body

    def _inject_pending(self, stmt: ast.stmt) -> list[ast.stmt] | ast.stmt:
        stmt = self.generic_visit(stmt)

        if self.pending_assigns:
            nodes = self.pending_assigns + [stmt]
            self.pending_assigns = []
            return nodes
        return stmt

    def visit_Assign(self, node):
        return self._inject_pending(node)

    def visit_Expr(self, node):
        return self._inject_pending(node)

    def visit_Assert(self, node):
        return self._inject_pending(node)  

    def visit_If(self, node: ast.If):
        node.test = self.visit(node.test)
        assigns = self.pending_assigns
        self.pending_assigns = []

        node.body = self._visit_body(node.body)
        node.orelse = self._visit_body(node.orelse)

        if assigns:
            return assigns + [node]
        return node

    def visit_While(self, node: ast.While):
        node.test = self.visit(node.test)
        assigns = self.pending_assigns
        self.pending_assigns = []

        node.body = self._visit_body(node.body)
        node.orelse = self._visit_body(node.orelse)

        if assigns:
            recompute = [
                ast.Assign(targets=a.targets, value=a.value)
                for a in assigns
            ]
            node.body = recompute + node.body
            return assigns + [node]
        return node

    def visit_For(self, node: ast.For):
        node.target = self.visit(node.target)
        node.iter = self.visit(node.iter)

        assigns = self.pending_assigns
        self.pending_assigns = []

        node.body = self._visit_body(node.body)
        node.orelse = self._visit_body(node.orelse)

        if assigns:
            return assigns + [node]
        return node

    def visit_Try(self, node: ast.Try):
        node.body = self._visit_body(node.body)
        node.orelse = self._visit_body(node.orelse)
        node.finalbody = self._visit_body(node.finalbody)

        node.handlers = [self.visit(h) for h in node.handlers]

        if self.pending_assigns:
            return self.pending_assigns + [node]
        return node

    def visit_ExceptHandler(self, node):
        self.generic_visit(node)
        return node

    def visit_FunctionDef(self, node: ast.FunctionDef):
        node.body = self._visit_body(node.body)
        return node

    def visit_IfExp(self, node):  # ternary
        self.generic_visit(node)
        return self._extract_expr(node)

    def get_refactored_code(self, source_code: str) -> str:
        tree = ast.parse(source_code)
        self.next_var_id = 0
        self.pending_assigns = []

        new_tree = self.visit(tree)
        ast.fix_missing_locations(new_tree)

        return ast.unparse(new_tree)