def access_dict():
    d = {}
    return d['missing']
