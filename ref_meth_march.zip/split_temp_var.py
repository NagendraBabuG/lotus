import ast
import copy

class SplitTempVar:

    def test_condition_checker(self, node2, replace_name):
        if isinstance(node2.test, ast.Compare):
            for elem in node2.test.comparators:
                if elem.id in replace_name:
                   elem.id = replace_name[elem.id]
        elif isinstance(node2.test, ast.Name):
            if node2.test.id in replace_name:
                node2.test.id = replace_name[node2.test.id]
        elif isinstance(node2.test, ast.Call):
            for elem in node2.test.args:
                if elem.id in replace_name:
                    elem.id = replace_name[elem.id]
        return node2, replace_name


    def replace_id(self, node, idx, replace_name, target_list):
        for node2 in ast.walk(node):
            if isinstance(node2, ast.Name) and (node2.id in replace_name) and not isinstance(node2.ctx, ast.Store):
                node2.id = replace_name[node2.id]
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if target.id in target_list:
                    new_name = target.id + f'{idx}'
                    replace_name[target.id] = new_name 
                    idx += 1 
                    target.id = new_name
                if target.id not in target_list:
                    target_list.append(target.id)
        return node, idx, replace_name, target_list

    def replace_id2(self, if_node, if_idx, replace_name_if, if_target, target_list):
        for inner_node in ast.walk(if_node):
            if isinstance(inner_node, ast.Name) and (inner_node.id in replace_name_if) and not isinstance(inner_node.ctx, ast.Store):
                inner_node.id = replace_name_if[inner_node.id]
        flag = 0 
        if isinstance(if_node, ast.Assign):
            for target in if_node.targets:
                if target.id in target_list:
                    new_name = target.id + f'{if_idx}'
                    replace_name_if[target.id] = new_name
                    target.id = new_name
                    if target.id not in if_target:
                        if_target.append(target.id)
                    if_idx += 1 
                    flag = 1 
                if target.id not in target_list:
                    target_list.append(target.id)
        return if_node, if_idx, replace_name_if, if_target, target_list, flag



    def while_idx_loop(self, node2, idx, replace_name, target_list):
        node2, replace_name = self.test_condition_checker(node2, replace_name)

        for while_node in node2.body:
            if isinstance(while_node, ast.While):
                while_node, idx, replace_name, target_list = self.while_idx_loop(
                    while_node, idx, replace_name, target_list
                )
            elif isinstance(while_node, ast.If):
                while_node, idx, replace_name, target_list = self.if_idx_loop(
                    while_node, idx, replace_name, target_list
                )
            else:
                while_node, idx, replace_name, target_list = self.replace_id(
                    while_node, idx, replace_name, target_list
                )

        return node2, idx, replace_name, target_list


    def if_idx_loop(self, node2, idx, replace_name, target_list):
        node2, replace_name = self.test_condition_checker(node2, replace_name)

        if_idx = idx  
        replace_name_if = copy.deepcopy(replace_name)

        if_target = [] 
        for if_node in node2.body:
            if isinstance(if_node, ast.While):
                if_node, if_idx, replace_name_if, if_target = self.while_idx_loop(
                    if_node, if_idx, replace_name_if, target_list
                )
            if_node, if_idx, replace_name_if, if_target, target_list, flag = self.replace_id2(
                if_node, if_idx, replace_name_if, if_target, target_list
            )

        else_idx = idx  
        replace_name_else = copy.deepcopy(replace_name)

        else_target = [] 
        for index, else_node in enumerate(node2.orelse):
            if isinstance(else_node, ast.If):
                else_node, else_idx, replace_name_else, else_target = self.if_idx_loop(
                    else_node, else_idx, replace_name_else, target_list
                )
            elif isinstance(else_node, ast.While):
                else_node, else_idx, replace_name_else, else_target = self.while_idx_loop(
                    else_node, else_idx, replace_name_else, target_list
                )
            else:
                else_node, else_idx, replace_name_else, else_target, target_list, flag = self.replace_id2(
                    else_node,
                    else_idx,
                    replace_name_else,
                    else_target,
                    target_list,
                )

        if if_target and else_target:
            if if_target != else_target:
                node2.body.append(
                    ast.Assign(
                        targets=[
                            ast.Name(id="duplicate_id", ctx=ast.Store())
                        ],
                        value=ast.Name(id=if_target[-1], ctx=ast.Load()),
                    )
                )

                node2.orelse.append(
                    ast.Assign(
                        targets=[
                            ast.Name(id="duplicate_id", ctx=ast.Store())
                        ],
                        value=ast.Name(id=else_target[-1], ctx=ast.Load()),
                    )
                )

                ast.fix_missing_locations(node2)

        
        if len(if_target) > len(else_target):
            replace_name = replace_name_if
            idx = if_idx
            target_list = if_target
        else:
            replace_name = replace_name_else
            idx = else_idx
            target_list = else_target

        replace_name[target_list[-1]] = 'duplicate_id'

        temp = {}
        for k, v in replace_name.items():
            if v in replace_name:
                temp[k] = replace_name[v]
        return node2, idx, temp, target_list



    def get_refactored_code(self, code):
        try:
            tree = ast.parse(code)
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    idx = 0
                    target_list = []
                    replace_name = {}
                    for node2 in node.body:
                        if isinstance(node2, ast.If):
                            node2, idx, replace_name, target_list = self.if_idx_loop(node2, idx, replace_name, target_list)
                            continue 
                        elif isinstance(node2, ast.While):
                            node2, idx, replace_name, target_list = self.while_idx_loop(node2, idx, replace_name, target_list)
                            continue

                        else:
                            node2, idx, replace_name, target_list = self.replace_id(node2, idx, replace_name, target_list)
            return ast.unparse(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")
