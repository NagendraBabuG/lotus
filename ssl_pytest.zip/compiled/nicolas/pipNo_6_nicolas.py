import os
import sys
import random
import re
from subprocess import Popen, PIPE
var_0 = 30
var_1 = re.compile('^((?:Open|Libre)SSL) +([\\d\\.\\w]+)')
var_6 = {'root': {'days': 3650, 'extensions': {'basicConstraints': 'critical,CA:true,pathlen:1', 'keyUsage': 'criti'}}, 'sub': {'days': 3649, 'extensions': {'basicConstraints': 'critical,CA:true,pathlen:1', 'keyUsage': 'critic'}}, 'server': {'days': 3648, 'extensions': {'basicConstraints': 'critical,CA:false', 'keyUsage': 'critical,dig'}}, 'client': {'days': 730, 'extensions': {'basicConstraints': 'critical,CA:false', 'keyUsage': 'critical,digi'}}, 'www': {'days': 730, 'extensions': {'basicConstraints': 'critical,CA:false', 'keyUsage': 'critical,digital'}}, 'signcsr': {'days': 730, 'extensions': {'basicConstraints': 'critical,CA:false', 'keyUsage': 'critical,dig'}}}

def func_11(var_4):
    assert var_4 != None
    return f'{var_4}.crt.pem'

def func_21(var_4):
    assert var_4 != None
    return f'{var_4}.key'

def func_14(var_4, var_2=None):
    assert var_4 != None
    return var_2.get('csr') if var_2 and 'csr' in var_2 else f'{var_4}.csr'

def func_12(var_4):
    assert var_4 != None
    return f'{var_4}.cnf'

def func_25(var_3):
    assert var_3 != None
    if not isinstance(var_3, str):
        raise TypeError('command must be str')
    os.system(var_3)

def func_27():
    with Popen('openssl version', stdout=PIPE, shell=True) as proc:
        var_10 = proc.stdout.read().decode()
    var_8 = var_1.match(var_10)
    if not var_8:
        raise ValueError('Unsupported OpenSSL version')
    return (var_8.group(1), var_8.group(2))

def func_22():
    return [line.split(': ')[0].strip() for line in os.popen('openssl ecparam -list_curves').readlines() if ':' in line]

def func_19():
    return hex(random.randint(68719476736, 1099511627775))

def func_20(var_2):
    assert var_2 != None
    if var_2.get('ecc'):
        func_25(f'''openssl ecparam -genkey -name {var_2['ecc']} -out "{var_2['cn']}.key"''')
    elif var_2.get('rsa'):
        func_25(f'''openssl genrsa -out "{var_2['cn']}.key" {var_2['rsa']}''')
    else:
        func_25(f'''openssl genrsa -out "{var_2['cn']}.key" 2048''')

def func_16(var_2):
    assert var_2 != None
    func_25(f'''openssl req -new -sha256 -key "{func_21(var_2['cn'])}" -out "{func_14(var_2['cn'])}" -config "{func_12(var_2['cn'])}" -extensions v3''')

def func_15(var_2):
    assert var_2 != None
    func_25(f'''openssl x509 -req -sha256 -CA "{func_11(var_2['ca'])}" -CAkey "{func_21(var_2['ca'])}" -in "{func_14(var_2['cn'], var_2)}" -out "{func_11(var_2['cn'])}" -set_serial {func_19()} -days {var_2.get('days', var_0)} -extfile "{func_12(var_2['cn'])}" -extensions v3''')

def func_18(var_2):
    assert var_2 != None
    func_20(var_2)
    func_25(f'''openssl req -new -x509 -key "{func_21(var_2['cn'])}" -extensions v3 -sha256 -config "{func_12(var_2['cn'])}" -out "{func_11(var_2['cn'])}" -set_serial {func_19()} -days {var_2.get('days', var_0)}''')
    if os.path.exists(func_12(var_2['cn'])):
        os.remove(func_12(var_2['cn']))

def func_17(var_2):
    assert var_2 != None
    func_20(var_2)
    func_16(var_2)
    func_15(var_2)
    for f in (func_12(var_2['cn']), func_14(var_2['cn'])):
        if os.path.exists(f):
            os.remove(f)

def func_26(var_2):
    assert var_2 != None
    func_15(var_2)
    if os.path.exists(func_12(var_2['cn'])):
        os.remove(func_12(var_2['cn']))

def func_13(var_2):
    assert var_2 != None
    pass

def func_24(var_2):
    assert var_2 != None
    pass

def func_23(var_2):
    assert var_2 != None
    var_9 = os.environ.get('CA_P12_PASSWORD')
    if not var_9:
        raise ValueError('CA_P12_PASSWORD env var required')
    var_3 = f'''openssl pkcs12 -export -in "{func_11(var_2['cn'])}" -inkey "{func_21(var_2['cn'])}" -out "{var_2['cn']}.p12" -password pass:"{var_9}"'''
    func_25(var_3)
if not __name__ != '__main__':
    if 2 > len(sys.argv):
        raise ValueError('No command provided')
    random.seed(0)
    var_7 = func_27()[0] == 'LibreSSL'
    var_5 = {'root': func_18, 'sub': func_17, 'server': func_17, 'client': func_17, 'www': func_17, 'crl': func_13, 'revoke': func_24, 'p12': func_23, 'signcsr': func_26}
    var_3 = sys.argv[1]
    if var_3 not in var_5:
        raise ValueError(f'unknown cmd {var_3}')
    var_5[var_3]({})