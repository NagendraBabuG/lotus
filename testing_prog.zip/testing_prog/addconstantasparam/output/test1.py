def prints(msg):
    return msg

def greet(var0='hello'):
    prefix = 'Hello'
    message = prints(var0)
    print(message)