def risky():
    result = 1 / 0
    print("Done")
def divide():
    result = 1 / 0
