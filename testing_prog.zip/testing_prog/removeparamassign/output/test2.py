def increment(a):
    a_copy = a
    a_copy += 1
    return a_copy