def provide_license(self, session_id, license_b64):
    session = self.sessions[session_id]
    license = wvproto.SignedLicense()
    license.ParseFromString(base64.b64decode(license_b64))
    session.license = license

    oaep_cipher = PKCS1_OAEP.new(session.device_key)
    session.session_key = oaep_cipher.decrypt(license.SessionKey)

    cmac_obj = CMAC.new(session.session_key, ciphermod=AES)
    lic_req_msg = session.license_request.Msg.SerializeToString()
    enc_key_base = b"ENCRYPTION\000" + lic_req_msg + b"\0\0\0\x80"
    enc_key = b"\x01" + enc_key_base

    cmac_obj.update(enc_key)
    enc_cmac_key = cmac_obj.digest()
    session.derived_keys["enc"] = enc_cmac_key

    for key in license.Msg.Key:
        key_id = key.Id or wvproto.License.KeyContainer.KeyType.Name(key.Type).encode("utf-8")
        encrypted_key = key.Key
        iv = key.Iv
        type = wvproto.License.KeyContainer.KeyType.Name(key.Type)

        cipher = AES.new(session.derived_keys["enc"], AES.MODE_CBC, iv=iv)
        decrypted_key = cipher.decrypt(encrypted_key)

        permissions = []

        if type == "OPERATOR_SESSION":
            perms = key._OperatorSessionKeyPermissions
            for (descriptor, value) in perms.ListFields():
                if value == 1:
                    permissions.append(descriptor.name)

        session.keys.append(
            EncryptionKey(
                key_id,
                type,
                Padding.unpad(decrypted_key, 16),
                permissions
            )
        )