class Ed25519Adapter:

    def sign(self, private_key, data):
        return private_key.sign(data)

    def verify(self, public_key, signature, data):
        return public_key.verify(signature, data)
