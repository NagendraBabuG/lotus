def append_item(lst):
    lst.append(1)

def update_dict(d):
    d['key'] = 'value'
