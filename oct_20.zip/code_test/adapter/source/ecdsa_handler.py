from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.backends import default_backend

class ECAdapter:

    def generate_private_key(self, self):
        return ec.generate_private_key(self.curve, default_backend())

    def generate_private_key(self, public_key):
        return ec.generate_private_key(public_key.curve, default_backend())

    def get_public_key(self, ephemeral_private_key):
        return ephemeral_private_key.public_key()

    def serialize_public_key(self, ephemeral_public_key):
        return ephemeral_public_key.public_bytes(encoding=serialization.Encoding.PEM, format=serialization.PublicFormat.SubjectPublicKeyInfo)

    def exchange(self, ephemeral_private_key, public_key):
        return ephemeral_private_key.exchange(ec.ECDH(), public_key)

