import ast
import os
from random import shuffle

#not works sometimes and it is not reorder methods inside class

class ShuffleFunctions(ast.NodeTransformer):


    def shuffle_functions(self, tree):
        self.module_node = None
        self.function_nodes = []
        self.line_list = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Module):
                module_node = node
                for idx, stmt in enumerate(node.body):
                    if isinstance(stmt, ast.FunctionDef):
                        self.function_nodes.append(stmt)
                        self.line_list.append(idx)

        if not self.function_nodes:
            return tree

        shuffle(self.function_nodes)
        
        for i, index in enumerate(self.line_list):
            if index < len(module_node.body):
                module_node.body[index] = self.function_nodes[i]
            else:
                print(f"Warning: Skipping index {index}, out of bounds")

        return tree
    def reorder_functions(self, tree):
        tree = self.shuffle_functions(tree)
        ast.fix_missing_locations(tree)
        return ast.unparse(tree)

    def get_refactored_code(self, source_code):
        try:
            tree = ast.parse(source_code)
            return self.reorder_functions(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")