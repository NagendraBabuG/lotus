from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPrivateKey, RSAPublicKey

class RSAAdapter:

    def generate_private_key(self, bits):
        return rsa.generate_private_key(public_exponent=65537, key_size=bits, backend=default_backend())

    def get_public_key(self, privkey):
        return privkey.public_key()

