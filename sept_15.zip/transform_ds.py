from arta import RulesEngine
import libcst as cst
from pathlib import Path


def get_ds_transform_pqc(code):
    libname = "cryptography"
    inputs = {
        "tree":code,
        "library":libname
    }



    eng = RulesEngine(config_path="./arta_files")

    extracted_result = eng.apply_rules(inputs, rule_set="mapping_creator_rule_set")
    mappings = extracted_result['get_mapping_ids']


    print("mappings ", mappings)


    libname = "cryptography"
    mod_inputs = {
        "tree":code,
        "mappings":mappings,
        "library":libname
        
    }

    result = eng.apply_rules(mod_inputs, rule_set="transform_ds_keygen_sign_set")
    modified_tree = result['transform']




    mod_inputs4 = {
        "tree":modified_tree,
        "library": libname,
        "mappings":mappings
    }

    verify_result = eng.apply_rules(mod_inputs4, rule_set="ds_verify_rule_set")
    modified_verify_tree = verify_result['check_verify']



    mod_inputs6 = {
        "tree":modified_verify_tree,
        "mappings":mappings
    }

    add_result = eng.apply_rules(mod_inputs6, rule_set="add_rule_set")
    add_hash_nodes_tree = add_result['insert_hash_nodes']

    return add_hash_nodes_tree.code


def process_folder(input_folder, output_folder):

    input_folder = Path(input_folder)
    output_folder = Path(output_folder)

    output_folder.mkdir(parents=True, exist_ok=True)

    for file_path in input_folder.glob("*.py"):

        print(f"\nProcessing: {file_path.name}")

        try:
            with open(file_path, "r", encoding="utf-8") as f:
                src = f.read()

            tree = cst.parse_module(src)

            modified_code = get_ds_transform_pqc(tree)

            base_name = file_path.stem

            output_file = (
                output_folder / f"{base_name}_pqc.py"
            )

            with open(
                output_file,
                "w",
                encoding="utf-8"
            ) as f:
                f.write(modified_code)

            print(f"  Created: {output_file}")

        except Exception as e:
            print(
                f"  ERROR processing {file_path.name}: {e}"
            )


if __name__ == "__main__":

    process_folder(
        "./ds_files",
        "./ds_files/output"
    )