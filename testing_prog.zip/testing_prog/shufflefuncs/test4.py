def get_default():
    return 42

def show(value=get_default()):
    print(value)

show()
