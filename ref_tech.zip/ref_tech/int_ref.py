#integer refactor
import ast
import random
class ConstantRefactor(ast.NodeTransformer):
    def findFactor(self, num):
        if num%2 != 0:
            return [num/2, num/2]
        else:
            n = num//2
            return [n] + self.findFactor(n)
    def binOpFunc(self, length):
        if length <= 2:
            new_binop = ast.BinOp(
                left = ast.Constant(value=self.num_arr[length-2]),
                op=ast.Add(),
                right=ast.Constant(value=self.num_arr[length-1])
            )
            return new_binop
        else:
            length -= 1
            new_binop = ast.BinOp(
                left = self.binOpFunc(length),
                op = ast.Add(),
                right = ast.Constant(value=self.num_arr[length - 1])
            )
            return new_binop
    def visit_Constant(self, node):
        r = random.randint(0, 2)
        if isinstance(node.value, int) and node.value != 0 and r:
            self.num_arr = self.findFactor(node.value)
            return self.binOpFunc(len(self.num_arr))
        return node 
    def get_refactored_code(self, code):
        try:
            tree = ast.parse(code)
            mod_tree = self.visit(tree)
            return ast.unparse(mod_tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")
       