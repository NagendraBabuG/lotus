import ast

#converts single line funcs to lambda and also added conditon for not refactoring decorator methods
class LambdaRefactor(ast.NodeTransformer):
    
    def has_decorators(func_def: ast.FunctionDef) -> bool:
        return bool(func_def.decorator_list)

    def visit_Module(self, node):
        new_body = []
        for stmt in node.body:
            if isinstance(stmt, ast.FunctionDef) and len(stmt.body) == 1:
                ret_stmt = stmt.body[0]
                if isinstance(ret_stmt, ast.Return) and not stmt.decorator_list :
                    lambda_assign = ast.Assign(
                        targets=[ast.Name(id=stmt.name, ctx=ast.Store())],
                        value=ast.Lambda(
                            args=stmt.args,
                            body=ret_stmt.value
                        )
                    )
                    new_body.append(lambda_assign)
                    continue  
            new_body.append(stmt)
        node.body = new_body
        return node

    def get_refactored_code(self, source_code):
        try:
            tree = ast.parse(source_code)
            tree = self.visit(tree)
            ast.fix_missing_locations(tree)
            return ast.unparse(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")
