from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.backends import default_backend

class RSAAdapter:

    def generate_private_key(self):
        return rsa.generate_private_key(public_exponent=65537, key_size=1024, backend=default_backend())

    def get_public_key(self, private_key):
        return private_key.public_key()

    def serialize_private_key(self, private_key):
        return private_key.private_bytes(encoding=serialization.Encoding.PEM, format=serialization.PrivateFormat.PKCS8, encryption_algorithm=serialization.NoEncryption())

    def serialize_public_key(self, public_key):
        return public_key.public_bytes(encoding=serialization.Encoding.PEM, format=serialization.PublicFormat.SubjectPublicKeyInfo)

    def get_private_numbers(self, private_key):
        return private_key.private_numbers()

    def get_public_numbers(self, public_key):
        return public_key.public_numbers()

