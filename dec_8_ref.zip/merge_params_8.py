import ast
import re

HEX_PATTERN = re.compile(r"\b0x[0-9A-Fa-f]+\b")

class CommonParamMerger(ast.NodeTransformer):
    def __init__(self):
        self.func_params = {}
        self.func_nodes = {}
        self.merge_groups = []

    def visit(self, node):
        if not isinstance(node, ast.Module):
            return super().visit(node)

        for n in ast.walk(node):
            if isinstance(n, ast.FunctionDef):
                params = [a.arg for a in n.args.args if a.arg != 'self']
                self.func_params[n.name] = params
                self.func_nodes[n.name] = n

        if len(self.func_params) < 2:
            return node

        from collections import defaultdict
        groups = defaultdict(list)
        for fname, params in self.func_params.items():
            key = tuple(sorted(params))
            if params:
                groups[key].append(fname)

        merge_id = 0
        for param_key, func_names in groups.items():
            if len(func_names) >= 2:
                merged_name = f"_mp{merge_id}"
                merge_id += 1
                self.merge_groups.append((list(param_key), merged_name, func_names))

        for param_names, merged_name, func_names in self.merge_groups:
            for fname in func_names:
                func_node = self.func_nodes[fname]

                new_args = []
                seen = set()
                for arg in func_node.args.args:
                    if arg.arg == 'self':
                        new_args.append(arg)
                    elif arg.arg not in param_names:
                        if arg.arg not in seen:
                            new_args.append(arg)
                            seen.add(arg.arg)
                new_args.append(ast.arg(arg=merged_name))
                func_node.args.args = new_args

                class Rewriter(ast.NodeTransformer):
                    def visit_Name(self, node):
                        if isinstance(node.ctx, ast.Load) and node.id in param_names:
                            return ast.Attribute(
                                value=ast.Name(id=merged_name, ctx=ast.Load()),
                                attr=node.id,
                                ctx=ast.Load()
                            )
                        return node

                    def visit_Call(self, node):
                        self.generic_visit(node)
                        if isinstance(node.func, ast.Name) and node.func.id in func_names:
                            new_args = []
                            new_keywords = []

                            for arg in node.args:
                                if isinstance(arg, ast.Name) and arg.id in param_names:
                                    continue
                                new_args.append(arg)

                            for kw in node.keywords:
                                if kw.arg not in param_names:
                                    new_keywords.append(kw)

                            insert_pos = 1 if 'self' in seen else 0
                            new_args.insert(insert_pos, ast.Name(id=merged_name, ctx=ast.Load()))

                            node.args = new_args
                            node.keywords = new_keywords
                        return node

                rewriter = Rewriter()
                func_node.body = [rewriter.visit(n) for n in func_node.body]

        return node

    def get_refactored_code(self, source_code):
        hex_map = {}
        for m in HEX_PATTERN.finditer(source_code):
            hx = m.group()
            dec = str(int(hx, 16))
            hex_map[dec] = hx

        tree = ast.parse(source_code)
        tree = self.visit(tree)
        ast.fix_missing_locations(tree)
        code = ast.unparse(tree)

        for dec, hx in hex_map.items():
            code = code.replace(dec, hx)
        return code


