from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

class Ed25519Adapter:

    def generate_private_key(self):
        return Ed25519PrivateKey.generate()

    def sign(self, private_key):
        return private_key.sign(b"my authenticated message")

    def get_public_key(self, private_key):
        return private_key.public_key()

    def verify(self, public_key, signature):
        return public_key.verify(signature, b"my authenticated message")

