def apply_discount():
    price = 100
    discount = 0.2 * price
    final_price = price - discount
    print(final_price)