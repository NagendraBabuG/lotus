import ast
import importlib.util
import sys
import os
from pathlib import Path
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from Levenshtein import distance
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

tokenizer = AutoTokenizer.from_pretrained("microsoft/codebert-base")
model = AutoModelForSequenceClassification.from_pretrained("microsoft/codebert-base")


MAX_LENGTH = 512

def tokenize_code(code1, code2):
    return tokenizer(code1, code2, return_tensors="pt", max_length=MAX_LENGTH,
                     truncation=True, padding="max_length")

def predict_clone_probability(code1, code2):
    inputs = tokenize_code(code1, code2)
    model.eval()
    with torch.no_grad():
        outputs = model(**inputs)
        prob = torch.softmax(outputs.logits, dim=1)[:, 1].item() 
    return prob

def levenshtein_difference_percentage(code1, code2):
    lev_dist = distance(code1, code2)
    max_len = max(len(code1), len(code2))
    return 0.0 if max_len == 0 else (lev_dist / max_len) * 100

def embedding_similarity_difference(code1, code2):
    inputs1 = tokenizer(code1, return_tensors="pt", max_length=MAX_LENGTH, truncation=True, padding=False)
    inputs2 = tokenizer(code2, return_tensors="pt", max_length=MAX_LENGTH, truncation=True, padding=False)

    with torch.no_grad():
        emb1 = model.roberta(**inputs1).last_hidden_state.mean(dim=1).numpy()
        emb2 = model.roberta(**inputs2).last_hidden_state.mean(dim=1).numpy()

    similarity = cosine_similarity(emb1, emb2)[0][0]
    return (1 - similarity) * 100  

def get_function_names(code):
    try:
        tree = ast.parse(code)
        return [node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)]
    except:
        return []




def analyze_code_pair(code_before: str, code_after: str) -> dict:
    clone_prob = predict_clone_probability(code_before, code_after)

    syntactic_diff = levenshtein_difference_percentage(code_before, code_after)

    embedding_diff = embedding_similarity_difference(code_before, code_after)

    
    is_clone = clone_prob > 0.5
    conclusion = "Likely a clean refactor (semantic clone)" if (is_clone) else "Not a clone or behavior changed"

    result = {
        "clone_probability": clone_prob,
        "is_clone": is_clone,
        "syntactic_difference_percent": round(syntactic_diff, 2),
        "semantic_difference_percent": round(embedding_diff, 2),
        "conclusion": conclusion
    }

    

    return result
"""

if __name__ == "__main__":
    code_before = "
def add(a, b):
    return a + b

def multiply(x, y):
    result = 0
    for _ in range(y):
        result += x
    return result
"

    code_after = "
def add(x, y):
    return x + y

def multiply(a, b):
    return a * b
"

    analyze_code_pair(code_before, code_after)

"""