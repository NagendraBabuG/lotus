import libcst as cst 

from libcst.display import dump



class AssignGroupers(cst.CSTTransformer):
    def __init__(self):
        self.fun_groups = []
        self.stmt_groups = []
    def checkInvalidBlocks(self, node):
        return (isinstance(node, cst.FunctionDef) or isinstance(node, cst.ClassDef) or isinstance(node, cst.If) or isinstance(node, cst.Else) or
                isinstance(node, cst.While) or isinstance(node, cst.For))
    
    def checkValidValues(self, node):
        return (isinstance(node.body[0].value, cst.Integer) or isinstance(node.body[0].value, cst.Float) or isinstance(node.body[0].value, cst.Name) or 
                isinstance(node.body[0].value, cst.SimpleString) or isinstance(node.body[0].value, cst.FormattedString) or isinstance(node.body[0].value, cst.Tuple) or 
                isinstance(node.body[0].value, cst.Dict) or isinstance(node.body[0].value, cst.List))
    

    def leave_Module(self, node, updated_node):
        flag = 0 
        current_group = []
        for node2 in updated_node.body:
            if not self.checkInvalidBlocks(node2) and len(node2.body) == 1 and isinstance(node2.body[0], cst.Assign) and self.checkValidValues(node2):
                if flag == 0:
                    flag = 1    
                current_group.append(node2.body[0])
            else:
                if current_group:
                    self.stmt_groups.append(cst.SimpleStatementLine(body=current_group))
                self.stmt_groups.append(node2)
                current_group = []
                flag = 0 
        if current_group:
            self.stmt_groups.append(cst.SimpleStatementLine(body=current_group))
        return updated_node.with_changes(body=self.stmt_groups)


    def leave_FunctionDef(self, node, updated_node):
        flag = 0
        current_groups = []
        func_groups = []
        for node2 in node.body.body:
            if len(node2.body) == 1 and isinstance(node2.body[0], cst.Assign) and self.checkValidValues(node2):
                if flag==0:
                    flag = 1
                current_groups.append(node2.body[0])
            else:
                if current_groups:
                    func_groups.append(cst.SimpleStatementLine(body=current_groups))
                func_groups.append(node2)
                current_groups = []
                flag = 0
        if current_groups:
            func_groups.append(cst.SimpleStatementLine(body=current_groups))

        return updated_node.with_changes(body=cst.IndentedBlock(body=func_groups))



    def get_refactored_code(self, source_code):
        module = cst.parse_module(source_code)
        wrapper = cst.MetadataWrapper(module)
        return wrapper.visit(self).code