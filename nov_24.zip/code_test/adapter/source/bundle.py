from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519


class Ed25519Adapter:

    def load_private_key(self, data):
        return ed25519.Ed25519PrivateKey.from_private_bytes(data)

    def serialize_public_key(self, public_key):
        return public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )

    def get_public_key(self, private_key):
        return private_key.public_key()

    def sign(self, private_key, data):
        return private_key.sign(data)
