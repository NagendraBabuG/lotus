def generate_keys():
    key = ECC.generate(curve='p192')
    public_key = key.public_key()
    return (key, public_key)

def sign_generation(key, msg):
    signer = pss.new(key)
    signed = signer.sign(msg)
    sigb64 = base64.b64encode(signed)
    return sigb64

def verify_function(signature, message, public_key):
    decoded = base64.b64decode(message)
    verify_object = eddsa.new(public_key, 'rfc8032')
    try:
        verify_object.verify(decoded, signed)
        print(f'{signed} VALID')
    except Exception as e:
        print(e)
Signature = sing(key, message)
is_valid = verify_function(public_key, message, signed)