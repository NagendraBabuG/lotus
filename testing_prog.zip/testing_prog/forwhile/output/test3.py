def find_first_even_while(lst):
    index = 0
    for index in range(len(lst)):
        if lst[index] % 2 == 0:
            return lst[index]
    return None
print(find_first_even_while([1, 3, 4, 6, 7]))