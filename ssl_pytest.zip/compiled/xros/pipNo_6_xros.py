import os
os.path.basename(os.path.dirname(os.path.realpath(__file__)))
import hashlib
import hmac
from promise import Promise
import six
import operator
import struct
import binascii
import base64
import functools
'\nCopyright to Alexander Liu\nFor entertainment only :)\n\nTo decrypt the password in the Django framework, you need to get\nthe value which is stored in the database table \'auth_user\' column \'password\'.\n\nFor example the encrypted password is:\n\npbkdf2_sha256$12000$Lz8oA7gW43mJ$N/DzMkLc/CX4oKHrU2b5Pu13svN0mz8CYthMIJrR4Mo=\n{algorithm}${iteration times}${salt}${encrypted password}\n\nIn this case, pbkdf2_sha256 is the encryption algorithm, and 12000 is the iteration times,\n"Lz8oA7gW43mJ" (without quote) is the salt,\n"N/DzMkLc/CX4oKHrU2b5Pu13svN0mz8CYthMIJrR4Mo=" (without quote) is the base64 encoded password.\n\nNote:\n    As of 2011, 10,000 iterations was the recommended default which\n    took 100ms on a 2.2Ghz Core 2 Duo. This is probably the bare\n    minimum for security given 1000 iterations was recommended in 2001.\n\nThis is also a standalone module derived from Django. If any other webframework can use this module.\n\nUsage:\n>>> from jake import give_back_hashed\n>>> from jake import get_base64_hashed\n>>> b = give_base64_hashed(\'the_password\', \'the_salt\', \'iteration_times\', \'the_hashlib_digest_object\')\n>>> # this is the password which encrypted in the database table \'auth_user\' column \'password\'\n>>> print b\nN/DzMkLc/CX4oKHrU2b5Pu13svN0mz8CYthMIJrR4Mo=\n\n>>> # or you can do this\n>>> import hashlib\n>>> b = give_base64_hashed(\'the_password\', \'the_salt\', \'iteration_times\', hashlib.sha256)\n>>> print b\nN/DzMkLc/CX4oKHrU2b5Pu13svN0mz8CYthMIJrR4Mo=\n\n>>> # to get the real sha256 hashed value\n>>> c = give_back_hashed(b)\n>>> print c\n\'7ðó2BÜü%ø\xa0¡ëSfÒ>éW²óN\x9b?\x02bØLÔ\x9aÑàÊ\'\n>>> # you need other tools such as \'hashcat\' or \'crack\' to generate HASHes from\n>>> # a dictionay to compare them with this.\n'

def func_25(var_22):
    assert var_22 != None
    return int(binascii.hexlify(var_22), 16)

def func_26(var_22, var_9):
    assert var_22 != None and var_9 != None
    return binascii.unhexlify((var_9 % var_22).encode('ascii'))

def func_27(var_18, var_6='utf-8', var_20=False, var_7='strict'):
    assert var_18 != None and var_6 != None and (var_20 != None) and (var_7 != None)
    ...
    if isinstance(var_18, six.memoryview):
        var_18 = bytes(var_18)
    ...
    if isinstance(var_18, bytes):
        if not var_6 != 'utf-8':
            return var_18
        else:
            return var_18.decode('utf-8', var_7).encode(var_6, var_7)
    if var_20 and (var_18 is None or isinstance(var_18, int)):
        return var_18
    if isinstance(var_18, Promise):
        return six.text_type(var_18).encode(var_6, var_7)
    if not isinstance(var_18, six.string_types):
        try:
            if six.PY3:
                return six.text_type(var_18).encode(var_6)
            else:
                return bytes(var_18)
        except UnicodeEncodeError:
            if isinstance(var_18, Exception):
                return b' '.join([func_27(arg, var_6, var_20, var_7) for arg in var_18])
            return six.text_type(var_18).encode(var_6, var_7)
    else:
        return var_18.encode(var_6, var_7)

def func_30(var_16, var_19, var_13, var_5=0, var_4=None):
    assert var_16 != None and var_19 != None and (var_13 != None) and (var_5 != None)
    assert var_13 > 0
    if not var_4:
        var_4 = hashlib.sha256
    var_16 = func_27(var_16)
    var_19 = func_27(var_19)
    var_10 = var_4().digest_size
    if not var_5:
        var_5 = var_10
    if (2 ** 32 - 1) * var_10 < var_5:
        raise OverflowError('dklen too big')
    var_14 = -(-var_5 // var_10)
    var_17 = var_5 - (var_14 - 1) * var_10
    var_9 = '%%0%ix' % (var_10 * 2)
    (var_12, var_15) = (var_4(), var_4())
    if var_12.block_size < len(var_16):
        var_16 = var_4(var_16).digest()
    var_16 += b'\x00' * (var_12.block_size - len(var_16))
    var_12.update(var_16.translate(hmac.trans_36))
    var_15.update(var_16.translate(hmac.trans_5C))

    def func_23(var_11):
        assert var_11 != None

        def func_24():
            var_21 = var_19 + struct.pack(b'>I', var_11)
            for j in range(int(var_13)):
                (var_2, var_3) = (var_12.copy(), var_15.copy())
                var_2.update(var_21)
                var_3.update(var_2.digest())
                var_21 = var_3.digest()
                yield func_25(var_21)
        return func_26(functools.reduce(operator.xor, func_24()), var_9)
    var_0 = [func_23(var_22) for var_22 in range(1, var_14 + 1)]
    return b''.join(var_0[:-1]) + var_0[-1][:var_17]

def func_28(var_16, var_19, var_13, var_5=0, var_4=None):
    assert var_16 != None and var_19 != None and (var_13 != None) and (var_5 != None)
    var_8 = func_30(var_16, var_19, var_13, var_5=0, var_4=None)
    var_8 = base64.b64encode(var_8).decode('ascii').strip()
    return var_8

def func_29(var_1):
    assert var_1 != None
    ...
    ...
    return base64.b64decode(var_1)