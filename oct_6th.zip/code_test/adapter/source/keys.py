from __future__ import annotations
import base64
import os
import sqlite3
import uuid
from pathlib import Path
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)
from .credential import IssuedKey, public_raw
from .errors import NotFoundError, ValidationError

class Ed25519Adapter:

    def generate_private_key(self):
        return Ed25519PrivateKey.generate()

    def serialize_private_key(self, sk):
        return sk.private_bytes(encoding=serialization.Encoding.PEM, format=serialization.PrivateFormat.PKCS8, encryption_algorithm=serialization.NoEncryption())

    def get_public_key(self, sk):
        return sk.public_key()

