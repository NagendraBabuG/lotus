from cryptography.hazmat.primitives.asymmetric.ed448 import Ed448PrivateKey

class Ed448Adapter:

    def generate_private_key(self):
        return Ed448PrivateKey.generate()

    def sign(self, private_key):
        return private_key.sign(b"my authenticated message")

    def get_public_key(self, private_key):
        return private_key.public_key()

    def verify(self, public_key, signature):
        return public_key.verify(signature, b"my authenticated message")

