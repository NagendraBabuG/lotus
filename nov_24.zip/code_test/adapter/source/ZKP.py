from cryptography.hazmat.primitives.asymmetric import ec


class ECAdapter:

    def generate_private_key(self):
        return ec.generate_private_key(ec.SECP256R1())

    def get_public_key(self, private_key):
        return private_key.public_key()
