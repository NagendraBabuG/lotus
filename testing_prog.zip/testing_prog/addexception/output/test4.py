def bad_index():
    try:
        lst = []
        return lst[1]
    except Exception as exception:
        print(f'Operation Failed: {exception}')