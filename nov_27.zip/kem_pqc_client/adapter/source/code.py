from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import ec

class ECAdapter:

    def get_public_key(self, private_key):
        return private_key.public_key()

    def generate_private_key(self):
        return ec.generate_private_key(ec.BrainpoolP256R1(), default_backend())

    def get_public_numbers(self, public_key):
        return public_key.public_numbers()

    def exchange(self, private_key, peer_public_key):
        return private_key.exchange(ec.ECDH(), peer_public_key)

