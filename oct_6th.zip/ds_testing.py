from pathlib import Path
import libcst as cst
from arta import RulesEngine


def get_ds_transform_pqc(code):
    libname = "cryptography"
    inputs = {"tree": code, "library": libname}

    eng = RulesEngine(config_path="./arta_files")

    extracted_result = eng.apply_rules(inputs, rule_set="mapping_creator_rule_set")
    mappings = extracted_result["get_mapping_ids"]

    print("mappings ", mappings)

    libname = "cryptography"
    mod_inputs = {"tree": code, "mappings": mappings, "library": libname}

    result = eng.apply_rules(mod_inputs, rule_set="transform_ds_keygen_sign_set")
    modified_tree = result["transform"]

    mod_inputs4 = {
        "tree": modified_tree,
        "library": libname,
        "mappings": mappings,
    }

    verify_result = eng.apply_rules(mod_inputs4, rule_set="ds_verify_rule_set")
    modified_verify_tree = verify_result["check_verify"]

    mod_inputs6 = {"tree": modified_verify_tree, "mappings": mappings}

    add_result = eng.apply_rules(mod_inputs6, rule_set="add_rule_set")
    add_hash_nodes_tree = add_result["insert_hash_nodes"]

    return add_hash_nodes_tree.code


def run_tests(input_folder, expected_folder, output_folder, log_file="result.txt"):
    input_dir = Path(input_folder)
    expected_dir = Path(expected_folder)
    output_dir = Path(output_folder)

    output_dir.mkdir(parents=True, exist_ok=True)

    equal_files = []
    not_equal_files = []
    missing_expected_files = []
    error_files = []

    for file_path in input_dir.glob("*.py"):
        filename = file_path.name
        print(f"\nProcessing: {filename}")

        try:
            # 1. Read and transform input code
            with open(file_path, "r", encoding="utf-8") as f:
                src = f.read()

            tree = cst.parse_module(src)
            transformed_code = get_ds_transform_pqc(tree)

            # 2. Save the transformed output file
            transformed_file = output_dir / filename
            with open(transformed_file, "w", encoding="utf-8") as f:
                f.write(transformed_code)
            
            """
            # 3. Locate expected file
            expected_file = expected_dir / filename
            if not expected_file.exists():
                print(f"  WARNING: Expected file not found for {filename}")
                missing_expected_files.append(filename)
                continue

            with open(expected_file, "r", encoding="utf-8") as f:
                expected_code = f.read()

            # 4. Compare transformation with expected output (ignoring trailing whitespace/newlines)
            if transformed_code.strip() == expected_code.strip():
                print(f"  MATCH: Output matches expected code.")
                equal_files.append(filename)
            else:
                print(f"  MISMATCH: Output differs from expected code.")
                not_equal_files.append(filename)
            """

        except Exception as e:
            print(f"  ERROR processing {filename}: {e}")
            error_files.append(f"{filename} (Error: {e})")
    """
    # 5. Write comparison results to result.txt
    with open(log_file, "w", encoding="utf-8") as f:
        f.write("=== TEST SUMMARY ===\n\n")

        f.write(f"MATCHED FILES ({len(equal_files)}):\n")
        for name in equal_files:
            f.write(f"  [EQUAL] {name}\n")

        f.write(f"\nMISMATCHED FILES ({len(not_equal_files)}):\n")
        for name in not_equal_files:
            f.write(f"  [NOT EQUAL] {name}\n")

        if missing_expected_files:
            f.write(f"\nMISSING EXPECTED FILES ({len(missing_expected_files)}):\n")
            for name in missing_expected_files:
                f.write(f"  [MISSING EXPECTED] {name}\n")

        if error_files:
            f.write(f"\nERRORS ENCOUNTERED ({len(error_files)}):\n")
            for err in error_files:
                f.write(f"  [ERROR] {err}\n")

    print(f"\nResults written to {log_file}")
    """


if __name__ == "__main__":
    run_tests(
        input_folder="./testing/input",
        expected_folder="./testing/expected",
        output_folder="./testing/output",
        log_file="testing_result.txt",
    )