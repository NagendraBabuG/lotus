def is_even(num):
    return num%2 == 0

nums=[1,2,3,4,5]
ans = list(filter(is_even, nums))
print(ans)


nums2 = [1,2,3,4,5]
ans2 = [num for num in nums2 if is_even(num)]

print(ans2)


def sign(key):
    return lambda msg:pkcs1_15.new(key).sign(msg)
def verify(key):
    return lambda signature:pkc1_15.new(key).verify(signature)

global_key = RSA.generate(1024)
global_pubkey = global_key.publickey()
msgs = ['string', 'of', 'message']

sign_ = sign(global_key)
verify_ = verify(global_pubkey)
ans = list(verify(filter(verify_, msgs)))
ans4 = [msg for msg in msgs if verify_(msg)]