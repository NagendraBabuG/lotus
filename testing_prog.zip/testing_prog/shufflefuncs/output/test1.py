def main():
    greet()

def greet():
    print('Hello!')
main()