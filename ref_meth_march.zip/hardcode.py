import ast


class HardcodedValues:

    SUPPORTED_TYPES = (str, int)

    def _collect_literals(self, body):
        literals = set()

        for stmt in body:
            for sub in ast.walk(stmt):

                if isinstance(
                    sub,
                    (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef),
                ):
                    continue

                if isinstance(sub, ast.Call):

                    for arg in sub.args:
                        if isinstance(arg, ast.Constant) and isinstance(
                            arg.value, self.SUPPORTED_TYPES
                        ):
                            literals.add(arg.value)

                    for kw in sub.keywords:
                        if (
                            isinstance(kw.value, ast.Constant)
                            and isinstance(
                                kw.value.value, self.SUPPORTED_TYPES
                            )
                        ):
                            literals.add(kw.value.value)

        return literals

    class Replacer(ast.NodeTransformer):
        def __init__(self, mapping):
            self.mapping = mapping

        def visit_Call(self, node):
            self.generic_visit(node)

            node.args = [
                ast.Name(id=self.mapping[a.value], ctx=ast.Load())
                if isinstance(a, ast.Constant) and a.value in self.mapping
                else a
                for a in node.args
            ]

            new_keywords = []
            for kw in node.keywords:
                if (
                    isinstance(kw.value, ast.Constant)
                    and kw.value.value in self.mapping
                ):
                    new_keywords.append(
                        ast.keyword(
                            arg=kw.arg,
                            value=ast.Name(
                                id=self.mapping[kw.value.value],
                                ctx=ast.Load(),
                            ),
                        )
                    )
                else:
                    new_keywords.append(kw)

            node.keywords = new_keywords
            return node

    def _inject_scope(self, node):

        literals = self._collect_literals(node.body)

        if not literals:
            return

        mapping = {}
        assigns = []

        for i, lit in enumerate(sorted(literals, key=str)):
            name = f"var{i}"
            mapping[lit] = name

            assign = ast.Assign(
                targets=[ast.Name(id=name, ctx=ast.Store())],
                value=ast.Constant(value=lit),
            )
            ast.fix_missing_locations(assign)
            assigns.append(assign)

        node.body = assigns + node.body

        self.Replacer(mapping).visit(node)

    def refactor(self, tree):

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                self._inject_scope(node)

        self._inject_scope(tree)

        return ast.unparse(tree)

    def get_refactored_code(self, source_code):
        tree = ast.parse(source_code)
        return self.refactor(tree)
