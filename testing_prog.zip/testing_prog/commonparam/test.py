def sign(key, msg):
    signer = pkcs1_15.new(key)
    sign = signer.sign(msg)
    return sign

def verify(key, msg, sign):
    verifier = pkcs1_15.new(key)
    valid = verifier.verify(msg, sign)
    return valid

key = "12"
msg = "hlo"