def double_and_print(x):
    print(x)
    return x * 2