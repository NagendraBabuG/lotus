# ----------------------
# App A: Master Key Manager (Flask)
# ----------------------

from flask import Flask, request, jsonify
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import rsa
import uuid, requests, datetime, os, base64
import jwt


app = Flask(__name__)

# Load App B's public key
with open("app_b_public.pem", "rb") as f:
    app_b_public_key = serialization.load_pem_public_key(f.read())

# Load App A's private key for signing JWTs
with open("app_a_private.pem", "rb") as f:
    app_a_private_key_pem = f.read()
    app_a_private_key = serialization.load_pem_private_key(app_a_private_key_pem, password=None)

@app.route("/api/keys", methods=["POST"])
def receive_key():
    data = request.json
    user_id = data["user_id"]
    key_data = data["key_data"].encode()

    # Generate key_id
    key_id = str(uuid.uuid4())

    # Encrypt key_data using App B's public key
    encrypted_key = app_b_public_key.encrypt(
        key_data,
        padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None)
    )

    # Send encrypted key to App B
    store_response = requests.post("http://localhost:8001/api/secure-store", json={
        "key_id": key_id,
        "owner_id": user_id,
        "encrypted_key": base64.b64encode(encrypted_key).decode(),
        "created_by": "app-a"
    })

    if store_response.status_code != 200:
        return jsonify({"error": "Failed to store key in App B"}), 500

    # Create access token (JWT)
    payload = {
        "sub": user_id,
        "key_id": key_id,
        "iat": datetime.datetime.utcnow(),
        "exp": datetime.datetime.utcnow() + datetime.timedelta(minutes=5),
        "scope": "read",
        "iss": "app-a"
    }

    token = jwt.encode(payload, app_a_private_key_pem, algorithm="RS256")

    return jsonify({"message": "Key stored successfully", "access_token": token})

if __name__ == '__main__':
    app.run(port=8000, debug=True)
