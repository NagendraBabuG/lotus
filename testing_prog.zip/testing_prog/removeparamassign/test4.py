def process(a, b, c):
    a += 1
    c = c * 2
    return a + b + c


def maybe_modify(x):
    if x > 0:
        x -= 1
    return x
