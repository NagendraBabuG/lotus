import ast


class ParamRecorder(ast.NodeVisitor):
    def __init__(self):
        self.func2par = {}
        self.class2func = {}
        self.func_calls = {}

    def visit_ClassDef(self, node):
        funcs = []
        for inner in node.body:
            if isinstance(inner, ast.FunctionDef) and not (
                inner.name.startswith("__") and inner.name.endswith("__")
            ):
                funcs.append(inner.name)
        self.class2func[node.name] = funcs
        self.generic_visit(node)

    def visit_FunctionDef(self, node):
        if node.name.startswith("__") and node.name.endswith("__"):
            return

        # Skip class methods
        for funcs in self.class2func.values():
            if node.name in funcs:
                return

        self.func2par[node.name] = [a.arg for a in node.args.args]
        self.generic_visit(node)

    def visit_Call(self, node):
        if isinstance(node.func, ast.Name) and node.func.id in self.func2par:
            self.func_calls.setdefault(node.func.id, []).append(node.args[:])
        self.generic_visit(node)


def recursive_check(arr):
    result = []
    for i in range(len(arr)):
        for j in range(i + 1, len(arr)):
            inter = set(arr[i]) & set(arr[j])
            if inter and inter not in result:
                result.append(inter)
    return [
        s for s in result
        if not any(s < other for other in result if s != other)
    ]


def group_common_param(func2par, funcs):
    return recursive_check([func2par[f] for f in funcs])


class ParamUpdater(ast.NodeTransformer):
    def __init__(self, merged_params, value_map, core_funcs, func2par):
        self.cp = set(merged_params)
        self.value_map = value_map
        self.core_funcs = core_funcs
        self.func2par = func2par

    def visit_Module(self, node):
        self.generic_visit(node)

        class_def = ast.ClassDef(
            name="MergedParam",
            bases=[],
            keywords=[],
            body=[ast.Pass()],
            decorator_list=[],
            type_params=[]
        )

        mp_assign = ast.Assign(
            targets=[ast.Name("_mp", ast.Store())],
            value=ast.Call(ast.Name("MergedParam", ast.Load()), [], [])
        )

        attr_assigns = []
        for p, v in self.value_map.items():
            attr_assigns.append(
                ast.Assign(
                    targets=[
                        ast.Attribute(
                            ast.Name("_mp", ast.Load()),
                            p,
                            ast.Store()
                        )
                    ],
                    value=v
                )
            )

        node.body = [class_def, mp_assign] + attr_assigns + node.body
        ast.fix_missing_locations(node)
        return node

    def visit_Call(self, node):
        self.generic_visit(node)

        if not isinstance(node.func, ast.Name):
            return node
        if node.func.id not in self.core_funcs:
            return node

        params = self.func2par[node.func.id]
        new_args = []

        for arg, param in zip(node.args, params):
            if param in self.cp:
                new_args.append(
                    ast.Attribute(
                        ast.Name("_mp", ast.Load()),
                        param,
                        ast.Load()
                    )
                )
            else:
                new_args.append(arg)

        node.args = new_args
        ast.fix_missing_locations(node)
        return node


class MergeParamRefactor:
    def get_refactored_code(self, code):
        tree = ast.parse(code)
        rec = ParamRecorder()
        rec.visit(tree)

        funcs = list(rec.func2par)
        groups = group_common_param(rec.func2par, funcs)

        selected_groups = []

        for group in groups:
            # ONLY full matches
            core_funcs = {
                f for f, p in rec.func2par.items()
                if group <= set(p)
            }

            if len(core_funcs) < 2:
                continue

            value_map = {}
            valid = True

            # Collect values
            for f in core_funcs:
                calls = rec.func_calls.get(f)
                if not calls:
                    valid = False
                    break

                params = rec.func2par[f]
                call = calls[0]

                for i, p in enumerate(params):
                    if p in group:
                        arg = call[i]
                        if not isinstance(arg, ast.Constant):
                            valid = False
                            break
                        if p not in value_map:
                            value_map[p] = arg
                        elif ast.dump(value_map[p]) != ast.dump(arg):
                            valid = False
                            break
                if not valid:
                    break

            if not valid:
                continue

            # Verify ALL calls match
            for f in core_funcs:
                params = rec.func2par[f]
                for call in rec.func_calls[f]:
                    for i, p in enumerate(params):
                        if p in group:
                            if ast.dump(call[i]) != ast.dump(value_map[p]):
                                valid = False
                                break
                    if not valid:
                        break
                if not valid:
                    break

            if valid:
                selected_groups.append((group, value_map, core_funcs))

        if not selected_groups:
            return ast.unparse(tree)

        merged_params = []
        final_values = {}
        final_core_funcs = set()

        for g, v, cfs in selected_groups:
            for p in g:
                if p not in merged_params:
                    merged_params.append(p)
                    final_values[p] = v[p]
            final_core_funcs |= cfs

        updater = ParamUpdater(
            merged_params,
            final_values,
            final_core_funcs,
            rec.func2par
        )

        new_tree = updater.visit(tree)
        return ast.unparse(new_tree)