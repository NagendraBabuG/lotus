from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa

class RSAAdapter:

    def generate_private_key(self):
        return rsa.generate_private_key(public_exponent=65537, key_size=2048, backend=default_backend())

    def serialize_private_key(self, key):
        return key.private_bytes(encoding=serialization.Encoding.PEM, format=serialization.PrivateFormat.PKCS8, encryption_algorithm=serialization.NoEncryption())

    def get_public_key(self, key):
        return key.public_key()

