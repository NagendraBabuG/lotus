def append_item(lst):
    lst_copy = lst
    lst_copy.append(1)

def update_dict(d):
    d_copy = d
    d_copy['key'] = 'value'