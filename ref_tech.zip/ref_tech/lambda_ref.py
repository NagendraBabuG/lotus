import ast

class LambdaRefactor(ast.NodeTransformer):



    @staticmethod
    def has_decorators(func_def: ast.FunctionDef) -> bool:
        return bool(func_def.decorator_list)

    def _function_to_lambda(self, func_def: ast.FunctionDef):
        if len(func_def.body) != 1:
            return None

        stmt = func_def.body[0]
        if not isinstance(stmt, ast.Return) or stmt.value is None:
            return None

        if self.has_decorators(func_def):
            return None

        return ast.Assign(
            targets=[ast.Name(id=func_def.name, ctx=ast.Store())],
            value=ast.Lambda(
                args=func_def.args,
                body=stmt.value
            )
        )

    def _lambda_to_function(self, assign: ast.Assign):
        if len(assign.targets) != 1:
            return None

        target = assign.targets[0]
        if not isinstance(target, ast.Name):
            return None

        if not isinstance(assign.value, ast.Lambda):
            return None

        lam = assign.value

        return ast.FunctionDef(
            name=target.id,
            args=lam.args,
            body=[ast.Return(value=lam.body)],
            decorator_list=[]
        )

    def visit_Module(self, node: ast.Module):
        new_body = []
        for stmt in node.body:
            if isinstance(stmt, ast.FunctionDef):
                converted = self._function_to_lambda(stmt)
                if converted:
                    new_body.append(converted)
                    continue

            if isinstance(stmt, ast.Assign):
                converted = self._lambda_to_function(stmt)
                if converted:
                    new_body.append(converted)
                    continue

            new_body.append(self.visit(stmt))

        node.body = new_body
        return node

    def visit_ClassDef(self, node: ast.ClassDef):
        new_body = []
        for stmt in node.body:
            if isinstance(stmt, ast.FunctionDef):
                converted = self._function_to_lambda(stmt)
                if converted:
                    new_body.append(converted)
                    continue

            if isinstance(stmt, ast.Assign):
                converted = self._lambda_to_function(stmt)
                if converted:
                    new_body.append(converted)
                    continue

            new_body.append(self.visit(stmt))

        node.body = new_body
        return node

    def visit_FunctionDef(self, node: ast.FunctionDef):
        node.body = [self.visit(stmt) for stmt in node.body]
        return node

    def get_refactored_code(self, source_code: str) -> str:
        try:
            tree = ast.parse(source_code)
            tree = self.visit(tree)
            ast.fix_missing_locations(tree)
            return ast.unparse(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")
