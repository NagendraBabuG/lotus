import ast
import re


FIXED_DS_MAPPING = {
    "Ed25519Adapter": "MLDSA65Adapter",
    "Ed448Adapter": "MLDSA87Adapter",
}


def get_pqc_ds_ec_curve(curve):
    if curve is None:
        return "MLDSA65Adapter"

    curve = curve.lower()

    if curve in [
        "secp224r1", "secp192r1", "sect233k1",
        "sect163k1", "sect233r1", "sect163r2",
        "secp256r1", "secp256k1", "sect283r1", "sect283k1",
    ]:
        return "MLDSA65Adapter"

    if curve in [
        "secp521r1", "secp384r1", "sect409k1",
        "sect409r1", "sect571k1", "sect571r1",
    ]:
        return "MLDSA87Adapter"

    return "MLDSA87Adapter"


def get_pqc_ds_with_keysize_rsa_or_dsa(key_size):
    if key_size is None:
        return "MLDSA87Adapter"

    if key_size < 3072:
        return "MLDSA44Adapter"
    elif key_size < 7680:
        return "MLDSA65Adapter"

    return "MLDSA87Adapter"


def get_source_key_size(source_file):
    tree = ast.parse(source_file.read_text(encoding="utf-8"))

    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            for keyword in node.keywords:
                if (
                    keyword.arg == "key_size"
                    and isinstance(keyword.value, ast.Constant)
                    and isinstance(keyword.value.value, int)
                ):
                    return keyword.value.value

        if isinstance(node, ast.Assign):
            for target in node.targets:
                if (
                    isinstance(target, ast.Name)
                    and target.id == "key_size"
                    and isinstance(node.value, ast.Constant)
                    and isinstance(node.value.value, int)
                ):
                    return node.value.value

    return None


def get_source_ec_curve(source_file):
    tree = ast.parse(source_file.read_text(encoding="utf-8"))

    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            if node.func.attr.startswith(("SECP", "Brainpool", "SECT")):
                return node.func.attr.lower()

    return None


def get_expected_target(source_name, source_file):
    if source_name in FIXED_DS_MAPPING:
        return FIXED_DS_MAPPING[source_name]

    if source_name in ("RSAAdapter", "DSAAdapter"):
        key_size = get_source_key_size(source_file)
        return get_pqc_ds_with_keysize_rsa_or_dsa(key_size)

    if source_name == "ECAdapter":
        curve = get_source_ec_curve(source_file)
        return get_pqc_ds_ec_curve(curve)

    return None