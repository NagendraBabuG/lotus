import ast


class CryptoTryExceptInjector(ast.NodeTransformer):
    CRYPTO_FUNCTIONS = {"encrypt", "decrypt", "sign", "verify", "hash", "digest", "hmac", "cipher"}
    EXCEPTION_TYPE = "Exception"
    ERROR_MESSAGE = "error"

    def __init__(self):
        self.temp_counter = 0

    def fresh_temp(self):
        name = f"_crypto_tmp_{self.temp_counter}"
        self.temp_counter += 1
        return name

    def is_crypto_call(self, node):
        if isinstance(node.func, ast.Attribute):
            return node.func.attr in self.CRYPTO_FUNCTIONS
        if isinstance(node.func, ast.Name):
            return node.func.id in self.CRYPTO_FUNCTIONS
        return False

    def build_try_except(self, assign):
        handler = ast.ExceptHandler(
            type=ast.Name(id=self.EXCEPTION_TYPE, ctx=ast.Load()),
            name="e", 
            body=[
                ast.Expr(
                    value=ast.Call(
                        func=ast.Name(id="print", ctx=ast.Load()),
                        args=[
                            ast.Constant(value=self.ERROR_MESSAGE),
                            ast.Name(id="e", ctx=ast.Load())
                        ],
                        keywords=[]
                    )
                )
            ]
        )
        try_node = ast.Try(
            body=[assign],
            handlers=[handler],
            orelse=[],
            finalbody=[]
        )
        ast.fix_missing_locations(try_node)
        return try_node

    def replace_crypto_call_in_expr(self, expr):
        if not isinstance(expr, ast.Call) or not self.is_crypto_call(expr):
            return expr, []

        temp = self.fresh_temp()
        assign = ast.Assign(
            targets=[ast.Name(id=temp, ctx=ast.Store())],
            value=expr
        )
        ast.fix_missing_locations(assign)

        try_block = self.build_try_except(assign)
        result = ast.Name(id=temp, ctx=ast.Load())
        ast.fix_missing_locations(result)

        return result, [try_block]

    def visit_Assign(self, node):
        self.generic_visit(node)

        if isinstance(node.value, ast.Call) and self.is_crypto_call(node.value):
            result, extra_stmts = self.replace_crypto_call_in_expr(node.value)
            node.value = result
            return extra_stmts + [node]
        return node

    def visit_Return(self, node):
        self.generic_visit(node)
        if node.value and isinstance(node.value, ast.Call) and self.is_crypto_call(node.value):
            result, extra_stmts = self.replace_crypto_call_in_expr(node.value)
            node.value = result
            return extra_stmts + [node]
        return node

    def visit_Expr(self, node):
        self.generic_visit(node)
        if isinstance(node.value, ast.Call) and self.is_crypto_call(node.value):
            result, extra_stmts = self.replace_crypto_call_in_expr(node.value)
            node.value = result
            return extra_stmts + [node]
        return node

    def visit_If(self, node):
        self.generic_visit(node)
        extra_stmts = []

        if isinstance(node.test, ast.Call) and self.is_crypto_call(node.test):
            result, stmts = self.replace_crypto_call_in_expr(node.test)
            node.test = result
            extra_stmts.extend(stmts)

        new_body = []
        for stmt in node.body:
            transformed = self.visit(stmt)
            if isinstance(transformed, list):
                new_body.extend(transformed)
            else:
                new_body.append(transformed)

        new_orelse = []
        for stmt in node.orelse:
            transformed = self.visit(stmt)
            if isinstance(transformed, list):
                new_orelse.extend(transformed)
            else:
                new_orelse.append(transformed)

        result_node = ast.If(test=node.test, body=new_body, orelse=new_orelse)
        ast.fix_missing_locations(result_node)
        return extra_stmts + [result_node]

    def visit_FunctionDef(self, node):
        self.temp_counter = 0
        new_body = []
        for stmt in node.body:
            transformed = self.visit(stmt)
            if isinstance(transformed, list):
                new_body.extend(transformed)
            else:
                new_body.append(transformed)
        node.body = new_body
        return node

    def inject_try_except(self, source_code):
        tree = ast.parse(source_code)
        tree = self.visit(tree)
        ast.fix_missing_locations(tree)
        return ast.unparse(tree)


if __name__ == "__main__":
    src = '''
import encrypter

def safe_encrypt(data):
    return encrypter.encrypt(data)

def process():
    key = encrypter.decrypt(ciphertext)
    sig = encrypter.sign(message)
    if encrypter.verify(sig, message):
        print("OK")
    encrypter.hash(data)

encrypter.encrypt("secret")
'''

    injector = CryptoTryExceptInjector()
    print(injector.inject_try_except(src))