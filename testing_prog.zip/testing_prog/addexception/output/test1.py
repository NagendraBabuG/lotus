def risky():
    try:
        result = 1 / 0
        print('Done')
    except Exception as error:
        print(f'ERROR: {error}')

def divide():
    try:
        result = 1 / 0
    except Exception as exception:
        print(f'ERROR: {exception}')