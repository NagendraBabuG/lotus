import socket
import ssl
import threading
import time
import os
import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from datetime import datetime
import pandas as pd
from sklearn.linear_model import LinearRegression
import numpy as np

# ----------- 🔐 Auto SSL Cert Generation -----------
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa

CERT_FILE = "server.crt"
KEY_FILE = "server.key"

def generate_ssl_cert():
    if os.path.exists(CERT_FILE) and os.path.exists(KEY_FILE):
        return

    print("[🔧] Generating SSL cert and key...")

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, u"US"),
        x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME, u"State"),
        x509.NameAttribute(NameOID.LOCALITY_NAME, u"City"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, u"MyOrg"),
        x509.NameAttribute(NameOID.COMMON_NAME, u"localhost"),
    ])
    cert = x509.CertificateBuilder().subject_name(
        subject
    ).issuer_name(
        subject
    ).public_key(
        key.public_key()
    ).serial_number(
        x509.random_serial_number()
    ).not_valid_before(
        datetime.utcnow()
    ).not_valid_after(
        datetime.utcnow().replace(year=datetime.utcnow().year + 1)
    ).add_extension(
        x509.SubjectAlternativeName([x509.DNSName(u"localhost")]),
        critical=False,
    ).sign(key, hashes.SHA256())

    with open(KEY_FILE, "wb") as f:
        f.write(key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption(),
        ))

    with open(CERT_FILE, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))

# ---------- 🌐 Server Configuration --------------
HOST = '127.0.0.1'
PORT = 65432

client_data = {}
lock = threading.Lock()
log_df = pd.DataFrame(columns=["timestamp", "ip", "bandwidth_kbps", "category"])

x_vals = []
y_vals = []

PORT_CATEGORY = {
    1935: "Streaming",
    3074: "Gaming",
    5004: "Video Call",
    443: "HTTPS",
    80: "Web",
    22: "SSH"
}

def classify_port(port):
    return PORT_CATEGORY.get(port, "Other")

def predict_bandwidth(df):
    if len(df) < 2: return 0
    df['ts'] = df['timestamp'].apply(lambda x: x.timestamp())
    X = df[['ts']]
    y = df['bandwidth_kbps']
    model = LinearRegression().fit(X, y)
    future = pd.DataFrame({'ts': [datetime.now().timestamp() + 60]})
    return model.predict(future)[0]

def handle_client(conn, addr):
    ip = addr[0]
    print(f"[+] Connection from {ip}")

    while True:
        try:
            data = conn.recv(4096)
            if not data: break
            bandwidth_kbps = len(data) * 8 / 1000
            src_port = addr[1]
            category = classify_port(src_port)

            timestamp = datetime.now()

            with lock:
                client_data[ip] = bandwidth_kbps
                global log_df
                log_df = pd.concat([log_df, pd.DataFrame([{
                    "timestamp": timestamp,
                    "ip": ip,
                    "bandwidth_kbps": bandwidth_kbps,
                    "category": category
                }])], ignore_index=True)

                x_vals.append(timestamp.strftime("%H:%M:%S"))
                y_vals.append(bandwidth_kbps)
                if len(x_vals) > 20:
                    x_vals.pop(0)
                    y_vals.pop(0)
        except Exception as e:
            print(f"[!] Error with {ip}: {e}")
            break

    print(f"[-] Connection closed: {ip}")
    conn.close()

def update_gui():
    with lock:
        client_list.delete(0, tk.END)
        for ip, bw in client_data.items():
            client_list.insert(tk.END, f"{ip}: {bw:.2f} kbps")

        ax.clear()
        ax.plot(x_vals, y_vals, color='blue', marker='o')
        ax.set_title("Real-Time Bandwidth Usage")
        ax.set_xlabel("Time")
        ax.set_ylabel("Kbps")
        ax.grid(True)
        fig.autofmt_xdate()
        canvas.draw()

        predicted = predict_bandwidth(log_df[log_df['ip'] == ip]) if ip in client_data else 0
        prediction_label.config(text=f"📈 Predicted next minute usage: {predicted:.2f} kbps")

    root.after(1000, update_gui)

def start_server():
    generate_ssl_cert()

    context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    context.load_cert_chain(certfile=CERT_FILE, keyfile=KEY_FILE)

    bindsock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    bindsock.bind((HOST, PORT))
    bindsock.listen(5)
    print(f"[🔒] Secure server listening on {HOST}:{PORT}")

    while True:
        newsock, addr = bindsock.accept()
        try:
            connstream = context.wrap_socket(newsock, server_side=True)
            threading.Thread(target=handle_client, args=(connstream, addr), daemon=True).start()
        except ssl.SSLError as e:
            print(f"[!] SSL error with {addr}: {e}")
            newsock.close()

# ---------- 🖼️ GUI Setup ------------------
root = tk.Tk()
root.title("🔒 Real-Time Secure Bandwidth Monitor")

main_frame = ttk.Frame(root, padding=10)
main_frame.pack(fill="both", expand=True)

client_list = tk.Listbox(main_frame, height=8, font=("Consolas", 12))
client_list.pack(fill="x", pady=5)

prediction_label = ttk.Label(main_frame, text="📈 Predicted next minute usage: --", font=("Arial", 12))
prediction_label.pack(pady=5)

fig, ax = plt.subplots(figsize=(6, 3))
canvas = FigureCanvasTkAgg(fig, master=main_frame)
canvas.get_tk_widget().pack(fill="both", expand=True)

# ----------- 🔁 Start everything ----------
threading.Thread(target=start_server, daemon=True).start()
update_gui()
root.mainloop()
