import ast
import random
import re

HEX_PATTERN = re.compile(r"0x[0-9A-Fa-f]+")


class AddAssertions(ast.NodeTransformer):
    def visit_FunctionDef(self, node):
        args = node.args.args
        defaults = node.args.defaults
        offset = len(args) - len(defaults)

        params_to_assert = []

        for i, arg in enumerate(args):
            if arg.arg == 'self':
                continue

            default = None
            if i >= offset:
                default = defaults[i - offset]

            if not (isinstance(default, ast.Constant) and default.value is None):
                params_to_assert.append(arg.arg)

        if params_to_assert:
            conds = [
                ast.Compare(
                    left=ast.Name(id=p, ctx=ast.Load()),
                    ops=[ast.NotEq()],
                    comparators=[ast.Constant(None)]
                )
                for p in params_to_assert
            ]
            test = conds[0] if len(conds) == 1 else ast.BoolOp(op=ast.And(), values=conds)
            node.body.insert(0, ast.Assert(test=test))

        return self.generic_visit(node)

    def get_refactored_code(self, source_code):
        hex_literals = HEX_PATTERN.findall(source_code)
        try:
            tree = ast.parse(source_code)
            tree = self.visit(tree)
            result = ast.unparse(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")

        for hx in hex_literals:
            dec = str(int(hx, 16))
            result = result.replace(dec, hx)

        return result

wrapper = AddAssertions()

source = '''
def process(user, config, data=None):
    user = user.strip()
    return user + str(config)

def safe_div(a, b=0):
    result = a / b
    return result

def validate(name, age, email=None):
    name = name.lower()
    pass

def test(x=5):
    print(x)

def login(username, password=None):
    if password is None:
        password = 'guest'
    return username
'''

print(wrapper.get_refactored_code(source))