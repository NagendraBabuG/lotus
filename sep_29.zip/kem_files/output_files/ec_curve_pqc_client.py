from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.asymmetric import mlkem

# Generate a private key for use in the exchange.
server_private_key = mlkem.MLKEM768PrivateKey.generate()
# In a real handshake the peer is a remote client. For this
# example we'll generate another local private key though.
peer_private_key = mlkem.MLKEM768PrivateKey.generate()
shared_key = server_private_key.decapsulate(
    ciphertext
)
# Perform key derivation.
derived_key = HKDF(
    algorithm=hashes.SHA256(),
    length=32,
    salt=None,
    info=b'handshake data',
).derive(shared_key)
same_shared_key = peer_private_key.decapsulate(
    ciphertext
)
# Perform key derivation.
same_derived_key = HKDF(
    algorithm=hashes.SHA256(),
    length=32,
    salt=None,
    info=b'handshake data',
).derive(same_shared_key)
derived_key == same_derived_key