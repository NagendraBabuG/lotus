from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519


class Ed25519Adapter:

    def serialize_public_key(self, public_key):
        return public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )

    def generate_private_key(self):
        return ed25519.Ed25519PrivateKey.generate()

    def get_public_key(self, private_key):
        return private_key.public_key()

    def load_public_key(self, data):
        return ed25519.Ed25519PublicKey.from_public_bytes(data)
