def test3(score):
    grade = 'A' if score >= 90 else 'B' if score >= 80 else 'C'
    return grade