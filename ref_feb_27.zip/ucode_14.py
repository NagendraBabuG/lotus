def Crypto_encrypt(self, data):
    log.info(f"Performing Crypto Package RSA encryption using {self.key_size} bit RSA public key")
    cipher_data = []
    after_iend_data_embedded = []
    self.original_data_len = len(data)
    pub_key = RSA.construct((self.public_key[1], self.public_key[0]))
    cipher = PKCS1_OAEP.new(pub_key)

    for i in range(0, len(data), self.encrypted_chunk_size_in_bytes_substracted2):
        chunk_to_encrypt_hex = bytes(data[i: i + self.encrypted_chunk_size_in_bytes_substracted2])
        cipher_hex = cipher.encrypt(chunk_to_encrypt_hex)

        for i in range(self.encrypted_chunk_size_in_bytes_substracted2):
            cipher_data.append(cipher_hex[i])
        after_iend_data_embedded.append(cipher_hex[-1])
    cipher_data.append(after_iend_data_embedded.pop())
    return cipher_data, after_iend_data_embedded