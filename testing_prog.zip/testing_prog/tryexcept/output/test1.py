def func1(key, msg):
    try:
        signer = pkcs1_15.new(key)
        signature = signer.sign(msg)
    except Exception as e:
        print(f'Exception encountered.{e}')
    return signature

def func2(key):
    msg = b'hello'
    try:
        sign = pcks1_15.new(key).sign(msg)
    except Exception as e:
        print(f'ERROR:{e}')
    return sign

def func3(key, msg):
    try:
        sign = pcks1_15.new(key).sign(msg)
    except Exception as error:
        print(f'Operation failed.{error}')
    return sign
msg = b'hello'
try:
    sign = pcks1_15.new(key).sign(msg)
except Exception as e:
    print(f'ERROR:{e}')

def risky():
    try:
        result = 1 / 0
        print('Done')
    except Exception as error:
        print(f'ERROR: {error}')

def risky():
    result = 1 / 0
    print('Done')