import libcst as cst


class AssignGroupers(cst.CSTTransformer):
    
    def _is_invalid_block(self, node):
        return isinstance(
            node,
            (
                cst.FunctionDef,
                cst.ClassDef,
                cst.If,
                cst.While,
                cst.For,
                cst.Try,
                cst.With,
                cst.AsyncFor,
                cst.AsyncWith,
            ),
        )

    def _is_valid_assign(self, assign: cst.Assign) -> bool:
        for t in assign.targets:
            if not isinstance(
                t.target, (cst.Name, cst.Attribute, cst.Subscript)
            ):
                return False

        return isinstance(assign.value, cst.BaseExpression)

    def _is_simple_assign_line(self, stmt):
        return (
            isinstance(stmt, cst.SimpleStatementLine)
            and len(stmt.body) == 1
            and isinstance(stmt.body[0], cst.Assign)
            and self._is_valid_assign(stmt.body[0])
        )

    
    def _group_statements(self, statements):
        grouped = []
        current_group = []

        for stmt in statements:
            if self._is_simple_assign_line(stmt):
                current_group.append(stmt.body[0])
            else:
                if current_group:
                    grouped.append(
                        cst.SimpleStatementLine(body=current_group)
                    )
                    current_group = []

                grouped.append(stmt)

        if current_group:
            grouped.append(
                cst.SimpleStatementLine(body=current_group)
            )

        return grouped

    
    def leave_Module(
        self, original_node: cst.Module, updated_node: cst.Module
    ) -> cst.Module:
        new_body = self._group_statements(updated_node.body)
        return updated_node.with_changes(body=new_body)

    def leave_FunctionDef(
        self, original_node: cst.FunctionDef, updated_node: cst.FunctionDef
    ) -> cst.FunctionDef:

        if not isinstance(updated_node.body, cst.IndentedBlock):
            return updated_node

        new_body = self._group_statements(updated_node.body.body)

        return updated_node.with_changes(
            body=updated_node.body.with_changes(body=new_body)
        )

    def leave_ClassDef(
        self, original_node: cst.ClassDef, updated_node: cst.ClassDef
    ) -> cst.ClassDef:

        if not isinstance(updated_node.body, cst.IndentedBlock):
            return updated_node

        new_body = self._group_statements(updated_node.body.body)

        return updated_node.with_changes(
            body=updated_node.body.with_changes(body=new_body)
        )

    def get_refactored_code(self, source_code: str) -> str:
        module = cst.parse_module(source_code)
        wrapper = cst.MetadataWrapper(module)
        modified = wrapper.visit(self)
        return modified.code

