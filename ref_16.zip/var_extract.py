import ast
import random
import re

HEX_PATTERN = re.compile(r"0x[0-9A-Fa-f]+")


class CryptoVarExtractor(ast.NodeTransformer):
    def __init__(self):
        self.exp2 = []

    def dup_remover(self, node):
        if isinstance(node, ast.BoolOp):
            for elm in node.values:
                self.exp2.remove(elm)
                if isinstance(elm, ast.BoolOp):
                    self.dup_remover(elm)
        else:
            return
        
    def extract_vars(self, tree):
        for node in ast.walk(tree):
            if isinstance(node, ast.BoolOp):
                for node2 in node.values:
                    self.exp2.append(node2)
            elif isinstance(node, ast.If):
                if isinstance(node.test, ast.Call):
                    self.exp2.append(node.test)
        for e in self.exp2:
            self.dup_remover(e)
        var_map = {}
        var_exp_map = {}
        assign_stmt = []
        for idx, condition in enumerate(self.exp2):
            var_name = f"var{idx}"
            var_exp_map[condition] = var_name
            stmt = ast.Assign(targets=[ast.Name(id=var_name, ctx=ast.Store())], value=condition)
            var_map[var_name] = stmt
            ast.fix_missing_locations(stmt)
            assign_stmt.append(stmt)
        
        for node in ast.walk(tree):
            if isinstance(node, ast.BoolOp):
                for idx, node2 in enumerate(node.values):
                    if node2 in var_exp_map:
                        node.values[idx] = ast.Name(id=var_exp_map[node2], ctx=ast.Load())
                        ast.fix_missing_locations(node.values[idx])
            elif isinstance(node, ast.If):
                if isinstance(node.test, ast.Call) and node.test in self.exp2:
                    node.test = ast.Name(id=var_exp_map[node.test], ctx=ast.Load())
                    ast.fix_missing_locations(node.test)
        map_line = {}
        index = 0

        for node in ast.walk(tree):
            if isinstance(node, ast.Module):
                for element in node.body:
                    index += 1
                    inner_index = 0
                    if isinstance(element, ast.If):
                        if isinstance(element.test, ast.BoolOp):
                            for elm in element.test.values:
                                if elm.id in var_exp_map.values() and var_map[elm.id] not in node.body:
                                    node.body.insert(index+inner_index-1, var_map[elm.id])
                                    inner_index += 1
                                    map_line[index] = elm.id

                        elif isinstance(element.test, ast.Name):
                            if element.test.id in var_exp_map.values() and var_map[element.test.id] not in node.body:
                                inner_index += 1
                                map_line[index] = element.test.id

        return tree
    
    def get_refactored_code(self, source_code):
        hex_literals = HEX_PATTERN.findall(source_code)
        try:
            tree = ast.parse(source_code)
            tree = self.extract_vars(tree)
            ast.fix_missing_locations(tree)
            result = ast.unparse(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")

        for hx in hex_literals:
            dec = str(int(hx, 16))
            result = result.replace(dec, hx)

        return result

