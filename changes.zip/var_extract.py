import ast
import re

HEX_PATTERN = re.compile(r"\b0x[0-9A-Fa-f]+\b")

class CryptoVarExtractor(ast.NodeTransformer):
    def __init__(self):
        self.condition_to_var = {}
        self.assign_stmts = []
        self.next_var_id = 0

    def _make_var_name(self):
        name = f"cond_{self.next_var_id}"
        self.next_var_id += 1
        return name

    def extract_vars(self, tree):
        candidates = []

        for node in ast.walk(tree):
            if isinstance(node, ast.Compare):
                if not (isinstance(node.left, ast.Name) and
                        all(isinstance(op, (ast.Eq, ast.NotEq, ast.Lt, ast.Gt, ast.LtE, ast.GtE)) for op in node.ops) and
                        all(isinstance(c, (ast.Name, ast.Constant)) for c in node.comparators)):
                    candidates.append(node)
                else:
                    if self._is_in_complex_boolop(node):
                        candidates.append(node)

            elif isinstance(node, ast.Call) and isinstance(node._parent, ast.If):  
                candidates.append(node)

        for node in ast.walk(tree):
            if isinstance(node, ast.Constant) and isinstance(node.value, int):
                if node.value > 10000 or (node.value < 0 and node.value < -10000):
                    if self._has_condition_parent(node):
                        candidates.append(node)

        seen = set()
        for node in candidates:
            if id(node) not in seen:
                seen.add(id(node))
                var_name = self._make_var_name()
                self.condition_to_var[id(node)] = var_name

                assign = ast.Assign(
                    targets=[ast.Name(id=var_name, ctx=ast.Store())],
                    value=node
                )
                ast.fix_missing_locations(assign)
                self.assign_stmts.append(assign)

        for node in ast.walk(tree):
            for child in ast.iter_child_nodes(node):
                child._parent = node

        class Replacer(ast.NodeTransformer):
            def __init__(self, mapping):
                self.mapping = mapping

            def visit_BoolOp(self, node):
                node = self.generic_visit(node)
                new_values = []
                for val in node.values:
                    if id(val) in self.mapping:
                        new_values.append(ast.Name(id=self.mapping[id(val)], ctx=ast.Load()))
                    else:
                        new_values.append(val)
                node.values = new_values
                return node

            def visit_If(self, node):
                node = self.generic_visit(node)
                if id(node.test) in self.mapping:
                    node.test = ast.Name(id=self.mapping[id(node.test)], ctx=ast.Load())
                return node

        tree = Replacer(self.condition_to_var).visit(tree)

        if isinstance(tree, ast.Module) and self.assign_stmts:
            tree.body = self.assign_stmts + tree.body

        ast.fix_missing_locations(tree)
        return tree

    def _is_in_complex_boolop(self, node):
        parent = getattr(node, '_parent', None)
        while parent:
            if isinstance(parent, ast.BoolOp) and len(parent.values) > 2:
                return True
            parent = getattr(parent, '_parent', None)
        return False

    def _has_condition_parent(self, node):
        parent = getattr(node, '_parent', None)
        while parent:
            if isinstance(parent, (ast.BoolOp, ast.If, ast.Compare)):
                return True
            parent = getattr(parent, '_parent', None)
        return False

    def get_refactored_code(self, source_code):
        hex_matches = list(HEX_PATTERN.finditer(source_code))
        hex_map = {}
        for m in hex_matches:
            hx = m.group()
            dec = str(int(hx, 16))
            hex_map[dec] = hx

        try:
            tree = ast.parse(source_code)

            for node in ast.walk(tree):
                for child in ast.iter_child_nodes(node):
                    child._parent = node

            tree = self.extract_vars(tree)
            result = ast.unparse(tree)
        except Exception as e:
            raise ValueError(f"Parse/transform failed: {e}")

        for dec, hx in hex_map.items():
            result = result.replace(dec, hx)

        return result
