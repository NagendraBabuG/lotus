def access_dict():
    try:
        d = {}
        return d['missing']
    except Exception as error:
        print(f'Exception encountered: {error}')