import ast
import re

HEX_PATTERN = re.compile(r"\b0x[0-9A-Fa-f]+\b")

class CryptoVarExtractor(ast.NodeTransformer):
    def __init__(self):
        self.next_var_id = 0
        self.scope_stack = []

    def _push(self):
        self.scope_stack.append({"mapping": {}, "assigns": [], "delayed": []})

    def _pop(self):
        return self.scope_stack.pop()

    def _current(self):
        return self.scope_stack[-1]

    def _var(self):
        n = f"cond_{self.next_var_id}"
        self.next_var_id += 1
        return n

    def _should_extract(self, node):
        if isinstance(node, (ast.Name, ast.Constant)):
            return False
        if isinstance(node, ast.Compare):
            if isinstance(node.left, ast.Name):
                if all(isinstance(c, (ast.Name, ast.Constant)) for c in node.comparators):
                    if all(isinstance(op, (ast.Eq, ast.NotEq)) for op in node.ops):
                        return False  
            return True
        if isinstance(node, ast.BoolOp):
            return len(node.values) >= 2  
        if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.BitXor, ast.BitAnd, ast.BitOr)):
            return True
        if isinstance(node, ast.Call):
            return True
        return True

    def _extract(self, node):
        scope = self._current()
        nid = id(node)

        if nid in scope["mapping"]:
            return ast.Name(id=scope["mapping"][nid], ctx=ast.Load())

        if not self._should_extract(node):
            return node

        var_name = self._var()
        scope["mapping"][nid] = var_name

        assign = ast.Assign(
            targets=[ast.Name(id=var_name, ctx=ast.Store())],
            value=node
        )
        ast.fix_missing_locations(assign)
        scope["delayed"].append(assign)

        return ast.Name(id=var_name, ctx=ast.Load())

    def visit_Module(self, node):
        self._push()
        self.generic_visit(node)
        scope = self._pop()

        inserts = [n for n in node.body if isinstance(n, (ast.Import, ast.ImportFrom))]
        rest = [n for n in node.body if not isinstance(n, (ast.Import, ast.ImportFrom))]

        node.body = inserts + scope["delayed"] + rest
        return node

    def visit_FunctionDef(self, node):
        self._push()
        self.generic_visit(node)
        scope = self._pop()
        if scope["delayed"]:
            node.body = scope["delayed"] + node.body
        return node

    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_If(self, node):
        self.generic_visit(node)
        node.test = self._extract(node.test)
        return node

    def visit_While(self, node):
        self.generic_visit(node)
        node.test = self._extract(node.test)
        return node

    def visit_BoolOp(self, node):
        self.generic_visit(node)
        return self._extract(node)

    def visit_Compare(self, node):
        self.generic_visit(node)
        return self._extract(node)

    def get_refactored_code(self, source_code):
        hex_map = {}
        for m in HEX_PATTERN.finditer(source_code):
            hx = m.group()
            dec = str(int(hx, 16))
            hex_map[dec] = hx

        tree = ast.parse(source_code)
        tree = self.visit(tree)
        ast.fix_missing_locations(tree)
        code = ast.unparse(tree)

        for dec, hx in hex_map.items():
            code = code.replace(dec, hx)
        return code
    