from cryptography.hazmat.primitives.asymmetric.x448 import X448PrivateKey

class X448Adapter:

    def generate_private_key(self):
        return X448PrivateKey.generate()

    def exchange(self, private_key, peer_public_key):
        return private_key.exchange(peer_public_key)

