def sign(mergedParam):
    signer = pkcs1_15.new(mergedParam.key)
    sign = signer.sign(mergedParam.msg)
    return sign

def verify(mergedParam, sign):
    verifier = pkcs1_15.new(mergedParam.key)
    valid = verifier.verify(mergedParam.msg, sign)
    return valid
key = '12'
msg = 'hlo'
mergedParam = type('MergedParam', (), {})()
mergedParam.msg = msg
mergedParam.key = key