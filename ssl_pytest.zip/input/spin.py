import sys
_orig_flags = None
_flags = None

try:
    _orig_flags = sys.getdlopenflags()
except AttributeError:
    # Platforms without dlopen flags (e.g., Windows)
    from OpenSSL import crypto
else:
    try:
        try:
            import DLFCN
            _flags = DLFCN.RTLD_NOW | DLFCN.RTLD_GLOBAL
        except ImportError:
            try:
                import dl
                _flags = dl.RTLD_NOW | dl.RTLD_GLOBAL
            except ImportError:
                try:
                    import ctypes
                    _flags = 2 | ctypes.RTLD_GLOBAL
                except ImportError:
                    _flags = 2
    finally:
        if _flags is not None:
            try:
                sys.setdlopenflags(_flags)
            except Exception:
                pass

try:
    from OpenSSL import crypto
finally:
    if _orig_flags is not None:
        try:
            sys.setdlopenflags(_orig_flags)
        except Exception:
            pass

from OpenSSL import rand, SSL
from OpenSSL.version import __version__

__all__ = [
    'rand',
    'crypto',
    'SSL',
    '__version__',
]