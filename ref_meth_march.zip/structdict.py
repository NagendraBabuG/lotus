import ast
import copy

class ParentAssigner(ast.NodeVisitor):
    def __init__(self):
        self.parent_map = {}

    def visit(self, node):
        for child in ast.iter_child_nodes(node):
            self.parent_map[child] = node
            self.visit(child)

class StructRef:
    def __init__(self):
        self.node_to_var = {}
        self.idx = 0
        self.parent_map = {}
        self.injections = {} 

    def _get_statement_info(self, node):
        curr = node
        while curr in self.parent_map:
            parent = self.parent_map[curr]
            for field in ['body', 'orelse', 'finalbody']:
                child_list = getattr(parent, field, None)
                if isinstance(child_list, list) and curr in child_list:
                    return child_list, curr
            curr = parent
        return None, None

    def _identify_literals(self, node):
        for child in ast.iter_child_nodes(node):
            self._identify_literals(child)

        if isinstance(node, (ast.Dict, ast.List)):
            parent = self.parent_map.get(node)
            if isinstance(parent, ast.Assign) and len(parent.targets) == 1 and isinstance(parent.targets[0], ast.Name):
                return

            var_name = f"dict{self.idx}" if isinstance(node, ast.Dict) else f"list{self.idx}"
            self.node_to_var[id(node)] = var_name
            self.idx += 1
            
            body_list, stmt = self._get_statement_info(node)
            if body_list is not None:
                self.injections.setdefault(id(stmt), []).append((var_name, node))

    def _transform_with_mapping(self, node, id_map, skip_root_id=None):
        class Replacer(ast.NodeTransformer):
            def visit_Dict(self, n):
                self.generic_visit(n)
                if id(n) in id_map and id(n) != skip_root_id:
                    return ast.Name(id=id_map[id(n)], ctx=ast.Load())
                return n
            def visit_List(self, n):
                self.generic_visit(n)
                if id(n) in id_map and id(n) != skip_root_id:
                    return ast.Name(id=id_map[id(n)], ctx=ast.Load())
                return n
        return Replacer().visit(node)

    def get_refactored_code(self, code):
        try:
            tree = ast.parse(code)
            self.node_to_var, self.injections, self.idx = {}, {}, 0
            
            pa = ParentAssigner()
            pa.visit(tree)
            self.parent_map = pa.parent_map

            self._identify_literals(tree)

            final_injections = {}
            for stmt_id, items in self.injections.items():
                instr_list = []
                for var_name, original_node in items:
                    memo = {}
                    val_node_copy = copy.deepcopy(original_node, memo)
                    
                    copy_mapping = {}
                    for orig_id, var in self.node_to_var.items():
                        if orig_id in memo:
                            copy_mapping[id(memo[orig_id])] = var
                    
                    transformed_val = self._transform_with_mapping(
                        val_node_copy, 
                        copy_mapping, 
                        skip_root_id=id(val_node_copy)
                    )
                    
                    instr_list.append(ast.Assign(
                        targets=[ast.Name(id=var_name, ctx=ast.Store())],
                        value=transformed_val
                    ))
                final_injections[stmt_id] = instr_list

            tree = self._transform_with_mapping(tree, self.node_to_var)

            for node in ast.walk(tree):
                for field in ['body', 'orelse', 'finalbody']:
                    child_list = getattr(node, field, None)
                    if isinstance(child_list, list):
                        new_list = []
                        for stmt in child_list:
                            if id(stmt) in final_injections:
                                new_list.extend(final_injections[id(stmt)])
                            new_list.append(stmt)
                        setattr(node, field, new_list)

            ast.fix_missing_locations(tree)
            return ast.unparse(tree)
        except Exception as e:
            return f"Error: {e}"
