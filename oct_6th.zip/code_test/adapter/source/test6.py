from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric import utils

class EllipticCurveAdapter:

    def generate_private_key(self):
        return ec.generate_private_key(ec.SECP384R1())

    def sign(self, private_key, digest):
        return private_key.sign(digest, ec.ECDSA(utils.Prehashed(hashes.SHA256())))

    def get_public_key(self, private_key):
        return private_key.public_key()

    def verify(self, public_key, sig, digest):
        return public_key.verify(sig, digest, ec.ECDSA(utils.Prehashed(hashes.SHA256())))

