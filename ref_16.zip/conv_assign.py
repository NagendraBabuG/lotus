import ast
import random
import re

HEX_PATTERN = re.compile(r"0x[0-9A-Fa-f]+")

class AugAssignRefactor(ast.NodeTransformer):
    
    def visit_AugAssign(self, node):
        new_assign = ast.Assign(targets=[node.target], value=ast.BinOp(left=ast.Name(id=node.target.id, ctx=ast.Load()), op=node.op,
                                                                       right=node.value))
        ast.fix_missing_locations(new_assign)
        return new_assign
    
    def visit_Assign(self, node):
        if len(node.targets) == 1 and isinstance(node.value, ast.BinOp) and node.targets[0].id == node.value.left.id:
            new_aug = ast.AugAssign(
                target=node.targets[0],op=node.value.op,
                vlaue=node.value.right
            )
            ast.fix_missing_locations(new_aug)
            return new_aug
        return node
    
    def get_refactored_code(self, source_code):
        hex_literals = HEX_PATTERN.findall(source_code)
        try:
            tree = ast.parse(source_code)
            tree = self.visit(tree)
            result = ast.unparse(tree)
        except SyntaxError as e:
            raise ValueError(f"Syntax error in source code: {e}")

        for hx in hex_literals:
            dec = str(int(hx, 16))
            result = result.replace(dec, hx)

        return result
    