def test2():
    a = 1
    b = 1
    c = 1
    d = 1
    assert a == b
    assert b == c
    assert c == d
    assert a == d
    assert b == d
test2()