import os
import shutil
import itertools
from pathlib import Path
from collections import defaultdict
import numpy as np
import bert_code

from defaut_arg_deep import AddDefaultArgValue
from except_code import ExceptionRefactor
from hardcode_deep import HardcodedValues
from forwhilev2 import ForWhile
from lambda_refactor import LambdaRefactor
from asserts import AddAssertions
from partials_ls import PartialsRefactor
from ternary_ref import TernaryRefactor
from try_crypto import CryptoTryExceptInjector
from conv_assign import AugAssignRefactor
from conv_except_assertion import RaiseRefactor
from multi_sinline_stmts import AssignGroupers
from elif_ren import ElIfConverter
from elseIf import ElseIfConverter
from param_refact_v2 import ParameterRefactor
from var_extract import CryptoVarExtractor
import rem_comments


def read_code(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read()

refactor_classes = {
    "raise_refact": RaiseRefactor(),
    "line_stmts": AssignGroupers(),
    "elif_ref": ElIfConverter(),
    "elseif": ElseIfConverter(),    
    "add_default_arg": AddDefaultArgValue(),
    "hardcoded_values": HardcodedValues(),
    "exception_code": ExceptionRefactor(),
    "var_extract": CryptoVarExtractor(),
    "loops": ForWhile(),
    "lambda_refactor": LambdaRefactor(),
    "assertions": AddAssertions(),
    "partials": PartialsRefactor(),
    "param_refactor": ParameterRefactor(),
    "ternary": TernaryRefactor(),
    "crypto_try": CryptoTryExceptInjector(),
    "conv_assign": AugAssignRefactor()

}

def apply_one_technique(code: str, tech_name: str) -> str:
    refactor = refactor_classes[tech_name]
    return refactor.get_refactored_code(code)


def score_technique_on_program(original_code: str, tech_name: str) -> float:
    variant = apply_one_technique(original_code, tech_name)
    return bert_code.analyze_code_pair(original_code, variant)


def evaluate_all_techniques(source_dir: str = "source"):
    programs = [p for p in Path(source_dir).glob("*.py")]
    if not programs:
        raise ValueError(f"No .py files found in {source_dir}")

    technique_scores = defaultdict(list) 

    print(f"Found {len(programs)} programs. Evaluating {len(refactor_classes)} techniques …")
    for prog_path in programs:
        orig_code = read_code(prog_path)
        for tech in refactor_classes:
            prob = score_technique_on_program(orig_code, tech).semantic_difference_percent
            prob = 100 - prob
            technique_scores[tech].append(prob)

    mean_scores = {tech: np.mean(scores) for tech, scores in technique_scores.items()}
    return mean_scores

def build_pipelines(mean_scores: dict, pipeline_count: int = 4):
    sorted_tech = sorted(mean_scores.items(), key=lambda x: x[1], reverse=True)
    tech_names = [t[0] for t in sorted_tech]

    if len(tech_names) < pipeline_count * 4:
        raise ValueError("Not enough techniques for 4 pipelines with 4 tech each.")

    pipelines = []
    for i in range(pipeline_count):
        start = i * 4
        pipelines.append(tech_names[start:start+4])
    return pipelines


def apply_pipeline(code: str, pipeline: list) -> str:
    for tech in pipeline:
        code = apply_one_technique(code, tech)
    return code

def generate_pipeline_variants(source_dir: str = "source",
                               target_base: str = "target",
                               pipelines: list = None):
    os.makedirs(target_base, exist_ok=True)
    programs = [p for p in Path(source_dir).glob("*.py")]

    for idx, pipe in enumerate(pipelines, start=1):
        pipe_dir = Path(target_base) / f"pipeline_{idx}"
        os.makedirs(pipe_dir, exist_ok=True)
        print(f"\n--- Pipeline {idx} : {pipe} ---")
        for prog_path in programs:
            orig_code = read_code(prog_path)
            new_code = apply_pipeline(orig_code, pipe)

            out_path = pipe_dir / prog_path.name
            out_path.write_text(new_code, encoding="utf-8")
        print(f"  → {len(programs)} files written to {pipe_dir}")


def main():
    mean_scores = evaluate_all_techniques("source")
    print("\n=== Mean CodeBERT Clone-Probability per Technique ===")
    for tech, score in sorted(mean_scores.items(), key=lambda x: x[1], reverse=True):
        print(f"{tech:20} : {score:.4f}")

    pipelines = build_pipelines(mean_scores, pipeline_count=4)
    print("\n=== Generated Pipelines (top-4 each) ===")
    for i, p in enumerate(pipelines, 1):
        print(f"Pipeline {i}: {p}")

    generate_pipeline_variants(pipelines=pipelines)

if __name__ == "__main__":
    main()
