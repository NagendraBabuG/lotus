import base64
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import mldsa



def generate_keypair():
    """Generate an Ed25519 keypair and return (priv_obj, pub_obj, priv_pem, pub_pem)."""
    priv = mldsa.MLDSA65PrivateKey.generate()
    pub = priv.public_key()
    priv_pem = priv.private_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PrivateFormat.Raw,
        encryption_algorithm=serialization.NoEncryption(),
    )
    pub_pem = pub.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    return priv, pub, priv_pem, pub_pem


def pubkey_to_did(pub: mldsa.MLDSA65PublicKey) -> str:
    """Create a simple did:ed25519:<base64url(pub)> identifier for the public key."""
    raw = pub.public_bytes(
        encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
    )
    b64 = base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")
    return f"did:ed25519:{b64}"
