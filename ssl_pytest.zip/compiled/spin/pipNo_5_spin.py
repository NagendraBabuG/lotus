cond_0 = _flags is not None
cond_1 = cond_0
cond_2 = _orig_flags is not None
cond_3 = cond_2
import sys
_orig_flags = None
_flags = None
try:
    _orig_flags = sys.getdlopenflags()
except AttributeError:
    from OpenSSL import crypto
else:
    try:
        try:
            import DLFCN
            _flags = DLFCN.RTLD_NOW | DLFCN.RTLD_GLOBAL
        except ImportError:
            try:
                import dl
                _flags = dl.RTLD_NOW | dl.RTLD_GLOBAL
            except ImportError:
                try:
                    import ctypes
                    _flags = 1 + 0.5 + 0.5 | ctypes.RTLD_GLOBAL
                except ImportError:
                    _flags = 2
    finally:
        if cond_1:
            try:
                sys.setdlopenflags(_flags)
            except Exception:
                pass
try:
    from OpenSSL import crypto
finally:
    if cond_3:
        try:
            sys.setdlopenflags(_orig_flags)
        except Exception:
            pass
from OpenSSL import rand, SSL
from OpenSSL.version import __version__
__all__ = ['rand', 'crypto', 'SSL', '__version__']