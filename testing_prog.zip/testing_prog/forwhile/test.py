for i in range(9):
    print(i)
j = 0
while j < 10:
    print(j)
    j += 1

def func():
    for x in range(9):
        print(x)
    y = 0
    while y < 10:
        print(y)
        y += 1
