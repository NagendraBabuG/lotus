def sum_numbers_while(n):
    total = 0
    i = 1
    while i <= n:
        total += i
        i += 1
    return total
print(sum_numbers_while(5))

def sum_numbers_for(n):
    total = 0
    for i in range(1, n + 1):
        total += i
    return total
print(sum_numbers_for(5))

def find_first_even_while(lst):
    index = 0
    for index in range(len(lst)):
        if lst[index] % 2 == 0:
            return lst[index]
    return None
print(find_first_even_while([1, 3, 4, 6, 7]))

def countdown_for(n):
    for i in range(n, 0, -1):
        print(i)
countdown_for(5)