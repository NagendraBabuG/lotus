from cryptography.hazmat.primitives.asymmetric import mldsa

private_key = mldsa.MLDSA44PrivateKey.generate()