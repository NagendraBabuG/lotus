from __future__ import annotations
import os
import typing as t
from base64 import b64decode, b64encode
from getpass import getuser
from socket import gethostname
from cryptography import __version__ as CRYPTOGRAPHY_VERSION
from cryptography.exceptions import InvalidSignature, UnsupportedAlgorithm
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import dsa, ec, padding, rsa
from cryptography.hazmat.primitives.asymmetric.ed448 import Ed448PrivateKey
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)
from cryptography.hazmat.primitives.asymmetric.mldsa import (
    MLDSA44PrivateKey,
    MLDSA65PrivateKey,
    MLDSA87PrivateKey,
)
from ansible_collections.community.crypto.plugins.module_utils._crypto.cryptography_support import (
    is_potential_certificate_issuer_private_key,
)
from cryptography.hazmat.primitives.asymmetric.types import (
    PublicKeyTypes as AllPublicKeyTypes,
)

class RSAAdapter:

    def generate_private_key(self, size):
        return rsa.generate_private_key(public_exponent=65537, key_size=size)

class DSAAdapter:

    def generate_private_key(self, size):
        return dsa.generate_private_key(key_size=size)

class Ed25519Adapter:

    def generate_private_key(self):
        return Ed25519PrivateKey.generate()

class ECAdapter:

    def generate_private_key(self, _ALGORITHM_PARAMETERS):
        return ec.generate_private_key(_ALGORITHM_PARAMETERS)

    def get_public_key(self, privatekey):
        return privatekey.public_key()

